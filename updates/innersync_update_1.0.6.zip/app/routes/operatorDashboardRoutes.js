const express = require("express");
const pool = require("../database/db");

const router = express.Router();

function requireLogin(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Session expired" });
    }
    next();
}

function rangeConfig(value) {
    const range = ["today", "week", "month"].includes(value) ? value : "today";
    if (range === "week") {
        return {
            range,
            startSql: "CURRENT_DATE - INTERVAL '6 days'",
            seriesStartSql: "CURRENT_DATE - INTERVAL '6 days'",
            seriesStepSql: "INTERVAL '1 day'",
            bucketSql: "date_trunc('day', event_time)",
            labelSql: "TO_CHAR(s.bucket, 'DD Mon')",
            periodLabel: "7 hari terakhir"
        };
    }
    if (range === "month") {
        return {
            range,
            startSql: "CURRENT_DATE - INTERVAL '29 days'",
            seriesStartSql: "CURRENT_DATE - INTERVAL '29 days'",
            seriesStepSql: "INTERVAL '1 day'",
            bucketSql: "date_trunc('day', event_time)",
            labelSql: "TO_CHAR(s.bucket, 'DD Mon')",
            periodLabel: "30 hari terakhir"
        };
    }
    return {
        range,
        startSql: "CURRENT_DATE",
        seriesStartSql: "CURRENT_DATE",
        seriesStepSql: "INTERVAL '1 hour'",
        bucketSql: "date_trunc('hour', event_time)",
        labelSql: "TO_CHAR(s.bucket, 'HH24:00')",
        periodLabel: "hari ini"
    };
}

function fullName(row) {
    return [row.first_name, row.second_name].filter(Boolean).join(" ").trim() || "-";
}

function numberValue(value) {
    return Number(value || 0);
}

let dashboardSupportSchemaReady = false;
async function ensureDashboardSupportSchema() {
    if (dashboardSupportSchemaReady) return;
    await pool.query(`
        CREATE TABLE IF NOT EXISTS delivery_monitor_hidden (
            hidden_id SERIAL PRIMARY KEY,
            source_type VARCHAR(40) NOT NULL,
            source_id TEXT NOT NULL,
            hidden_by VARCHAR(120),
            hidden_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(source_type, source_id)
        )
    `);
    dashboardSupportSchemaReady = true;
}

router.get("/api/operator-dashboard", requireLogin, async (req, res) => {
    const config = rangeConfig(String(req.query.range || "today").toLowerCase());

    try {
        await ensureDashboardSupportSchema();
        const [
            summaryResult,
            trafficResult,
            occupancyResult,
            activityResult,
            approvalResult,
            alertResult,
            communicationResult,
            integrationResult
        ] = await Promise.all([
            pool.query(`
                SELECT
                    COUNT(*) FILTER (
                        WHERE v.check_in_time IS NOT NULL
                          AND v.check_out_time IS NULL
                    )::int AS active_visitors,
                    COUNT(*) FILTER (
                        WHERE v.check_in_time >= ${config.startSql}
                    )::int AS period_checkins,
                    COUNT(*) FILTER (
                        WHERE v.check_out_time >= ${config.startSql}
                    )::int AS period_checkouts,
                    COUNT(*) FILTER (
                        WHERE v.check_in_time IS NOT NULL
                          AND v.check_out_time IS NULL
                          AND v.expiry_date < NOW()
                    )::int AS overdue_visitors,
                    (
                        SELECT COUNT(*)::int
                        FROM visitor_invitations i
                        WHERE i.status IN ('PENDING', 'ACCESS_PENDING', 'ACCESS_READY', 'WAITING_ARRIVAL')
                          AND i.checked_in_visitor_id IS NULL
                          AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                    ) AS waiting_arrival,
                    (
                        SELECT COUNT(*)::int
                        FROM visitor_invitations i
                        WHERE i.status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
                    ) AS waiting_approval,
                    (
                        SELECT COUNT(*)::int
                        FROM visitor_invitations i
                        WHERE i.status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
                          AND i.approval_timeout_at BETWEEN NOW() AND NOW() + INTERVAL '10 minutes'
                    ) AS approval_near_timeout
                FROM visitor_registration v
            `),
            pool.query(`
                WITH slots AS (
                    SELECT generate_series(
                        ${config.seriesStartSql},
                        ${config.range === "today" ? "CURRENT_DATE + INTERVAL '23 hours'" : "CURRENT_DATE"},
                        ${config.seriesStepSql}
                    ) AS bucket
                ), events AS (
                    SELECT check_in_time AS event_time, 'CHECK_IN' AS event_type
                    FROM visitor_registration
                    WHERE check_in_time >= ${config.startSql}
                    UNION ALL
                    SELECT check_out_time AS event_time, 'CHECK_OUT' AS event_type
                    FROM visitor_registration
                    WHERE check_out_time >= ${config.startSql}
                ), totals AS (
                    SELECT ${config.bucketSql} AS bucket,
                           COUNT(*) FILTER (WHERE event_type = 'CHECK_IN')::int AS check_in,
                           COUNT(*) FILTER (WHERE event_type = 'CHECK_OUT')::int AS check_out
                    FROM events
                    GROUP BY 1
                )
                SELECT ${config.labelSql} AS label,
                       COALESCE(t.check_in, 0)::int AS check_in,
                       COALESCE(t.check_out, 0)::int AS check_out
                FROM slots s
                LEFT JOIN totals t ON t.bucket = s.bucket
                ORDER BY s.bucket ASC
            `),
            pool.query(`
                SELECT COALESCE(NULLIF(f.floor_name, ''), NULLIF(v.permission_group, ''), 'Belum Diatur') AS area,
                       COUNT(*)::int AS total
                FROM visitor_registration v
                LEFT JOIN permission_groups pg ON pg.group_name = v.permission_group
                LEFT JOIN schindler_floors f ON f.floor_id = pg.floor_id
                WHERE v.check_in_time IS NOT NULL
                  AND v.check_out_time IS NULL
                GROUP BY 1
                ORDER BY total DESC, area ASC
                LIMIT 8
            `),
            pool.query(`
                SELECT *
                FROM (
                    SELECT v.check_in_time AS event_time,
                           v.first_name, v.second_name, v.host, v.permission_group AS area,
                           'CHECK_IN' AS event_type
                    FROM visitor_registration v
                    WHERE v.check_in_time IS NOT NULL
                    UNION ALL
                    SELECT v.check_out_time AS event_time,
                           v.first_name, v.second_name, v.host, v.permission_group AS area,
                           'CHECK_OUT' AS event_type
                    FROM visitor_registration v
                    WHERE v.check_out_time IS NOT NULL
                    UNION ALL
                    SELECT COALESCE(i.host_approved_at, i.bm_approved_at) AS event_time,
                           i.first_name, i.second_name, i.host, i.permission_group AS area,
                           'APPROVED' AS event_type
                    FROM visitor_invitations i
                    WHERE COALESCE(i.host_approved_at, i.bm_approved_at) IS NOT NULL
                      AND i.status <> 'REJECTED'
                    UNION ALL
                    SELECT COALESCE(i.host_rejected_at, i.bm_rejected_at, i.modified_time) AS event_time,
                           i.first_name, i.second_name, i.host, i.permission_group AS area,
                           'REJECTED' AS event_type
                    FROM visitor_invitations i
                    WHERE i.status = 'REJECTED'
                ) activity
                WHERE event_time IS NOT NULL
                ORDER BY event_time DESC
                LIMIT 8
            `),
            pool.query(`
                SELECT
                    COUNT(*) FILTER (
                        WHERE COALESCE(host_approved_at, bm_approved_at) >= ${config.startSql}
                          AND status <> 'REJECTED'
                    )::int AS approved,
                    COUNT(*) FILTER (
                        WHERE status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
                    )::int AS waiting,
                    COUNT(*) FILTER (
                        WHERE status = 'REJECTED'
                          AND COALESCE(host_rejected_at, bm_rejected_at, modified_time) >= ${config.startSql}
                    )::int AS rejected
                FROM visitor_invitations
            `),
            pool.query(`
                SELECT
                    (SELECT COUNT(*)::int FROM visitor_registration
                     WHERE check_in_time IS NOT NULL AND check_out_time IS NULL AND expiry_date < NOW()) AS overdue,
                    (SELECT COUNT(*)::int FROM visitor_invitations
                     WHERE status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
                       AND approval_timeout_at BETWEEN NOW() AND NOW() + INTERVAL '10 minutes') AS near_timeout,
                    (
                        SELECT COUNT(*)::int
                        FROM system_notifications n
                        WHERE n.status = 'FAILED'
                          AND n.channel = ANY(ARRAY['EMAIL_VISITOR','EMAIL_HOST','WHATSAPP','WHATSAPP_HOST','HOST_NOTIFICATION'])
                          AND n.created_time >= NOW() - INTERVAL '24 hours'
                          AND NOT EXISTS (
                              SELECT 1 FROM delivery_monitor_hidden hidden
                              WHERE hidden.source_type = 'NOTIFICATION'
                                AND hidden.source_id = n.notification_id::text
                                AND hidden.hidden_at >= n.created_time
                          )
                          AND NOT (
                              n.event_type = 'ACCESS_QR'
                              AND EXISTS (
                                  SELECT 1 FROM self_registration_access_jobs duplicate_job
                                  WHERE duplicate_job.invitation_id::text = n.detail->>'invitation_id'
                              )
                          )
                    ) + (
                        SELECT COUNT(*)::int
                        FROM self_registration_access_jobs j
                        JOIN visitor_invitations i USING(invitation_id)
                        WHERE j.updated_at >= NOW() - INTERVAL '24 hours'
                          AND j.phase = 'PROVISION'
                          AND i.status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN')
                          AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                          AND (
                              (j.email_status = 'FAILED' AND NOT EXISTS (
                                  SELECT 1 FROM delivery_monitor_hidden hidden
                                  WHERE hidden.source_type = 'QUEUE'
                                    AND hidden.source_id = 'JOB_EMAIL_' || j.invitation_id::text
                                    AND hidden.hidden_at >= j.updated_at
                              ))
                              OR
                              (j.whatsapp_status = 'FAILED' AND NOT EXISTS (
                                  SELECT 1 FROM delivery_monitor_hidden hidden
                                  WHERE hidden.source_type = 'QUEUE'
                                    AND hidden.source_id = 'JOB_WHATSAPP_' || j.invitation_id::text
                                    AND hidden.hidden_at >= j.updated_at
                              ))
                          )
                    ) AS failed_delivery,
                    (SELECT COUNT(*)::int FROM device_sync_logs
                     WHERE status = 'FAILED' AND created_time >= NOW() - INTERVAL '24 hours') AS failed_device_sync
            `),
            pool.query(`
                SELECT
                    EXISTS(
                        SELECT 1 FROM smtp_settings
                        WHERE NULLIF(BTRIM(smtp_host), '') IS NOT NULL
                          AND NULLIF(BTRIM(smtp_user), '') IS NOT NULL
                          AND NULLIF(BTRIM(from_email), '') IS NOT NULL
                    ) AS email_configured,
                    COALESCE((SELECT send_mode FROM whatsapp_settings ORDER BY setting_id LIMIT 1), 'manual') AS whatsapp_mode,
                    EXISTS(
                        SELECT 1 FROM whatsapp_settings
                        WHERE LOWER(COALESCE(send_mode, '')) = 'api'
                          AND NULLIF(BTRIM(access_token), '') IS NOT NULL
                          AND NULLIF(BTRIM(phone_number_id), '') IS NOT NULL
                    ) AS whatsapp_configured,
                    (SELECT COUNT(*)::int
                     FROM self_registration_access_jobs j
                     JOIN visitor_invitations i USING(invitation_id)
                     WHERE j.phase = 'PROVISION'
                       AND i.status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN')
                       AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                       AND j.email_status IN ('PENDING', 'PROCESSING')) AS email_pending,
                    (SELECT COUNT(*)::int
                     FROM self_registration_access_jobs j
                     JOIN visitor_invitations i USING(invitation_id)
                     WHERE j.phase = 'PROVISION'
                       AND i.status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN')
                       AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                       AND j.whatsapp_status IN ('PENDING', 'PROCESSING')) AS whatsapp_pending,
                    (SELECT COUNT(*)::int FROM system_notifications n
                     WHERE n.status = 'FAILED' AND n.channel IN ('EMAIL_VISITOR','EMAIL_HOST')
                       AND n.created_time >= NOW() - INTERVAL '24 hours'
                       AND NOT EXISTS (
                           SELECT 1 FROM delivery_monitor_hidden hidden
                           WHERE hidden.source_type = 'NOTIFICATION'
                             AND hidden.source_id = n.notification_id::text
                             AND hidden.hidden_at >= n.created_time
                       )
                       AND NOT (
                           n.event_type = 'ACCESS_QR'
                           AND EXISTS (
                               SELECT 1 FROM self_registration_access_jobs duplicate_job
                               WHERE duplicate_job.invitation_id::text = n.detail->>'invitation_id'
                           )
                       ))
                    + (SELECT COUNT(*)::int
                       FROM self_registration_access_jobs j
                       JOIN visitor_invitations i USING(invitation_id)
                       WHERE j.phase = 'PROVISION'
                         AND i.status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN')
                         AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                         AND j.email_status = 'FAILED'
                         AND NOT EXISTS (
                             SELECT 1 FROM delivery_monitor_hidden hidden
                             WHERE hidden.source_type = 'QUEUE'
                               AND hidden.source_id = 'JOB_EMAIL_' || j.invitation_id::text
                               AND hidden.hidden_at >= j.updated_at
                         )) AS email_failed,
                    (SELECT COUNT(*)::int FROM system_notifications n
                     WHERE n.status = 'FAILED' AND n.channel IN ('WHATSAPP','WHATSAPP_HOST')
                       AND n.created_time >= NOW() - INTERVAL '24 hours'
                       AND NOT EXISTS (
                           SELECT 1 FROM delivery_monitor_hidden hidden
                           WHERE hidden.source_type = 'NOTIFICATION'
                             AND hidden.source_id = n.notification_id::text
                             AND hidden.hidden_at >= n.created_time
                       )
                       AND NOT (
                           n.event_type = 'ACCESS_QR'
                           AND EXISTS (
                               SELECT 1 FROM self_registration_access_jobs duplicate_job
                               WHERE duplicate_job.invitation_id::text = n.detail->>'invitation_id'
                           )
                       ))
                    + (SELECT COUNT(*)::int
                       FROM self_registration_access_jobs j
                       JOIN visitor_invitations i USING(invitation_id)
                       WHERE j.phase = 'PROVISION'
                         AND i.status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN')
                         AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                         AND j.whatsapp_status = 'FAILED'
                         AND NOT EXISTS (
                             SELECT 1 FROM delivery_monitor_hidden hidden
                             WHERE hidden.source_type = 'QUEUE'
                               AND hidden.source_id = 'JOB_WHATSAPP_' || j.invitation_id::text
                               AND hidden.hidden_at >= j.updated_at
                         )) AS whatsapp_failed
            `),
            pool.query(`
                WITH latest_activity AS (
                    SELECT DISTINCT ON (config_id)
                           config_id, success, duration_ms, created_time, error_message
                    FROM api_activity_logs
                    WHERE config_id IS NOT NULL
                    ORDER BY config_id, created_time DESC, log_id DESC
                )
                SELECT c.config_id, c.config_name, c.provider_type, c.trigger_event,
                       h.status AS health_status, h.duration_ms AS health_duration_ms,
                       h.last_check_time, h.error_message AS health_error,
                       a.success AS last_success, a.duration_ms AS last_duration_ms,
                       a.created_time AS last_activity_time, a.error_message AS last_error
                FROM third_party_api_configs c
                LEFT JOIN api_provider_health_status h ON h.config_id = c.config_id
                LEFT JOIN latest_activity a ON a.config_id = c.config_id
                WHERE c.is_active = TRUE
                ORDER BY c.provider_type, c.execution_order, c.config_id
            `)
        ]);

        const summaryRow = summaryResult.rows[0] || {};
        const alertRow = alertResult.rows[0] || {};
        const attention = numberValue(alertRow.overdue)
            + numberValue(alertRow.near_timeout)
            + numberValue(alertRow.failed_delivery)
            + numberValue(alertRow.failed_device_sync);

        const alerts = [];
        if (numberValue(alertRow.overdue)) alerts.push({ type: "danger", icon: "clock", text: `${alertRow.overdue} visitor melewati expiry` });
        if (numberValue(alertRow.near_timeout)) alerts.push({ type: "warning", icon: "hourglass-half", text: `${alertRow.near_timeout} approval hampir timeout` });
        if (numberValue(alertRow.failed_delivery)) alerts.push({ type: "danger", icon: "paper-plane", text: `${alertRow.failed_delivery} pengiriman gagal dalam 24 jam` });
        if (numberValue(alertRow.failed_device_sync)) alerts.push({ type: "danger", icon: "microchip", text: `${alertRow.failed_device_sync} sinkronisasi device gagal dalam 24 jam` });

        const integrations = new Map();
        for (const row of integrationResult.rows) {
            const key = String(row.provider_type || "CUSTOM").toUpperCase();
            if (!integrations.has(key)) {
                integrations.set(key, {
                    provider: key,
                    config_count: 0,
                    health_states: [],
                    last_activity_time: null,
                    last_success: null,
                    last_duration_ms: null,
                    error: null
                });
            }
            const item = integrations.get(key);
            item.config_count += 1;
            if (row.health_status) item.health_states.push(String(row.health_status).toUpperCase());
            if (row.last_activity_time && (!item.last_activity_time || new Date(row.last_activity_time) > new Date(item.last_activity_time))) {
                item.last_activity_time = row.last_activity_time;
                item.last_success = row.last_success;
                item.last_duration_ms = row.last_duration_ms;
                item.error = row.last_error;
            }
        }

        const integrationHealth = [...integrations.values()].map(item => {
            let status = "CONFIGURED";
            if (item.health_states.includes("OFFLINE") || item.health_states.includes("FAILED")) status = "OFFLINE";
            else if (item.health_states.includes("ONLINE") || item.health_states.includes("CONNECTED")) status = "ONLINE";
            else if (item.last_success === false) status = "LAST_ERROR";
            else if (item.last_success === true) status = "LAST_OK";
            return { ...item, status };
        });

        res.json({
            success: true,
            checked_at: new Date().toISOString(),
            range: config.range,
            period_label: config.periodLabel,
            summary: {
                active: numberValue(summaryRow.active_visitors),
                waiting_arrival: numberValue(summaryRow.waiting_arrival),
                waiting_approval: numberValue(summaryRow.waiting_approval),
                approval_near_timeout: numberValue(summaryRow.approval_near_timeout),
                check_in: numberValue(summaryRow.period_checkins),
                check_out: numberValue(summaryRow.period_checkouts),
                attention
            },
            traffic: trafficResult.rows.map(row => ({
                label: row.label,
                check_in: numberValue(row.check_in),
                check_out: numberValue(row.check_out)
            })),
            occupancy: occupancyResult.rows.map(row => ({ area: row.area, total: numberValue(row.total) })),
            activity: activityResult.rows.map(row => ({
                event_time: row.event_time,
                visitor_name: fullName(row),
                host: row.host || "-",
                area: row.area || "-",
                event_type: row.event_type
            })),
            approvals: {
                approved: numberValue(approvalResult.rows[0]?.approved),
                waiting: numberValue(approvalResult.rows[0]?.waiting),
                rejected: numberValue(approvalResult.rows[0]?.rejected)
            },
            alerts,
            communication: communicationResult.rows[0] || {},
            integrations: integrationHealth
        });
    } catch (error) {
        console.error("OPERATOR DASHBOARD:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/operator-dashboard/details", requireLogin, async (req, res) => {
    const type = String(req.query.type || "").toLowerCase();
    const config = rangeConfig(String(req.query.range || "today").toLowerCase());
    const queries = {
        active: `
            SELECT first_name, second_name, host, permission_group AS area,
                   check_in_time AS event_time, expiry_date AS secondary_time,
                   'ACTIVE' AS status, company_name AS note
            FROM visitor_registration
            WHERE check_in_time IS NOT NULL AND check_out_time IS NULL
            ORDER BY check_in_time DESC
            LIMIT 100
        `,
        waiting_arrival: `
            SELECT first_name, second_name, host, permission_group AS area,
                   start_date AS event_time, expiry_date AS secondary_time,
                   status, company_name AS note
            FROM visitor_invitations
            WHERE status IN ('PENDING', 'ACCESS_PENDING', 'ACCESS_READY', 'WAITING_ARRIVAL')
              AND checked_in_visitor_id IS NULL
              AND (expiry_date IS NULL OR expiry_date >= NOW())
            ORDER BY start_date ASC NULLS LAST, invitation_id DESC
            LIMIT 100
        `,
        waiting_approval: `
            SELECT first_name, second_name, host, permission_group AS area,
                   created_time AS event_time, approval_timeout_at AS secondary_time,
                   status, company_name AS note
            FROM visitor_invitations
            WHERE status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
            ORDER BY approval_timeout_at ASC NULLS LAST, invitation_id DESC
            LIMIT 100
        `,
        check_in: `
            SELECT first_name, second_name, host, permission_group AS area,
                   check_in_time AS event_time, expiry_date AS secondary_time,
                   'CHECK_IN' AS status, company_name AS note
            FROM visitor_registration
            WHERE check_in_time >= ${config.startSql}
            ORDER BY check_in_time DESC
            LIMIT 100
        `,
        check_out: `
            SELECT first_name, second_name, host, permission_group AS area,
                   check_out_time AS event_time, expiry_date AS secondary_time,
                   'CHECK_OUT' AS status, company_name AS note
            FROM visitor_registration
            WHERE check_out_time >= ${config.startSql}
            ORDER BY check_out_time DESC
            LIMIT 100
        `,
        attention: `
            SELECT *
            FROM (
                SELECT v.first_name, v.second_name, v.host, v.permission_group AS area,
                       v.expiry_date AS event_time, NULL::timestamp AS secondary_time,
                       'OVERDUE'::text AS status, 'Visitor melewati masa berlaku akses'::text AS note
                FROM visitor_registration v
                WHERE v.check_in_time IS NOT NULL AND v.check_out_time IS NULL AND v.expiry_date < NOW()

                UNION ALL

                SELECT i.first_name, i.second_name, i.host, i.permission_group AS area,
                       i.approval_timeout_at AS event_time, NULL::timestamp AS secondary_time,
                       'APPROVAL_TIMEOUT'::text AS status, 'Approval akan timeout dalam 10 menit'::text AS note
                FROM visitor_invitations i
                WHERE i.status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
                  AND i.approval_timeout_at BETWEEN NOW() AND NOW() + INTERVAL '10 minutes'

                UNION ALL

                SELECT COALESCE(NULLIF(n.visitor_name, ''), '-') AS first_name, NULL::varchar AS second_name,
                       COALESCE(NULLIF(n.target, ''), '-') AS host, n.channel AS area,
                       n.created_time AS event_time, NULL::timestamp AS secondary_time,
                       'DELIVERY_FAILED'::text AS status,
                       COALESCE(NULLIF(n.message, ''), NULLIF(n.title, ''), 'Pengiriman notifikasi gagal') AS note
                FROM system_notifications n
                WHERE n.status = 'FAILED'
                  AND n.channel = ANY(ARRAY['EMAIL_VISITOR','EMAIL_HOST','WHATSAPP','WHATSAPP_HOST','HOST_NOTIFICATION'])
                  AND n.created_time >= NOW() - INTERVAL '24 hours'
                  AND NOT EXISTS (
                      SELECT 1 FROM delivery_monitor_hidden hidden
                      WHERE hidden.source_type = 'NOTIFICATION'
                        AND hidden.source_id = n.notification_id::text
                        AND hidden.hidden_at >= n.created_time
                  )
                  AND NOT (
                      n.event_type = 'ACCESS_QR'
                      AND EXISTS (
                          SELECT 1 FROM self_registration_access_jobs duplicate_job
                          WHERE duplicate_job.invitation_id::text = n.detail->>'invitation_id'
                      )
                  )

                UNION ALL

                SELECT i.first_name, i.second_name, i.host, i.permission_group AS area,
                       j.updated_at AS event_time, NULL::timestamp AS secondary_time,
                       'DELIVERY_FAILED'::text AS status,
                       CONCAT_WS(' | ',
                           CASE WHEN j.email_status = 'FAILED' THEN CONCAT('Email: ', COALESCE(j.email_error, j.error, 'gagal')) END,
                           CASE WHEN j.whatsapp_status = 'FAILED' THEN CONCAT('WhatsApp: ', COALESCE(j.whatsapp_error, j.error, 'gagal')) END
                       ) AS note
                FROM self_registration_access_jobs j
                JOIN visitor_invitations i USING(invitation_id)
                WHERE j.updated_at >= NOW() - INTERVAL '24 hours'
                  AND j.phase = 'PROVISION'
                  AND i.status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN')
                  AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
                  AND (
                      (j.email_status = 'FAILED' AND NOT EXISTS (
                          SELECT 1 FROM delivery_monitor_hidden hidden
                          WHERE hidden.source_type = 'QUEUE'
                            AND hidden.source_id = 'JOB_EMAIL_' || j.invitation_id::text
                            AND hidden.hidden_at >= j.updated_at
                      ))
                      OR
                      (j.whatsapp_status = 'FAILED' AND NOT EXISTS (
                          SELECT 1 FROM delivery_monitor_hidden hidden
                          WHERE hidden.source_type = 'QUEUE'
                            AND hidden.source_id = 'JOB_WHATSAPP_' || j.invitation_id::text
                            AND hidden.hidden_at >= j.updated_at
                      ))
                  )

                UNION ALL

                SELECT COALESCE(v.first_name, '-') AS first_name, v.second_name,
                       COALESCE(NULLIF(l.device_name, ''), '-') AS host,
                       COALESCE(NULLIF(l.permission_group, ''), '-') AS area,
                       l.created_time AS event_time, NULL::timestamp AS secondary_time,
                       'DEVICE_SYNC_FAILED'::text AS status,
                       COALESCE(NULLIF(l.error_message, ''), 'Sinkronisasi device gagal') AS note
                FROM device_sync_logs l
                LEFT JOIN visitor_registration v ON v.visitor_id = l.visitor_id
                WHERE l.status = 'FAILED' AND l.created_time >= NOW() - INTERVAL '24 hours'
            ) details
            ORDER BY event_time DESC NULLS LAST
            LIMIT 100
        `
    };

    if (!queries[type]) {
        return res.status(400).json({ success: false, message: "Jenis detail dashboard tidak valid." });
    }

    try {
        await ensureDashboardSupportSchema();
        const result = await pool.query(queries[type]);
        res.json({
            success: true,
            type,
            range: config.range,
            period_label: config.periodLabel,
            truncated: result.rows.length >= 100,
            items: result.rows.map(row => ({
                visitor_name: fullName(row),
                host: row.host || "-",
                area: row.area || "-",
                event_time: row.event_time || null,
                secondary_time: row.secondary_time || null,
                status: row.status || "-",
                note: row.note || "-"
            }))
        });
    } catch (error) {
        console.error("OPERATOR DASHBOARD DETAILS:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = router;
