const QRCode = require("qrcode");
const multer = require("multer");
const express = require("express");
const crypto = require("crypto");
const fs = require("node:fs/promises");
const path = require("node:path");
const router = express.Router();
const pool = require("../database/db");
const { createCloudflareQuickTunnelManager } = require("../services/cloudflareQuickTunnel");
const cloudflareQuickTunnel = createCloudflareQuickTunnelManager({
    pool,
    appRoot: path.resolve(__dirname, "..")
});
router.use(["/api/public/self-registration", "/api/public/approval", "/api/public/extension", "/api/public/extension-approval", "/api/invitations"], (req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    const json = res.json.bind(res);
    res.json = body => json({ ...body, server_time: new Date().toISOString() });
    next();
});
const ExcelJS = require("exceljs");
const nodemailer = require("nodemailer");
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const { executeActiveThirdPartyConfigs, hasActiveThirdPartyProvider } = require("./apiIntegrationRoutes");
const {
    ensureDeviceSchema,
    executeDeviceSyncForVisitor,
    getDevicesForPermissionGroup,
    sendToDevice,
    syncPermissionGroupDevices,
    normalizeDeviceIds
} = require("./deviceRoutes");
const { ensureSystemNotificationSchema, createSystemNotification } = require("./notificationService");
const {
    ensureCardFormatSchema,
    getCardFormatSettings,
    normalizeCardFormatSettings,
    formatCardNumber,
    analyzeCardFormats
} = require("../utils/cardFormatMapping");
const {
    DEFAULT_TIME_ZONE,
    DEFAULT_OPERATIONAL_START,
    DEFAULT_OPERATIONAL_END,
    DEFAULT_OPERATIONAL_DAYS,
    normalizeApprovalTime,
    normalizeApprovalTimeZone,
    normalizeApprovalDays,
    computeApprovalWindow
} = require("../utils/approvalSchedule");
const { isRetryableResult } = require("../utils/apiRetry");
const { createSelfRegistrationWorkflow } = require("../services/selfRegistrationWorkflow");
const selfRegistrationWorkflow = createSelfRegistrationWorkflow(pool, {
    isBlacklisted: findActiveIdentityBlacklist,
    notify: createSystemNotification,
    qrValue: async (code, plan) => {
        const settings = await getCardFormatSettings(pool);
        const preview = formatCardNumber(code, settings);
        const qrValue = settings.enabled && settings.apply_to_qr ? preview.formatted : preview.raw;
        return qrValue;
    },
    plan: async invitation => {
        const configs = await isVisitorRegistrationApiMode()
            ? (await pool.query("SELECT config_id,provider_type,trigger_event FROM third_party_api_configs WHERE is_active=TRUE AND trigger_event IN ('CHECKIN','CHECKOUT') ORDER BY execution_order,config_id")).rows : [];
        const addConfigs = configs.filter(row => row.trigger_event === "CHECKIN");
        const devices = await getDevicesForPermissionGroup(invitation.permission_group);
        const stage = (kind, id) => ({ kind, id, state: "PENDING" });
        const settings = await getQrSettings();
        return {
            digits: settings?.digit_length,
            hasDevices: devices.length > 0,
            add: [...addConfigs.map(row => stage("API", row.config_id)), ...devices.map(row => stage("DEVICE", row.device_id))],
            remove: [...configs.filter(row => row.trigger_event === "CHECKOUT").map(row => stage("API", row.config_id)), ...devices.map(row => stage("DEVICE", row.device_id))]
        };
    },
    send: async (stage, visitor, revoke, req) => {
        if (stage.kind === "DEVICE") {
            const device = (await pool.query("SELECT * FROM devices WHERE device_id=$1", [stage.id])).rows[0];
            if (!device) throw new Error("Device target tidak ditemukan.");
            const result = await sendToDevice(device, visitor, revoke ? "CHECKOUT" : "CHECKIN", req);
            return { success: result.status === "SUCCESS", error: result.error_message };
        }
        const config = (await pool.query("SELECT * FROM third_party_api_configs WHERE config_id=$1", [stage.id])).rows[0];
        if (!config || !config.is_active) throw new Error("Konfigurasi API target tidak aktif atau sudah dihapus.");
        if (config.provider_type === "INNERRANGE" && !revoke && !visitor.third_party_user_id) {
            const reusableId = await allocateThirdPartyUserSlot(visitor.visitor_id, req);
            if (reusableId) {
                visitor.third_party_user_id = reusableId;
                await pool.query("UPDATE visitor_registration SET third_party_user_id=$2 WHERE visitor_id=$1", [visitor.visitor_id, reusableId]);
            }
        }
        if (visitor.third_party_user_id && !revoke) {
            visitor.innerrange_user_id = visitor.third_party_user_id;
            visitor.reuse_third_party_user_id = true;
        }
        const results = await executeActiveThirdPartyConfigs(req, revoke ? "CHECKOUT" : "CHECKIN", visitor, { configId: stage.id, backgroundRetry: false });
        const result = results[0];
        if (!result || result.skipped) throw new Error(result?.error || "Target API tidak dijalankan.");
        if (!revoke && result.success && result.reference_id && config.provider_type === "INNERRANGE") {
            await pool.query("UPDATE visitor_registration SET third_party_user_id=$2 WHERE visitor_id=$1", [visitor.visitor_id,result.reference_id]);
            await upsertThirdPartyUserSlot(result.reference_id, visitor.visitor_id, "IN_USE");
        }
        return result;
    },
    confirm: async (stage, visitor, revoke, req, job) => {
        if (stage.kind !== "API") return false;
        const config = (await pool.query(
            "SELECT provider_type FROM third_party_api_configs WHERE config_id=$1",
            [stage.id]
        )).rows[0];
        if (String(config?.provider_type || "").toUpperCase() !== "INNERRANGE") return false;
        return confirmInnerrangeAccessState(req, visitor, revoke, job?.qr_value);
    },
    release: async visitorId => {
        const visitor = (await pool.query("SELECT third_party_user_id FROM visitor_registration WHERE visitor_id=$1", [visitorId])).rows[0];
        if (visitor?.third_party_user_id) await releaseThirdPartyUserSlot(visitor.third_party_user_id, visitorId);
    },
    prepareMembers: prepareSelfRegistrationGroupMembers,
    markMembersCheckedIn: markSelfRegistrationGroupMembersCheckedIn,
    removeMembersAccess: removeSelfRegistrationGroupMembersAccess,
    notifyCheckin: notifySelfRegistrationHostCheckin,
    email: async (invitation, qrValue) => {
        const qrSettings = await getQrSettings();
        if (qrSettings?.auto_email !== true) return { skipped: true, reason: "Auto email QR disabled" };
        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const { subject, body } = await buildVisitorQrEmailContent(settings, qrSettings, invitation, qrValue);
        const result = await transporter.sendMail({
            from: `"${settings.from_name || "Innersync"}" <${settings.from_email || settings.smtp_user}>`,
            to: invitation.email_address,
            subject,
            text: body,
            attachments: [{ filename: "Visitor-Access-QR.png", content: await QRCode.toBuffer(qrValue, { width: 480, margin: 2 }), contentType: "image/png" }]
        });
        if (!result.accepted?.length) throw new Error("Server email tidak menerima penerima visitor.");
        return { success: true };
    },
    whatsapp: async (invitation, qrValue) => {
        return sendVisitorAccessQrWhatsapp(
            { session: { user: { username: "SELF_REGISTRATION", full_name: "Self Registration" } }, ip: "127.0.0.1" },
            invitation,
            qrValue
        );
    }
});
let activePort = null;
let lastCard = "";
let schemaReady = false;
let autoCheckoutSchedulerStarted = false;
let autoCheckoutRunning = false;
let expiryCheckoutRunning = false;
let visitorExtensionSchedulerRunning = false;

function parseLooseBoolean(value) {
    return ["true", "1", "yes", "on"].includes(String(value || "").trim().toLowerCase());
}

// Tambahkan di baris paling atas visitorRoutes.js
console.log("Visitor Routes loaded successfully!");

async function ensureVisitorSchema() {
    if (schemaReady) return;

    await ensureSystemNotificationSchema();
    await ensureCardFormatSchema(pool);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS host VARCHAR(150)
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS third_party_user_id VARCHAR(100)
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS schindler_person_id VARCHAR(100)
    `);

    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS watchlist_status VARCHAR(20)");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS watchlist_entry_id INTEGER");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS watchlist_note TEXT");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS source_invitation_id INTEGER");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS group_booking_code VARCHAR(40)");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS group_member_id INTEGER");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS group_leader BOOLEAN NOT NULL DEFAULT FALSE");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_watchlist_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            blacklist_mode VARCHAR(30) NOT NULL DEFAULT 'WARNING_ONLY',
            notify_security BOOLEAN NOT NULL DEFAULT TRUE,
            updated_by VARCHAR(100),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        INSERT INTO visitor_watchlist_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_watchlist (
            watchlist_id SERIAL PRIMARY KEY,
            list_type VARCHAR(20) NOT NULL,
            visitor_name VARCHAR(200),
            identity_number VARCHAR(120),
            phone_number VARCHAR(80),
            email_address VARCHAR(255),
            company_name VARCHAR(180),
            reason TEXT,
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS list_type VARCHAR(20) NOT NULL DEFAULT 'BLACKLIST'");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS visitor_name VARCHAR(200)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS identity_number VARCHAR(120)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS phone_number VARCHAR(80)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS company_name VARCHAR(180)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS reason TEXT");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS start_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS expiry_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_watchlist_identity ON visitor_watchlist (identity_number)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_watchlist_type_active ON visitor_watchlist (list_type, is_active)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS third_party_user_slots (
            slot_id SERIAL PRIMARY KEY,
            provider VARCHAR(50) NOT NULL DEFAULT 'innerrange',
            third_party_user_id VARCHAR(100) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
            current_visitor_id INTEGER,
            last_visitor_id INTEGER,
            last_assigned_time TIMESTAMP,
            last_released_time TIMESTAMP,
            created_time TIMESTAMP DEFAULT NOW(),
            modified_time TIMESTAMP,
            UNIQUE(provider, third_party_user_id)
        )
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS created_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW(),
        ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS permission_groups (
            group_id SERIAL PRIMARY KEY,
            group_name VARCHAR(100) UNIQUE NOT NULL,
            integration_id VARCHAR(80),
            floor_id INTEGER,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        ALTER TABLE permission_groups
        ADD COLUMN IF NOT EXISTS integration_id VARCHAR(80)
    `);

    await pool.query(`
        ALTER TABLE permission_groups
        ADD COLUMN IF NOT EXISTS floor_id INTEGER
    `);

    await ensureDeviceSchema();

    await pool.query(`
        CREATE TABLE IF NOT EXISTS schindler_floors (
            floor_id SERIAL PRIMARY KEY,
            floor_name VARCHAR(120) UNIQUE NOT NULL,
            destination_code VARCHAR(40) NOT NULL,
            return_code VARCHAR(40) NOT NULL DEFAULT '1',
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW(),
            modified_at TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_hosts (
            host_id SERIAL PRIMARY KEY,
            host_name VARCHAR(150) UNIQUE NOT NULL,
            host_email VARCHAR(255),
            host_whatsapp VARCHAR(80),
            location VARCHAR(150),
            note TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS host_email VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS host_whatsapp VARCHAR(80)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS location VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS note TEXT");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS modified_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS approval_schedule_override BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS approval_operational_start VARCHAR(5)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS approval_operational_end VARCHAR(5)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS approval_operational_days VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5'");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS approval_national_holidays_closed BOOLEAN");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS approval_collective_leave_closed BOOLEAN");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS host_notification_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            email_subject TEXT DEFAULT 'Visitor Check-In - {{visitor_name}}',
            email_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS email_subject TEXT DEFAULT 'Visitor Check-In - {{visitor_name}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS email_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS whatsapp_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS whatsapp_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO host_notification_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_invitations (
            invitation_id SERIAL PRIMARY KEY,
            booking_code VARCHAR(40) UNIQUE NOT NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
            first_name VARCHAR(100) NOT NULL,
            second_name VARCHAR(100),
            identity_number VARCHAR(120),
            identity_type VARCHAR(80),
            company_name VARCHAR(150),
            email_address VARCHAR(255),
            phone_number VARCHAR(50),
            visitor_photo VARCHAR(255),
            identity_photo VARCHAR(255),
            host VARCHAR(150),
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            permission_group VARCHAR(100),
            purpose_note TEXT,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP,
            sent_email_time TIMESTAMP,
            sent_whatsapp_time TIMESTAMP,
            checked_in_visitor_id INTEGER,
            checked_in_time TIMESTAMP,
            cancelled_time TIMESTAMP,
            cancel_reason TEXT
        )
    `);

    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS booking_code VARCHAR(40)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS status VARCHAR(40) NOT NULL DEFAULT 'PENDING'");
    await pool.query(`
        DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema = current_schema()
                  AND table_name = 'visitor_invitations'
                  AND column_name = 'status'
                  AND character_maximum_length < 40
            ) THEN
                ALTER TABLE visitor_invitations ALTER COLUMN status TYPE VARCHAR(40);
            END IF;
        END $$
    `);
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS first_name VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS second_name VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS identity_number VARCHAR(120)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS identity_type VARCHAR(80)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS company_name VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS phone_number VARCHAR(50)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS visitor_photo VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS identity_photo VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS start_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS expiry_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS permission_group VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS purpose_note TEXT");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS sent_email_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS sent_whatsapp_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS checked_in_visitor_id INTEGER");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS checked_in_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS cancelled_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS cancel_reason TEXT");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_mode VARCHAR(30)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS bm_approval_status VARCHAR(20) NOT NULL DEFAULT 'NOT_REQUIRED'");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS bm_approved_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS bm_approved_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS bm_rejected_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS bm_rejected_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS bm_reject_reason TEXT");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host_approval_status VARCHAR(20) NOT NULL DEFAULT 'NOT_REQUIRED'");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host_approved_by VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host_approved_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host_rejected_by VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host_rejected_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host_reject_reason TEXT");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_starts_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_timeout_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_operational_start VARCHAR(5)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_operational_end VARCHAR(5)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_operational_days VARCHAR(20)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_holiday_dates JSONB NOT NULL DEFAULT '{\"closed\":[],\"open\":[]}'::jsonb");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_timeout_minutes INTEGER");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS approval_timezone VARCHAR(60)");
    await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS visitor_invitations_booking_code_uq ON visitor_invitations (booking_code)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS self_registration_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            approval_mode VARCHAR(30) NOT NULL DEFAULT 'NO_APPROVAL',
            bm_timeout_minutes INTEGER NOT NULL DEFAULT 60,
            host_timeout_minutes INTEGER NOT NULL DEFAULT 60,
            approval_timezone VARCHAR(60) NOT NULL DEFAULT 'Asia/Jakarta',
            bm_operational_start VARCHAR(5) NOT NULL DEFAULT '08:00',
            bm_operational_end VARCHAR(5) NOT NULL DEFAULT '17:00',
            default_host_operational_start VARCHAR(5) NOT NULL DEFAULT '08:00',
            default_host_operational_end VARCHAR(5) NOT NULL DEFAULT '17:00',
            bm_operational_days VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
            default_host_operational_days VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
            national_holidays_closed BOOLEAN NOT NULL DEFAULT TRUE,
            collective_leave_closed BOOLEAN NOT NULL DEFAULT TRUE,
            host_email_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            host_whatsapp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            group_registration_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            group_max_members INTEGER NOT NULL DEFAULT 10,
            group_qr_mode VARCHAR(20) NOT NULL DEFAULT 'PER_PERSON',
            member_identity_photo_required BOOLEAN NOT NULL DEFAULT TRUE,
            member_face_photo_required BOOLEAN NOT NULL DEFAULT TRUE,
            checkin_qr_token VARCHAR(120),
            checkin_qr_title VARCHAR(150) NOT NULL DEFAULT 'Visitor Location Check-in',
            updated_by VARCHAR(100),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        ALTER TABLE self_registration_settings
        ADD COLUMN IF NOT EXISTS approval_mode VARCHAR(30) NOT NULL DEFAULT 'NO_APPROVAL',
        ADD COLUMN IF NOT EXISTS bm_timeout_minutes INTEGER NOT NULL DEFAULT 60,
        ADD COLUMN IF NOT EXISTS host_timeout_minutes INTEGER NOT NULL DEFAULT 60,
        ADD COLUMN IF NOT EXISTS approval_timezone VARCHAR(60) NOT NULL DEFAULT 'Asia/Jakarta',
        ADD COLUMN IF NOT EXISTS bm_operational_start VARCHAR(5) NOT NULL DEFAULT '08:00',
        ADD COLUMN IF NOT EXISTS bm_operational_end VARCHAR(5) NOT NULL DEFAULT '17:00',
        ADD COLUMN IF NOT EXISTS default_host_operational_start VARCHAR(5) NOT NULL DEFAULT '08:00',
        ADD COLUMN IF NOT EXISTS default_host_operational_end VARCHAR(5) NOT NULL DEFAULT '17:00',
        ADD COLUMN IF NOT EXISTS bm_operational_days VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
        ADD COLUMN IF NOT EXISTS default_host_operational_days VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
        ADD COLUMN IF NOT EXISTS national_holidays_closed BOOLEAN NOT NULL DEFAULT TRUE,
        ADD COLUMN IF NOT EXISTS collective_leave_closed BOOLEAN NOT NULL DEFAULT TRUE,
        ADD COLUMN IF NOT EXISTS host_email_enabled BOOLEAN NOT NULL DEFAULT TRUE,
        ADD COLUMN IF NOT EXISTS host_whatsapp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS group_registration_enabled BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS group_max_members INTEGER NOT NULL DEFAULT 10,
        ADD COLUMN IF NOT EXISTS group_qr_mode VARCHAR(20) NOT NULL DEFAULT 'PER_PERSON',
        ADD COLUMN IF NOT EXISTS member_identity_photo_required BOOLEAN NOT NULL DEFAULT TRUE,
        ADD COLUMN IF NOT EXISTS member_face_photo_required BOOLEAN NOT NULL DEFAULT TRUE,
        ADD COLUMN IF NOT EXISTS checkin_qr_token VARCHAR(120),
        ADD COLUMN IF NOT EXISTS checkin_qr_title VARCHAR(150) NOT NULL DEFAULT 'Visitor Location Check-in',
        ADD COLUMN IF NOT EXISTS updated_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW(),
        ADD COLUMN IF NOT EXISTS extension_enabled BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS extension_reminder_minutes INTEGER NOT NULL DEFAULT 30,
        ADD COLUMN IF NOT EXISTS extension_email_enabled BOOLEAN NOT NULL DEFAULT TRUE,
        ADD COLUMN IF NOT EXISTS extension_whatsapp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS extension_duration_options VARCHAR(100) NOT NULL DEFAULT '30,60',
        ADD COLUMN IF NOT EXISTS extension_max_requests INTEGER NOT NULL DEFAULT 1,
        ADD COLUMN IF NOT EXISTS extension_max_total_minutes INTEGER NOT NULL DEFAULT 120,
        ADD COLUMN IF NOT EXISTS extension_approval_timeout_minutes INTEGER NOT NULL DEFAULT 30
    `);

    await pool.query(`
        INSERT INTO self_registration_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);
    await pool.query(
        `UPDATE self_registration_settings
         SET checkin_qr_token = $1
         WHERE setting_id = 1 AND (checkin_qr_token IS NULL OR LENGTH(TRIM(checkin_qr_token)) < 32)`,
        [crypto.randomBytes(32).toString("hex")]
    );
    await pool.query(`
        CREATE TABLE IF NOT EXISTS self_registration_holidays (
            holiday_id SERIAL PRIMARY KEY,
            holiday_date DATE UNIQUE NOT NULL,
            holiday_name VARCHAR(180) NOT NULL,
            holiday_type VARCHAR(30) NOT NULL DEFAULT 'NATIONAL_HOLIDAY',
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_by VARCHAR(100),
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            modified_at TIMESTAMP
        )
    `);
    await selfRegistrationWorkflow.ensureSchema();

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_approval_tokens (
            token_id SERIAL PRIMARY KEY,
            invitation_id INTEGER NOT NULL REFERENCES visitor_invitations(invitation_id) ON DELETE CASCADE,
            approval_step VARCHAR(20) NOT NULL,
            token VARCHAR(120) UNIQUE NOT NULL,
            target_email VARCHAR(255),
            target_whatsapp VARCHAR(80),
            status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
            expires_at TIMESTAMP NOT NULL,
            used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("CREATE INDEX IF NOT EXISTS visitor_approval_tokens_invitation_idx ON visitor_approval_tokens (invitation_id)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_extension_requests (
            request_id SERIAL PRIMARY KEY,
            visitor_id INTEGER NOT NULL REFERENCES visitor_registration(visitor_id) ON DELETE CASCADE,
            request_token VARCHAR(120) UNIQUE NOT NULL,
            host_token VARCHAR(120) UNIQUE,
            status VARCHAR(30) NOT NULL DEFAULT 'OFFERED',
            requested_minutes INTEGER,
            original_expiry TIMESTAMP NOT NULL,
            requested_expiry TIMESTAMP,
            reason TEXT,
            bm_status VARCHAR(20) NOT NULL DEFAULT 'NOT_REQUESTED',
            bm_decided_by VARCHAR(100),
            bm_decided_at TIMESTAMP,
            bm_reason TEXT,
            host_status VARCHAR(20) NOT NULL DEFAULT 'NOT_REQUESTED',
            host_decided_by VARCHAR(150),
            host_decided_at TIMESTAMP,
            host_reason TEXT,
            approval_timeout_at TIMESTAMP,
            reminder_sent_at TIMESTAMP,
            email_status VARCHAR(20),
            email_error TEXT,
            whatsapp_status VARCHAR(20),
            whatsapp_error TEXT,
            sync_status VARCHAR(20),
            sync_error TEXT,
            sync_details JSONB,
            deleted_at TIMESTAMP,
            deleted_by VARCHAR(100),
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    `);
    await pool.query("ALTER TABLE visitor_extension_requests ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP");
    await pool.query("ALTER TABLE visitor_extension_requests ADD COLUMN IF NOT EXISTS deleted_by VARCHAR(100)");
    await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS visitor_extension_requests_expiry_uq ON visitor_extension_requests (visitor_id, original_expiry)");
    await pool.query("CREATE INDEX IF NOT EXISTS visitor_extension_requests_status_idx ON visitor_extension_requests (status, created_at DESC)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_invitation_members (
            member_id SERIAL PRIMARY KEY,
            invitation_id INTEGER NOT NULL REFERENCES visitor_invitations(invitation_id) ON DELETE CASCADE,
            member_name VARCHAR(180) NOT NULL,
            identity_number VARCHAR(120),
            identity_type VARCHAR(80),
            company_name VARCHAR(150),
            email_address VARCHAR(255),
            phone_number VARCHAR(50),
            visitor_photo VARCHAR(255),
            identity_photo VARCHAR(255),
            access_code VARCHAR(40),
            status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            created_at TIMESTAMP DEFAULT NOW(),
            modified_at TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS access_code VARCHAR(40)");
    await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'PENDING'");
    await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS visitor_id INTEGER");
    await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS qr_value TEXT");
    await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS phone_number VARCHAR(50)");
    await pool.query("CREATE INDEX IF NOT EXISTS visitor_invitation_members_invitation_idx ON visitor_invitation_members (invitation_id)");
    await pool.query("CREATE INDEX IF NOT EXISTS visitor_invitation_members_visitor_idx ON visitor_invitation_members (visitor_id)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS auto_checkout_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            schedule_date DATE DEFAULT CURRENT_DATE,
            schedule_time VARCHAR(5) NOT NULL DEFAULT '18:00',
            schedule_type VARCHAR(20) NOT NULL DEFAULT 'ONCE',
            last_run_at TIMESTAMP,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_date DATE DEFAULT CURRENT_DATE");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_time VARCHAR(5) NOT NULL DEFAULT '18:00'");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_type VARCHAR(20) NOT NULL DEFAULT 'ONCE'");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS last_run_at TIMESTAMP");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO auto_checkout_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS qr_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            digit_length INTEGER NOT NULL DEFAULT 10,
            preview_title VARCHAR(100) NOT NULL DEFAULT 'Visitor QR Code',
            preview_subtitle VARCHAR(150) NOT NULL DEFAULT 'QR Code dibuat dari Card Number',
            show_card_number BOOLEAN NOT NULL DEFAULT TRUE,
            auto_email BOOLEAN NOT NULL DEFAULT FALSE,
            auto_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
            auto_sms BOOLEAN NOT NULL DEFAULT FALSE,
            public_base_url TEXT,
            public_base_url_source VARCHAR(20) NOT NULL DEFAULT 'MANUAL',
            quick_tunnel_auto_start BOOLEAN NOT NULL DEFAULT FALSE,
            quick_tunnel_last_url TEXT,
            quick_tunnel_last_started_at TIMESTAMP,
            quick_tunnel_last_error TEXT,
            self_registration_qr_title VARCHAR(150) NOT NULL DEFAULT 'Visitor Self Registration',
            self_registration_qr_subtitle VARCHAR(200) NOT NULL DEFAULT 'Scan QR untuk isi form kunjungan mandiri',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS smtp_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            smtp_host VARCHAR(255),
            smtp_port INTEGER DEFAULT 587,
            smtp_secure BOOLEAN NOT NULL DEFAULT FALSE,
            smtp_user VARCHAR(255),
            smtp_pass TEXT,
            from_email VARCHAR(255),
            from_name VARCHAR(150) DEFAULT 'Visitor Registration',
            email_subject TEXT DEFAULT 'Visitor QR Code - {{visitor_name}}',
            email_body TEXT DEFAULT 'Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}',
            invitation_email_subject TEXT DEFAULT 'Visitor Invitation - {{booking_code}}',
            invitation_email_body TEXT DEFAULT 'Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang.',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE smtp_settings ADD COLUMN IF NOT EXISTS invitation_email_subject TEXT DEFAULT 'Visitor Invitation - {{booking_code}}'");
    await pool.query("ALTER TABLE smtp_settings ADD COLUMN IF NOT EXISTS invitation_email_body TEXT DEFAULT 'Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang.'");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS whatsapp_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            send_mode VARCHAR(20) NOT NULL DEFAULT 'manual',
            provider VARCHAR(30) NOT NULL DEFAULT 'meta',
            access_token TEXT,
            phone_number_id VARCHAR(120),
            base_url TEXT,
            api_version VARCHAR(20) NOT NULL DEFAULT 'v20.0',
            message_template TEXT DEFAULT 'Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE whatsapp_settings ADD COLUMN IF NOT EXISTS base_url TEXT");

    await pool.query(`
        ALTER TABLE qr_settings
        ADD COLUMN IF NOT EXISTS auto_email BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS auto_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS auto_sms BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS public_base_url TEXT,
        ADD COLUMN IF NOT EXISTS public_base_url_source VARCHAR(20) NOT NULL DEFAULT 'MANUAL',
        ADD COLUMN IF NOT EXISTS quick_tunnel_auto_start BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS quick_tunnel_last_url TEXT,
        ADD COLUMN IF NOT EXISTS quick_tunnel_last_started_at TIMESTAMP,
        ADD COLUMN IF NOT EXISTS quick_tunnel_last_error TEXT,
        ADD COLUMN IF NOT EXISTS self_registration_qr_title VARCHAR(150) NOT NULL DEFAULT 'Visitor Self Registration',
        ADD COLUMN IF NOT EXISTS self_registration_qr_subtitle VARCHAR(200) NOT NULL DEFAULT 'Scan QR untuk isi form kunjungan mandiri'
    `);

    await pool.query(`
        INSERT INTO qr_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        INSERT INTO smtp_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        INSERT INTO whatsapp_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_operator_notes (
            note_id SERIAL PRIMARY KEY,
            visitor_id INTEGER NOT NULL REFERENCES visitor_registration(visitor_id) ON DELETE CASCADE,
            note_text TEXT NOT NULL,
            created_by VARCHAR(100) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_operator_note_reads (
            note_id INTEGER NOT NULL REFERENCES visitor_operator_notes(note_id) ON DELETE CASCADE,
            username VARCHAR(100) NOT NULL,
            read_at TIMESTAMP NOT NULL DEFAULT NOW(),
            PRIMARY KEY (note_id, username)
        )
    `);

    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_operator_notes_visitor ON visitor_operator_notes (visitor_id, created_at DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_operator_note_reads_user ON visitor_operator_note_reads (username, note_id)");

    schemaReady = true;
}

function buildTemplate(template, data) {
    return String(template || "").replace(/\{\{(\w+)\}\}/g, (_, key) => data[key] ?? "");
}

function createSmtpTransport(settings) {
    if (!settings?.smtp_host || !settings?.smtp_port || !settings?.smtp_user || !settings?.smtp_pass) {
        throw new Error("Setting SMTP belum lengkap.");
    }

    return nodemailer.createTransport({
        host: settings.smtp_host,
        port: Number(settings.smtp_port),
        secure: settings.smtp_secure === true,
        auth: {
            user: settings.smtp_user,
            pass: settings.smtp_pass
        }
    });
}

async function getSmtpSettings() {
    const result = await pool.query("SELECT * FROM smtp_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function getQrSettings() {
    const result = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function getHostNotificationSettings() {
    const result = await pool.query("SELECT * FROM host_notification_settings WHERE setting_id = 1");
    return result.rows[0];
}

function formatDateTimeText(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString("en-GB");
}

function getApprovalTimeZoneLabel(timeZone) {
    return normalizeApprovalTimeZone(timeZone, DEFAULT_TIME_ZONE) === "Asia/Jakarta" ? "WIB" : normalizeApprovalTimeZone(timeZone, DEFAULT_TIME_ZONE);
}

function formatApprovalDateTimeText(value, timeZone) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    const zone = normalizeApprovalTimeZone(timeZone, DEFAULT_TIME_ZONE);
    return `${date.toLocaleString("id-ID", { timeZone: zone, dateStyle: "medium", timeStyle: "short" })} ${getApprovalTimeZoneLabel(zone)}`;
}

function formatApprovalOperationalText(invitation) {
    const start = String(invitation?.approval_operational_start || "").replace(":", ".");
    const end = String(invitation?.approval_operational_end || "").replace(":", ".");
    if (!start || !end) return "-";
    const dayNames = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];
    const days = normalizeApprovalDays(invitation?.approval_operational_days, DEFAULT_OPERATIONAL_DAYS)
        .map(day => dayNames[day - 1])
        .join(", ");
    return `${days}, ${start}-${end} ${getApprovalTimeZoneLabel(invitation?.approval_timezone)}`;
}

async function sendHostCheckinEmail(req, visitor) {
    try {
        const options = arguments[2] || {};
        const onlyChannel = String(options.only_channel || "").toUpperCase();
        const notifySettings = await getHostNotificationSettings();
        const emailEnabled = notifySettings?.enabled === true && onlyChannel !== "WHATSAPP";
        const whatsappEnabled = notifySettings?.whatsapp_enabled === true && onlyChannel !== "EMAIL";
        if (!emailEnabled && !whatsappEnabled) return { skipped: true, reason: "Host notification disabled" };

        const hostName = String(visitor?.host || "").trim();
        if (!hostName) return { skipped: true, reason: "Host kosong" };

        const hostResult = await pool.query(
            "SELECT * FROM visitor_hosts WHERE host_name = $1 LIMIT 1",
            [hostName]
        );
        const host = hostResult.rows[0];
        const targetEmail = String(host?.host_email || "").trim();
        const targetWhatsapp = String(host?.host_whatsapp || "").trim();
        if (emailEnabled && !targetEmail && whatsappEnabled && !targetWhatsapp) {
            return { skipped: true, reason: "Email dan WhatsApp host kosong" };
        }
        if (emailEnabled && !targetEmail && !whatsappEnabled) return { skipped: true, reason: "Email host kosong" };
        if (whatsappEnabled && !targetWhatsapp && !emailEnabled) return { skipped: true, reason: "WhatsApp host kosong" };

        const visitorName = getVisitorDisplayName(visitor);
        const templateData = {
            visitor_name: visitorName,
            first_name: visitor?.first_name || "",
            second_name: visitor?.second_name || "",
            company_name: visitor?.company_name || "-",
            host: hostName,
            host_email: targetEmail,
            host_whatsapp: targetWhatsapp,
            host_location: host?.location || "-",
            purpose_note: visitor?.purpose_note || "-",
            card_number: visitor?.card_number || "-",
            permission_group: visitor?.permission_group || "-",
            check_in_time: formatDateTimeText(visitor?.check_in_time || new Date()),
            start: formatDateTimeText(visitor?.start_date),
            expiry: formatDateTimeText(visitor?.expiry_date)
        };

        const results = [];

        if (emailEnabled && targetEmail) {
            try {
                const settings = await getSmtpSettings();
                const transporter = createSmtpTransport(settings);
                const subject = buildTemplate(
                    notifySettings.email_subject || "Visitor Check-In - {{visitor_name}}",
                    templateData
                );
                const body = buildTemplate(
                    notifySettings.email_body || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}",
                    templateData
                );

                await transporter.sendMail({
                    from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
                    to: targetEmail,
                    subject,
                    text: body
                });

                await saveActivityLog(
                    req,
                    "SEND_HOST_CHECKIN_EMAIL",
                    `Send host check-in email to ${targetEmail} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"})`
                );
                await createSystemNotification(req, {
                    channel: "EMAIL_HOST",
                    event_type: "CHECKIN",
                    status: "SUCCESS",
                    visitor_id: visitor?.visitor_id,
                    visitor_name: visitorName,
                    target: targetEmail,
                    title: "Email ke Host berhasil",
                    message: `Informasi check-in ${visitorName} berhasil dikirim ke ${targetEmail}.`,
                    detail: { host: hostName, card_number: visitor?.card_number || null }
                });
                results.push({ channel: "email", success: true, to: targetEmail });
            } catch (emailError) {
                await saveActivityLog(req, "SEND_HOST_CHECKIN_EMAIL_FAILED", `Send host check-in email failed for ${visitorName}: ${emailError.message}`);
                await createSystemNotification(req, {
                    channel: "EMAIL_HOST",
                    event_type: "CHECKIN",
                    status: "FAILED",
                    visitor_id: visitor?.visitor_id,
                    visitor_name: visitorName,
                    target: targetEmail,
                    title: "Email ke Host gagal",
                    message: emailError.message,
                    detail: { host: hostName, card_number: visitor?.card_number || null }
                });
                results.push({ channel: "email", success: false, to: targetEmail, error: emailError.message });
            }
        }

        if (whatsappEnabled && targetWhatsapp) {
            try {
                const whatsappSettings = await getWhatsappSettings();
                const body = buildTemplate(
                    notifySettings.whatsapp_body || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}",
                    templateData
                );

                await sendPlainWhatsappMessage(whatsappSettings, targetWhatsapp, body);
                await saveActivityLog(
                    req,
                    "SEND_HOST_CHECKIN_WHATSAPP",
                    `Send host check-in WhatsApp to ${targetWhatsapp} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"})`
                );
                await createSystemNotification(req, {
                    channel: "WHATSAPP_HOST",
                    event_type: "CHECKIN",
                    status: "SUCCESS",
                    visitor_id: visitor?.visitor_id,
                    visitor_name: visitorName,
                    target: targetWhatsapp,
                    title: "WhatsApp ke Host berhasil",
                    message: `Informasi check-in ${visitorName} berhasil dikirim ke ${targetWhatsapp}.`,
                    detail: { host: hostName, card_number: visitor?.card_number || null }
                });
                results.push({ channel: "whatsapp", success: true, to: targetWhatsapp });
            } catch (whatsappError) {
                await saveActivityLog(req, "SEND_HOST_CHECKIN_WHATSAPP_FAILED", `Send host check-in WhatsApp failed for ${visitorName}: ${whatsappError.message}`);
                await createSystemNotification(req, {
                    channel: "WHATSAPP_HOST",
                    event_type: "CHECKIN",
                    status: "FAILED",
                    visitor_id: visitor?.visitor_id,
                    visitor_name: visitorName,
                    target: targetWhatsapp,
                    title: "WhatsApp ke Host gagal",
                    message: whatsappError.message,
                    detail: { host: hostName, card_number: visitor?.card_number || null }
                });
                results.push({ channel: "whatsapp", success: false, to: targetWhatsapp, error: whatsappError.message });
            }
        }

        return { success: results.some(item => item.success), results };
    } catch (error) {
        console.log("SEND HOST CHECKIN NOTIFICATION ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_HOST_CHECKIN_NOTIFICATION_FAILED",
            `Send host check-in notification failed for ${getVisitorDisplayName(visitor)}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "HOST_NOTIFICATION",
            event_type: "CHECKIN",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: getVisitorDisplayName(visitor),
            target: visitor?.host || null,
            title: "Notifikasi ke Host gagal",
            message: error.message,
            detail: { host: visitor?.host || null, card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

async function getFormattedQrCardNumber(cardNumber) {
    const settings = await getCardFormatSettings(pool);
    const preview = formatCardNumber(cardNumber || "", settings);
    return settings.enabled && settings.apply_to_qr ? preview.formatted : preview.raw;
}

async function buildQrShareUrlFromSettings(settings, visitor, qrCardNumber = null) {
    const baseUrl = String(settings?.public_base_url || "").trim().replace(/\/+$/, "");
    if (!baseUrl || !visitor?.card_number) return "-";
    const params = new URLSearchParams({
        qrCard: String(qrCardNumber || visitor.card_number || ""),
        visitor: getVisitorDisplayName(visitor)
    });
    return `${baseUrl}/qr-info.html?${params.toString()}`;
}

function buildPublicQrImageUrl(settings, qrValue, fallbackPublicUrl = "") {
    let baseUrl = String(settings?.public_base_url || "").trim();
    if (!baseUrl && fallbackPublicUrl) {
        try {
            baseUrl = new URL(fallbackPublicUrl).origin;
        } catch (error) {
            baseUrl = "";
        }
    }
    if (!/^https?:\/\//i.test(baseUrl) || !String(qrValue || "").trim()) return "";

    const imageUrl = new URL("/api/public/self-registration/qr", `${baseUrl.replace(/\/+$/, "")}/`);
    imageUrl.searchParams.set("value", String(qrValue).trim());
    imageUrl.searchParams.set("format", "png");
    return imageUrl.toString();
}

async function buildVisitorQrEmailContent(settings, qrSettings, visitor, qrCardNumber) {
    const visitorName = getVisitorDisplayName(visitor);
    const shareUrl = await buildQrShareUrlFromSettings(qrSettings, { ...visitor, card_number: qrCardNumber || visitor?.card_number }, qrCardNumber);
    const templateData = {
        visitor_name: visitorName,
        first_name: visitor?.first_name || "",
        second_name: visitor?.second_name || "",
        company_name: visitor?.company_name || "-",
        host: visitor?.host || "-",
        start: formatDateTimeText(visitor?.start_date),
        expiry: formatDateTimeText(visitor?.expiry_date),
        card_number: qrCardNumber || "-",
        card_number_raw: visitor?.card_number || qrCardNumber || "-",
        share_url: shareUrl,
        purpose_note: visitor?.purpose_note || "-"
    };
    return {
        subject: buildTemplate(settings.email_subject || "Visitor QR Code - {{visitor_name}}", templateData),
        body: buildTemplate(
            settings.email_body || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
            templateData
        ),
        shareUrl
    };
}

async function sendVisitorCheckinQrEmail(req, visitor) {
    const visitorName = getVisitorDisplayName(visitor);
    let targetEmail = String(visitor?.email_address || "").trim();

    try {
        const qrSettings = await getQrSettings();
        if (qrSettings?.auto_email !== true) return { skipped: true, reason: "Auto email QR disabled" };

        if (!targetEmail) {
            await createSystemNotification(req, {
                channel: "EMAIL_VISITOR",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_id: visitor?.visitor_id,
                visitor_name: visitorName,
                title: "Email QR ke Visitor gagal",
                message: "Email visitor belum diisi.",
                detail: { card_number: visitor?.card_number || null }
            });
            return { success: false, error: "Email visitor belum diisi." };
        }

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const qrCardNumber = await getFormattedQrCardNumber(visitor?.card_number);
        const { subject, body, shareUrl } = await buildVisitorQrEmailContent(settings, qrSettings, visitor, qrCardNumber);
        const qrBuffer = await QRCode.toBuffer(String(qrCardNumber || shareUrl || visitorName), {
            errorCorrectionLevel: "H",
            margin: 2,
            width: 480
        });

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body,
            attachments: [
                {
                    filename: `QR_${String(qrCardNumber || "visitor").replace(/[^a-z0-9_-]+/gi, "_")}.png`,
                    content: qrBuffer,
                    contentType: "image/png"
                }
            ]
        });

        await saveActivityLog(
            req,
            "SEND_QR_EMAIL",
            `Auto send QR email to ${targetEmail} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"}, Card ${visitor?.card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail,
            title: "Email QR ke Visitor berhasil",
            message: `QR Code visitor berhasil dikirim otomatis ke ${targetEmail}.`,
            detail: { card_number: qrCardNumber || null, card_number_raw: visitor?.card_number || null, share_url: shareUrl }
        });

        return { success: true, to: targetEmail };
    } catch (error) {
        console.log("SEND VISITOR QR EMAIL ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_QR_EMAIL_FAILED",
            `Auto send QR email failed for ${visitorName}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail || null,
            title: "Email QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

async function sendVisitorAccessQrWhatsapp(req, visitor, qrValue) {
    const visitorName = getVisitorDisplayName(visitor);
    const qrSettings = await getQrSettings();
    if (qrSettings?.auto_whatsapp !== true) return { skipped: true, reason: "Auto WhatsApp QR disabled" };

    const settings = await getWhatsappSettings();
    if (!settings || settings.send_mode !== "api") return { skipped: true, reason: "WhatsApp mode manual" };
    assertWhatsappApiSettings(settings);

    const targetPhone = normalizeWhatsappPhone(visitor?.phone_number);
    if (!targetPhone) throw new Error("Nomor WhatsApp visitor belum diisi.");

    const qrCardNumber = String(qrValue || visitor?.card_number || "").trim();
    if (!qrCardNumber) throw new Error("Nomor QR akses belum tersedia.");

    const shareUrl = await buildQrShareUrlFromSettings(qrSettings, { ...visitor, card_number: qrCardNumber }, qrCardNumber);
    const templateData = {
        visitor_name: visitorName,
        first_name: visitor?.first_name || "",
        second_name: visitor?.second_name || "",
        company_name: visitor?.company_name || "-",
        host: visitor?.host || "-",
        start: formatDateTimeText(visitor?.start_date),
        expiry: formatDateTimeText(visitor?.expiry_date),
        card_number: qrCardNumber,
        card_number_raw: visitor?.card_number || qrCardNumber,
        share_url: shareUrl,
        purpose_note: visitor?.purpose_note || "-"
    };
    const caption = buildTemplate(
        settings.message_template || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
        templateData
    );
    const publicImageUrl = buildPublicQrImageUrl(qrSettings, qrCardNumber, shareUrl);
    const mediaResult = await sendWhatsappQrMedia(settings, {
        toPhone: targetPhone,
        caption,
        qrValue: qrCardNumber,
        publicImageUrl
    });

    await saveActivityLog(
        req,
        "SEND_QR_WHATSAPP",
        `Auto send QR WhatsApp API to ${targetPhone} for ${visitorName} (Card ${qrCardNumber})`
    );
    await createSystemNotification(req, {
        channel: "WHATSAPP",
        event_type: "QR_SHARE",
        status: "SUCCESS",
        visitor_id: visitor?.visitor_id || null,
        visitor_name: visitorName,
        target: targetPhone,
        title: "WhatsApp QR berhasil",
        message: `QR Code visitor berhasil dikirim otomatis via WhatsApp Business API ke ${targetPhone}.`,
        detail: {
            provider: mediaResult.provider,
            card_number: qrCardNumber,
            card_number_raw: visitor?.card_number || null,
            share_url: shareUrl,
            media_url: mediaResult.mediaUrl || null,
            response: mediaResult.response
        }
    });
    return { success: true, to: targetPhone };
}

async function sendVisitorCheckinQrWhatsapp(req, visitor) {
    const visitorName = getVisitorDisplayName(visitor);
    const targetPhone = normalizeWhatsappPhone(visitor?.phone_number);
    try {
        const qrCardNumber = await getFormattedQrCardNumber(visitor?.card_number);
        return await sendVisitorAccessQrWhatsapp(req, visitor, qrCardNumber);
    } catch (error) {
        console.log("SEND VISITOR QR WHATSAPP ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_QR_WHATSAPP_FAILED",
            `Auto send QR WhatsApp failed for ${visitorName}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetPhone || null,
            title: "WhatsApp QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

function normalizeBookingCode(value) {
    return String(value || "").trim().toUpperCase();
}

function safeUploadFilename(value) {
    const raw = String(value || "").trim();
    if (!raw) return null;
    const filename = raw
        .replace(/^\/?uploads[\\/]/i, "")
        .split(/[\\/]/)
        .pop();
    if (!filename || filename === "." || filename === ".." || filename.includes("..")) return null;
    return filename;
}

async function generateBookingCode() {
    const date = new Date();
    const datePart = `${date.getFullYear()}${pad2(date.getMonth() + 1)}${pad2(date.getDate())}`;
    for (let attempt = 0; attempt < 20; attempt += 1) {
        const randomPart = crypto.randomBytes(3).toString("hex").toUpperCase();
        const code = `INV-${datePart}-${randomPart}`;
        const existing = await pool.query("SELECT 1 FROM visitor_invitations WHERE booking_code = $1 LIMIT 1", [code]);
        if (existing.rows.length === 0) return code;
    }
    throw new Error("Gagal generate booking code unik.");
}

function normalizeSelfRegistrationApprovalMode(value) {
    const mode = String(value || "NO_APPROVAL").trim().toUpperCase();
    return ["NO_APPROVAL", "BM_ONLY", "HOST_ONLY", "BM_AND_HOST"].includes(mode) ? mode : "NO_APPROVAL";
}

function clampInteger(value, fallback, min, max) {
    const number = parseInt(value, 10);
    if (!Number.isFinite(number)) return fallback;
    return Math.min(Math.max(number, min), max);
}

function escapeHtmlText(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    }[char]));
}

function toDateKey(value) {
    if (!value) return "";
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
        return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
    }
    const direct = String(value).trim().slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(direct)) return direct;
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString().slice(0, 10);
}

async function getSelfRegistrationSettings() {
    await ensureVisitorSchema();
    const result = await pool.query("SELECT * FROM self_registration_settings WHERE setting_id = 1");
    const settings = result.rows[0] || {};
    return {
        ...settings,
        approval_mode: normalizeSelfRegistrationApprovalMode(settings.approval_mode),
        bm_timeout_minutes: clampInteger(settings.bm_timeout_minutes, 60, 1, 10080),
        host_timeout_minutes: clampInteger(settings.host_timeout_minutes, 60, 1, 10080),
        approval_timezone: normalizeApprovalTimeZone(settings.approval_timezone, DEFAULT_TIME_ZONE),
        bm_operational_start: normalizeApprovalTime(settings.bm_operational_start, DEFAULT_OPERATIONAL_START),
        bm_operational_end: normalizeApprovalTime(settings.bm_operational_end, DEFAULT_OPERATIONAL_END),
        default_host_operational_start: normalizeApprovalTime(settings.default_host_operational_start, DEFAULT_OPERATIONAL_START),
        default_host_operational_end: normalizeApprovalTime(settings.default_host_operational_end, DEFAULT_OPERATIONAL_END),
        bm_operational_days: normalizeApprovalDays(settings.bm_operational_days, DEFAULT_OPERATIONAL_DAYS),
        default_host_operational_days: normalizeApprovalDays(settings.default_host_operational_days, DEFAULT_OPERATIONAL_DAYS),
        national_holidays_closed: settings.national_holidays_closed !== false,
        collective_leave_closed: settings.collective_leave_closed !== false,
        group_max_members: clampInteger(settings.group_max_members, 10, 1, 100),
        extension_enabled: settings.extension_enabled === true,
        extension_reminder_minutes: clampInteger(settings.extension_reminder_minutes, 30, 5, 1440),
        extension_email_enabled: settings.extension_email_enabled !== false,
        extension_whatsapp_enabled: settings.extension_whatsapp_enabled === true,
        extension_duration_options: normalizeExtensionDurations(settings.extension_duration_options),
        extension_max_requests: clampInteger(settings.extension_max_requests, 1, 1, 10),
        extension_max_total_minutes: clampInteger(settings.extension_max_total_minutes, 120, 15, 1440),
        extension_approval_timeout_minutes: clampInteger(settings.extension_approval_timeout_minutes, 30, 5, 1440)
    };
}

function normalizeExtensionDurations(value) {
    const raw = Array.isArray(value) ? value : String(value || "30,60").split(",");
    const values = [...new Set(raw.map(item => clampInteger(item, 0, 15, 1440)).filter(Boolean))].sort((a, b) => a - b);
    return values.length ? values : [30, 60];
}

function getUploadedFile(req, fieldName) {
    if (Array.isArray(req.files)) {
        return req.files.find(file => file.fieldname === fieldName) || null;
    }
    return req.files?.[fieldName]?.[0] || null;
}

function parseJsonArray(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    try {
        const parsed = JSON.parse(String(value));
        return Array.isArray(parsed) ? parsed : [];
    } catch {
        return [];
    }
}

function splitVisitorName(fullName) {
    const parts = String(fullName || "").trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return { firstName: "", secondName: "" };
    return {
        firstName: parts[0],
        secondName: parts.slice(1).join(" ")
    };
}

function getSelfRegistrationMembersFromRequest(req, settings) {
    const body = req.body || {};
    const enabled = settings?.group_registration_enabled === true;
    const requested = parseLooseBoolean(body.group_registration) || parseLooseBoolean(body.is_group_registration);
    if (!enabled || !requested) return [];

    const members = parseJsonArray(body.members).map((raw, index) => {
        const key = String(raw.key || raw.id || index);
        const uploadedFace = getUploadedFile(req, `member_visitor_photo_${key}`)?.filename;
        const uploadedIdentity = getUploadedFile(req, `member_identity_photo_${key}`)?.filename;
        const memberName = String(raw.member_name || raw.name || "").trim();
        return {
            key,
            member_name: memberName,
            identity_number: String(raw.identity_number || raw.id_number || "").trim(),
            identity_type: String(raw.identity_type || "E-KTP").trim(),
            company_name: String(raw.company_name || body.company_name || "").trim(),
            email_address: String(raw.email_address || raw.email || "").trim(),
            phone_number: String(raw.phone_number || raw.telephone_number || raw.whatsapp || "").trim(),
            visitor_photo: uploadedFace || safeUploadFilename(raw.existing_visitor_photo || raw.visitor_photo),
            identity_photo: uploadedIdentity || safeUploadFilename(raw.existing_identity_photo || raw.identity_photo)
        };
    }).filter(member => member.member_name || member.identity_number);

    const maxMembers = clampInteger(settings?.group_max_members, 10, 1, 100);
    if (members.length > maxMembers) {
        throw new Error(`Maksimal anggota grup ${maxMembers} orang.`);
    }
    members.forEach((member, index) => {
        if (!member.member_name) throw new Error(`Nama anggota grup #${index + 1} wajib diisi.`);
        if (!member.identity_number) throw new Error(`ID Number anggota grup #${index + 1} wajib diisi.`);
        if (settings.member_face_photo_required !== false && !member.visitor_photo) {
            throw new Error(`Foto wajah anggota ${member.member_name} wajib diisi.`);
        }
        if (settings.member_identity_photo_required !== false && !member.identity_photo) {
            throw new Error(`Foto identitas anggota ${member.member_name} wajib diisi.`);
        }
    });
    return members;
}

async function saveInvitationMembers(clientOrPool, invitationId, members) {
    await clientOrPool.query("DELETE FROM visitor_invitation_members WHERE invitation_id = $1", [invitationId]);
    for (const member of members) {
        await clientOrPool.query(
            `INSERT INTO visitor_invitation_members (
                invitation_id, member_name, identity_number, identity_type, company_name,
                email_address, phone_number, visitor_photo, identity_photo, status, created_at, modified_at
             )
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'PENDING',NOW(),NOW())`,
            [
                invitationId,
                member.member_name,
                member.identity_number || null,
                member.identity_type || null,
                member.company_name || null,
                member.email_address || null,
                member.phone_number || null,
                member.visitor_photo || null,
                member.identity_photo || null
            ]
        );
    }
}

async function loadInvitationMembers(invitationIds, options = {}) {
    const ids = [...new Set((Array.isArray(invitationIds) ? invitationIds : [invitationIds]).map(Number).filter(Boolean))];
    if (!ids.length) return new Map();
    const includeAccess = options.includeAccess === true;
    const result = await pool.query(
        `SELECT member_id, invitation_id, member_name, identity_number, identity_type, company_name,
                email_address, phone_number, visitor_photo, identity_photo, visitor_id,
                ${includeAccess ? "access_code, qr_value," : "NULL AS access_code, NULL AS qr_value,"}
                status, created_at, modified_at
         FROM visitor_invitation_members
         WHERE invitation_id = ANY($1::int[])
         ORDER BY invitation_id ASC, member_id ASC`,
        [ids]
    );
    const map = new Map(ids.map(id => [id, []]));
    result.rows.forEach(row => {
        const item = {
            ...row,
            visitor_photo: safeUploadFilename(row.visitor_photo),
            identity_photo: safeUploadFilename(row.identity_photo)
        };
        map.get(Number(row.invitation_id))?.push(item);
    });
    return map;
}

async function attachInvitationMembers(rows, options = {}) {
    const list = Array.isArray(rows) ? rows : [];
    const map = await loadInvitationMembers(list.map(row => row.invitation_id), options);
    return list.map(row => ({
        ...row,
        members: map.get(Number(row.invitation_id)) || [],
        group_member_count: (map.get(Number(row.invitation_id)) || []).length
    }));
}

async function attachInvitationMembersToRow(row, options = {}) {
    if (!row?.invitation_id) return row;
    const map = await loadInvitationMembers(row.invitation_id, options);
    const members = map.get(Number(row.invitation_id)) || [];
    return {
        ...row,
        members,
        group_member_count: members.length
    };
}

async function buildAutomaticAccessValue(client, digits) {
    const settings = await getCardFormatSettings(pool);
    const length = Math.min(24, Math.max(4, Number(digits) || 10));
    for (let attempt = 0; attempt < 30; attempt += 1) {
        let code = String(crypto.randomInt(1, 10));
        for (let i = 1; i < length; i += 1) code += String(crypto.randomInt(0, 10));
        const preview = formatCardNumber(code, settings);
        const qrValue = settings.enabled && settings.apply_to_qr ? preview.formatted : preview.raw;
        if (!/^\d+$/.test(qrValue)) throw new Error("Format QR akses otomatis harus berupa angka. Periksa Card Format Mapping.");
        const duplicate = await client.query(
            `SELECT 1 FROM visitor_registration WHERE card_number IN ($1,$2)
             UNION ALL SELECT 1 FROM self_registration_access_jobs WHERE access_code IN ($1,$2) OR qr_value IN ($1,$2)
             UNION ALL SELECT 1 FROM visitor_invitation_members WHERE access_code IN ($1,$2) OR qr_value IN ($1,$2)
             LIMIT 1`,
            [code, qrValue]
        );
        if (!duplicate.rows.length) return { code, qrValue };
    }
    throw new Error("Nomor akses unik anggota grup belum tersedia.");
}

async function prepareSelfRegistrationGroupMembers(client, invitation, context = {}) {
    const invitationId = Number(invitation?.invitation_id);
    if (!invitationId) return [];

    const members = (await client.query(
        `SELECT *
         FROM visitor_invitation_members
         WHERE invitation_id = $1
         ORDER BY member_id ASC`,
        [invitationId]
    )).rows;
    if (!members.length) {
        await client.query(
            `UPDATE visitor_registration
             SET source_invitation_id=$1, group_booking_code=$2, group_leader=TRUE, modified_time=NOW()
             WHERE visitor_id=$3`,
            [invitationId, invitation.booking_code || null, context.leaderVisitor?.visitor_id]
        );
        return [];
    }

    await client.query(
        `UPDATE visitor_registration
         SET source_invitation_id=$1, group_booking_code=$2, group_leader=TRUE, modified_time=NOW()
         WHERE visitor_id=$3`,
        [invitationId, invitation.booking_code || null, context.leaderVisitor?.visitor_id]
    );

    const created = [];
    const phase = context.phase === "WAITING_ARRIVAL" ? "WAITING_ARRIVAL" : "ACCESS_PENDING";
    const digits = context.plan?.digits;
    for (const member of members) {
        if (member.visitor_id) continue;
        if (member.identity_number && await findActiveIdentityBlacklist(member.identity_number)) {
            throw new Error(`Anggota grup ${member.member_name} masuk blacklist aktif.`);
        }
        if (member.identity_number) {
            const active = await client.query(
                `SELECT visitor_id
                 FROM visitor_registration
                 WHERE UPPER(BTRIM(identity_number)) = UPPER(BTRIM($1))
                   AND check_out_time IS NULL
                   AND (check_in_time IS NOT NULL OR status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL'))
                 LIMIT 1`,
                [member.identity_number]
            );
            if (active.rows.length) {
                throw new Error(`Anggota grup ${member.member_name} masih memiliki kunjungan atau akses aktif.`);
            }
        }
        const access = await buildAutomaticAccessValue(client, digits);
        const name = splitVisitorName(member.member_name);
        const visitor = await client.query(
            `INSERT INTO visitor_registration (
                first_name, second_name, identity_number, identity_type, company_name, email_address, phone_number,
                host, permission_group, purpose_note, visitor_photo, identity_photo, start_date, expiry_date,
                card_number, schindler_person_id, created_by, created_time, check_in_time, status,
                source_invitation_id, group_booking_code, group_member_id, group_leader
             )
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'SELF_REGISTRATION',NOW(),NULL,$17,$18,$19,$20,FALSE)
             RETURNING *`,
            [
                name.firstName,
                name.secondName || null,
                member.identity_number || null,
                member.identity_type || invitation.identity_type || null,
                member.company_name || invitation.company_name || null,
                member.email_address || null,
                member.phone_number || null,
                invitation.host || null,
                invitation.permission_group || "Visitor",
                invitation.purpose_note || null,
                member.visitor_photo || null,
                member.identity_photo || null,
                invitation.start_date || null,
                invitation.expiry_date || null,
                access.code,
                crypto.randomUUID().replace(/-/g, "").toUpperCase(),
                phase,
                invitationId,
                invitation.booking_code || null,
                member.member_id
            ]
        );
        await client.query(
            `UPDATE visitor_invitation_members
             SET visitor_id=$2, access_code=$3, qr_value=$4, status=$5, modified_at=NOW()
             WHERE member_id=$1`,
            [member.member_id, visitor.rows[0].visitor_id, access.code, access.qrValue, phase]
        );
        created.push(visitor.rows[0]);
    }
    return created;
}

async function markSelfRegistrationGroupMembersCheckedIn(client, invitationId) {
    const result = await client.query(
        `UPDATE visitor_registration
         SET status='CHECKED_IN',
             check_in_time=COALESCE(check_in_time,NOW()),
             modified_time=NOW()
         WHERE source_invitation_id=$1
           AND group_leader=FALSE
           AND check_in_time IS NULL
         RETURNING *`,
        [invitationId]
    );
    await client.query(
        `UPDATE visitor_invitation_members
         SET status='CHECKED_IN', modified_at=NOW()
         WHERE invitation_id=$1 AND visitor_id IS NOT NULL`,
        [invitationId]
    );
    if (result.rows.length) {
        runBackgroundTask(`GROUP MEMBER CHECKIN ${invitationId}`, async () => {
            const reqLike = {
                session: { user: { username: "SELF_REGISTRATION", full_name: "Self Registration" } },
                ip: "127.0.0.1"
            };
            await Promise.allSettled(result.rows.map(visitor => {
                const tasks = [
                    sendHostCheckinEmail(reqLike, visitor),
                    runCheckinApiBackground(reqLike, visitor),
                    runDeviceSyncBackground(reqLike, visitor, "CHECKIN")
                ];
                if (String(visitor.email_address || "").trim()) tasks.push(sendVisitorCheckinQrEmail(reqLike, visitor));
                if (String(visitor.phone_number || "").trim()) tasks.push(sendVisitorCheckinQrWhatsapp(reqLike, visitor));
                return Promise.allSettled(tasks);
            }));
        });
    }
    return result.rows;
}

async function removeSelfRegistrationGroupMembersAccess(client, invitationId) {
    const result = await client.query(
        `UPDATE visitor_registration
         SET check_out_time=CASE WHEN check_in_time IS NOT NULL THEN COALESCE(check_out_time,NOW()) ELSE check_out_time END,
             status='ACCESS_EXPIRED',
             modified_time=NOW()
         WHERE source_invitation_id=$1
           AND group_leader=FALSE
           AND check_out_time IS NULL
         RETURNING *`,
        [invitationId]
    );
    await client.query(
        `UPDATE visitor_invitation_members
         SET status='ACCESS_EXPIRED', modified_at=NOW()
         WHERE invitation_id=$1 AND visitor_id IS NOT NULL`,
        [invitationId]
    );
    if (result.rows.length) {
        runBackgroundTask(`GROUP MEMBER REVOKE ${invitationId}`, async () => {
            const reqLike = {
                session: { user: { username: "SELF_REGISTRATION", full_name: "Self Registration" } },
                ip: "127.0.0.1"
            };
            for (const visitor of result.rows) {
                let apiResults = [];
                if (await isVisitorRegistrationApiMode()) {
                    try {
                        apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKOUT", visitor);
                    } catch (apiError) {
                        console.log("THIRD PARTY GROUP REVOKE API ERROR:", apiError.message);
                    }
                }
                if (shouldReleaseInnerrangeSlot(apiResults)) {
                    await releaseThirdPartyUserSlot(visitor.third_party_user_id, visitor.visitor_id);
                }
                await runDeviceSyncBackground(reqLike, visitor, "CHECKOUT");
            }
        });
    }
    return result.rows;
}

async function finishSelfRegistrationInvitationWhenNoActiveVisitors(checkedOutVisitor, reqLike) {
    const invitationId = Number(checkedOutVisitor?.source_invitation_id || 0);
    if (!invitationId) return false;

    const active = await pool.query(
        `SELECT 1
         FROM visitor_registration
         WHERE source_invitation_id = $1
           AND check_out_time IS NULL
           AND (check_in_time IS NOT NULL OR status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL','CHECKED_IN'))
         LIMIT 1`,
        [invitationId]
    );
    if (active.rows.length) return false;

    await pool.query(
        `UPDATE visitor_invitations
         SET status='ACCESS_EXPIRED',
             modified_by=$2,
             modified_time=NOW()
         WHERE invitation_id=$1
           AND status IN ('ACCESS_PENDING','WAITING_ARRIVAL','ACCESS_READY','ACCESS_FAILED','CHECKED_IN')`,
        [invitationId, getCurrentUsername(reqLike)]
    );

    return true;
}

function getLocationCheckinQrValue(settings) {
    return `INNERSYNC-CHECKIN:${String(settings?.checkin_qr_token || "").trim()}`;
}

function secureTextEqual(left, right) {
    const leftBuffer = Buffer.from(String(left || ""));
    const rightBuffer = Buffer.from(String(right || ""));
    return leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer);
}

function getInitialSelfRegistrationApprovalState(settings) {
    const mode = normalizeSelfRegistrationApprovalMode(settings?.approval_mode);
    if (mode === "BM_ONLY") {
        return { status: "WAITING_BM_APPROVAL", bm: "WAITING", host: "NOT_REQUIRED", timeoutMinutes: settings.bm_timeout_minutes };
    }
    if (mode === "HOST_ONLY") {
        return { status: "WAITING_HOST_APPROVAL", bm: "NOT_REQUIRED", host: "WAITING", timeoutMinutes: settings.host_timeout_minutes };
    }
    if (mode === "BM_AND_HOST") {
        return { status: "WAITING_BM_APPROVAL", bm: "WAITING", host: "PENDING_BM", timeoutMinutes: settings.bm_timeout_minutes };
    }
    return { status: "PENDING", bm: "NOT_REQUIRED", host: "NOT_REQUIRED", timeoutMinutes: null };
}

function addMinutes(date, minutes) {
    const result = new Date(date);
    result.setMinutes(result.getMinutes() + Number(minutes || 0));
    return result;
}

async function getApprovalStageWindow(settings, stage, hostName, visitStart, visitExpiry, now = new Date()) {
    const approvalStep = String(stage || "BM").toUpperCase() === "HOST" ? "HOST" : "BM";
    let operationalStart = settings.bm_operational_start;
    let operationalEnd = settings.bm_operational_end;
    let operationalDays = settings.bm_operational_days;
    let nationalHolidaysClosed = settings.national_holidays_closed === true;
    let collectiveLeaveClosed = settings.collective_leave_closed === true;
    let scheduleSource = "BM";

    if (approvalStep === "HOST") {
        operationalStart = settings.default_host_operational_start;
        operationalEnd = settings.default_host_operational_end;
        operationalDays = settings.default_host_operational_days;
        scheduleSource = "HOST_DEFAULT";
        const hostResult = await pool.query(
            `SELECT approval_schedule_override,
                    approval_operational_start,
                    approval_operational_end,
                    approval_operational_days,
                    approval_national_holidays_closed,
                    approval_collective_leave_closed
             FROM visitor_hosts
             WHERE host_name = $1
             LIMIT 1`,
            [String(hostName || "").trim()]
        );
        const host = hostResult.rows[0];
        if (host?.approval_schedule_override === true) {
            operationalStart = normalizeApprovalTime(host.approval_operational_start, operationalStart);
            operationalEnd = normalizeApprovalTime(host.approval_operational_end, operationalEnd);
            operationalDays = normalizeApprovalDays(host.approval_operational_days, operationalDays);
            nationalHolidaysClosed = host.approval_national_holidays_closed === null || host.approval_national_holidays_closed === undefined
                ? nationalHolidaysClosed
                : host.approval_national_holidays_closed === true;
            collectiveLeaveClosed = host.approval_collective_leave_closed === null || host.approval_collective_leave_closed === undefined
                ? collectiveLeaveClosed
                : host.approval_collective_leave_closed === true;
            scheduleSource = "HOST_OVERRIDE";
        }
    }

    const holidayResult = await pool.query(
        `SELECT holiday_date::text AS holiday_date, holiday_type
         FROM self_registration_holidays
         WHERE is_active = TRUE
         ORDER BY holiday_date`
    );
    const closedDates = [];
    const openDates = [];
    holidayResult.rows.forEach(holiday => {
        const date = toDateKey(holiday.holiday_date);
        const type = String(holiday.holiday_type || "").toUpperCase();
        if (!date) return;
        if (type === "OPEN_OVERRIDE") openDates.push(date);
        else if (type === "CUSTOM_CLOSED"
            || (type === "NATIONAL_HOLIDAY" && nationalHolidaysClosed)
            || (type === "COLLECTIVE_LEAVE" && collectiveLeaveClosed)) closedDates.push(date);
    });

    return {
        ...computeApprovalWindow({
            now,
            visitStart,
            visitExpiry,
            timeoutMinutes: approvalStep === "HOST" ? settings.host_timeout_minutes : settings.bm_timeout_minutes,
            operationalStart,
            operationalEnd,
            operationalDays,
            closedDates,
            openDates,
            timeZone: settings.approval_timezone
        }),
        step: approvalStep,
        scheduleSource
    };
}

async function createApprovalToken(invitationId, step, settings) {
    const token = crypto.randomBytes(32).toString("hex");
    const timeoutMinutes = step === "HOST"
        ? clampInteger(settings?.host_timeout_minutes, 60, 1, 10080)
        : clampInteger(settings?.bm_timeout_minutes, 60, 1, 10080);
    const target = await pool.query(
        `SELECT i.host, i.approval_timeout_at, h.host_email, h.host_whatsapp
         FROM visitor_invitations i
         LEFT JOIN visitor_hosts h ON h.host_name = i.host
         WHERE i.invitation_id = $1`,
        [invitationId]
    );
    const row = target.rows[0] || {};
    const expiresAt = row.approval_timeout_at || addMinutes(new Date(), timeoutMinutes);

    await pool.query(
        `UPDATE visitor_approval_tokens
         SET status = 'REVOKED'
         WHERE invitation_id = $1 AND approval_step = $2 AND status = 'ACTIVE'`,
        [invitationId, step]
    );

    const result = await pool.query(
        `INSERT INTO visitor_approval_tokens (
            invitation_id,
            approval_step,
            token,
            target_email,
            target_whatsapp,
            expires_at
         )
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING *`,
        [
            invitationId,
            step,
            token,
            String(row.host_email || "").trim() || null,
            String(row.host_whatsapp || "").trim() || null,
            expiresAt
        ]
    );

    return result.rows[0];
}

function getPublicBaseUrl(req) {
    const protocol = req.get("x-forwarded-proto") || req.protocol || "http";
    return `${protocol}://${req.get("host")}`;
}

async function buildApprovalUrl(req, token) {
    const qrSettings = await getQrSettings();
    const configuredBaseUrl = String(qrSettings?.public_base_url || "").trim();
    let baseUrl;
    try {
        baseUrl = new URL(configuredBaseUrl || getPublicBaseUrl(req));
        if (!["https:", "http:"].includes(baseUrl.protocol) || baseUrl.username || baseUrl.password) {
            throw new Error("Invalid public URL");
        }
    } catch {
        throw new Error("Public Base URL tidak valid. Periksa pengaturan di Invitation Booking.");
    }
    const approvalUrl = new URL("/approval.html", baseUrl);
    approvalUrl.searchParams.set("token", token);
    return approvalUrl.toString();
}

async function sendHostApprovalEmail(req, invitation, tokenRow) {
    const targetEmail = String(tokenRow?.target_email || "").trim();
    if (!targetEmail) throw new Error("Email host belum diisi.");

    const settings = await getSmtpSettings();
    const transporter = createSmtpTransport(settings);
    const visitorName = getVisitorDisplayName(invitation);
    const approvalUrl = await buildApprovalUrl(req, tokenRow.token);
    const subject = `Visitor Approval Request - ${visitorName}`;
    const html = `
        <div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;color:#0f172a;">
            <h2 style="margin:0 0 10px;">Visitor Approval Request</h2>
            <p style="color:#475569;">Silakan review permintaan kunjungan berikut.</p>
            <table style="width:100%;border-collapse:collapse;margin:18px 0;">
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Visitor</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(visitorName)}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Company</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(invitation.company_name || "-")}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Host</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(invitation.host || "-")}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Start</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(formatDateTimeText(invitation.start_date))}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Expiry</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(formatDateTimeText(invitation.expiry_date))}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Purpose</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(invitation.purpose_note || "-")}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Jam Operasional Host</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(formatApprovalOperationalText(invitation))}</td></tr>
                <tr><td style="padding:8px;border-bottom:1px solid #e2e8f0;"><b>Countdown Dimulai</b></td><td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtmlText(formatApprovalDateTimeText(invitation.approval_starts_at, invitation.approval_timezone))}</td></tr>
            </table>
            <a href="${approvalUrl}" style="display:inline-block;background:#0d47b5;color:white;text-decoration:none;padding:14px 20px;border-radius:12px;font-weight:800;">Review Approval</a>
            <p style="margin-top:18px;color:#64748b;font-size:13px;">Link ini bersifat unik dan akan expired sesuai pengaturan approval.</p>
        </div>
    `;
    const text = [
        "Visitor Approval Request",
        `Visitor: ${visitorName}`,
        `Company: ${invitation.company_name || "-"}`,
        `Host: ${invitation.host || "-"}`,
        `Start: ${formatDateTimeText(invitation.start_date)}`,
        `Expiry: ${formatDateTimeText(invitation.expiry_date)}`,
        `Purpose: ${invitation.purpose_note || "-"}`,
        `Jam Operasional Host: ${formatApprovalOperationalText(invitation)}`,
        `Countdown Dimulai: ${formatApprovalDateTimeText(invitation.approval_starts_at, invitation.approval_timezone)}`,
        "",
        `Review: ${approvalUrl}`
    ].join("\n");

    return transporter.sendMail({
        from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
        to: targetEmail,
        subject,
        html,
        text
    });
}

async function sendHostApprovalWhatsapp(req, invitation, tokenRow) {
    const targetWhatsapp = normalizeWhatsappPhone(tokenRow?.target_whatsapp);
    if (!targetWhatsapp) throw new Error("WhatsApp host belum diisi.");

    const settings = await getWhatsappSettings();
    const visitorName = getVisitorDisplayName(invitation);
    const approvalUrl = await buildApprovalUrl(req, tokenRow.token);
    const body = [
        "Visitor Approval Request",
        `Visitor: ${visitorName}`,
        `Company: ${invitation.company_name || "-"}`,
        `Host: ${invitation.host || "-"}`,
        `Start: ${formatDateTimeText(invitation.start_date)}`,
        `Expiry: ${formatDateTimeText(invitation.expiry_date)}`,
        `Purpose: ${invitation.purpose_note || "-"}`,
        `Jam Operasional Host: ${formatApprovalOperationalText(invitation)}`,
        `Countdown Dimulai: ${formatApprovalDateTimeText(invitation.approval_starts_at, invitation.approval_timezone)}`,
        "",
        `Review Approval: ${approvalUrl}`
    ].join("\n");

    const result = await sendPlainWhatsappMessage(settings, targetWhatsapp, body);
    await saveActivityLog(
        req,
        "SEND_HOST_APPROVAL_WHATSAPP",
        `Send host approval WhatsApp to ${targetWhatsapp} for ${visitorName} (${invitation.booking_code || "-"})`
    );
    await createSystemNotification(req, {
        channel: "WHATSAPP",
        event_type: "HOST_APPROVAL",
        status: "SUCCESS",
        visitor_name: visitorName,
        target: targetWhatsapp,
        title: "WhatsApp approval host berhasil",
        message: `Link approval host berhasil dikirim via WhatsApp Business API ke ${targetWhatsapp}.`,
        detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id, response: result }
    });
    return result;
}

async function startHostApproval(req, invitation, settings) {
    const tokenRow = await createApprovalToken(invitation.invitation_id, "HOST", settings);
    let emailWarning = null;
    let whatsappWarning = null;
    if (settings.host_email_enabled !== false) {
        try {
            await sendHostApprovalEmail(req, invitation, tokenRow);
            await pool.query(
                "UPDATE visitor_invitations SET sent_email_time = NOW(), modified_time = NOW() WHERE invitation_id = $1",
                [invitation.invitation_id]
            );
        } catch (error) {
            emailWarning = error.message;
            await createSystemNotification(req, {
                channel: "EMAIL_HOST",
                event_type: "HOST_APPROVAL",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                target: tokenRow.target_email || null,
                title: "Email approval host gagal",
                message: error.message,
                detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id }
            });
        }
    }
    if (settings.host_whatsapp_enabled === true) {
        try {
            await sendHostApprovalWhatsapp(req, invitation, tokenRow);
            await pool.query(
                "UPDATE visitor_invitations SET sent_whatsapp_time = NOW(), modified_time = NOW() WHERE invitation_id = $1",
                [invitation.invitation_id]
            );
        } catch (error) {
            whatsappWarning = error.message;
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "HOST_APPROVAL",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                target: tokenRow.target_whatsapp || null,
                title: "WhatsApp approval host gagal",
                message: error.message,
                detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id }
            });
        }
    }
    return { token: tokenRow, email_warning: emailWarning, whatsapp_warning: whatsappWarning };
}

function invitationTemplateData(invitation) {
    const visitorName = `${invitation?.first_name || ""} ${invitation?.second_name || ""}`.trim() || "Visitor";
    return {
        booking_code: invitation?.booking_code || "-",
        visitor_name: visitorName,
        first_name: invitation?.first_name || "",
        second_name: invitation?.second_name || "",
        company_name: invitation?.company_name || "-",
        host: invitation?.host || "-",
        start: formatDateTimeText(invitation?.start_date),
        expiry: formatDateTimeText(invitation?.expiry_date),
        permission_group: invitation?.permission_group || "-",
        purpose_note: invitation?.purpose_note || "-"
    };
}

function buildBookingInvitationMessage(invitation) {
    const data = invitationTemplateData(invitation);
    return [
        "Visitor Invitation",
        `Booking Code: ${data.booking_code}`,
        `Nama: ${data.visitor_name}`,
        `Company: ${data.company_name}`,
        `Host: ${data.host}`,
        `Start: ${data.start}`,
        `Expiry: ${data.expiry}`,
        `Keperluan: ${data.purpose_note}`,
        "",
        "Tunjukkan booking code ini ke operator saat datang."
    ].join("\n");
}

async function sendBookingInvitationEmail(req, invitation) {
    const targetEmail = String(invitation?.email_address || "").trim();
    if (!targetEmail) throw new Error("Email visitor belum diisi.");

    const settings = await getSmtpSettings();
    const transporter = createSmtpTransport(settings);
    const data = invitationTemplateData(invitation);
    const subject = buildTemplate(settings.invitation_email_subject || "Visitor Invitation - {{booking_code}}", data);
    const body = buildTemplate(settings.invitation_email_body || buildBookingInvitationMessage(invitation), data);
    const qrDataUrl = await QRCode.toDataURL(data.booking_code, {
        errorCorrectionLevel: "H",
        margin: 2,
        width: 480
    });
    const qrBuffer = Buffer.from(qrDataUrl.replace(/^data:image\/png;base64,/, ""), "base64");

    await transporter.sendMail({
        from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
        to: targetEmail,
        subject,
        text: body,
        attachments: [
            {
                filename: `Booking_QR_${data.booking_code}.png`,
                content: qrBuffer,
                contentType: "image/png"
            }
        ]
    });

    await pool.query(
        "UPDATE visitor_invitations SET sent_email_time = NOW(), modified_by = $1, modified_time = NOW() WHERE invitation_id = $2",
        [getCurrentUsername(req), invitation.invitation_id]
    );

        await saveActivityLog(
            req,
            "SEND_INVITATION_EMAIL",
            `Send booking invitation ${data.booking_code} to ${targetEmail}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "INVITATION",
            status: "SUCCESS",
            visitor_name: data.visitor_name,
            target: targetEmail,
            title: "Email invitation berhasil",
            message: `Booking code ${data.booking_code} berhasil dikirim ke ${targetEmail}.`,
            detail: { booking_code: data.booking_code }
        });
}

async function getInvitationByBookingCode(code) {
    const bookingCode = normalizeBookingCode(code);
    if (!bookingCode) return null;
    const result = await pool.query("SELECT * FROM visitor_invitations WHERE booking_code = $1 LIMIT 1", [bookingCode]);
    return result.rows[0] || null;
}

async function validatePendingInvitationByCode(code) {
    const invitation = await getInvitationByBookingCode(code);
    if (!invitation) {
        return { ok: false, status: 404, message: "Booking code tidak ditemukan." };
    }
    if (invitation.status !== "PENDING") {
        return { ok: false, status: 400, message: `Booking code sudah berstatus ${invitation.status}.` };
    }
    if (invitation.created_by === "SELF_REGISTRATION" && await findActiveIdentityBlacklist(invitation.identity_number)) {
        return { ok: false, status: 403, message: "Visitor masuk Blacklist aktif. Check-In dari Self Registration diblokir." };
    }
    if (invitation.expiry_date && new Date(invitation.expiry_date) < new Date()) {
        await pool.query(
            "UPDATE visitor_invitations SET status = 'EXPIRED', modified_time = NOW() WHERE invitation_id = $1",
            [invitation.invitation_id]
        );
        return { ok: false, status: 400, message: "Booking code sudah expired." };
    }
    return { ok: true, invitation };
}

async function getWhatsappSettings() {
    const result = await pool.query("SELECT * FROM whatsapp_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function isVisitorRegistrationApiMode() {
    try {
        const result = await pool.query("SELECT operation_mode FROM maintenance_settings WHERE setting_id = 1");
        return String(result.rows[0]?.operation_mode || "VISITOR_REGISTRATION").toUpperCase() !== "MIDDLEWARE_SYNC";
    } catch (error) {
        return true;
    }
}

function normalizeWhatsappPhone(phone) {
    let targetPhone = String(phone || "").replace(/[^0-9+]/g, "").replace(/^\+/, "");
    if (targetPhone.startsWith("0")) {
        targetPhone = `62${targetPhone.slice(1)}`;
    }
    return targetPhone;
}

function describeFetchFailure(error) {
    const cause = error?.cause || {};
    return [cause.code, cause.message, error?.message]
        .map(value => String(value || "").trim())
        .filter((value, index, values) => value && values.indexOf(value) === index)
        .join(" - ") || "koneksi API WhatsApp terputus";
}

const VPSMURAH_CLOUDCHAT_BASE_URL = "https://my.vpsmurah.co.id/api/svc/v1";

function normalizeWhatsappProvider(provider) {
    const value = String(provider || "meta").trim().toLowerCase();
    if (["vpsmurah", "vpsmurah_cloudchat", "cloudchat"].includes(value)) return "vpsmurah";
    return value;
}

function getCloudchatBaseUrl(settings) {
    return String(settings?.base_url || VPSMURAH_CLOUDCHAT_BASE_URL).trim().replace(/\/+$/, "");
}

function assertWhatsappApiSettings(settings) {
    const provider = normalizeWhatsappProvider(settings?.provider);
    if (!["meta", "vpsmurah"].includes(provider)) {
        throw new Error("Provider WhatsApp belum didukung.");
    }
    if (!settings?.access_token) {
        throw new Error(provider === "vpsmurah" ? "API Key VPSMurah CloudChat wajib diisi." : "Access Token WhatsApp wajib diisi.");
    }
    if (provider === "meta" && !settings.phone_number_id) {
        throw new Error("Phone Number ID WhatsApp wajib diisi.");
    }
    if (provider === "vpsmurah" && !/^https:\/\//i.test(getCloudchatBaseUrl(settings))) {
        throw new Error("Base URL VPSMurah CloudChat harus menggunakan HTTPS.");
    }
    return provider;
}

async function readWhatsappApiResponse(response) {
    const raw = await response.text();
    if (!raw) return {};
    try {
        return JSON.parse(raw);
    } catch (error) {
        return { message: raw };
    }
}

function whatsappApiError(result, fallback) {
    const errorValue = result?.error;
    if (typeof errorValue === "string" && errorValue.trim()) return errorValue.trim();
    return String(errorValue?.message || result?.message || result?.detail || fallback).trim();
}

async function sendCloudchatRequest(settings, endpointPath, payload) {
    let response;
    try {
        response = await fetch(`${getCloudchatBaseUrl(settings)}/${String(endpointPath).replace(/^\/+/, "")}`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${settings.access_token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
    } catch (error) {
        const uncertainError = new Error(`Respons VPSMurah CloudChat tidak diterima (${describeFetchFailure(error)}). Pesan mungkin tetap terkirim; periksa WhatsApp sebelum retry.`);
        uncertainError.deliveryStatus = "UNCONFIRMED";
        throw uncertainError;
    }

    const result = await readWhatsappApiResponse(response);
    if (!response.ok || result?.success === false || result?.ok === false || result?.status === false) {
        throw new Error(whatsappApiError(result, `VPSMurah CloudChat API error ${response.status}`));
    }
    return result;
}

async function sendWhatsappQrMedia(settings, { toPhone, caption, qrValue, publicImageUrl, imageBuffer = null }) {
    const provider = assertWhatsappApiSettings(settings);
    if (provider === "vpsmurah") {
        if (!publicImageUrl) {
            throw new Error("Public Base URL QR wajib diisi agar VPSMurah CloudChat dapat mengambil gambar QR.");
        }
        const response = await sendCloudchatRequest(settings, "/wa-api/media", {
            to: toPhone,
            type: "image",
            url: publicImageUrl,
            caption: String(caption || "")
        });
        return { provider: "VPSMURAH_CLOUDCHAT", response, mediaUrl: publicImageUrl };
    }

    const apiVersion = settings.api_version || "v20.0";
    const baseUrl = `https://graph.facebook.com/${apiVersion}/${settings.phone_number_id}`;
    const resolvedImageBuffer = imageBuffer || await QRCode.toBuffer(String(qrValue || ""), {
        errorCorrectionLevel: "H",
        margin: 2,
        width: 480
    });
    const uploadForm = new FormData();
    uploadForm.append("messaging_product", "whatsapp");
    uploadForm.append("type", "image/png");
    uploadForm.append("file", new Blob([resolvedImageBuffer], { type: "image/png" }), `QR_${qrValue || "visitor"}.png`);

    let uploadResponse;
    try {
        uploadResponse = await fetch(`${baseUrl}/media`, {
            method: "POST",
            headers: { Authorization: `Bearer ${settings.access_token}` },
            body: uploadForm
        });
    } catch (error) {
        throw new Error(`Upload media WhatsApp gagal karena koneksi: ${describeFetchFailure(error)}`);
    }
    const uploadResult = await readWhatsappApiResponse(uploadResponse);
    if (!uploadResponse.ok || !uploadResult.id) {
        throw new Error(whatsappApiError(uploadResult, "Upload media WhatsApp gagal."));
    }

    let sendResponse;
    try {
        sendResponse = await fetch(`${baseUrl}/messages`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${settings.access_token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                messaging_product: "whatsapp",
                to: toPhone,
                type: "image",
                image: { id: uploadResult.id, caption: String(caption || "") }
            })
        });
    } catch (error) {
        const uncertainError = new Error(`Respons Meta tidak diterima (${describeFetchFailure(error)}). Pesan mungkin tetap terkirim; periksa WhatsApp sebelum retry.`);
        uncertainError.deliveryStatus = "UNCONFIRMED";
        throw uncertainError;
    }
    const sendResult = await readWhatsappApiResponse(sendResponse);
    if (!sendResponse.ok) {
        throw new Error(whatsappApiError(sendResult, "Kirim WhatsApp API gagal."));
    }
    return { provider: "META", response: sendResult };
}

async function sendPlainWhatsappMessage(settings, toPhone, body) {
    if (!settings || settings.send_mode !== "api") {
        throw new Error("Mode WhatsApp API belum aktif.");
    }
    const provider = assertWhatsappApiSettings(settings);

    const targetPhone = normalizeWhatsappPhone(toPhone);
    if (!targetPhone) {
        throw new Error("Nomor WhatsApp tujuan belum diisi.");
    }

    if (provider === "vpsmurah") {
        return sendCloudchatRequest(settings, "/wa-api/messages", {
            to: targetPhone,
            text: String(body || "")
        });
    }

    const apiVersion = settings.api_version || "v20.0";
    const response = await fetch(`https://graph.facebook.com/${apiVersion}/${settings.phone_number_id}/messages`, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${settings.access_token}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            messaging_product: "whatsapp",
            to: targetPhone,
            type: "text",
            text: { body: String(body || "") }
        })
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(result?.error?.message || result?.message || `WhatsApp API error ${response.status}`);
    }

    return result;
}

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function normalizeTime(value, fallback = "18:00") {
    const text = String(value || "").trim();
    return /^\d{2}:\d{2}$/.test(text) ? text : fallback;
}

function normalizeDate(value) {
    if (value instanceof Date) return localDateKey(value);
    const text = String(value || "").trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.slice(0, 10);
    return localDateKey();
}

function normalizeScheduleType(value, fallback = "ONCE") {
    const type = String(value || fallback).trim().toUpperCase();
    return ["ONCE", "DAILY", "MONTHLY", "YEARLY"].includes(type) ? type : fallback;
}

function pad2(value) {
    return String(value).padStart(2, "0");
}

function localDateKey(date = new Date()) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

async function saveActivityLog(req, activityType, description) {
    try {
        await pool.query(
            `INSERT INTO activity_logs
            (
                username,
                activity_type,
                description,
                ip_address
            )
            VALUES ($1,$2,$3,$4)`,
            [
                getCurrentUsername(req),
                activityType,
                description,
                req.ip
            ]
        );
    } catch (error) {
        console.log("SAVE VISITOR ACTIVITY LOG ERROR:", error.message);
    }
}

function normalizeWatchlistType(value) {
    const type = String(value || "").trim().toUpperCase();
    return type === "WHITELIST" ? "WHITELIST" : "BLACKLIST";
}

function normalizeWatchlistMode(value) {
    const mode = String(value || "").trim().toUpperCase();
    return ["WARNING_ONLY", "BLOCK_CHECKIN", "REQUIRE_SUPERADMIN"].includes(mode) ? mode : "WARNING_ONLY";
}

function normalizeComparable(value) {
    return String(value || "").trim();
}

function normalizePhoneComparable(value) {
    return String(value || "").replace(/[^0-9]/g, "");
}

function getWatchlistVisitorName(payload = {}) {
    return String(payload.visitor_name || `${payload.first_name || ""} ${payload.second_name || ""}`.trim() || "").trim();
}

async function getWatchlistSettings() {
    const result = await pool.query("SELECT * FROM visitor_watchlist_settings WHERE setting_id = 1");
    return result.rows[0] || { blacklist_mode: "WARNING_ONLY", notify_security: true };
}

function watchlistEntryActiveSql(alias = "") {
    const prefix = alias ? `${alias}.` : "";
    return `${prefix}is_active = TRUE AND (${prefix}start_date IS NULL OR ${prefix}start_date <= NOW()) AND (${prefix}expiry_date IS NULL OR ${prefix}expiry_date >= NOW())`;
}

async function findVisitorWatchlistMatches(payload = {}) {
    const identityNumber = normalizeComparable(payload.identity_number);
    const email = normalizeComparable(payload.email_address || payload.email).toLowerCase();
    const phone = normalizePhoneComparable(payload.phone_number || payload.telephone_number);
    const visitorName = getWatchlistVisitorName(payload).toLowerCase();
    const params = [];
    const filters = [];

    if (identityNumber) {
        params.push(identityNumber);
        filters.push(`identity_number = $${params.length}`);
    }
    if (email) {
        params.push(email);
        filters.push(`LOWER(email_address) = $${params.length}`);
    }
    if (phone) {
        params.push(phone);
        filters.push(`REGEXP_REPLACE(COALESCE(phone_number, ''), '[^0-9]', '', 'g') = $${params.length}`);
    }
    if (visitorName) {
        params.push(`%${visitorName}%`);
        filters.push(`LOWER(COALESCE(visitor_name, '')) LIKE $${params.length}`);
    }

    if (!filters.length) return [];

    const identityOrder = identityNumber ? "CASE WHEN identity_number = $1 THEN 0 ELSE 1 END," : "";
    const result = await pool.query(
        `SELECT *
         FROM visitor_watchlist
         WHERE ${watchlistEntryActiveSql()}
           AND (${filters.join(" OR ")})
         ORDER BY
           CASE list_type WHEN 'BLACKLIST' THEN 0 ELSE 1 END,
           ${identityOrder}
           watchlist_id DESC`,
        params
    );

    return result.rows.map(row => {
        const matchTypes = [];
        if (identityNumber && String(row.identity_number || "").trim() === identityNumber) matchTypes.push("ID_NUMBER");
        if (email && String(row.email_address || "").trim().toLowerCase() === email) matchTypes.push("EMAIL");
        if (phone && normalizePhoneComparable(row.phone_number) === phone) matchTypes.push("PHONE");
        if (visitorName && String(row.visitor_name || "").trim().toLowerCase().includes(visitorName)) matchTypes.push("NAME");
        return { ...row, match_types: matchTypes };
    });
}

async function findActiveIdentityBlacklist(identityNumber) {
    const matches = await findVisitorWatchlistMatches({ identity_number: identityNumber });
    return matches.find(entry => entry.list_type === "BLACKLIST" && entry.match_types.includes("ID_NUMBER")) || null;
}

async function discardRejectedSelfRegistrationUploads(req) {
    const uploadRoot = path.resolve("uploads");
    const files = Array.isArray(req.files)
        ? req.files
        : Object.values(req.files || {}).flat();
    for (const file of files) {
        if (!file.path) continue;
        const target = path.resolve(file.path);
        if (path.dirname(target) !== uploadRoot) continue;
        try {
            await fs.unlink(target);
        } catch (error) {
            if (error.code !== "ENOENT") console.warn("Rejected self-registration upload cleanup failed:", error.code);
        }
    }
}

function summarizeWatchlistDecision(matches = [], settings = {}) {
    const exactBlacklist = matches.find(row => row.list_type === "BLACKLIST" && row.match_types?.some(type => ["ID_NUMBER", "EMAIL", "PHONE"].includes(type)));
    const possibleBlacklist = matches.find(row => row.list_type === "BLACKLIST");
    const exactWhitelist = matches.find(row => row.list_type === "WHITELIST" && row.match_types?.some(type => ["ID_NUMBER", "EMAIL", "PHONE"].includes(type)));
    const mode = normalizeWatchlistMode(settings.blacklist_mode);
    const primary = exactBlacklist || exactWhitelist || possibleBlacklist || matches[0] || null;
    const status = exactBlacklist ? "BLACKLIST" : exactWhitelist ? "WHITELIST" : possibleBlacklist ? "BLACKLIST" : "NORMAL";

    return {
        status,
        mode,
        blocked: status === "BLACKLIST" && mode === "BLOCK_CHECKIN" && !!exactBlacklist,
        require_approval: status === "BLACKLIST" && mode === "REQUIRE_SUPERADMIN" && !!exactBlacklist,
        primary,
        matches
    };
}

router.get("/api/system-notifications/unread-count", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const result = await pool.query(
            "SELECT COUNT(*)::int AS unread_count FROM system_notifications WHERE is_read = FALSE"
        );
        res.json({ success: true, unread_count: result.rows[0]?.unread_count || 0 });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/system-notifications", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 500);
        const filters = [];
        const params = [];

        if (req.query.unread_only === "true") {
            filters.push("is_read = FALSE");
        }

        if (String(req.query.read_status || "").toUpperCase() === "READ") {
            filters.push("is_read = TRUE");
        } else if (String(req.query.read_status || "").toUpperCase() === "UNREAD") {
            filters.push("is_read = FALSE");
        }

        if (req.query.channel) {
            params.push(String(req.query.channel).toUpperCase());
            filters.push(`channel = $${params.length}`);
        }

        if (req.query.status) {
            params.push(String(req.query.status).toUpperCase());
            filters.push(`status = $${params.length}`);
        }

        if (req.query.search) {
            params.push(`%${String(req.query.search).trim()}%`);
            filters.push(`(title ILIKE $${params.length} OR message ILIKE $${params.length} OR visitor_name ILIKE $${params.length} OR target ILIKE $${params.length})`);
        }

        params.push(limit);
        const result = await pool.query(
            `SELECT *
             FROM system_notifications
             ${filters.length ? `WHERE ${filters.join(" AND ")}` : ""}
             ORDER BY created_time DESC
             LIMIT $${params.length}`,
            params
        );
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/system-notifications/mark-read", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationId = Number(req.body.notification_id || 0);
        if (notificationId) {
            await pool.query(
                `UPDATE system_notifications
                 SET is_read = TRUE,
                     read_by = $1,
                     read_time = NOW()
                 WHERE notification_id = $2`,
                [getCurrentUsername(req), notificationId]
            );
        } else {
            await pool.query(
                `UPDATE system_notifications
                 SET is_read = TRUE,
                     read_by = $1,
                     read_time = NOW()
                 WHERE is_read = FALSE`,
                [getCurrentUsername(req)]
            );
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/system-notifications/:id/retry-api", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationResult = await pool.query(
            "SELECT * FROM system_notifications WHERE notification_id = $1",
            [req.params.id]
        );
        const notification = notificationResult.rows[0];

        if (!notification) {
            return res.status(404).json({ success: false, message: "Notification tidak ditemukan." });
        }

        const channel = String(notification.channel || "").toUpperCase();
        const provider = String(notification.provider_type || channel.replace(/^API_/, "") || "").toUpperCase();
        const triggerEvent = String(notification.event_type || "").toUpperCase();
        const detail = notification.detail || {};
        const configId = detail.config_id ? Number(detail.config_id) : null;

        if (!channel.startsWith("API_") || !provider || notification.status !== "FAILED") {
            return res.status(400).json({ success: false, message: "Retry hanya tersedia untuk notification API yang statusnya FAILED." });
        }
        if (!notification.visitor_id) {
            return res.status(400).json({ success: false, message: "Visitor ID tidak tersedia untuk retry API." });
        }
        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Event API tidak tersedia untuk retry." });
        }

        const visitorResult = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [notification.visitor_id]);
        const visitor = visitorResult.rows[0];
        if (!visitor) {
            return res.status(404).json({ success: false, message: "Visitor tidak ditemukan." });
        }

        await saveActivityLog(
            req,
            "RETRY_THIRD_PARTY_API",
            `Retry ${provider} ${triggerEvent} API for ${getVisitorDisplayName(visitor)} (Visitor ID ${visitor.visitor_id}) from notification ${notification.notification_id}`
        );

        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, visitor, {
            providerType: provider,
            configId
        });
        const retryResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === provider);
        const ok = retryResults.some(item => item.success === true);

        res.json({
            success: ok,
            message: ok ? `Retry ${provider} ${triggerEvent} berhasil.` : `Retry ${provider} ${triggerEvent} gagal. Cek Log Activity API dan notification terbaru.`,
            data: retryResults,
            api_results: apiResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

function normalizeDeliveryMonitorStatus(status) {
    const normalized = String(status || "INFO").toUpperCase();
    if (normalized === "SENT") return "SUCCESS";
    if (normalized === "SENDING") return "PROCESSING";
    return normalized;
}

async function ensureDeliveryMonitoringSchema() {
    await pool.query(`
        CREATE TABLE IF NOT EXISTS delivery_monitor_hidden (
            hidden_id SERIAL PRIMARY KEY,
            source_type VARCHAR(40) NOT NULL,
            source_id TEXT NOT NULL,
            hidden_by VARCHAR(120),
            hidden_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(source_type, source_id)
        )
    `);
}

function deliverySourceKey(item) {
    return `${String(item.source_type || "").toUpperCase()}::${String(item.source_id || "")}`;
}

function buildDeliveryMonitorItem(row, sourceType) {
    const detail = row.detail && typeof row.detail === "object" ? row.detail : {};
    return {
        source_type: sourceType,
        source_id: row.source_id,
        notification_id: row.notification_id || null,
        invitation_id: row.invitation_id || detail.invitation_id || null,
        visitor_id: row.visitor_id || null,
        channel: String(row.channel || "-").toUpperCase(),
        event_type: String(row.event_type || "-").toUpperCase(),
        status: normalizeDeliveryMonitorStatus(row.status),
        raw_status: String(row.status || "-").toUpperCase(),
        visitor_name: row.visitor_name || "-",
        target: row.target || "-",
        title: row.title || "-",
        message: row.message || row.error_message || "-",
        detail,
        created_time: row.created_time || null,
        updated_time: row.updated_time || row.created_time || null
    };
}

function matchesDeliveryMonitorFilter(item, { channel, status, search }) {
    if (channel && item.channel !== channel) return false;
    if (status && item.status !== status) return false;
    if (search) {
        const haystack = [
            item.channel,
            item.event_type,
            item.status,
            item.visitor_name,
            item.target,
            item.title,
            item.message
        ].join(" ").toLowerCase();
        if (!haystack.includes(search)) return false;
    }
    return true;
}

router.get("/api/delivery-monitoring", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        await selfRegistrationWorkflow.ensureSchema();
        await ensureDeliveryMonitoringSchema();

        const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 120, 20), 500);
        const channel = String(req.query.channel || "").trim().toUpperCase();
        const status = String(req.query.status || "").trim().toUpperCase();
        const search = String(req.query.search || "").trim().toLowerCase();
        const monitoredChannels = ["EMAIL_VISITOR", "EMAIL_HOST", "WHATSAPP", "WHATSAPP_HOST", "HOST_NOTIFICATION"];
        const hiddenResult = await pool.query("SELECT source_type, source_id, hidden_at FROM delivery_monitor_hidden");
        const hiddenMap = new Map(hiddenResult.rows.map(row => [
            `${String(row.source_type || "").toUpperCase()}::${String(row.source_id || "")}`,
            row.hidden_at ? new Date(row.hidden_at).getTime() : 0
        ]));

        const [notificationResult, jobResult] = await Promise.all([
            pool.query(
                `SELECT notification_id::text AS source_id,
                        notification_id,
                        NULL::integer AS invitation_id,
                        channel,
                        event_type,
                        status,
                        visitor_id,
                        visitor_name,
                        target,
                        title,
                        message,
                        detail,
                        created_time,
                        created_time AS updated_time
                 FROM system_notifications
                 WHERE channel = ANY($1::text[])
                 ORDER BY created_time DESC
                 LIMIT 300`,
                [monitoredChannels]
            ),
            pool.query(
                `SELECT *
                 FROM (
                    SELECT ('JOB_EMAIL_' || j.invitation_id)::text AS source_id,
                           NULL::integer AS notification_id,
                           j.invitation_id,
                           j.visitor_id,
                           'EMAIL_VISITOR'::text AS channel,
                           'ACCESS_QR'::text AS event_type,
                           COALESCE(j.email_status, 'PENDING') AS status,
                           CONCAT_WS(' ', i.first_name, i.second_name) AS visitor_name,
                           i.email_address AS target,
                           'Antrean Email QR Visitor'::text AS title,
                           COALESCE(j.email_error, 'Email QR otomatis untuk visitor') AS message,
                           jsonb_build_object('booking_code', i.booking_code, 'card_number', j.qr_value) AS detail,
                           j.created_at AS created_time,
                           j.updated_at AS updated_time
                    FROM self_registration_access_jobs j
                    JOIN visitor_invitations i ON i.invitation_id = j.invitation_id
                    UNION ALL
                    SELECT ('JOB_WHATSAPP_' || j.invitation_id)::text AS source_id,
                           NULL::integer AS notification_id,
                           j.invitation_id,
                           j.visitor_id,
                           'WHATSAPP'::text AS channel,
                           'ACCESS_QR'::text AS event_type,
                           COALESCE(j.whatsapp_status, 'PENDING') AS status,
                           CONCAT_WS(' ', i.first_name, i.second_name) AS visitor_name,
                           i.phone_number AS target,
                           'Antrean WhatsApp QR Visitor'::text AS title,
                           COALESCE(j.whatsapp_error, 'WhatsApp QR otomatis untuk visitor') AS message,
                           jsonb_build_object('booking_code', i.booking_code, 'card_number', j.qr_value) AS detail,
                           j.created_at AS created_time,
                           j.updated_at AS updated_time
                    FROM self_registration_access_jobs j
                    JOIN visitor_invitations i ON i.invitation_id = j.invitation_id
                 ) queue_rows
                 ORDER BY updated_time DESC
                 LIMIT 300`
            )
        ]);

        const queueKeys = new Set(jobResult.rows.map(row => `${row.invitation_id}:${String(row.channel || "").toUpperCase()}`));
        const notificationRows = notificationResult.rows.filter(row => {
            const detail = row.detail && typeof row.detail === "object" ? row.detail : {};
            const invitationId = Number(row.invitation_id || detail.invitation_id || 0);
            const eventType = String(row.event_type || "").toUpperCase();
            const channelName = String(row.channel || "").toUpperCase();
            return !(eventType === "ACCESS_QR" && invitationId && queueKeys.has(`${invitationId}:${channelName}`));
        });

        const items = [
            ...jobResult.rows.map(row => buildDeliveryMonitorItem(row, "QUEUE")),
            ...notificationRows.map(row => buildDeliveryMonitorItem(row, "NOTIFICATION"))
        ]
            .filter(item => {
                const hiddenAt = hiddenMap.get(deliverySourceKey(item));
                if (!hiddenAt) return true;
                const itemTime = new Date(item.updated_time || item.created_time || 0).getTime();
                return itemTime > hiddenAt;
            })
            .filter(item => item.status !== "OPENED")
            .filter(item => matchesDeliveryMonitorFilter(item, { channel, status, search }))
            .sort((a, b) => new Date(b.updated_time || b.created_time || 0) - new Date(a.updated_time || a.created_time || 0))
            .slice(0, limit);

        const summary = items.reduce((acc, item) => {
            acc.total += 1;
            if (item.status === "PENDING") acc.pending += 1;
            else if (item.status === "PROCESSING") acc.processing += 1;
            else if (item.status === "SUCCESS") acc.success += 1;
            else if (item.status === "FAILED") acc.failed += 1;
            else if (item.status === "UNCONFIRMED") acc.unconfirmed += 1;
            else if (item.status === "SKIPPED") acc.skipped += 1;
            return acc;
        }, { total: 0, pending: 0, processing: 0, success: 0, failed: 0, unconfirmed: 0, skipped: 0 });

        res.json({ success: true, data: items, summary });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function parseDeliverySource(body = {}) {
    return {
        sourceType: String(body.source_type || "").trim().toUpperCase(),
        sourceId: String(body.source_id || "").trim(),
        channel: String(body.channel || "").trim().toUpperCase(),
        eventType: String(body.event_type || "").trim().toUpperCase(),
        invitationId: Number(body.invitation_id || 0),
        visitorId: Number(body.visitor_id || 0),
        notificationId: Number(body.notification_id || 0)
    };
}

async function hideDeliveryMonitoringItem(req, sourceType, sourceId) {
    await ensureDeliveryMonitoringSchema();
    await pool.query(
        `INSERT INTO delivery_monitor_hidden (source_type, source_id, hidden_by, hidden_at)
         VALUES ($1, $2, $3, NOW())
         ON CONFLICT (source_type, source_id)
         DO UPDATE SET hidden_by = EXCLUDED.hidden_by, hidden_at = NOW()`,
        [sourceType, sourceId, getCurrentUsername(req)]
    );
}

async function queueDeliveryRetry(req, payload) {
    if (!payload.invitationId) throw new Error("Invitation ID tidak tersedia untuk retry antrean.");
    if (payload.sourceId.startsWith("JOB_EMAIL_") || payload.channel === "EMAIL_VISITOR") {
        await pool.query(
            "UPDATE self_registration_access_jobs SET email_status='PENDING', email_error=NULL, updated_at=NOW() WHERE invitation_id=$1",
            [payload.invitationId]
        );
    } else if (payload.sourceId.startsWith("JOB_WHATSAPP_") || payload.channel === "WHATSAPP") {
        await pool.query(
            "UPDATE self_registration_access_jobs SET whatsapp_status='PENDING', whatsapp_error=NULL, updated_at=NOW() WHERE invitation_id=$1",
            [payload.invitationId]
        );
    } else {
        throw new Error("Channel antrean tidak dikenali.");
    }

    setImmediate(() => selfRegistrationWorkflow.processJob(payload.invitationId).catch(error => {
        console.error("DELIVERY QUEUE RETRY:", error.message);
    }));
}

async function retryFailedDeliveryNotification(req, payload) {
    const notificationResult = await pool.query(
        "SELECT * FROM system_notifications WHERE notification_id = $1",
        [payload.notificationId || payload.sourceId]
    );
    const notification = notificationResult.rows[0];
    if (!notification) throw new Error("Notification gagal tidak ditemukan.");
    if (String(notification.status || "").toUpperCase() !== "FAILED") {
        throw new Error("Hanya status gagal yang bisa di-retry.");
    }

    const channel = payload.channel || String(notification.channel || "").toUpperCase();
    const eventType = payload.eventType || String(notification.event_type || "").toUpperCase();
    const detail = notification.detail || {};
    const invitationId = payload.invitationId || Number(detail.invitation_id || 0);
    const visitorId = payload.visitorId || Number(notification.visitor_id || 0);

    if (invitationId && ["ACCESS_QR", "QR_SHARE"].includes(eventType) && ["EMAIL_VISITOR", "WHATSAPP"].includes(channel)) {
        await queueDeliveryRetry(req, { ...payload, invitationId, channel });
        return;
    }

    if (visitorId && eventType === "CHECKIN" && ["EMAIL_HOST", "WHATSAPP_HOST", "HOST_NOTIFICATION"].includes(channel)) {
        const visitor = (await pool.query("SELECT * FROM visitor_registration WHERE visitor_id=$1", [visitorId])).rows[0];
        if (!visitor) throw new Error("Visitor tidak ditemukan untuk retry notifikasi host.");
        if (channel === "EMAIL_HOST") await sendHostCheckinEmail(req, visitor, { only_channel: "EMAIL" });
        else if (channel === "WHATSAPP_HOST") await sendHostCheckinEmail(req, visitor, { only_channel: "WHATSAPP" });
        else await sendHostCheckinEmail(req, visitor);
        return;
    }

    if (invitationId && eventType === "HOST_APPROVAL" && ["EMAIL_HOST", "WHATSAPP"].includes(channel)) {
        const invitation = (await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id=$1", [invitationId])).rows[0];
        if (!invitation) throw new Error("Invitation tidak ditemukan untuk retry approval host.");
        const tokenRow = (await pool.query(
            `SELECT *
             FROM visitor_approval_tokens
             WHERE invitation_id=$1
               AND approval_step='HOST'
               AND status='ACTIVE'
             ORDER BY token_id DESC
             LIMIT 1`,
            [invitationId]
        )).rows[0];
        if (!tokenRow) throw new Error("Token approval host aktif tidak ditemukan.");
        if (channel === "EMAIL_HOST") await sendHostApprovalEmail(req, invitation, tokenRow);
        else await sendHostApprovalWhatsapp(req, invitation, tokenRow);
        return;
    }

    if (invitationId && ["INVITATION", "INVITATION_IMPORT"].includes(eventType) && channel === "EMAIL_VISITOR") {
        const invitation = (await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id=$1", [invitationId])).rows[0];
        if (!invitation) throw new Error("Invitation tidak ditemukan untuk retry email booking.");
        await sendBookingInvitationEmail(req, invitation);
        return;
    }

    if (visitorId && ["QR_SHARE", "ACCESS_QR"].includes(eventType) && ["EMAIL_VISITOR", "WHATSAPP"].includes(channel)) {
        const visitor = (await pool.query("SELECT * FROM visitor_registration WHERE visitor_id=$1", [visitorId])).rows[0];
        if (!visitor) throw new Error("Visitor tidak ditemukan untuk retry QR visitor.");
        if (channel === "EMAIL_VISITOR") await sendVisitorCheckinQrEmail(req, visitor);
        else await sendVisitorCheckinQrWhatsapp(req, visitor);
        return;
    }

    if (visitorId && eventType.startsWith("EXTENSION_") && ["EMAIL_VISITOR", "WHATSAPP", "EMAIL_HOST", "WHATSAPP_HOST"].includes(channel)) {
        const requestId = Number(detail.request_id || 0);
        const extensionRequest = requestId ? await getExtensionRequest(requestId) : null;
        if (!extensionRequest) throw new Error("Permintaan perpanjangan tidak ditemukan untuk retry.");
        if (eventType === "EXTENSION_APPROVAL" && ["EMAIL_HOST", "WHATSAPP_HOST"].includes(channel)) {
            await sendExtensionHostApproval(req, extensionRequest, { only_channel: channel === "EMAIL_HOST" ? "EMAIL" : "WHATSAPP" });
        } else if (["EMAIL_VISITOR", "WHATSAPP"].includes(channel)) {
            const kind = eventType.replace(/^EXTENSION_/, "") || "REMINDER";
            await sendExtensionVisitorMessage(req, extensionRequest, kind, { only_channel: channel === "EMAIL_VISITOR" ? "EMAIL" : "WHATSAPP" });
        } else {
            throw new Error("Channel extension tidak sesuai dengan jenis notifikasi.");
        }
        return;
    }

    throw new Error("Retry belum tersedia untuk jenis pengiriman ini.");
}

router.post("/api/delivery-monitoring/retry", async (req, res) => {
    try {
        const payload = parseDeliverySource(req.body || {});
        if (!payload.sourceType || !payload.sourceId) {
            return res.status(400).json({ success: false, message: "Source monitoring tidak lengkap." });
        }

        if (payload.sourceType === "QUEUE") {
            await queueDeliveryRetry(req, payload);
        } else if (payload.sourceType === "NOTIFICATION") {
            await retryFailedDeliveryNotification(req, payload);
        } else {
            return res.status(400).json({ success: false, message: "Source monitoring tidak dikenali." });
        }

        if (payload.sourceType === "NOTIFICATION") {
            await hideDeliveryMonitoringItem(req, payload.sourceType, payload.sourceId);
        }
        res.json({ success: true, message: "Retry pengiriman sudah diproses." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/delivery-monitoring/delete", async (req, res) => {
    try {
        const payload = parseDeliverySource(req.body || {});
        if (!payload.sourceType || !payload.sourceId) {
            return res.status(400).json({ success: false, message: "Source monitoring tidak lengkap." });
        }
        await hideDeliveryMonitoringItem(req, payload.sourceType, payload.sourceId);
        res.json({ success: true, message: "Item monitoring disembunyikan." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/delivery-monitoring/clear", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        await selfRegistrationWorkflow.ensureSchema();
        await ensureDeliveryMonitoringSchema();

        const username = getCurrentUsername(req);
        const monitoredChannels = ["EMAIL_VISITOR", "EMAIL_HOST", "WHATSAPP", "WHATSAPP_HOST", "HOST_NOTIFICATION"];
        const result = await pool.query(
            `WITH current_items AS (
                SELECT 'NOTIFICATION'::text AS source_type,
                       notification_id::text AS source_id
                FROM system_notifications
                WHERE channel = ANY($1::text[])
                  AND status <> 'OPENED'
                UNION ALL
                SELECT 'QUEUE'::text AS source_type,
                       ('JOB_EMAIL_' || invitation_id)::text AS source_id
                FROM self_registration_access_jobs
                UNION ALL
                SELECT 'QUEUE'::text AS source_type,
                       ('JOB_WHATSAPP_' || invitation_id)::text AS source_id
                FROM self_registration_access_jobs
            )
            INSERT INTO delivery_monitor_hidden (source_type, source_id, hidden_by, hidden_at)
            SELECT source_type, source_id, $2, NOW()
            FROM current_items
            ON CONFLICT (source_type, source_id)
            DO UPDATE SET hidden_by = EXCLUDED.hidden_by, hidden_at = NOW()
            RETURNING hidden_id`,
            [monitoredChannels, username]
        );

        res.json({
            success: true,
            message: "Semua item monitoring sudah dibersihkan dari tampilan.",
            cleared: result.rows.length
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

function hasNonEmptyInnerrangeCard(responseBody) {
    const text = String(responseBody || "");
    const cardMatches = [...text.matchAll(/<CardNumber>\s*([^<\s]+)\s*<\/CardNumber>/gi)];
    return cardMatches.some(match => String(match[1] || "").trim());
}

function escapeRegularExpression(value) {
    return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function hasInnerrangeCard(responseBody, cardNumber) {
    if (!String(cardNumber || "").trim()) return false;
    return new RegExp(`<CardNumber>\\s*${escapeRegularExpression(cardNumber)}\\s*<\\/CardNumber>`, "i")
        .test(String(responseBody || ""));
}

function hasInnerrangePrimaryPermissionGroup(responseBody, integrationId) {
    if (!String(integrationId || "").trim()) return false;
    const section = String(responseBody || "").match(/<PrimaryPermissionGroup\b[\s\S]*?<\/PrimaryPermissionGroup>/i)?.[0] || "";
    return new RegExp(`\\bID\\s*=\\s*["']${escapeRegularExpression(integrationId)}["']`, "i").test(section);
}

async function confirmInnerrangeAccessState(reqLike, visitor, revoke, expectedQrValue) {
    if (!visitor?.third_party_user_id) return false;
    const apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECK_INNERRANGE", {
        ...visitor,
        innerrange_user_id: visitor.third_party_user_id
    }, { providerType: "INNERRANGE", backgroundRetry: false });
    const checkResult = apiResults.find(item =>
        String(item.provider_type || "").toUpperCase() === "INNERRANGE" && item.skipped !== true
    );
    if (checkResult?.success !== true) return false;
    if (revoke) return isInnerrangeUserCleanForReuse(checkResult.response_body);
    const group = (await pool.query(
        "SELECT integration_id FROM permission_groups WHERE group_name=$1 LIMIT 1",
        [visitor.permission_group]
    )).rows[0];
    return hasInnerrangeCard(checkResult.response_body, expectedQrValue || visitor.card_number)
        && hasInnerrangePrimaryPermissionGroup(checkResult.response_body, group?.integration_id);
}

function hasActiveInnerrangePermissionGroup(responseBody) {
    const text = String(responseBody || "");
    return /<PrimaryPermissionGroup\b[\s\S]*?<Ref\b[\s\S]*?<\/PrimaryPermissionGroup>/i.test(text);
}

function isInnerrangeUserCleanForReuse(responseBody) {
    const text = String(responseBody || "");
    if (!text.trim()) return false;
    return !hasNonEmptyInnerrangeCard(text) && !hasActiveInnerrangePermissionGroup(text);
}

async function verifyInnerrangeSlotClean(reqLike, thirdPartyUserId) {
    const apiResults = await executeActiveThirdPartyConfigs(
        reqLike,
        "CHECK_INNERRANGE",
        {
            third_party_user_id: thirdPartyUserId,
            innerrange_user_id: thirdPartyUserId
        },
        { providerType: "INNERRANGE" }
    );
    const checkResult = apiResults.find(item =>
        String(item.provider_type || "").toUpperCase() === "INNERRANGE"
        && item.skipped !== true
    );

    if (!checkResult) {
        return { clean: false, reason: "API CHECK_INNERRANGE belum aktif." };
    }
    if (checkResult.success !== true) {
        return {
            clean: false,
            reason: checkResult.error || `API CHECK_INNERRANGE gagal (${checkResult.status || "-"})`
        };
    }

    const clean = isInnerrangeUserCleanForReuse(checkResult.response_body);
    return {
        clean,
        reason: clean ? "" : "User InnerRange masih memiliki card atau permission group aktif."
    };
}

async function reserveThirdPartyUserSlotForVerify(visitorId) {
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('innerrange_slot_allocation'))");

        const result = await client.query(
            `UPDATE third_party_user_slots
             SET status = 'VERIFYING',
                 current_visitor_id = $1,
                 last_visitor_id = $1,
                 modified_time = NOW()
             WHERE slot_id = (
                 SELECT slot_id
                 FROM third_party_user_slots
                 WHERE provider = 'innerrange'
                   AND status IN ('AVAILABLE', 'PENDING_VERIFY')
                   AND NOT EXISTS (
                       SELECT 1
                       FROM visitor_registration v
                       WHERE v.third_party_user_id = third_party_user_slots.third_party_user_id
                         AND v.check_out_time IS NULL
                   )
                 ORDER BY last_released_time ASC NULLS FIRST, slot_id ASC
                 LIMIT 1
                 FOR UPDATE SKIP LOCKED
             )
             RETURNING third_party_user_id`,
            [visitorId]
        );

        await client.query("COMMIT");
        return result.rows[0]?.third_party_user_id || null;
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

async function markThirdPartyUserSlotPendingVerify(thirdPartyUserId, visitorId) {
    await pool.query(
        `UPDATE third_party_user_slots
         SET status = 'PENDING_VERIFY',
             current_visitor_id = NULL,
             last_visitor_id = $2,
             last_released_time = NOW(),
             modified_time = NOW()
         WHERE provider = 'innerrange'
           AND third_party_user_id = $1`,
        [thirdPartyUserId, visitorId]
    );
}

async function allocateThirdPartyUserSlot(visitorId, reqLike) {
    const maxVerifyAttempts = 10;

    for (let attempt = 0; attempt < maxVerifyAttempts; attempt += 1) {
        const candidateUserId = await reserveThirdPartyUserSlotForVerify(visitorId);
        if (!candidateUserId) return null;

        const verifyResult = await verifyInnerrangeSlotClean(reqLike, candidateUserId);
        if (verifyResult.clean) {
            await upsertThirdPartyUserSlot(candidateUserId, visitorId, "IN_USE");
            return candidateUserId;
        }

        console.log(`SKIP REUSE SLOT ${candidateUserId}: ${verifyResult.reason}`);
        await markThirdPartyUserSlotPendingVerify(candidateUserId, visitorId);
    }

    return null;
}

async function upsertThirdPartyUserSlot(thirdPartyUserId, visitorId, status = "IN_USE") {
    if (!thirdPartyUserId) return;

    await pool.query(
        `INSERT INTO third_party_user_slots (
            provider,
            third_party_user_id,
            status,
            current_visitor_id,
            last_visitor_id,
            last_assigned_time,
            last_released_time,
            created_time,
            modified_time
        )
        VALUES (
            'innerrange',
            $1,
            $2::text,
            $3::integer,
            $3::integer,
            CASE WHEN $2::text = 'IN_USE' THEN NOW() ELSE NULL END,
            CASE WHEN $2::text IN ('AVAILABLE', 'PENDING_VERIFY') THEN NOW() ELSE NULL END,
            NOW(),
            NOW()
        )
        ON CONFLICT (provider, third_party_user_id)
        DO UPDATE SET
            status = EXCLUDED.status,
            current_visitor_id = EXCLUDED.current_visitor_id,
            last_visitor_id = EXCLUDED.last_visitor_id,
            last_assigned_time = CASE WHEN EXCLUDED.status = 'IN_USE' THEN NOW() ELSE third_party_user_slots.last_assigned_time END,
            last_released_time = CASE WHEN EXCLUDED.status IN ('AVAILABLE', 'PENDING_VERIFY') THEN NOW() ELSE third_party_user_slots.last_released_time END,
            modified_time = NOW()`,
        [thirdPartyUserId, status, visitorId]
    );
}

async function releaseThirdPartyUserSlot(thirdPartyUserId, visitorId) {
    if (!thirdPartyUserId) return;

    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('innerrange_slot_allocation'))");

        const existing = await client.query(
            `SELECT status, current_visitor_id
             FROM third_party_user_slots
             WHERE provider = 'innerrange'
               AND third_party_user_id = $1
             FOR UPDATE`,
            [thirdPartyUserId]
        );

        if (existing.rows.length > 0) {
            const currentVisitorId = existing.rows[0].current_visitor_id;
            const isHeldByAnotherVisitor = existing.rows[0].status === "IN_USE"
                && currentVisitorId
                && Number(currentVisitorId) !== Number(visitorId);

            if (isHeldByAnotherVisitor) {
                console.log(`SKIP RELEASE SLOT ${thirdPartyUserId}: held by visitor ${currentVisitorId}, not ${visitorId}`);
                await client.query("COMMIT");
                return;
            }
        }

        await client.query(
            `INSERT INTO third_party_user_slots (
                provider,
                third_party_user_id,
                status,
                current_visitor_id,
                last_visitor_id,
                last_released_time,
                created_time,
                modified_time
            )
            VALUES ('innerrange', $1, 'PENDING_VERIFY', NULL, $2, NOW(), NOW(), NOW())
            ON CONFLICT (provider, third_party_user_id)
            DO UPDATE SET
                status = 'PENDING_VERIFY',
                current_visitor_id = NULL,
                last_visitor_id = $2,
                last_released_time = NOW(),
                modified_time = NOW()`,
            [thirdPartyUserId, visitorId]
        );

        await client.query("COMMIT");
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

function hasProviderSuccess(apiResults, providerType) {
    return (apiResults || []).some(item =>
        String(item.provider_type || "").toUpperCase() === String(providerType || "").toUpperCase()
        && item.success === true
    );
}

function hasProviderResult(apiResults, providerType) {
    return (apiResults || []).some(item =>
        String(item.provider_type || "").toUpperCase() === String(providerType || "").toUpperCase()
    );
}

function stringifyLogValue(value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    try {
        return JSON.stringify(value);
    } catch (error) {
        return String(value || "");
    }
}

function extractInnerrangeUserIdFromText(value) {
    const text = stringifyLogValue(value);
    const patterns = [
        /<User\b[^>]*\bAddress\s*=\s*["'](U\d+)["']/i,
        /\bAddress\s*=\s*\\["'](U\d+)\\["']/i,
        /<Address>\s*(U\d+)\s*<\/Address>/i,
        /"innerrange_user_id"\s*:\s*"(U\d+)"/i,
        /"third_party_user_id"\s*:\s*"(U\d+)"/i
    ];

    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match?.[1]) return match[1];
    }

    return null;
}

async function recoverInnerrangeUserIdFromCheckinLog(visitor, reqLike) {
    if (!visitor?.visitor_id || visitor.third_party_user_id || visitor.innerrange_user_id) {
        return visitor;
    }

    const cardNumber = String(visitor.card_number || "").trim();
    if (!cardNumber) return visitor;

    const result = await pool.query(
        `SELECT l.request_payload, l.response_body
         FROM api_activity_logs l
         JOIN third_party_api_configs c ON c.config_id = l.config_id
         WHERE c.provider_type = 'INNERRANGE'
           AND c.trigger_event = 'CHECKIN'
           AND l.success = TRUE
           AND (
                l.request_payload::text ILIKE $1
                OR COALESCE(l.response_body, '') ILIKE $1
           )
         ORDER BY l.created_time DESC, l.log_id DESC
         LIMIT 10`,
        [`%${cardNumber}%`]
    );

    for (const row of result.rows) {
        const thirdPartyUserId = extractInnerrangeUserIdFromText(row.request_payload)
            || extractInnerrangeUserIdFromText(row.response_body);
        if (!thirdPartyUserId) continue;

        await pool.query(
            `UPDATE visitor_registration
             SET third_party_user_id = $1,
                 modified_by = $2,
                 modified_time = NOW()
             WHERE visitor_id = $3`,
            [thirdPartyUserId, getCurrentUsername(reqLike), visitor.visitor_id]
        );
        await upsertThirdPartyUserSlot(thirdPartyUserId, visitor.visitor_id, "IN_USE");
        return {
            ...visitor,
            third_party_user_id: thirdPartyUserId,
            innerrange_user_id: thirdPartyUserId
        };
    }

    return visitor;
}

function shouldReleaseInnerrangeSlot(apiResults) {
    return !hasProviderResult(apiResults, "INNERRANGE") || hasProviderSuccess(apiResults, "INNERRANGE");
}

function getVisitorDisplayName(visitor) {
    return `${visitor?.first_name || ""} ${visitor?.second_name || ""}`.trim() || "Visitor";
}

async function generateSchindlerPersonId() {
    for (let attempt = 0; attempt < 10; attempt += 1) {
        const personId = crypto.randomUUID().replace(/-/g, "").toUpperCase();
        const existing = await pool.query(
            "SELECT 1 FROM visitor_registration WHERE schindler_person_id = $1 LIMIT 1",
            [personId]
        );
        if (existing.rows.length === 0) return personId;
    }

    throw new Error("Gagal generate Schindler Person ID unik.");
}

async function getAutoCheckoutSettings() {
    await ensureVisitorSchema();
    const result = await pool.query("SELECT * FROM auto_checkout_settings WHERE setting_id = 1");
    return result.rows[0] || {};
}

function shouldRunAutoCheckout(settings) {
    const now = new Date();
    const todayKey = localDateKey(now);
    const scheduleDateKey = normalizeDate(settings.schedule_date);
    const currentTime = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
    const lastRunKey = settings.last_run_at ? localDateKey(new Date(settings.last_run_at)) : "";
    return settings.enabled === true
        && todayKey >= scheduleDateKey
        && currentTime >= normalizeTime(settings.schedule_time)
        && lastRunKey !== todayKey;
}

function addAutoCheckoutScheduleInterval(dateValue, scheduleType) {
    const date = new Date(`${normalizeDate(dateValue)}T00:00:00`);
    if (scheduleType === "MONTHLY") date.setMonth(date.getMonth() + 1);
    else if (scheduleType === "YEARLY") date.setFullYear(date.getFullYear() + 1);
    else date.setDate(date.getDate() + 1);
    return localDateKey(date);
}

async function advanceAutoCheckoutSchedule(settings) {
    const scheduleType = normalizeScheduleType(settings.schedule_type);
    if (scheduleType === "ONCE") {
        await pool.query("UPDATE auto_checkout_settings SET enabled = FALSE, last_run_at = NOW(), updated_at = NOW() WHERE setting_id = 1");
        return;
    }

    const nextDate = addAutoCheckoutScheduleInterval(settings.schedule_date, scheduleType);
    await pool.query(
        "UPDATE auto_checkout_settings SET schedule_date = $1, last_run_at = NOW(), updated_at = NOW() WHERE setting_id = 1",
        [nextDate]
    );
}

async function checkoutVisitorRecord(visitor, reqLike, sourceLabel) {
    const result = await pool.query(
        `UPDATE visitor_registration
         SET check_out_time = NOW(),
             status = CASE WHEN source_invitation_id IS NOT NULL THEN 'ACCESS_EXPIRED' ELSE status END,
             modified_by = $2,
             modified_time = NOW()
         WHERE visitor_id = $1
           AND check_out_time IS NULL
         RETURNING *`,
        [visitor.visitor_id, getCurrentUsername(reqLike)]
    );

    if (result.rows.length === 0) {
        return { success: false, visitor_id: visitor.visitor_id, message: "Visitor sudah check-out atau tidak ditemukan." };
    }

    let checkedOutVisitor = result.rows[0];
    await pool.query(`
        UPDATE visitor_extension_requests
        SET status='TIMEOUT', updated_at=NOW()
        WHERE visitor_id=$1 AND status IN ('OFFERED','WAITING_APPROVAL')
    `, [checkedOutVisitor.visitor_id]);
    if (checkedOutVisitor.source_invitation_id) {
        await pool.query(
            `UPDATE visitor_invitation_members
             SET status='ACCESS_EXPIRED', modified_at=NOW()
             WHERE visitor_id=$1`,
            [checkedOutVisitor.visitor_id]
        );
    }
    const isAutomaticCheckout = ["AUTO_CHECKOUT", "EXPIRY_CHECKOUT"].includes(sourceLabel);
    await saveActivityLog(
        reqLike,
        isAutomaticCheckout ? "AUTO_CHECK_OUT_VISITOR" : "CHECK_OUT_VISITOR",
        `${isAutomaticCheckout ? "Auto check out" : "Check out"} visitor ${getVisitorDisplayName(checkedOutVisitor)} (Visitor ID ${checkedOutVisitor.visitor_id}, Card ${checkedOutVisitor.card_number || "-"})${sourceLabel === "EXPIRY_CHECKOUT" ? " karena expiry time tercapai" : ""}`
    );

    let apiResults = [];
    if (await isVisitorRegistrationApiMode()) {
        try {
            checkedOutVisitor = await recoverInnerrangeUserIdFromCheckinLog(checkedOutVisitor, reqLike);
            apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKOUT", checkedOutVisitor);
        } catch (apiError) {
            console.log("THIRD PARTY AUTO CHECKOUT API ERROR:", apiError.message);
        }
    }

    if (shouldReleaseInnerrangeSlot(apiResults)) {
        await releaseThirdPartyUserSlot(checkedOutVisitor.third_party_user_id, checkedOutVisitor.visitor_id);
    }

    runBackgroundTask(`DEVICE CHECKOUT VISITOR ${checkedOutVisitor.visitor_id || "-"}`, () =>
        runDeviceSyncBackground(reqLike, checkedOutVisitor, "CHECKOUT")
    );

    const invitation_finished = await finishSelfRegistrationInvitationWhenNoActiveVisitors(checkedOutVisitor, reqLike);

    return { success: true, visitor_id: checkedOutVisitor.visitor_id, invitation_finished, api_results: apiResults };
}

async function runAutoCheckout(createdBy = "AUTO_CHECKOUT", ipAddress = "127.0.0.1") {
    if (autoCheckoutRunning) {
        throw new Error("Auto Check-Out sedang berjalan. Tunggu proses sebelumnya selesai.");
    }

    autoCheckoutRunning = true;
    const reqLike = {
        session: { user: { username: createdBy, full_name: createdBy } },
        ip: ipAddress
    };

    try {
        await ensureVisitorSchema();
        const activeVisitors = await pool.query(`
            SELECT *
            FROM visitor_registration
            WHERE check_out_time IS NULL AND check_in_time IS NOT NULL
            ORDER BY check_in_time ASC, visitor_id ASC
        `);

        const results = [];
        for (const visitor of activeVisitors.rows) {
            results.push(await checkoutVisitorRecord(visitor, reqLike, "AUTO_CHECKOUT"));
        }

        await saveActivityLog(
            reqLike,
            "AUTO_CHECKOUT_RUN",
            `Auto Check-Out selesai. ${results.filter(item => item.success).length} dari ${activeVisitors.rows.length} visitor aktif berhasil di-checkout.`
        );

        return {
            total_active: activeVisitors.rows.length,
            checked_out: results.filter(item => item.success).length,
            failed: results.filter(item => !item.success).length,
            results
        };
    } finally {
        autoCheckoutRunning = false;
    }
}

function extensionPublicBaseUrl(settings) {
    return String(settings?.public_base_url || `http://localhost:${process.env.PORT || 8081}`).trim().replace(/\/+$/g, "");
}

async function getExtensionRequest(requestId) {
    const result = await pool.query(`
        SELECT er.*, v.first_name, v.second_name, v.email_address, v.phone_number,
               v.host, v.permission_group, v.card_number, v.check_in_time, v.check_out_time,
               v.source_invitation_id, vh.host_email, vh.host_whatsapp
        FROM visitor_extension_requests er
        JOIN visitor_registration v ON v.visitor_id=er.visitor_id
        LEFT JOIN visitor_hosts vh ON vh.host_name=v.host
        WHERE er.request_id=$1
        LIMIT 1
    `, [requestId]);
    return result.rows[0] || null;
}

async function recordExtensionNotification(reqLike, payload) {
    try {
        await createSystemNotification(reqLike, payload);
    } catch (error) {
        console.log("EXTENSION NOTIFICATION LOG ERROR:", error.message);
    }
}

async function sendExtensionVisitorMessage(reqLike, request, kind = "REMINDER", options = {}) {
    const settings = await getSelfRegistrationSettings();
    const qrSettings = await getQrSettings();
    const visitorName = getVisitorDisplayName(request);
    const requestUrl = `${extensionPublicBaseUrl(qrSettings)}/extension-request.html?token=${encodeURIComponent(request.request_token)}`;
    const approved = kind === "APPROVED";
    const rejected = kind === "REJECTED";
    const subject = approved
        ? `Perpanjangan kunjungan disetujui - ${visitorName}`
        : rejected ? `Perpanjangan kunjungan tidak disetujui - ${visitorName}` : `Waktu kunjungan segera berakhir - ${visitorName}`;
    const body = approved
        ? `Halo ${visitorName}, perpanjangan kunjungan Anda telah disetujui sampai ${formatDateTimeText(request.requested_expiry)}.`
        : rejected
            ? `Halo ${visitorName}, perpanjangan kunjungan Anda tidak disetujui. Waktu kunjungan tetap berakhir ${formatDateTimeText(request.original_expiry)}.${request.bm_reason || request.host_reason ? ` Alasan: ${request.bm_reason || request.host_reason}` : ""}`
            : `Halo ${visitorName}, waktu kunjungan Anda akan berakhir pada ${formatDateTimeText(request.original_expiry)}. Ajukan perpanjangan melalui link berikut: ${requestUrl}`;
    const updates = {};
    const onlyChannel = String(options.only_channel || "").toUpperCase();

    if (onlyChannel !== "WHATSAPP" && settings.extension_email_enabled && request.email_address) {
        try {
            const smtp = await getSmtpSettings();
            const transporter = createSmtpTransport(smtp);
            await transporter.sendMail({
                from: `"${smtp.from_name || "Innersync"}" <${smtp.from_email || smtp.smtp_user}>`,
                to: request.email_address,
                subject,
                text: body
            });
            updates.email_status = "SUCCESS";
            updates.email_error = null;
            await recordExtensionNotification(reqLike, { channel: "EMAIL_VISITOR", event_type: `EXTENSION_${kind}`, status: "SUCCESS", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.email_address, title: subject, message: body, detail: { request_id: request.request_id } });
        } catch (error) {
            updates.email_status = "FAILED";
            updates.email_error = error.message;
            await recordExtensionNotification(reqLike, { channel: "EMAIL_VISITOR", event_type: `EXTENSION_${kind}`, status: "FAILED", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.email_address, title: subject, message: error.message, detail: { request_id: request.request_id } });
        }
    } else if (kind === "REMINDER" && !onlyChannel) {
        updates.email_status = "SKIPPED";
    }

    if (onlyChannel !== "EMAIL" && settings.extension_whatsapp_enabled && request.phone_number) {
        try {
            await sendPlainWhatsappMessage(await getWhatsappSettings(), request.phone_number, body);
            updates.whatsapp_status = "SUCCESS";
            updates.whatsapp_error = null;
            await recordExtensionNotification(reqLike, { channel: "WHATSAPP", event_type: `EXTENSION_${kind}`, status: "SUCCESS", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.phone_number, title: subject, message: body, detail: { request_id: request.request_id } });
        } catch (error) {
            updates.whatsapp_status = "FAILED";
            updates.whatsapp_error = error.message;
            await recordExtensionNotification(reqLike, { channel: "WHATSAPP", event_type: `EXTENSION_${kind}`, status: "FAILED", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.phone_number, title: subject, message: error.message, detail: { request_id: request.request_id } });
        }
    } else if (kind === "REMINDER" && !onlyChannel) {
        updates.whatsapp_status = "SKIPPED";
    }

    if (kind === "REMINDER" && !onlyChannel) {
        await pool.query(`
            UPDATE visitor_extension_requests
            SET reminder_sent_at=NOW(), email_status=$2, email_error=$3,
                whatsapp_status=$4, whatsapp_error=$5, updated_at=NOW()
            WHERE request_id=$1
        `, [request.request_id, updates.email_status || null, updates.email_error || null, updates.whatsapp_status || null, updates.whatsapp_error || null]);
    }
    return updates;
}

async function sendExtensionHostApproval(reqLike, request, options = {}) {
    const settings = await getSelfRegistrationSettings();
    const qrSettings = await getQrSettings();
    const visitorName = getVisitorDisplayName(request);
    const approvalUrl = `${extensionPublicBaseUrl(qrSettings)}/extension-approval.html?token=${encodeURIComponent(request.host_token)}`;
    const subject = `Approval perpanjangan kunjungan - ${visitorName}`;
    const body = `${visitorName} meminta perpanjangan ${request.requested_minutes} menit, dari ${formatDateTimeText(request.original_expiry)} sampai ${formatDateTimeText(request.requested_expiry)}.${request.reason ? ` Keperluan: ${request.reason}.` : ""}\n\nApprove atau reject: ${approvalUrl}`;
    const onlyChannel = String(options.only_channel || "").toUpperCase();

    if (!onlyChannel) await recordExtensionNotification(reqLike, {
        channel: "INTERNAL", event_type: "EXTENSION_APPROVAL", status: "PENDING",
        visitor_id: request.visitor_id, visitor_name: visitorName, target: "BM",
        title: "Perpanjangan menunggu approval BM", message: body,
        detail: { request_id: request.request_id }
    });

    if (onlyChannel !== "WHATSAPP" && settings.host_email_enabled && request.host_email) {
        try {
            const smtp = await getSmtpSettings();
            const transporter = createSmtpTransport(smtp);
            await transporter.sendMail({ from: `"${smtp.from_name || "Innersync"}" <${smtp.from_email || smtp.smtp_user}>`, to: request.host_email, subject, text: body });
            await recordExtensionNotification(reqLike, { channel: "EMAIL_HOST", event_type: "EXTENSION_APPROVAL", status: "SUCCESS", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.host_email, title: subject, message: body, detail: { request_id: request.request_id } });
        } catch (error) {
            await recordExtensionNotification(reqLike, { channel: "EMAIL_HOST", event_type: "EXTENSION_APPROVAL", status: "FAILED", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.host_email, title: subject, message: error.message, detail: { request_id: request.request_id } });
        }
    }
    if (onlyChannel !== "EMAIL" && settings.host_whatsapp_enabled && request.host_whatsapp) {
        try {
            await sendPlainWhatsappMessage(await getWhatsappSettings(), request.host_whatsapp, body);
            await recordExtensionNotification(reqLike, { channel: "WHATSAPP_HOST", event_type: "EXTENSION_APPROVAL", status: "SUCCESS", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.host_whatsapp, title: subject, message: body, detail: { request_id: request.request_id } });
        } catch (error) {
            await recordExtensionNotification(reqLike, { channel: "WHATSAPP_HOST", event_type: "EXTENSION_APPROVAL", status: "FAILED", visitor_id: request.visitor_id, visitor_name: visitorName, target: request.host_whatsapp, title: subject, message: error.message, detail: { request_id: request.request_id } });
        }
    }
}

async function syncApprovedVisitorExtension(requestId, reqLike) {
    const request = await getExtensionRequest(requestId);
    if (!request) throw new Error("Permintaan perpanjangan tidak ditemukan.");
    const visitorResult = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id=$1", [request.visitor_id]);
    const visitor = visitorResult.rows[0];
    if (!visitor || visitor.check_out_time) throw new Error("Visitor sudah check-out atau tidak ditemukan.");

    let apiResults = [];
    let deviceResults = [];
    let syncError = "";
    try {
        if (await isVisitorRegistrationApiMode()) {
            apiResults = await executeActiveThirdPartyConfigs(reqLike, "EDIT", visitor, { backgroundRetry: false });
        }
        deviceResults = await executeDeviceSyncForVisitor(visitor, "EDIT", reqLike);
        const failures = [
            ...apiResults.filter(item => item && !item.skipped && item.success !== true).map(item => item.error || item.message || item.provider_type || "API gagal"),
            ...deviceResults.filter(item => item?.status !== "SUCCESS").map(item => item.error_message || item.device_name || "Device gagal")
        ];
        syncError = failures.join("; ");
    } catch (error) {
        syncError = error.message;
    }

    const status = syncError ? "SYNC_FAILED" : "ACTIVE";
    await pool.query(`
        UPDATE visitor_extension_requests
        SET status=$2, sync_status=$3, sync_error=$4, sync_details=$5::jsonb, updated_at=NOW()
        WHERE request_id=$1
    `, [requestId, status, syncError ? "FAILED" : "SUCCESS", syncError || null, JSON.stringify({ api_results: apiResults, device_results: deviceResults })]);
    return getExtensionRequest(requestId);
}

async function finalizeVisitorExtension(requestId, reqLike) {
    const client = await pool.connect();
    let request;
    try {
        await client.query("BEGIN");
        const claim = await client.query(`
            UPDATE visitor_extension_requests
            SET status='APPROVED_SYNC_PENDING', updated_at=NOW()
            WHERE request_id=$1 AND status='WAITING_APPROVAL'
              AND bm_status='APPROVED' AND host_status='APPROVED'
              AND original_expiry>NOW()
            RETURNING *
        `, [requestId]);
        if (!claim.rows.length) {
            await client.query("ROLLBACK");
            return getExtensionRequest(requestId);
        }
        request = claim.rows[0];
        const visitorUpdate = await client.query(`
            UPDATE visitor_registration
            SET expiry_date=$2, modified_by=$3, modified_time=NOW()
            WHERE visitor_id=$1 AND check_out_time IS NULL
            RETURNING *
        `, [request.visitor_id, request.requested_expiry, getCurrentUsername(reqLike)]);
        if (!visitorUpdate.rows.length) throw new Error("Visitor sudah check-out atau tidak ditemukan.");
        if (visitorUpdate.rows[0].source_invitation_id) {
            await client.query(`
                UPDATE visitor_invitations
                SET expiry_date=GREATEST(COALESCE(expiry_date, $2), $2), modified_time=NOW(), modified_by=$3
                WHERE invitation_id=$1
            `, [visitorUpdate.rows[0].source_invitation_id, request.requested_expiry, getCurrentUsername(reqLike)]);
        }
        await client.query("COMMIT");
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }

    const completed = await syncApprovedVisitorExtension(requestId, reqLike);
    await saveActivityLog(reqLike, "APPROVE_VISITOR_EXTENSION", `Perpanjangan visitor ${getVisitorDisplayName(completed)} disetujui sampai ${formatDateTimeText(completed.requested_expiry)}.`);
    await sendExtensionVisitorMessage(reqLike, completed, "APPROVED");
    return completed;
}

async function rejectVisitorExtension(requestId, reqLike, actor, reason) {
    const result = await pool.query(`
        UPDATE visitor_extension_requests
        SET status='REJECTED', updated_at=NOW()
        WHERE request_id=$1 AND status='WAITING_APPROVAL'
        RETURNING *
    `, [requestId]);
    if (!result.rows.length) return getExtensionRequest(requestId);
    const request = await getExtensionRequest(requestId);
    await saveActivityLog(reqLike, "REJECT_VISITOR_EXTENSION", `Perpanjangan visitor ${getVisitorDisplayName(request)} ditolak oleh ${actor}${reason ? `: ${reason}` : ""}.`);
    await sendExtensionVisitorMessage(reqLike, request, "REJECTED");
    return request;
}

async function runVisitorExtensionSchedulerTick() {
    if (visitorExtensionSchedulerRunning) return;
    visitorExtensionSchedulerRunning = true;
    const reqLike = { session: { user: { username: "EXTENSION_SCHEDULER", full_name: "EXTENSION_SCHEDULER" } }, ip: "127.0.0.1" };
    try {
        await ensureVisitorSchema();
        await pool.query(`
            UPDATE visitor_extension_requests er
            SET status='TIMEOUT', updated_at=NOW()
            FROM visitor_registration v
            WHERE er.visitor_id=v.visitor_id AND er.status IN ('OFFERED','WAITING_APPROVAL')
              AND (er.approval_timeout_at<=NOW() OR er.original_expiry<=NOW() OR v.check_out_time IS NOT NULL)
        `);
        const settings = await getSelfRegistrationSettings();
        if (!settings.extension_enabled) return;
        const visitors = await pool.query(`
            SELECT v.*
            FROM visitor_registration v
            WHERE v.check_in_time IS NOT NULL AND v.check_out_time IS NULL
              AND v.expiry_date>NOW()
              AND v.expiry_date<=NOW()+($1::int * INTERVAL '1 minute')
              AND NOT EXISTS (
                  SELECT 1 FROM visitor_extension_requests er
                  WHERE er.visitor_id=v.visitor_id AND er.original_expiry=v.expiry_date
              )
              AND (SELECT COUNT(*) FROM visitor_extension_requests er2 WHERE er2.visitor_id=v.visitor_id AND er2.status IN ('ACTIVE','SYNC_FAILED'))<$2
            ORDER BY v.expiry_date ASC
            LIMIT 100
        `, [settings.extension_reminder_minutes, settings.extension_max_requests]);
        for (const visitor of visitors.rows) {
            const inserted = await pool.query(`
                INSERT INTO visitor_extension_requests (visitor_id, request_token, status, original_expiry)
                VALUES ($1,$2,'OFFERED',$3)
                ON CONFLICT (visitor_id, original_expiry) DO NOTHING
                RETURNING request_id
            `, [visitor.visitor_id, crypto.randomBytes(32).toString("hex"), visitor.expiry_date]);
            if (!inserted.rows.length) continue;
            const request = await getExtensionRequest(inserted.rows[0].request_id);
            await sendExtensionVisitorMessage(reqLike, request, "REMINDER");
        }
    } finally {
        visitorExtensionSchedulerRunning = false;
    }
}

async function runExpiredVisitorCheckout() {
    if (expiryCheckoutRunning) return { skipped: true, total_expired: 0, checked_out: 0, failed: 0, results: [] };
    expiryCheckoutRunning = true;
    const reqLike = {
        session: { user: { username: "EXPIRY_CHECKOUT_SCHEDULER", full_name: "EXPIRY_CHECKOUT_SCHEDULER" } },
        ip: "127.0.0.1"
    };

    try {
        await ensureVisitorSchema();
        const expiredVisitors = await pool.query(`
            SELECT *
            FROM visitor_registration
            WHERE check_out_time IS NULL
              AND check_in_time IS NOT NULL
              AND expiry_date IS NOT NULL
              AND expiry_date <= NOW()
            ORDER BY expiry_date ASC, visitor_id ASC
            LIMIT 250
        `);

        const results = [];
        for (const visitor of expiredVisitors.rows) {
            try {
                results.push(await checkoutVisitorRecord(visitor, reqLike, "EXPIRY_CHECKOUT"));
            } catch (error) {
                console.log(`EXPIRY CHECKOUT VISITOR ${visitor.visitor_id} ERROR:`, error.message);
                results.push({ success: false, visitor_id: visitor.visitor_id, message: error.message });
            }
        }

        if (expiredVisitors.rows.length) {
            await saveActivityLog(
                reqLike,
                "EXPIRY_AUTO_CHECKOUT_RUN",
                `Expiry Auto Check-Out selesai. ${results.filter(item => item.success).length} dari ${expiredVisitors.rows.length} visitor expired berhasil di-checkout.`
            );
        }

        return {
            total_expired: expiredVisitors.rows.length,
            checked_out: results.filter(item => item.success).length,
            failed: results.filter(item => !item.success).length,
            results
        };
    } finally {
        expiryCheckoutRunning = false;
    }
}

async function runAutoCheckoutSchedulerTick() {
    try {
        await runVisitorExtensionSchedulerTick();
    } catch (error) {
        console.log("VISITOR EXTENSION SCHEDULER TICK ERROR:", error.message);
    }

    try {
        await runExpiredVisitorCheckout();
    } catch (error) {
        console.log("EXPIRY CHECKOUT SCHEDULER TICK ERROR:", error.message);
    }

    try {
        const settings = await getAutoCheckoutSettings();
        if (!shouldRunAutoCheckout(settings)) return;

        runAutoCheckout("AUTO_CHECKOUT_SCHEDULER")
            .then(() => advanceAutoCheckoutSchedule(settings))
            .catch(error => console.log("AUTO CHECKOUT SCHEDULER ERROR:", error.message));
    } catch (error) {
        console.log("AUTO CHECKOUT SCHEDULER TICK ERROR:", error.message);
    }
}

function startAutoCheckoutScheduler() {
    if (autoCheckoutSchedulerStarted) return;
    autoCheckoutSchedulerStarted = true;
    setInterval(runAutoCheckoutSchedulerTick, 60 * 1000);
    setTimeout(runAutoCheckoutSchedulerTick, 5000);
}

function createBackgroundReq(req) {
    return {
        session: req.session,
        ip: req.ip,
        headers: req.headers,
        socket: req.socket
    };
}

function runBackgroundTask(label, task) {
    setImmediate(() => {
        Promise.resolve()
            .then(task)
            .catch(error => console.log(`${label} ERROR:`, error.message));
    });
}

async function runCheckinApiBackground(reqLike, visitor) {
    if (!(await isVisitorRegistrationApiMode())) {
        return;
    }

    const username = getCurrentUsername(reqLike);
    const workingVisitor = { ...(visitor || {}) };
    let reusableThirdPartyUserId = null;

    try {
        const skipThirdPartyReuse = parseLooseBoolean(
            workingVisitor.skip_third_party_reuse ||
            workingVisitor.force_new_third_party_user ||
            workingVisitor.disable_third_party_reuse
        );
        const hasInnerrangeCheckin = skipThirdPartyReuse
            ? false
            : await hasActiveThirdPartyProvider("CHECKIN", "INNERRANGE");
        reusableThirdPartyUserId = hasInnerrangeCheckin
            ? await allocateThirdPartyUserSlot(workingVisitor.visitor_id, reqLike)
            : null;

        if (reusableThirdPartyUserId) {
            workingVisitor.third_party_user_id = reusableThirdPartyUserId;
            workingVisitor.innerrange_user_id = reusableThirdPartyUserId;
            workingVisitor.reuse_third_party_user_id = true;
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = $1,
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE visitor_id = $3`,
                [reusableThirdPartyUserId, username, workingVisitor.visitor_id]
            );
        }

        const apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKIN", workingVisitor);
        const innerrangeResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === "INNERRANGE");
        const successResult = innerrangeResults.find(item => item.success);
        const referenceResult = innerrangeResults.find(item => item.success && item.reference_id);
        const hasTransientInnerrangeFailure = innerrangeResults.some(item =>
            item.success !== true &&
            isRetryableResult({
                status: item.status,
                response_status: item.status,
                response_body: item.response_body,
                error_message: item.error
            })
        );

        if (referenceResult?.reference_id) {
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = $1,
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE visitor_id = $3`,
                [referenceResult.reference_id, username, workingVisitor.visitor_id]
            );
            await upsertThirdPartyUserSlot(referenceResult.reference_id, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId && successResult) {
            await upsertThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId && hasTransientInnerrangeFailure) {
            await upsertThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId) {
            await releaseThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id);
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = NULL,
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE visitor_id = $2`,
                [username, workingVisitor.visitor_id]
            );
        }
    } catch (apiError) {
        console.log("THIRD PARTY CHECK-IN API BACKGROUND ERROR:", apiError.message);
        if (reusableThirdPartyUserId) {
            await releaseThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id);
        }
    }
}

async function runDeviceSyncBackground(reqLike, visitor, action) {
    try {
        await executeDeviceSyncForVisitor(visitor, action, reqLike);
    } catch (error) {
        console.log(`DEVICE SYNC ${action} ERROR:`, error.message);
    }
}

function runCheckinFollowupBackground(req, visitor) {
    const reqLike = createBackgroundReq(req);
    const visitorSnapshot = { ...(visitor || {}) };
    runBackgroundTask(`CHECKIN FOLLOWUP VISITOR ${visitorSnapshot.visitor_id || "-"}`, async () => {
        await Promise.allSettled([
            sendHostCheckinEmail(reqLike, visitorSnapshot),
            sendVisitorCheckinQrEmail(reqLike, visitorSnapshot),
            sendVisitorCheckinQrWhatsapp(reqLike, visitorSnapshot),
            runCheckinApiBackground(reqLike, visitorSnapshot),
            runDeviceSyncBackground(reqLike, visitorSnapshot, "CHECKIN")
        ]);
    });
}

function notifySelfRegistrationHostCheckin(visitor) {
    const visitorSnapshot = { ...(visitor || {}) };
    const reqLike = {
        session: { user: { username: "SELF_REGISTRATION", full_name: "Self Registration" } },
        ip: "127.0.0.1"
    };
    runBackgroundTask(`HOST CHECKIN NOTIFICATION ${visitorSnapshot.visitor_id || "-"}`, () =>
        sendHostCheckinEmail(reqLike, visitorSnapshot)
    );
}

const VISITOR_SCHEMA_PATHS = [
    "/register-visitor",
    "/visitors",
    "/api/public/qr-info",
    "/api/public/self-registration",
    "/api/permission-groups",
    "/api/visitor-history",
    "/api/floors",
    "/api/invitations",
    "/api/hosts",
    "/api/host-notification-settings",
    "/api/qr-settings",
    "/api/smtp-settings",
    "/api/send-qr-email",
    "/api/whatsapp-settings",
    "/api/send-qr-whatsapp",
    "/api/whatsapp-opened",
    "/api/auto-checkout-settings",
    "/api/auto-checkout",
    "/api/visitor-extension-settings",
    "/api/extension-requests",
    "/api/public/extension",
    "/api/public/extension-approval",
    "/api/visitor-log-filter-options",
    "/api/visitor-logs",
    "/api/visitor-stats",
    "/api/visitor-analytics",
    "/api/visitor-watchlist",
    "/api/visitor-watchlist-settings",
    "/sync-acs",
    "/sync-lift",
    "/export-excel",
    "/card-reader"
];

router.use(VISITOR_SCHEMA_PATHS, async (req, res, next) => {
    try {
        await ensureVisitorSchema();
        next();
    } catch (error) {
        next(error);
    }
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, "uploads/"),
    filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage: storage });

router.get("/api/visitor-watchlist-settings", async (req, res) => {
    try {
        const settings = await getWatchlistSettings();
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/visitor-watchlist-settings", async (req, res) => {
    try {
        const mode = normalizeWatchlistMode(req.body.blacklist_mode);
        const notifySecurity = req.body.notify_security !== false;
        const result = await pool.query(
            `INSERT INTO visitor_watchlist_settings (setting_id, blacklist_mode, notify_security, updated_by, updated_at)
             VALUES (1, $1, $2, $3, NOW())
             ON CONFLICT (setting_id) DO UPDATE
             SET blacklist_mode = EXCLUDED.blacklist_mode,
                 notify_security = EXCLUDED.notify_security,
                 updated_by = EXCLUDED.updated_by,
                 updated_at = NOW()
             RETURNING *`,
            [mode, notifySecurity, getCurrentUsername(req)]
        );
        await saveActivityLog(req, "UPDATE_VISITOR_WATCHLIST_SETTING", `Update visitor watchlist mode to ${mode}`);
        res.json({ success: true, message: "Setting watchlist berhasil disimpan.", data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/visitor-watchlist", async (req, res) => {
    try {
        const type = String(req.query.type || "").trim().toUpperCase();
        const search = String(req.query.search || "").trim();
        const params = [];
        const filters = [];

        if (["BLACKLIST", "WHITELIST"].includes(type)) {
            params.push(type);
            filters.push(`list_type = $${params.length}`);
        }
        if (search) {
            params.push(`%${search.toLowerCase()}%`);
            filters.push(`(
                LOWER(COALESCE(visitor_name, '')) LIKE $${params.length}
                OR LOWER(COALESCE(identity_number, '')) LIKE $${params.length}
                OR LOWER(COALESCE(phone_number, '')) LIKE $${params.length}
                OR LOWER(COALESCE(email_address, '')) LIKE $${params.length}
                OR LOWER(COALESCE(company_name, '')) LIKE $${params.length}
            )`);
        }

        const where = filters.length ? `WHERE ${filters.join(" AND ")}` : "";
        const result = await pool.query(
            `SELECT *
             FROM visitor_watchlist
             ${where}
             ORDER BY is_active DESC,
                      CASE list_type WHEN 'BLACKLIST' THEN 0 ELSE 1 END,
                      watchlist_id DESC`,
            params
        );
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/visitor-watchlist", async (req, res) => {
    try {
        const listType = normalizeWatchlistType(req.body.list_type);
        const visitorName = String(req.body.visitor_name || "").trim();
        const identityNumber = String(req.body.identity_number || "").trim();
        const phoneNumber = String(req.body.phone_number || "").trim();
        const emailAddress = String(req.body.email_address || "").trim();

        if (!visitorName && !identityNumber && !phoneNumber && !emailAddress) {
            return res.status(400).json({ success: false, message: "Isi minimal nama, ID Number, phone, atau email." });
        }

        const result = await pool.query(
            `INSERT INTO visitor_watchlist (
                list_type, visitor_name, identity_number, phone_number, email_address,
                company_name, reason, start_date, expiry_date, is_active, created_by, created_time
             )
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
             RETURNING *`,
            [
                listType,
                visitorName || null,
                identityNumber || null,
                phoneNumber || null,
                emailAddress || null,
                String(req.body.company_name || "").trim() || null,
                String(req.body.reason || "").trim() || null,
                req.body.start_date || null,
                req.body.expiry_date || null,
                req.body.is_active !== false,
                getCurrentUsername(req)
            ]
        );
        await saveActivityLog(req, `ADD_${listType}_VISITOR`, `Add ${listType.toLowerCase()} visitor ${visitorName || identityNumber || emailAddress || phoneNumber}`);
        res.json({ success: true, message: `${listType} visitor berhasil disimpan.`, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/visitor-watchlist/:id", async (req, res) => {
    try {
        const listType = normalizeWatchlistType(req.body.list_type);
        const result = await pool.query(
            `UPDATE visitor_watchlist
             SET list_type = $1,
                 visitor_name = $2,
                 identity_number = $3,
                 phone_number = $4,
                 email_address = $5,
                 company_name = $6,
                 reason = $7,
                 start_date = $8,
                 expiry_date = $9,
                 is_active = $10,
                 modified_by = $11,
                 modified_time = NOW()
             WHERE watchlist_id = $12
             RETURNING *`,
            [
                listType,
                String(req.body.visitor_name || "").trim() || null,
                String(req.body.identity_number || "").trim() || null,
                String(req.body.phone_number || "").trim() || null,
                String(req.body.email_address || "").trim() || null,
                String(req.body.company_name || "").trim() || null,
                String(req.body.reason || "").trim() || null,
                req.body.start_date || null,
                req.body.expiry_date || null,
                req.body.is_active !== false,
                getCurrentUsername(req),
                req.params.id
            ]
        );
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Data watchlist tidak ditemukan." });
        await saveActivityLog(req, `EDIT_${listType}_VISITOR`, `Edit ${listType.toLowerCase()} visitor ${result.rows[0].visitor_name || result.rows[0].identity_number || "-"}`);
        res.json({ success: true, message: "Watchlist berhasil diupdate.", data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.delete("/api/visitor-watchlist/:id", async (req, res) => {
    try {
        const current = await pool.query("SELECT * FROM visitor_watchlist WHERE watchlist_id = $1", [req.params.id]);
        if (!current.rows.length) return res.status(404).json({ success: false, message: "Data watchlist tidak ditemukan." });
        await pool.query("DELETE FROM visitor_watchlist WHERE watchlist_id = $1", [req.params.id]);
        await saveActivityLog(req, `DELETE_${current.rows[0].list_type}_VISITOR`, `Delete ${String(current.rows[0].list_type || "").toLowerCase()} visitor ${current.rows[0].visitor_name || current.rows[0].identity_number || "-"}`);
        res.json({ success: true, message: "Watchlist berhasil dihapus." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/visitor-watchlist/check", async (req, res) => {
    try {
        const matches = await findVisitorWatchlistMatches(req.query);
        const settings = await getWatchlistSettings();
        const decision = summarizeWatchlistDecision(matches, settings);
        res.json({ success: true, data: decision });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Register Visitor
router.post("/register-visitor", upload.fields([{ name: "visitor_photo", maxCount: 1 }, { name: "identity_photo", maxCount: 1 }]), async (req, res) => {
    try {
        let visitorPhoto = req.files["visitor_photo"] ? req.files["visitor_photo"][0].filename : null;
        let identityPhoto = req.files["identity_photo"] ? req.files["identity_photo"][0].filename : null;
        const { first_name, second_name, identity_number, identity_type, company_name, email_address, card_number, permission_group, purpose_note, start_date, expiry_date, host } = req.body;
        const operatorNote = String(req.body.operator_note || "").trim();
        if (operatorNote.length > 1000) {
            return res.status(400).json({ success: false, message: "Operator Note maksimal 1000 karakter." });
        }
        const skipThirdPartyReuse = parseLooseBoolean(
            req.body.skip_third_party_reuse ||
            req.body.force_new_third_party_user ||
            req.body.disable_third_party_reuse
        );
        const bookingCode = normalizeBookingCode(req.body.booking_code);
        const phone_number = req.body.phone_number || req.body.telephone_number || null;
        const username = getCurrentUsername(req);
        const schindlerPersonId = await generateSchindlerPersonId();

        let bookingInvitation = null;
        if (bookingCode) {
            const validation = await validatePendingInvitationByCode(bookingCode);
            if (!validation.ok) {
                return res.status(validation.status).json({ success: false, message: validation.message });
            }
            bookingInvitation = validation.invitation;
            visitorPhoto = visitorPhoto || bookingInvitation.visitor_photo || null;
            identityPhoto = identityPhoto || bookingInvitation.identity_photo || null;
        }

        const watchlistSettings = await getWatchlistSettings();
        const watchlistMatches = await findVisitorWatchlistMatches({
            first_name,
            second_name,
            identity_number,
            email_address,
            phone_number
        });
        const watchlistDecision = summarizeWatchlistDecision(watchlistMatches, watchlistSettings);

        const requiresSuperadminApproval = watchlistDecision.require_approval &&
            String(req.session?.role_name || "").toUpperCase() !== "SUPERADMIN";

        if (watchlistDecision.blocked || requiresSuperadminApproval) {
            const primary = watchlistDecision.primary || {};
            await saveActivityLog(
                req,
                requiresSuperadminApproval ? "BLACKLIST_CHECKIN_NEED_APPROVAL" : "BLACKLIST_CHECKIN_BLOCKED",
                `${requiresSuperadminApproval ? "Need superadmin approval for" : "Blocked"} blacklist visitor ${first_name || ""} ${second_name || ""} (ID ${identity_number || "-"}). Reason: ${primary.reason || "-"}`
            );
            if (watchlistSettings.notify_security !== false) {
                await createSystemNotification(req, {
                    channel: "VISITOR_WATCHLIST",
                    event_type: "CHECKIN",
                    status: "FAILED",
                    visitor_name: `${first_name || ""} ${second_name || ""}`.trim(),
                    target: identity_number || null,
                    title: requiresSuperadminApproval ? "Blacklist Visitor perlu approval" : "Blacklist Visitor diblokir",
                    message: `Visitor ${`${first_name || ""} ${second_name || ""}`.trim() || identity_number || "-"} masuk blacklist. ${primary.reason || ""}`.trim(),
                    detail: { identity_number, watchlist_id: primary.watchlist_id || null, mode: watchlistDecision.mode }
                });
            }
            return res.status(403).json({
                success: false,
                watchlist: watchlistDecision,
                message: requiresSuperadminApproval
                    ? "Visitor masuk Blacklist. Check-In perlu approval SUPERADMIN."
                    : "Visitor masuk Blacklist. Check-In diblokir sesuai setting."
            });
        }
        
        const qrData = JSON.stringify({ first_name, second_name, company_name, host, card_number, start_date, expiry_date });
        const qrCode = await QRCode.toDataURL(qrData);
        
        const result = await pool.query(
            `INSERT INTO visitor_registration (
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note,
            visitor_photo,
            identity_photo,
            qr_code,
            start_date,
            expiry_date,
            schindler_person_id,
            watchlist_status,
            watchlist_entry_id,
            watchlist_note,
            created_by,
            created_time,
            check_in_time
            )
            VALUES (
            $1, $2, $3, $4, $5,
            $6, $7, $8, $9, $10,
            $11, $12, $13, $14, $15,
            $16, $17, $18, $19, $20, $21,
            NOW(),
            NOW()
            )
            RETURNING *`,
            [
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note,
            visitorPhoto,
            identityPhoto,
            qrCode,
            start_date || null,
            expiry_date || null,
            schindlerPersonId,
            watchlistDecision.status,
            watchlistDecision.primary?.watchlist_id || null,
            watchlistDecision.primary?.reason || null,
            username
            ]
            );

        if (operatorNote) {
            await pool.query(
                `INSERT INTO visitor_operator_notes (visitor_id, note_text, created_by)
                 VALUES ($1, $2, $3)`,
                [result.rows[0].visitor_id, operatorNote, username]
            );
        }
            
        await saveActivityLog(
            req,
            "CHECK_IN_VISITOR",
            `Check in visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );

        if (watchlistDecision.status === "BLACKLIST") {
            await saveActivityLog(
                req,
                "BLACKLIST_VISITOR_CHECKIN_WARNING",
                `Blacklist visitor check-in warning ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, ID Number ${identity_number || "-"})`
            );
            if (watchlistSettings.notify_security !== false) {
                await createSystemNotification(req, {
                    channel: "VISITOR_WATCHLIST",
                    event_type: "CHECKIN",
                    status: "FAILED",
                    visitor_id: result.rows[0].visitor_id,
                    visitor_name: getVisitorDisplayName(result.rows[0]),
                    target: identity_number || null,
                    title: "Warning Blacklist Visitor",
                    message: `${getVisitorDisplayName(result.rows[0])} masuk blacklist. ${watchlistDecision.primary?.reason || ""}`.trim(),
                    detail: {
                        identity_number,
                        watchlist_id: watchlistDecision.primary?.watchlist_id || null,
                        mode: watchlistDecision.mode,
                        matches: watchlistDecision.matches?.map(item => ({ id: item.watchlist_id, type: item.list_type, match_types: item.match_types })) || []
                    }
                });
            }
        }

        if (bookingInvitation) {
            await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'CHECKED_IN',
                     checked_in_visitor_id = $1,
                     checked_in_time = NOW(),
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE invitation_id = $3`,
                [result.rows[0].visitor_id, username, bookingInvitation.invitation_id]
            );
            await saveActivityLog(
                req,
                "USE_BOOKING_CODE",
                `Use booking code ${bookingCode} for visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id})`
            );
        }

        runCheckinFollowupBackground(req, {
            ...result.rows[0],
            skip_third_party_reuse: skipThirdPartyReuse,
            force_new_third_party_user: skipThirdPartyReuse
        });

        res.json({
            success: true,
            message: "Visitor registered",
            data: result.rows[0],
            watchlist: watchlistDecision,
            api_results: [],
            background_processing: true
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Search Visitor by ID
router.get("/visitors/search", async (req, res) => {
    try {
        const { id } = req.query;
        const result = await pool.query("SELECT * FROM visitor_registration WHERE identity_number = $1 ORDER BY visitor_id DESC LIMIT 1", [id]);
        res.json(result.rows.length > 0 ? { found: true, ...result.rows[0] } : { found: false });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/api/public/returning-visitor", async (req, res) => {
    try {
        const identityNumber = String(req.query.id || req.query.identity_number || "").trim();
        if (!identityNumber) {
            return res.status(400).json({ success: false, message: "ID Number wajib diisi." });
        }

        const result = await pool.query(
            `SELECT
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number,
                visitor_photo,
                identity_photo
             FROM visitor_registration
             WHERE UPPER(BTRIM(identity_number)) = UPPER(BTRIM($1))
               AND check_out_time IS NOT NULL
             ORDER BY visitor_id DESC
             LIMIT 1`,
            [identityNumber]
        );

        if (!result.rows.length) {
            return res.json({ success: true, found: false });
        }

        const row = result.rows[0];
        const memberSource = await pool.query(
            `SELECT i.invitation_id
             FROM visitor_invitations i
             WHERE UPPER(BTRIM(i.identity_number)) = UPPER(BTRIM($1))
               AND EXISTS (
                   SELECT 1 FROM visitor_invitation_members m
                   WHERE m.invitation_id = i.invitation_id
               )
             ORDER BY i.created_time DESC NULLS LAST, i.invitation_id DESC
             LIMIT 1`,
            [identityNumber]
        );
        const membersMap = memberSource.rows.length
            ? await loadInvitationMembers(memberSource.rows[0].invitation_id)
            : new Map();
        const members = memberSource.rows.length
            ? membersMap.get(Number(memberSource.rows[0].invitation_id)) || []
            : [];
        res.json({
            success: true,
            found: true,
            data: {
                first_name: row.first_name || "",
                second_name: row.second_name || "",
                identity_number: row.identity_number || "",
                identity_type: row.identity_type || "",
                company_name: row.company_name || "",
                email_address: row.email_address || "",
                phone_number: row.phone_number || "",
                visitor_photo: safeUploadFilename(row.visitor_photo),
                identity_photo: safeUploadFilename(row.identity_photo),
                members
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/public/qr-info", async (req, res) => {
    try {
        const cardNumber = String(req.query.card_number || "").trim();

        if (!cardNumber) {
            return res.status(400).json({ success: false, message: "Card number wajib diisi" });
        }

        const result = await pool.query(
            `SELECT first_name,
                    second_name,
                    company_name,
                    host,
                    permission_group,
                    purpose_note,
                    start_date,
                    expiry_date,
                    card_number
             FROM visitor_registration
             WHERE card_number = $1
             ORDER BY visitor_id DESC
             LIMIT 1`,
            [cardNumber]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "QR visitor tidak ditemukan" });
        }

        const settings = await pool.query("SELECT preview_title, preview_subtitle, show_card_number FROM qr_settings WHERE setting_id = 1");

        res.json({
            success: true,
            data: result.rows[0],
            settings: settings.rows[0] || {}
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/permission-groups", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT pg.group_id,
                   pg.group_name,
                   pg.integration_id,
                   pg.floor_id,
                   sf.floor_name,
                   sf.destination_code AS schindler_destination_floor_code,
                   sf.return_code AS schindler_return_floor_code,
                   CASE
                       WHEN sf.destination_code IS NOT NULL
                       THEN CONCAT('specific,', sf.destination_code, ',', sf.return_code)
                       ELSE ''
                   END AS schindler_auto_zone,
                   CASE
                       WHEN sf.destination_code IS NOT NULL
                       THEN CONCAT(sf.return_code, ',', sf.destination_code)
                       ELSE ''
                   END AS schindler_access_zones_always,
                   pg.description,
                   pg.created_at,
                   COALESCE(
                       ARRAY_REMOVE(ARRAY_AGG(DISTINCT d.device_id), NULL),
                       ARRAY[]::integer[]
                   ) AS device_ids,
                   COALESCE(
                       STRING_AGG(DISTINCT d.device_name, ', '),
                       ''
                   ) AS device_names
            FROM permission_groups pg
            LEFT JOIN schindler_floors sf ON sf.floor_id = pg.floor_id
            LEFT JOIN permission_group_devices pgd ON pgd.group_id = pg.group_id
            LEFT JOIN devices d ON d.device_id = pgd.device_id
            GROUP BY pg.group_id, sf.floor_id
            ORDER BY pg.group_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/visitors/:id", async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT v.*, j.invitation_id AS access_invitation_id, i.status AS access_status,
                    j.phase AS access_phase, j.error AS access_error, j.email_status AS access_email_status,
                    j.email_error AS access_email_error, j.whatsapp_status AS access_whatsapp_status,
                    j.whatsapp_error AS access_whatsapp_error,
                    CASE WHEN i.status IN ('ACCESS_READY','CHECKED_IN') AND i.expiry_date>NOW() AND j.phase<>'REVOKE' THEN j.qr_value END AS access_qr_value,
                    (SELECT COUNT(*)::int
                     FROM visitor_operator_notes n
                     WHERE n.visitor_id = v.visitor_id) AS note_count,
                    (SELECT COUNT(*)::int
                     FROM visitor_operator_notes n
                     WHERE n.visitor_id = v.visitor_id
                       AND n.created_by <> $2
                       AND NOT EXISTS (
                           SELECT 1
                           FROM visitor_operator_note_reads r
                           WHERE r.note_id = n.note_id
                             AND r.username = $2
                       )) AS unread_note_count
             FROM visitor_registration v
             LEFT JOIN self_registration_access_jobs j ON j.visitor_id=v.visitor_id
             LEFT JOIN visitor_invitations i ON i.invitation_id=j.invitation_id
             WHERE v.visitor_id = $1`,
            [req.params.id, getCurrentUsername(req)]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/visitors/:id/operator-notes", async (req, res) => {
    try {
        const visitorId = Number(req.params.id);
        const username = getCurrentUsername(req);
        if (!Number.isInteger(visitorId) || visitorId <= 0) {
            return res.status(400).json({ success: false, message: "Visitor ID tidak valid." });
        }

        const visitor = await pool.query(
            `SELECT visitor_id, first_name, second_name, check_out_time
             FROM visitor_registration
             WHERE visitor_id = $1`,
            [visitorId]
        );
        if (!visitor.rows.length) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        const notes = await pool.query(
            `SELECT n.note_id,
                    n.visitor_id,
                    n.note_text,
                    n.created_by,
                    n.created_at,
                    CASE
                        WHEN n.created_by = $2 OR r.note_id IS NOT NULL THEN TRUE
                        ELSE FALSE
                    END AS is_read
             FROM visitor_operator_notes n
             LEFT JOIN visitor_operator_note_reads r
               ON r.note_id = n.note_id
              AND r.username = $2
             WHERE n.visitor_id = $1
             ORDER BY n.created_at ASC, n.note_id ASC`,
            [visitorId, username]
        );

        res.json({
            success: true,
            data: {
                visitor: visitor.rows[0],
                notes: notes.rows,
                unread_count: notes.rows.filter(note => note.is_read !== true).length
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/visitors/:id/operator-notes", async (req, res) => {
    try {
        const visitorId = Number(req.params.id);
        const noteText = String(req.body.note_text || "").trim();
        const username = getCurrentUsername(req);

        if (!Number.isInteger(visitorId) || visitorId <= 0) {
            return res.status(400).json({ success: false, message: "Visitor ID tidak valid." });
        }
        if (!noteText) {
            return res.status(400).json({ success: false, message: "Operator Note wajib diisi." });
        }
        if (noteText.length > 1000) {
            return res.status(400).json({ success: false, message: "Operator Note maksimal 1000 karakter." });
        }

        const result = await pool.query(
            `INSERT INTO visitor_operator_notes (visitor_id, note_text, created_by)
             SELECT visitor_id, $2, $3
             FROM visitor_registration
             WHERE visitor_id = $1
             RETURNING *`,
            [visitorId, noteText, username]
        );
        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            "ADD_VISITOR_OPERATOR_NOTE",
            `Add operator note for Visitor ID ${visitorId}`
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/visitors/:id/operator-notes/mark-read", async (req, res) => {
    try {
        const visitorId = Number(req.params.id);
        const username = getCurrentUsername(req);
        if (!Number.isInteger(visitorId) || visitorId <= 0) {
            return res.status(400).json({ success: false, message: "Visitor ID tidak valid." });
        }

        await pool.query(
            `INSERT INTO visitor_operator_note_reads (note_id, username, read_at)
             SELECT note_id, $2::varchar(100), NOW()
             FROM visitor_operator_notes
             WHERE visitor_id = $1
               AND created_by <> $2::varchar(100)
             ON CONFLICT (note_id, username)
             DO UPDATE SET read_at = EXCLUDED.read_at`,
            [visitorId, username]
        );

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/visitor-history", async (req, res) => {
    try {
        const identityNumber = String(req.query.identity_number || "").trim();

        if (!identityNumber) {
            return res.status(400).json({ success: false, message: "Identity number wajib diisi" });
        }

        const result = await pool.query(
            `SELECT visitor_id,
                    first_name,
                    second_name,
                    identity_number,
                    company_name,
                    host,
                    permission_group,
                    purpose_note,
                    check_in_time,
                    check_out_time,
                    created_by
             FROM visitor_registration
             WHERE identity_number = $1
             ORDER BY check_in_time ASC NULLS LAST, visitor_id ASC`,
            [identityNumber]
        );

        res.json({
            success: true,
            data: {
                total_visits: result.rows.length,
                visits: result.rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/visitors/:id/check-integration", async (req, res) => {
    try {
        const provider = String(req.body.provider || "").trim().toUpperCase();
        const configId = req.body.config_id ? Number(req.body.config_id) : null;
        const triggerMap = {
            INNERRANGE: "CHECK_INNERRANGE",
            SCHINDLER: "CHECK_SCHINDLER"
        };
        const triggerEvent = triggerMap[provider];

        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Provider check tidak valid" });
        }

        const visitor = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);
        if (visitor.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, visitor.rows[0], {
            providerType: provider,
            configId
        });
        const providerResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === provider);

        if (providerResults.length === 0) {
            return res.status(400).json({
                success: false,
                message: `API check ${provider} belum dibuat/aktif. Buat setting API dengan mode ${triggerEvent}.`
            });
        }

        const ok = providerResults.some(item => item.success === true);

        res.json({
            success: ok,
            message: ok ? `Check ${provider} berhasil.` : `Check ${provider} gagal. Cek Log Activity API.`,
            data: providerResults,
            api_results: apiResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/visitors/:id/check-integration-configs", async (req, res) => {
    try {
        const provider = String(req.query.provider || "").trim().toUpperCase();
        const triggerMap = {
            INNERRANGE: "CHECK_INNERRANGE",
            SCHINDLER: "CHECK_SCHINDLER"
        };
        const triggerEvent = triggerMap[provider];

        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Provider check tidak valid" });
        }

        const result = await pool.query(
            `SELECT config_id,
                    config_name,
                    provider_type,
                    trigger_event,
                    action_type,
                    execution_order
             FROM third_party_api_configs
             WHERE is_active = TRUE
               AND provider_type = $1
               AND trigger_event = $2
             ORDER BY execution_order ASC, config_id ASC`,
            [provider, triggerEvent]
        );

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/visitors/:id", async (req, res) => {
    try {
        const automatic = await pool.query("SELECT 1 FROM self_registration_access_jobs WHERE visitor_id=$1", [req.params.id]);
        if (automatic.rows.length) return res.status(409).json({ success: false, message: "Data approval akses otomatis tidak dapat diedit. Cabut akses dan buat pengajuan baru untuk mengubah data." });
        const {
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            telephone_number,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note
        } = req.body;

        const result = await pool.query(
            `UPDATE visitor_registration
             SET first_name = $1,
                 second_name = $2,
                 identity_number = $3,
                 identity_type = $4,
                 company_name = $5,
                 email_address = $6,
                 phone_number = $7,
                 host = $8,
                 card_number = $9,
                 permission_group = $10,
                 purpose_note = $11,
                 modified_by = $12,
                 modified_time = NOW()
             WHERE visitor_id = $13
             RETURNING *`,
            [
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number || telephone_number || null,
                host,
                card_number,
                permission_group,
                purpose_note,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            "EDIT_VISITOR",
            `Edit visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "EDIT", result.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY EDIT API ERROR:", apiError.message);
            }
        }

        runBackgroundTask(`DEVICE EDIT VISITOR ${result.rows[0].visitor_id || "-"}`, () =>
            runDeviceSyncBackground(createBackgroundReq(req), result.rows[0], "EDIT")
        );

        res.json({ success: true, data: result.rows[0], api_results: apiResults });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/visitors/:id", async (req, res) => {
    try {
        const automatic = await pool.query("SELECT 1 FROM self_registration_access_jobs WHERE visitor_id=$1", [req.params.id]);
        if (automatic.rows.length) return res.status(409).json({ success: false, message: "Gunakan Cabut Akses untuk visitor otomatis. Riwayat approval tetap disimpan." });
        const target = await pool.query(
            "SELECT * FROM visitor_registration WHERE visitor_id = $1",
            [req.params.id]
        );

        if (target.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "DELETE", target.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY DELETE API ERROR:", apiError.message);
            }
        }

        if (shouldReleaseInnerrangeSlot(apiResults)) {
            await releaseThirdPartyUserSlot(target.rows[0].third_party_user_id, target.rows[0].visitor_id);
        }

        runBackgroundTask(`DEVICE DELETE VISITOR ${target.rows[0].visitor_id || "-"}`, () =>
            runDeviceSyncBackground(createBackgroundReq(req), target.rows[0], "DELETE")
        );

        await pool.query("DELETE FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);

        await saveActivityLog(
            req,
            "DELETE_VISITOR",
            `Delete visitor ${getVisitorDisplayName(target.rows[0])} (Visitor ID ${target.rows[0].visitor_id}, Card ${target.rows[0].card_number || "-"})`
        );

        res.json({ success: true, api_results: apiResults });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/permission-groups", async (req, res) => {
    try {
        const groupName = String(req.body.group_name || "").trim();
        const integrationId = String(req.body.integration_id || "").trim();
        const floorId = req.body.floor_id ? Number(req.body.floor_id) : null;
        const description = String(req.body.description || "").trim();
        const deviceIds = normalizeDeviceIds(req.body.device_ids);

        if (!groupName) {
            return res.status(400).json({ success: false, message: "Nama grouping wajib diisi" });
        }

        const result = await pool.query(
            `INSERT INTO permission_groups (group_name, integration_id, floor_id, description)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [groupName, integrationId || null, floorId || null, description || null]
        );

        await syncPermissionGroupDevices(result.rows[0].group_id, deviceIds);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Grouping sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/permission-groups/:id", async (req, res) => {
    try {
        const groupName = String(req.body.group_name || "").trim();
        const integrationId = String(req.body.integration_id || "").trim();
        const floorId = req.body.floor_id ? Number(req.body.floor_id) : null;
        const description = String(req.body.description || "").trim();
        const deviceIds = normalizeDeviceIds(req.body.device_ids);

        if (!groupName) {
            return res.status(400).json({ success: false, message: "Nama grouping wajib diisi" });
        }

        const result = await pool.query(
            `UPDATE permission_groups
             SET group_name = $1,
                 integration_id = $2,
                 floor_id = $3,
                 description = $4
             WHERE group_id = $5
             RETURNING *`,
            [groupName, integrationId || null, floorId || null, description || null, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Grouping tidak ditemukan" });
        }

        await syncPermissionGroupDevices(result.rows[0].group_id, deviceIds);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Grouping sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/permission-groups/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM permission_groups WHERE group_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/floors", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT floor_id,
                   floor_name,
                   destination_code,
                   return_code,
                   CONCAT('specific,', destination_code, ',', return_code) AS schindler_auto_zone,
                   CONCAT(return_code, ',', destination_code) AS schindler_access_zones_always,
                   description,
                   created_at,
                   modified_at
            FROM schindler_floors
            ORDER BY floor_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/floors", async (req, res) => {
    try {
        const floorName = String(req.body.floor_name || "").trim();
        const destinationCode = String(req.body.destination_code || "").trim();
        const returnCode = String(req.body.return_code || "1").trim();
        const description = String(req.body.description || "").trim();

        if (!floorName) return res.status(400).json({ success: false, message: "Nama floor wajib diisi" });
        if (!destinationCode) return res.status(400).json({ success: false, message: "Kode lantai tujuan wajib diisi" });
        if (!returnCode) return res.status(400).json({ success: false, message: "Kode turun/lobby wajib diisi" });

        const result = await pool.query(
            `INSERT INTO schindler_floors (floor_name, destination_code, return_code, description)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [floorName, destinationCode, returnCode, description || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Floor sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/floors/:id", async (req, res) => {
    try {
        const floorName = String(req.body.floor_name || "").trim();
        const destinationCode = String(req.body.destination_code || "").trim();
        const returnCode = String(req.body.return_code || "1").trim();
        const description = String(req.body.description || "").trim();

        if (!floorName) return res.status(400).json({ success: false, message: "Nama floor wajib diisi" });
        if (!destinationCode) return res.status(400).json({ success: false, message: "Kode lantai tujuan wajib diisi" });
        if (!returnCode) return res.status(400).json({ success: false, message: "Kode turun/lobby wajib diisi" });

        const result = await pool.query(
            `UPDATE schindler_floors
             SET floor_name = $1,
                 destination_code = $2,
                 return_code = $3,
                 description = $4,
                 modified_at = NOW()
             WHERE floor_id = $5
             RETURNING *`,
            [floorName, destinationCode, returnCode, description || null, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Floor tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Floor sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/floors/:id", async (req, res) => {
    try {
        const usage = await pool.query("SELECT COUNT(*)::int AS total FROM permission_groups WHERE floor_id = $1", [req.params.id]);
        if ((usage.rows[0]?.total || 0) > 0) {
            return res.status(400).json({ success: false, message: "Floor masih dipakai di Permission Group" });
        }

        await pool.query("DELETE FROM schindler_floors WHERE floor_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/invitations", async (req, res) => {
    try {
        await selfRegistrationWorkflow.expireApprovals();
        const includeCheckedIn = req.query.include_checked_in === "true";
        const statusFilter = includeCheckedIn ? "" : `WHERE i.status <> 'CHECKED_IN'
            AND NOT (i.access_mode='AUTOMATIC' AND j.visitor_id IS NOT NULL
                AND i.status IN ('ACCESS_PENDING','WAITING_ARRIVAL','ACCESS_READY','ACCESS_FAILED','ACCESS_EXPIRED'))`;
        const result = await pool.query(`
            SELECT i.*, j.error AS access_error, j.email_status AS access_email_status, j.email_error AS access_email_error,
                   j.whatsapp_status AS access_whatsapp_status, j.whatsapp_error AS access_whatsapp_error
            FROM visitor_invitations i
            LEFT JOIN self_registration_access_jobs j ON j.invitation_id=i.invitation_id
            ${statusFilter}
            ORDER BY i.invitation_id DESC
            LIMIT 500
        `);
        const data = await attachInvitationMembers(result.rows, { includeAccess: includeCheckedIn });
        res.json({ success: true, data });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations", async (req, res) => {
    try {
        const body = req.body || {};
        const firstName = String(body.first_name || "").trim();
        const secondName = String(body.second_name || "").trim();
        const identityNumber = String(body.identity_number || body.id_number || "").trim();
        const identityType = String(body.identity_type || "").trim();
        const email = String(body.email_address || "").trim();
        const phone = String(body.phone_number || body.telephone_number || "").trim();
        const host = String(body.host || "").trim();
        const visitorPhoto = safeUploadFilename(body.visitor_photo || body.existing_visitor_photo);
        const identityPhoto = safeUploadFilename(body.identity_photo || body.existing_identity_photo);

        if (!firstName) return res.status(400).json({ success: false, message: "First name wajib diisi." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib diisi." });
        if (!email && !phone) return res.status(400).json({ success: false, message: "Isi email atau nomor WhatsApp visitor." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const bookingCode = await generateBookingCode();
        const result = await pool.query(
            `INSERT INTO visitor_invitations (
                booking_code,
                status,
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number,
                visitor_photo,
                identity_photo,
                host,
                start_date,
                expiry_date,
                permission_group,
                purpose_note,
                created_by,
                created_time
             )
             VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, NOW())
             RETURNING *`,
            [
                bookingCode,
                firstName,
                secondName || null,
                identityNumber || null,
                identityType || null,
                String(body.company_name || "").trim() || null,
                email || null,
                phone || null,
                visitorPhoto,
                identityPhoto,
                host,
                body.start_date || null,
                body.expiry_date || null,
                String(body.permission_group || "Visitor").trim() || "Visitor",
                String(body.purpose_note || "").trim() || null,
                getCurrentUsername(req)
            ]
        );

        const invitation = result.rows[0];
        let emailWarning = null;
        if (body.send_email === true && invitation.email_address) {
            try {
                await sendBookingInvitationEmail(req, invitation);
            } catch (emailError) {
                emailWarning = emailError.message;
                await createSystemNotification(req, {
                    channel: "EMAIL_VISITOR",
                    event_type: "INVITATION",
                    status: "FAILED",
                    visitor_name: getVisitorDisplayName(invitation),
                    target: invitation.email_address,
                    title: "Email invitation gagal",
                    message: emailError.message,
                    detail: { booking_code: bookingCode }
                });
            }
        }

        await saveActivityLog(
            req,
            "CREATE_VISITOR_INVITATION",
            `Create booking invitation ${bookingCode} for ${getVisitorDisplayName(invitation)}`
        );

        res.json({ success: true, data: invitation, email_warning: emailWarning });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function normalizeImportHeader(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "");
}

function getImportValue(row, aliases) {
    for (const alias of aliases) {
        const value = row[alias];
        if (value !== undefined && value !== null && String(value).trim() !== "") return value;
    }
    return "";
}

function normalizeExcelDateValue(value) {
    if (!value) return null;
    if (value instanceof Date) return value;
    const text = String(value).trim();
    if (!text) return null;

    const dmyMatch = text.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})(?:[,\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (dmyMatch) {
        const [, day, month, year, hour = "0", minute = "0", second = "0"] = dmyMatch;
        return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }

    const ymdMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (ymdMatch) {
        const [, year, month, day, hour = "0", minute = "0", second = "0"] = ymdMatch;
        return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }

    const date = new Date(text);
    return Number.isNaN(date.getTime()) ? text : date;
}

function isPastDateValue(value) {
    if (!value) return false;
    const date = value instanceof Date ? value : new Date(value);
    return !Number.isNaN(date.getTime()) && date < new Date();
}

async function sendImportedInvitationEmails(reqLike, invitations) {
    const list = Array.isArray(invitations) ? invitations : [];
    for (const invitation of list) {
        if (!invitation?.email_address) {
            await createSystemNotification(reqLike, {
                channel: "EMAIL_VISITOR",
                event_type: "INVITATION_IMPORT",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                title: "Email invitation import gagal",
                message: "Email visitor belum diisi, booking code tidak bisa dikirim otomatis.",
                detail: { booking_code: invitation?.booking_code || null, invitation_id: invitation?.invitation_id || null }
            });
            continue;
        }

        try {
            await sendBookingInvitationEmail(reqLike, invitation);
        } catch (emailError) {
            await createSystemNotification(reqLike, {
                channel: "EMAIL_VISITOR",
                event_type: "INVITATION_IMPORT",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                target: invitation.email_address,
                title: "Email invitation import gagal",
                message: emailError.message,
                detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id }
            });
        }
    }
}

router.get("/api/invitations/template", async (req, res) => {
    try {
        const workbook = new ExcelJS.Workbook();
        workbook.creator = "Innersync";
        workbook.created = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const sampleStart = `${tomorrow.getFullYear()}-${pad2(tomorrow.getMonth() + 1)}-${pad2(tomorrow.getDate())} 09:00`;
        const sampleExpiry = `${tomorrow.getFullYear()}-${pad2(tomorrow.getMonth() + 1)}-${pad2(tomorrow.getDate())} 17:00`;

        const worksheet = workbook.addWorksheet("Invitation Template");
        worksheet.columns = [
            { header: "First Name", key: "first_name", width: 18 },
            { header: "Second Name", key: "second_name", width: 18 },
            { header: "ID Number", key: "identity_number", width: 20 },
            { header: "Identity Type", key: "identity_type", width: 16 },
            { header: "Company", key: "company", width: 24 },
            { header: "Email", key: "email", width: 28 },
            { header: "Phone", key: "phone", width: 18 },
            { header: "Host", key: "host", width: 24 },
            { header: "Start Date", key: "start_date", width: 22 },
            { header: "Expiry Date", key: "expiry_date", width: 22 },
            { header: "Grouping", key: "grouping", width: 18 },
            { header: "Keperluan", key: "keperluan", width: 32 }
        ];

        worksheet.getRow(1).eachCell((cell) => {
            cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
            cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1677FF" } };
            cell.alignment = { vertical: "middle", horizontal: "center" };
            cell.border = {
                top: { style: "thin", color: { argb: "FFD1D5DB" } },
                left: { style: "thin", color: { argb: "FFD1D5DB" } },
                bottom: { style: "thin", color: { argb: "FFD1D5DB" } },
                right: { style: "thin", color: { argb: "FFD1D5DB" } }
            };
        });
        worksheet.getRow(1).height = 24;

        worksheet.addRow({
            first_name: "Budi",
            second_name: "Santoso",
            identity_number: "317xxxxxxxxxxxxx",
            identity_type: "E-KTP",
            company: "PT Contoh",
            email: "budi@example.com",
            phone: "081234567890",
            host: "PT EPCON MULTI GUNA",
            start_date: sampleStart,
            expiry_date: sampleExpiry,
            grouping: "Visitor",
            keperluan: "Meeting"
        });

        worksheet.views = [{ state: "frozen", ySplit: 1 }];
        worksheet.autoFilter = "A1:L1";
        worksheet.getColumn("start_date").numFmt = "yyyy-mm-dd hh:mm";
        worksheet.getColumn("expiry_date").numFmt = "yyyy-mm-dd hh:mm";

        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", "attachment; filename=\"invitation_import_template.xlsx\"");
        await workbook.xlsx.write(res);
        res.end();
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/import", upload.single("invitation_file"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "Pilih file Excel terlebih dahulu." });
        }

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(req.file.path);
        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
            return res.status(400).json({ success: false, message: "Sheet Excel tidak ditemukan." });
        }

        const headerRow = worksheet.getRow(1);
        const headers = {};
        headerRow.eachCell((cell, colNumber) => {
            const key = normalizeImportHeader(cell.value?.text || cell.value);
            if (key) headers[colNumber] = key;
        });

        const imported = [];
        const errors = [];

        for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber += 1) {
            const excelRow = worksheet.getRow(rowNumber);
            const row = {};
            excelRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                const key = headers[colNumber];
                if (!key) return;
                const value = cell.value?.text ?? cell.value?.result ?? cell.value;
                row[key] = value instanceof Date ? value : String(value ?? "").trim();
            });

            const firstName = String(getImportValue(row, ["first_name", "firstname", "nama_depan", "nama", "visitor_name", "name"]) || "").trim();
            const secondName = String(getImportValue(row, ["second_name", "lastname", "last_name", "nama_belakang"]) || "").trim();
            const identityNumber = String(getImportValue(row, ["id_number", "identity_number", "nomor_identitas", "no_identitas", "nik"]) || "").trim();
            const identityType = String(getImportValue(row, ["identity_type", "id_type", "tipe_identitas", "jenis_identitas"]) || "").trim();
            const email = String(getImportValue(row, ["email", "email_address", "email_visitor"]) || "").trim();
            const phone = String(getImportValue(row, ["phone", "phone_number", "whatsapp", "wa", "telephone", "telephone_number"]) || "").trim();
            const host = String(getImportValue(row, ["host", "nama_host"]) || "").trim();
            const startDateValue = normalizeExcelDateValue(getImportValue(row, ["start", "start_date", "tanggal_start", "check_in", "checkin"]));
            const expiryDateValue = normalizeExcelDateValue(getImportValue(row, ["expiry", "expiry_date", "expired", "tanggal_expiry"]));

            const isEmptyRow = !firstName && !secondName && !email && !phone && !host;
            if (isEmptyRow) continue;

            if (!firstName) {
                errors.push({ row: rowNumber, message: "First Name wajib diisi." });
                continue;
            }
            if (!host) {
                errors.push({ row: rowNumber, message: "Host wajib diisi." });
                continue;
            }
            if (!email && !phone) {
                errors.push({ row: rowNumber, message: "Email atau WhatsApp wajib diisi." });
                continue;
            }
            if (isPastDateValue(expiryDateValue)) {
                errors.push({ row: rowNumber, message: "Expiry Date sudah lewat, booking code tidak dibuat." });
                continue;
            }

            const bookingCode = await generateBookingCode();
            const result = await pool.query(
                `INSERT INTO visitor_invitations (
                    booking_code,
                    status,
                    first_name,
                    second_name,
                    identity_number,
                    identity_type,
                    company_name,
                    email_address,
                    phone_number,
                    host,
                    start_date,
                    expiry_date,
                    permission_group,
                    purpose_note,
                    created_by,
                    created_time
                 )
                 VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW())
                 RETURNING *`,
                [
                    bookingCode,
                    firstName,
                    secondName || null,
                    identityNumber || null,
                    identityType || null,
                    String(getImportValue(row, ["company", "company_name", "perusahaan"]) || "").trim() || null,
                    email || null,
                    phone || null,
                    host,
                    startDateValue,
                    expiryDateValue,
                    String(getImportValue(row, ["grouping", "permission_group", "group"]) || "Visitor").trim() || "Visitor",
                    String(getImportValue(row, ["keperluan", "purpose", "purpose_note", "note", "notes"]) || "").trim() || null,
                    getCurrentUsername(req)
                ]
            );
            imported.push(result.rows[0]);
        }

        await saveActivityLog(
            req,
            "IMPORT_VISITOR_INVITATION",
            `Import invitation XLS selesai. Imported ${imported.length}, failed ${errors.length}.`
        );

        if (imported.length > 0) {
            const reqLike = createBackgroundReq(req);
            const importedSnapshot = imported.map(item => ({ ...item }));
            runBackgroundTask("IMPORT INVITATION EMAIL", () => sendImportedInvitationEmails(reqLike, importedSnapshot));
        }

        res.json({
            success: true,
            imported: imported.length,
            failed: errors.length,
            email_processing: imported.length > 0,
            email_total: imported.length,
            errors,
            data: imported
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/self-registration/options", async (req, res) => {
    try {
        const [hosts, groups, settings] = await Promise.all([
            pool.query(`
                SELECT host_name, host_email, host_whatsapp, location, note
                FROM visitor_hosts
                ORDER BY host_name ASC
            `),
            pool.query(`
                SELECT group_name
                FROM permission_groups
                ORDER BY group_name ASC
            `),
            getSelfRegistrationSettings()
        ]);

        res.json({
            success: true,
            data: {
                hosts: hosts.rows,
                permission_groups: groups.rows,
                settings: {
                    group_registration_enabled: settings.group_registration_enabled === true,
                    group_max_members: settings.group_max_members,
                    group_qr_mode: "PER_PERSON",
                    member_identity_photo_required: settings.member_identity_photo_required !== false,
                    member_face_photo_required: settings.member_face_photo_required !== false
                }
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/self-registration/qr", async (req, res) => {
    try {
        const value = String(req.query.value || req.query.url || "").trim();
        if (!value) return res.status(400).send("QR value wajib diisi.");

        if (String(req.query.format || "").toLowerCase() === "png") {
            const png = await QRCode.toBuffer(value, {
                type: "png",
                errorCorrectionLevel: "H",
                margin: 2,
                width: 480
            });
            res.setHeader("Cache-Control", "no-store");
            return res.type("image/png").send(png);
        }

        const svg = await QRCode.toString(value, {
            type: "svg",
            errorCorrectionLevel: "H",
            margin: 2,
            width: 260
        });

        res.setHeader("Cache-Control", "no-store");
        res.type("image/svg+xml").send(svg);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

router.post("/api/public/self-registration", upload.any(), async (req, res) => {
    try {
        const body = req.body || {};
        const uploadedVisitorPhoto = getUploadedFile(req, "visitor_photo")?.filename || null;
        const uploadedIdentityPhoto = getUploadedFile(req, "identity_photo")?.filename || null;
        const visitorPhoto = uploadedVisitorPhoto || safeUploadFilename(body.existing_visitor_photo || body.visitor_photo);
        const identityPhoto = uploadedIdentityPhoto || safeUploadFilename(body.existing_identity_photo || body.identity_photo);
        const firstName = String(body.first_name || "").trim();
        const secondName = String(body.second_name || "").trim();
        const identityNumber = String(body.identity_number || body.id_number || "").trim();
        const identityType = String(body.identity_type || "E-KTP").trim();
        const email = String(body.email_address || "").trim();
        const phone = String(body.phone_number || body.telephone_number || "").trim();
        const host = String(body.host || "").trim();
        const permissionGroup = String(body.permission_group || "Visitor").trim() || "Visitor";
        const purposeNote = String(body.purpose_note || "").trim();
        const settings = await getSelfRegistrationSettings();
        const members = getSelfRegistrationMembersFromRequest(req, settings);

        if (!firstName) return res.status(400).json({ success: false, message: "Nama depan wajib diisi." });
        if (!identityNumber) return res.status(400).json({ success: false, message: "ID Number wajib diisi." });
        const blacklist = await findActiveIdentityBlacklist(identityNumber);
        if (blacklist) {
            await discardRejectedSelfRegistrationUploads(req);
            await saveActivityLog(req, "BLACKLIST_SELF_REGISTRATION_BLOCKED", `Self registration diblokir untuk ID ${identityNumber}, watchlist ${blacklist.watchlist_id}.`);
            const watchlistSettings = await getWatchlistSettings();
            if (watchlistSettings.notify_security !== false) {
                await createSystemNotification(req, {
                    channel: "VISITOR_WATCHLIST",
                    event_type: "SELF_REGISTRATION",
                    status: "BLOCKED",
                    visitor_name: [firstName, secondName].filter(Boolean).join(" "),
                    target: identityNumber,
                    title: "Blacklist Visitor: Self Registration diblokir",
                    message: "Pendaftaran mandiri ditolak karena ID Number cocok dengan blacklist aktif.",
                    detail: { watchlist_id: blacklist.watchlist_id, match_type: "ID_NUMBER" }
                });
            }
            return res.status(403).json({ success: false, message: "Registrasi tidak dapat dilanjutkan. Silakan hubungi receptionist." });
        }
        if (!visitorPhoto) return res.status(400).json({ success: false, message: "Foto wajah wajib diambil/upload." });
        if (!identityPhoto) return res.status(400).json({ success: false, message: "Foto identitas wajib diambil/upload." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib dipilih." });
        if (!email && !phone) return res.status(400).json({ success: false, message: "Isi email atau nomor WhatsApp." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });
        for (const member of members) {
            const memberBlacklist = await findActiveIdentityBlacklist(member.identity_number);
            if (memberBlacklist) {
                await discardRejectedSelfRegistrationUploads(req);
                await saveActivityLog(req, "BLACKLIST_SELF_REGISTRATION_GROUP_BLOCKED", `Self registration grup diblokir untuk anggota ${member.member_name} ID ${member.identity_number}.`);
                return res.status(403).json({ success: false, message: `Registrasi tidak dapat dilanjutkan. Anggota ${member.member_name} masuk blacklist aktif.` });
            }
        }

        await selfRegistrationWorkflow.expireApprovals();
        const pendingInvitation = await pool.query(
            `SELECT i.*
             FROM visitor_invitations i
             WHERE i.identity_number = $1
               AND i.status IN ('PENDING', 'WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL', 'ACCESS_PENDING', 'WAITING_ARRIVAL', 'ACCESS_READY', 'ACCESS_FAILED', 'CHECKED_IN')
               AND (i.expiry_date IS NULL OR i.expiry_date >= NOW())
               AND (i.status <> 'CHECKED_IN' OR i.access_mode = 'AUTOMATIC' OR EXISTS (
                   SELECT 1 FROM visitor_registration v
                   WHERE v.visitor_id = i.checked_in_visitor_id AND v.check_out_time IS NULL
               ))
             ORDER BY i.created_time DESC
             LIMIT 1`,
            [identityNumber]
        );

        if (pendingInvitation.rows.length) {
            const invitation = pendingInvitation.rows[0];
            const memberMap = await loadInvitationMembers(invitation.invitation_id);
            invitation.members = memberMap.get(Number(invitation.invitation_id)) || [];
            invitation.group_member_count = invitation.members.length;
            if (invitation.status === "CHECKED_IN") {
                return res.status(409).json({ success: false, message: "Kunjungan sebelumnya masih aktif. Selesaikan checkout sebelum membuat registrasi baru." });
            }
            if (invitation.access_mode === "AUTOMATIC") {
                return res.status(409).json({ success: false, message: "Registrasi aktif sudah ada. Buka kembali dari browser pendaftaran, cek email, atau hubungi receptionist." });
            }
            return res.json({
                success: true,
                data: invitation,
                reused: true,
                approval_required: invitation.status !== "PENDING",
                message: invitation.status === "PENDING"
                    ? "Booking code aktif untuk ID Number ini sudah ada."
                    : "Registrasi aktif untuk ID Number ini masih menunggu approval."
            });
        }

        const approvalState = getInitialSelfRegistrationApprovalState(settings);
        const accessMode = settings.access_mode === "AUTOMATIC" ? "AUTOMATIC" : "OPERATOR";
        const activationTiming = settings.activation_timing === "ON_OPERATOR_CHECKIN" ? "ON_OPERATOR_CHECKIN" : "AFTER_APPROVAL";
        if (accessMode === "AUTOMATIC" && (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !body.expiry_date || new Date(body.expiry_date) <= new Date(body.start_date || Date.now()))) {
            return res.status(400).json({ success: false, message: "Akses otomatis membutuhkan email dan jadwal kunjungan dengan waktu berakhir setelah waktu mulai." });
        }
        const startDate = body.start_date || new Date();
        const approvalStep = approvalState.status === "WAITING_HOST_APPROVAL"
            ? "HOST"
            : approvalState.status === "WAITING_BM_APPROVAL" ? "BM" : null;
        const approvalWindow = approvalStep
            ? await getApprovalStageWindow(settings, approvalStep, host, startDate, body.expiry_date || null)
            : null;
        if (approvalWindow?.invalid) {
            return res.status(400).json({
                success: false,
                message: approvalWindow.invalidReason === "VISIT_NON_OPERATIONAL"
                    ? "Tanggal kunjungan berada pada hari non-operasional atau kalender libur. Pilih tanggal lain atau tambahkan pengecualian Tetap Buka."
                    : "Jadwal kunjungan berakhir sebelum waktu approval dapat dimulai. Ubah jadwal kunjungan atau jam operasional approval."
            });
        }
        const bookingCode = await generateBookingCode();
        const result = await pool.query(
            `INSERT INTO visitor_invitations (
                booking_code,
                status,
                approval_mode,
                bm_approval_status,
                host_approval_status,
                approval_starts_at,
                approval_timeout_at,
                approval_operational_start,
                approval_operational_end,
                approval_operational_days,
                approval_holiday_dates,
                approval_timeout_minutes,
                approval_timezone,
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number,
                visitor_photo,
                identity_photo,
                host,
                start_date,
                expiry_date,
                permission_group,
                purpose_note,
                created_by,
                created_time,
                access_mode,
                public_status_token,
                activation_timing
             )
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, 'SELF_REGISTRATION', NOW(), $28, $29, $30)
             RETURNING *`,
            [
                bookingCode,
                approvalState.status,
                settings.approval_mode,
                approvalState.bm,
                approvalState.host,
                approvalWindow?.startsAt || null,
                approvalWindow?.timeoutAt || null,
                approvalWindow?.operationalStart || null,
                approvalWindow?.operationalEnd || null,
                approvalWindow?.operationalDays?.join(",") || null,
                approvalWindow ? JSON.stringify({ closed: approvalWindow.closedDates, open: approvalWindow.openDates }) : JSON.stringify({ closed: [], open: [] }),
                approvalWindow?.timeoutMinutes || null,
                approvalWindow?.timeZone || null,
                firstName,
                secondName || null,
                identityNumber,
                identityType || null,
                String(body.company_name || "").trim() || null,
                email || null,
                phone || null,
                visitorPhoto,
                identityPhoto,
                host,
                startDate,
                body.expiry_date || null,
                permissionGroup,
                purposeNote || null,
                accessMode,
                accessMode === "AUTOMATIC" ? crypto.randomBytes(32).toString("hex") : null,
                activationTiming
            ]
        );

        let invitation = result.rows[0];
        if (members.length) {
            await saveInvitationMembers(pool, invitation.invitation_id, members);
            const memberMap = await loadInvitationMembers(invitation.invitation_id);
            invitation.members = memberMap.get(Number(invitation.invitation_id)) || [];
            invitation.group_member_count = invitation.members.length;
        }
        let approvalEmailWarning = null;
        let approvalWhatsappWarning = null;
        if (invitation.status === "WAITING_HOST_APPROVAL") {
            const hostApproval = await startHostApproval(req, invitation, settings);
            approvalEmailWarning = hostApproval.email_warning;
            approvalWhatsappWarning = hostApproval.whatsapp_warning;
            const refreshed = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [invitation.invitation_id]);
            invitation = refreshed.rows[0] || invitation;
            const memberMap = await loadInvitationMembers(invitation.invitation_id);
            invitation.members = memberMap.get(Number(invitation.invitation_id)) || [];
            invitation.group_member_count = invitation.members.length;
        }
        await saveActivityLog(
            req,
            "SELF_REGISTRATION_INVITATION",
            `Self registration booking ${bookingCode} for ${getVisitorDisplayName(invitation)}`
        );
        await createSystemNotification(req, {
            channel: "SELF_REGISTRATION",
            event_type: "INVITATION",
            status: "SUCCESS",
            visitor_name: getVisitorDisplayName(invitation),
            target: email || phone || null,
            title: "Self registration baru",
            message: invitation.status === "PENDING"
                ? `Booking code ${bookingCode} dibuat dari form mandiri.`
                : `Self registration ${bookingCode} menunggu approval.`,
            detail: { booking_code: bookingCode, invitation_id: invitation.invitation_id, status: invitation.status }
        });

        if (!invitation.members) {
            const memberMap = await loadInvitationMembers(invitation.invitation_id);
            invitation.members = memberMap.get(Number(invitation.invitation_id)) || [];
            invitation.group_member_count = invitation.members.length;
        }

        res.json({
            success: true,
            data: invitation,
            approval_required: invitation.status !== "PENDING",
            email_warning: approvalEmailWarning,
            whatsapp_warning: approvalWhatsappWarning,
            message: invitation.status === "PENDING" ? "Booking code berhasil dibuat." : "Registrasi berhasil dikirim dan menunggu approval."
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/invitations/:id", async (req, res) => {
    try {
        const body = req.body || {};
        const firstName = String(body.first_name || "").trim();
        const identityNumber = String(body.identity_number || body.id_number || "").trim();
        const identityType = String(body.identity_type || "").trim();
        const host = String(body.host || "").trim();
        if (!firstName) return res.status(400).json({ success: false, message: "First name wajib diisi." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib diisi." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const current = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        if (!current.rows.length) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (current.rows[0].created_by === "SELF_REGISTRATION") {
            return res.status(400).json({ success: false, message: "Pengajuan mandiri tidak dapat diubah setelah submit. Batalkan dan buat pengajuan baru agar approval sesuai data." });
        }
        if (!["PENDING", "EXPIRED", "WAITING_BM_APPROVAL", "WAITING_HOST_APPROVAL", "REJECTED", "APPROVAL_TIMEOUT"].includes(current.rows[0].status)) {
            return res.status(400).json({ success: false, message: "Invitation yang sudah check-in/cancel tidak bisa diedit." });
        }

        const result = await pool.query(
            `UPDATE visitor_invitations
             SET first_name = $1,
                 second_name = $2,
                 identity_number = $3,
                 identity_type = $4,
                 company_name = $5,
                 email_address = $6,
                 phone_number = $7,
                 host = $8,
                 start_date = $9,
                 expiry_date = $10,
                 permission_group = $11,
                 purpose_note = $12,
                 status = CASE
                     WHEN status IN ('REJECTED', 'APPROVAL_TIMEOUT', 'EXPIRED') THEN 'PENDING'
                     ELSE status
                 END,
                 modified_by = $13,
                 modified_time = NOW()
             WHERE invitation_id = $14
             RETURNING *`,
            [
                firstName,
                String(body.second_name || "").trim() || null,
                identityNumber || null,
                identityType || null,
                String(body.company_name || "").trim() || null,
                String(body.email_address || "").trim() || null,
                String(body.phone_number || body.telephone_number || "").trim() || null,
                host,
                body.start_date || null,
                body.expiry_date || null,
                String(body.permission_group || "Visitor").trim() || "Visitor",
                String(body.purpose_note || "").trim() || null,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/:id/bm-approval", async (req, res) => {
    try {
        await selfRegistrationWorkflow.expireApprovals();
        const action = String(req.body?.action || "").trim().toUpperCase();
        const reason = String(req.body?.reason || "").trim();
        const current = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        let invitation = current.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (invitation.status !== "WAITING_BM_APPROVAL") {
            return res.status(400).json({ success: false, message: `Invitation berstatus ${invitation.status}, tidak menunggu approval BM.` });
        }
        if (invitation.approval_timeout_at && new Date(invitation.approval_timeout_at) < new Date()) {
            const expired = await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'APPROVAL_TIMEOUT',
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE invitation_id = $2 AND status='WAITING_BM_APPROVAL' AND approval_timeout_at <= NOW()
                 RETURNING *`,
                [getCurrentUsername(req), req.params.id]
            );
            return res.status(400).json({ success: false, message: "Approval BM sudah timeout.", data: expired.rows[0] });
        }

        if (action === "REJECT") {
            const rejected = await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'REJECTED',
                     bm_approval_status = 'REJECTED',
                     bm_rejected_by = $1,
                     bm_rejected_at = NOW(),
                     bm_reject_reason = $2,
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE invitation_id = $3 AND status='WAITING_BM_APPROVAL' AND approval_timeout_at > NOW()
                 RETURNING *`,
                [getCurrentUsername(req), reason || null, req.params.id]
            );
            if (!rejected.rows.length) return res.status(409).json({ success: false, message: "Status approval sudah berubah atau waktunya habis." });
            await saveActivityLog(req, "BM_REJECT_VISITOR_INVITATION", `BM reject invitation ${invitation.booking_code}`);
            return res.json({ success: true, data: rejected.rows[0], message: "Invitation berhasil direject BM." });
        }

        if (action !== "APPROVE") {
            return res.status(400).json({ success: false, message: "Action approval tidak valid." });
        }

        const settings = await getSelfRegistrationSettings();
        const needsHost = normalizeSelfRegistrationApprovalMode(invitation.approval_mode) === "BM_AND_HOST";
        const approvedStatus = needsHost ? "WAITING_HOST_APPROVAL" : "PENDING";
        const hostStatus = needsHost ? "WAITING" : "NOT_REQUIRED";
        const hostWindow = needsHost
            ? await getApprovalStageWindow(settings, "HOST", invitation.host, invitation.start_date || new Date(), invitation.expiry_date || null)
            : null;
        if (hostWindow?.invalid) {
            return res.status(400).json({
                success: false,
                message: hostWindow.invalidReason === "VISIT_NON_OPERATIONAL"
                    ? "Tanggal kunjungan bukan hari operasional Host. Tambahkan pengecualian Tetap Buka atau ubah tanggal kunjungan."
                    : "Jadwal kunjungan berakhir sebelum waktu approval Host dapat dimulai."
            });
        }
        const approved = await pool.query(
            `UPDATE visitor_invitations
             SET status = $1,
                 bm_approval_status = 'APPROVED',
                 bm_approved_by = $2,
                 bm_approved_at = NOW(),
                 host_approval_status = $3,
                 approval_starts_at = $4,
                 approval_timeout_at = $5,
                 approval_operational_start = $6,
                 approval_operational_end = $7,
                 approval_operational_days = $8,
                 approval_holiday_dates = $9,
                 approval_timeout_minutes = $10,
                 approval_timezone = $11,
                 modified_by = $2,
                 modified_time = NOW()
             WHERE invitation_id = $12 AND status='WAITING_BM_APPROVAL' AND approval_timeout_at > NOW()
             RETURNING *`,
            [
                approvedStatus,
                getCurrentUsername(req),
                hostStatus,
                hostWindow?.startsAt || null,
                hostWindow?.timeoutAt || null,
                hostWindow?.operationalStart || null,
                hostWindow?.operationalEnd || null,
                hostWindow?.operationalDays?.join(",") || null,
                hostWindow ? JSON.stringify({ closed: hostWindow.closedDates, open: hostWindow.openDates }) : JSON.stringify({ closed: [], open: [] }),
                hostWindow?.timeoutMinutes || null,
                hostWindow?.timeZone || null,
                req.params.id
            ]
        );
        if (!approved.rows.length) return res.status(409).json({ success: false, message: "Status approval sudah berubah atau waktunya habis." });
        invitation = approved.rows[0];
        let emailWarning = null;
        let whatsappWarning = null;
        if (needsHost) {
            const hostApproval = await startHostApproval(req, invitation, settings);
            emailWarning = hostApproval.email_warning;
            whatsappWarning = hostApproval.whatsapp_warning;
        }
        await saveActivityLog(req, "BM_APPROVE_VISITOR_INVITATION", `BM approve invitation ${invitation.booking_code}`);
        res.json({ success: true, data: invitation, email_warning: emailWarning, whatsapp_warning: whatsappWarning, message: needsHost ? "BM approve berhasil. Request dikirim ke host." : "BM approve berhasil." });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function completedHostApprovalMessage(row) {
    if (row.host_approval_status === "APPROVED") return "Request sudah disetujui Host. Tidak perlu approve ulang.";
    if (row.host_approval_status === "REJECTED") return "Request sudah ditolak Host. Keputusan sudah tercatat.";
    return "Link approval ini sudah digunakan. Silakan hubungi receptionist untuk memeriksa request.";
}

router.get("/api/public/approval/:token", async (req, res) => {
    try {
        await selfRegistrationWorkflow.expireApprovals();
        res.setHeader("Cache-Control", "no-store");
        const token = String(req.params.token || "").trim();
        const result = await pool.query(
            `SELECT t.token_id, t.approval_step, t.status AS token_status, t.expires_at,
                    i.*
             FROM visitor_approval_tokens t
             JOIN visitor_invitations i ON i.invitation_id = t.invitation_id
             WHERE t.token = $1
             LIMIT 1`,
            [token]
        );
        const row = result.rows[0];
        if (!row) return res.status(404).json({ success: false, message: "Approval link tidak ditemukan." });
        const data = await attachInvitationMembersToRow(row);
        if (row.token_status === "USED") {
            return res.json({ success: true, read_only: true, message: completedHostApprovalMessage(row), data });
        }
        if (row.token_status !== "ACTIVE") return res.status(400).json({ success: false, message: `Approval link sudah ${row.token_status}.`, data });
        if (row.status !== "WAITING_HOST_APPROVAL" || row.host_approval_status !== "WAITING") {
            return res.json({ success: true, read_only: true, message: "Request ini tidak lagi menunggu approval Host. Silakan periksa status kunjungannya.", data });
        }
        if (new Date(row.expires_at) <= new Date() || (row.approval_timeout_at && new Date(row.approval_timeout_at) <= new Date())) {
            await pool.query(
                `UPDATE visitor_approval_tokens SET status = 'EXPIRED' WHERE token_id = $1 AND status='ACTIVE'`,
                [row.token_id]
            );
            await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'APPROVAL_TIMEOUT',
                     modified_time = NOW()
                 WHERE invitation_id = $1 AND status = 'WAITING_HOST_APPROVAL'`,
                [row.invitation_id]
            );
            return res.status(400).json({ success: false, message: "Approval link sudah expired.", data: { ...data, token_status: "EXPIRED" } });
        }
        res.json({ success: true, data });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/public/approval/:token/respond", async (req, res) => {
    const client = await pool.connect();
    try {
        const token = String(req.params.token || "").trim();
        const action = String(req.body?.action || "").trim().toUpperCase();
        const reason = String(req.body?.reason || "").trim();
        if (!["APPROVE", "REJECT"].includes(action)) {
            return res.status(400).json({ success: false, message: "Action approval tidak valid." });
        }

        await client.query("BEGIN");
        const tokenResult = await client.query(
            `SELECT t.token_id,
                    t.approval_step,
                    t.token,
                    t.target_email,
                    t.target_whatsapp,
                    t.status AS token_status,
                    t.expires_at,
                    i.*
             FROM visitor_approval_tokens t
             JOIN visitor_invitations i ON i.invitation_id = t.invitation_id
             WHERE t.token = $1
             FOR UPDATE`,
            [token]
        );
        const row = tokenResult.rows[0];
        if (!row) {
            await client.query("ROLLBACK");
            return res.status(404).json({ success: false, message: "Approval link tidak ditemukan." });
        }
        if (row.token_status === "USED") {
            await client.query("ROLLBACK");
            return res.status(409).json({ success: false, read_only: true, message: completedHostApprovalMessage(row), data: await attachInvitationMembersToRow(row) });
        }
        if (row.token_status !== "ACTIVE") {
            await client.query("ROLLBACK");
            return res.status(400).json({ success: false, message: `Approval link sudah ${row.token_status}.` });
        }
        if (row.status !== "WAITING_HOST_APPROVAL" || row.host_approval_status !== "WAITING") {
            await client.query("ROLLBACK");
            return res.status(409).json({ success: false, read_only: true, message: "Request ini tidak lagi menunggu approval Host. Keputusan tidak diubah.", data: await attachInvitationMembersToRow(row) });
        }
        if (new Date(row.expires_at) <= new Date() || (row.approval_timeout_at && new Date(row.approval_timeout_at) <= new Date())) {
            await client.query("UPDATE visitor_approval_tokens SET status = 'EXPIRED' WHERE token_id = $1", [row.token_id]);
            await client.query(
                `UPDATE visitor_invitations
                 SET status = 'APPROVAL_TIMEOUT',
                     modified_time = NOW()
                 WHERE invitation_id = $1 AND status = 'WAITING_HOST_APPROVAL'`,
                [row.invitation_id]
            );
            await client.query("COMMIT");
            return res.status(400).json({ success: false, message: "Approval link sudah expired." });
        }

        await client.query(
            "UPDATE visitor_approval_tokens SET status = 'USED', used_at = NOW() WHERE token_id = $1",
            [row.token_id]
        );

        const hostIdentity = row.target_email || row.target_whatsapp || "HOST_LINK";
        const updateResult = action === "APPROVE"
            ? await client.query(
                `UPDATE visitor_invitations
                 SET status = 'PENDING',
                     host_approval_status = 'APPROVED',
                     host_approved_by = $1,
                     host_approved_at = NOW(),
                     approval_timeout_at = NULL,
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE invitation_id = $2
                 RETURNING *`,
                [hostIdentity, row.invitation_id]
            )
            : await client.query(
                `UPDATE visitor_invitations
                 SET status = 'REJECTED',
                     host_approval_status = 'REJECTED',
                     host_rejected_by = $1,
                     host_rejected_at = NOW(),
                     host_reject_reason = $2,
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE invitation_id = $3
                 RETURNING *`,
                [hostIdentity, reason || null, row.invitation_id]
            );

        await client.query("COMMIT");
        const invitation = updateResult.rows[0];
        await createSystemNotification(req, {
            channel: "HOST_APPROVAL",
            event_type: "INVITATION_APPROVAL",
            status: action === "APPROVE" ? "APPROVED" : "REJECTED",
            visitor_name: getVisitorDisplayName(invitation),
            target: invitation.host || null,
            title: action === "APPROVE" ? "Host approve visitor" : "Host reject visitor",
            message: `${invitation.booking_code} ${action === "APPROVE" ? "disetujui" : "ditolak"} oleh host.`,
            detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id }
        });
        res.json({ success: true, data: await attachInvitationMembersToRow(invitation), message: action === "APPROVE" ? "Visitor berhasil diapprove." : "Visitor berhasil direject." });
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        res.status(500).json({ success: false, error: error.message });
    } finally {
        client.release();
    }
});

function requireAccessOperator(req, res, next) {
    if (!req.session?.user_id) return res.status(401).json({ success: false, message: "Silakan login sebagai operator." });
    next();
}

router.get("/api/visitor-extension-settings", requireAccessOperator, async (req, res) => {
    try {
        const settings = await getSelfRegistrationSettings();
        res.json({ success: true, data: {
            enabled: settings.extension_enabled,
            reminder_minutes: settings.extension_reminder_minutes,
            email_enabled: settings.extension_email_enabled,
            whatsapp_enabled: settings.extension_whatsapp_enabled,
            duration_options: settings.extension_duration_options,
            max_requests: settings.extension_max_requests,
            max_total_minutes: settings.extension_max_total_minutes,
            approval_timeout_minutes: settings.extension_approval_timeout_minutes
        } });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/visitor-extension-settings", requireAccessOperator, async (req, res) => {
    try {
        const body = req.body || {};
        const durations = normalizeExtensionDurations(body.duration_options);
        const enabled = body.enabled === true;
        const emailEnabled = body.email_enabled !== false;
        const whatsappEnabled = body.whatsapp_enabled === true;
        if (enabled && !emailEnabled && !whatsappEnabled) {
            return res.status(400).json({ success: false, message: "Aktifkan minimal satu kanal pengingat: Email atau WhatsApp." });
        }
        const result = await pool.query(`
            UPDATE self_registration_settings
            SET extension_enabled=$1, extension_reminder_minutes=$2,
                extension_email_enabled=$3, extension_whatsapp_enabled=$4,
                extension_duration_options=$5, extension_max_requests=$6,
                extension_max_total_minutes=$7, extension_approval_timeout_minutes=$8,
                updated_by=$9, updated_at=NOW()
            WHERE setting_id=1
            RETURNING *
        `, [
            enabled,
            clampInteger(body.reminder_minutes, 30, 5, 1440),
            emailEnabled,
            whatsappEnabled,
            durations.join(","),
            clampInteger(body.max_requests, 1, 1, 10),
            clampInteger(body.max_total_minutes, 120, 15, 1440),
            clampInteger(body.approval_timeout_minutes, 30, 5, 1440),
            getCurrentUsername(req)
        ]);
        await saveActivityLog(req, "UPDATE_VISITOR_EXTENSION_SETTINGS", `Pengaturan expiry dan extension diperbarui. Status: ${enabled ? "aktif" : "nonaktif"}.`);
        res.json({ success: true, data: result.rows[0], message: "Pengaturan expiry dan extension berhasil disimpan." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/extension-requests", requireAccessOperator, async (req, res) => {
    try {
        const view = String(req.query.view || "pending").toLowerCase();
        const statuses = view === "history"
            ? ["ACTIVE", "REJECTED", "TIMEOUT"]
            : ["WAITING_APPROVAL", "APPROVED_SYNC_PENDING", "SYNC_FAILED"];
        const result = await pool.query(`
            SELECT er.*, v.first_name, v.second_name, v.email_address, v.phone_number,
                   v.host, v.permission_group, v.check_in_time, v.check_out_time,
                   v.expiry_date AS current_expiry
            FROM visitor_extension_requests er
            JOIN visitor_registration v ON v.visitor_id=er.visitor_id
            WHERE er.status=ANY($1::varchar[]) AND er.deleted_at IS NULL
            ORDER BY er.created_at DESC, er.request_id DESC
        `, [statuses]);
        const baseUrl = extensionPublicBaseUrl(await getQrSettings());
        const rows = result.rows.map(row => ({
            ...row,
            host_approval_url: row.host_token ? `${baseUrl}/extension-approval.html?token=${encodeURIComponent(row.host_token)}` : null
        }));
        const countResult = await pool.query(`
            SELECT status, COUNT(*)::int AS total
            FROM visitor_extension_requests
            WHERE deleted_at IS NULL
            GROUP BY status
        `);
        res.json({ success: true, data: rows, counts: Object.fromEntries(countResult.rows.map(row => [row.status, row.total])) });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/extension-requests/:id/bm-decision", requireAccessOperator, async (req, res) => {
    try {
        const action = String(req.body?.action || "").toUpperCase();
        const reason = String(req.body?.reason || "").trim().slice(0, 1000);
        if (!["APPROVE", "REJECT"].includes(action)) return res.status(400).json({ success: false, message: "Keputusan tidak valid." });
        if (action === "REJECT" && !reason) return res.status(400).json({ success: false, message: "Alasan reject wajib diisi." });
        const update = await pool.query(`
            UPDATE visitor_extension_requests
            SET bm_status=$2, bm_decided_by=$3, bm_decided_at=NOW(), bm_reason=$4, updated_at=NOW()
            WHERE request_id=$1 AND status='WAITING_APPROVAL' AND bm_status='WAITING' AND original_expiry>NOW()
            RETURNING request_id
        `, [req.params.id, action === "APPROVE" ? "APPROVED" : "REJECTED", getCurrentUsername(req), reason || null]);
        if (!update.rows.length) return res.status(409).json({ success: false, message: "Permintaan sudah diproses, kedaluwarsa, atau visitor sudah tidak aktif." });
        const data = action === "REJECT"
            ? await rejectVisitorExtension(req.params.id, req, "BM", reason)
            : await finalizeVisitorExtension(req.params.id, req);
        res.json({ success: true, data, message: action === "REJECT" ? "Perpanjangan ditolak oleh BM." : (data?.status === "WAITING_APPROVAL" ? "Approval BM tersimpan. Menunggu approval Host." : "Perpanjangan telah disetujui dan diproses.") });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/extension-requests/:id/retry-sync", requireAccessOperator, async (req, res) => {
    try {
        const claim = await pool.query(`
            UPDATE visitor_extension_requests SET status='APPROVED_SYNC_PENDING', updated_at=NOW()
            WHERE request_id=$1 AND status='SYNC_FAILED' AND deleted_at IS NULL RETURNING request_id
        `, [req.params.id]);
        if (!claim.rows.length) return res.status(409).json({ success: false, message: "Hanya sinkronisasi berstatus gagal yang dapat di-retry." });
        const data = await syncApprovedVisitorExtension(req.params.id, req);
        res.status(data.status === "ACTIVE" ? 200 : 502).json({ success: data.status === "ACTIVE", data, message: data.status === "ACTIVE" ? "Sinkronisasi perpanjangan berhasil." : `Sinkronisasi masih gagal: ${data.sync_error || "Periksa log integrasi."}` });
    } catch (error) {
        await pool.query("UPDATE visitor_extension_requests SET status='SYNC_FAILED', sync_error=$2, updated_at=NOW() WHERE request_id=$1", [req.params.id, error.message]).catch(() => {});
        res.status(500).json({ success: false, message: error.message });
    }
});

router.delete("/api/extension-requests/:id", requireAccessOperator, async (req, res) => {
    try {
        const requestId = Number(req.params.id);
        if (!Number.isInteger(requestId) || requestId <= 0) {
            return res.status(400).json({ success: false, message: "ID permintaan perpanjangan tidak valid." });
        }

        const result = await pool.query(`
            UPDATE visitor_extension_requests
            SET deleted_at=NOW(), deleted_by=$2, updated_at=NOW()
            WHERE request_id=$1 AND status='SYNC_FAILED' AND deleted_at IS NULL
            RETURNING request_id, visitor_id
        `, [requestId, getCurrentUsername(req)]);

        if (!result.rows.length) {
            return res.status(409).json({
                success: false,
                message: "Hanya permintaan berstatus Sync Gagal yang masih aktif yang dapat dihapus."
            });
        }

        await saveActivityLog(
            req,
            "DELETE_FAILED_VISITOR_EXTENSION",
            `Catatan perpanjangan gagal #${requestId} dihapus dari daftar. Data visitor dan transaksi integrasi tidak diubah.`
        );
        res.json({
            success: true,
            message: "Catatan Sync Gagal berhasil dihapus dari daftar. Expiry visitor dan transaksi API tidak diubah."
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/public/extension/:token", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT er.request_id, er.status, er.original_expiry, er.requested_expiry, er.requested_minutes,
                   er.reason, er.bm_status, er.host_status, er.approval_timeout_at,
                   v.first_name, v.second_name, v.host, v.check_out_time
            FROM visitor_extension_requests er
            JOIN visitor_registration v ON v.visitor_id=er.visitor_id
            WHERE er.request_token=$1 AND er.deleted_at IS NULL LIMIT 1
        `, [String(req.params.token || "")]);
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Link perpanjangan tidak ditemukan." });
        const settings = await getSelfRegistrationSettings();
        const row = result.rows[0];
        if (row.status === "OFFERED" && (row.check_out_time || new Date(row.original_expiry) <= new Date())) {
            await pool.query("UPDATE visitor_extension_requests SET status='TIMEOUT', updated_at=NOW() WHERE request_id=$1", [row.request_id]);
            row.status = "TIMEOUT";
        }
        res.json({ success: true, data: { ...row, duration_options: settings.extension_duration_options, extension_enabled: settings.extension_enabled } });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/public/extension/:token/request", async (req, res) => {
    try {
        const settings = await getSelfRegistrationSettings();
        if (!settings.extension_enabled) return res.status(409).json({ success: false, message: "Fitur perpanjangan sedang dinonaktifkan." });
        const minutes = clampInteger(req.body?.minutes, 0, 15, 1440);
        if (!settings.extension_duration_options.includes(minutes)) return res.status(400).json({ success: false, message: "Durasi perpanjangan tidak tersedia." });
        const reason = String(req.body?.reason || "").trim().slice(0, 1000);
        const current = await pool.query(`
            SELECT er.*, v.check_out_time,
                   (SELECT COALESCE(SUM(er2.requested_minutes),0)::int FROM visitor_extension_requests er2 WHERE er2.visitor_id=er.visitor_id AND er2.status IN ('ACTIVE','SYNC_FAILED')) AS total_extended,
                   (SELECT COUNT(*)::int FROM visitor_extension_requests er3 WHERE er3.visitor_id=er.visitor_id AND er3.status IN ('ACTIVE','SYNC_FAILED')) AS extension_count
            FROM visitor_extension_requests er
            JOIN visitor_registration v ON v.visitor_id=er.visitor_id
            WHERE er.request_token=$1 AND er.status='OFFERED' AND er.original_expiry>NOW()
            LIMIT 1
        `, [String(req.params.token || "")]);
        const offer = current.rows[0];
        if (!offer || offer.check_out_time) return res.status(409).json({ success: false, message: "Penawaran perpanjangan sudah tidak berlaku." });
        if (offer.extension_count >= settings.extension_max_requests) return res.status(409).json({ success: false, message: "Batas jumlah perpanjangan sudah tercapai." });
        if (offer.total_extended + minutes > settings.extension_max_total_minutes) return res.status(409).json({ success: false, message: "Durasi ini melebihi batas total perpanjangan." });
        const originalExpiry = new Date(offer.original_expiry);
        const requestedExpiry = new Date(originalExpiry.getTime() + minutes * 60000);
        const timeoutAt = new Date(Math.min(originalExpiry.getTime(), Date.now() + settings.extension_approval_timeout_minutes * 60000));
        const update = await pool.query(`
            UPDATE visitor_extension_requests
            SET status='WAITING_APPROVAL', requested_minutes=$2, requested_expiry=$3, reason=$4,
                bm_status='WAITING', host_status='WAITING', host_token=$5, approval_timeout_at=$6, updated_at=NOW()
            WHERE request_id=$1 AND status='OFFERED'
            RETURNING request_id
        `, [offer.request_id, minutes, requestedExpiry, reason || null, crypto.randomBytes(32).toString("hex"), timeoutAt]);
        if (!update.rows.length) return res.status(409).json({ success: false, message: "Permintaan ini sudah pernah dikirim." });
        const request = await getExtensionRequest(offer.request_id);
        await saveActivityLog({ session: { user: { username: "VISITOR_EXTENSION" } }, ip: req.ip }, "REQUEST_VISITOR_EXTENSION", `${getVisitorDisplayName(request)} meminta perpanjangan ${minutes} menit.`);
        await sendExtensionHostApproval({ session: { user: { username: "VISITOR_EXTENSION" } }, ip: req.ip }, request);
        res.json({ success: true, data: request, message: "Permintaan dikirim bersamaan ke BM dan Host." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/public/extension-approval/:token", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT er.request_id, er.status, er.original_expiry, er.requested_expiry, er.requested_minutes,
                   er.reason, er.bm_status, er.host_status, er.approval_timeout_at,
                   v.first_name, v.second_name, v.host, v.company_name, v.permission_group, v.check_out_time
            FROM visitor_extension_requests er
            JOIN visitor_registration v ON v.visitor_id=er.visitor_id
            WHERE er.host_token=$1 AND er.deleted_at IS NULL LIMIT 1
        `, [String(req.params.token || "")]);
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Link approval host tidak ditemukan." });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/public/extension-approval/:token", async (req, res) => {
    try {
        const action = String(req.body?.action || "").toUpperCase();
        const reason = String(req.body?.reason || "").trim().slice(0, 1000);
        if (!["APPROVE", "REJECT"].includes(action)) return res.status(400).json({ success: false, message: "Keputusan tidak valid." });
        if (action === "REJECT" && !reason) return res.status(400).json({ success: false, message: "Alasan reject wajib diisi." });
        const update = await pool.query(`
            UPDATE visitor_extension_requests
            SET host_status=$2, host_decided_by='HOST', host_decided_at=NOW(), host_reason=$3, updated_at=NOW()
            WHERE host_token=$1 AND status='WAITING_APPROVAL' AND host_status='WAITING'
              AND original_expiry>NOW() AND approval_timeout_at>NOW()
            RETURNING request_id
        `, [String(req.params.token || ""), action === "APPROVE" ? "APPROVED" : "REJECTED", reason || null]);
        if (!update.rows.length) return res.status(409).json({ success: false, message: "Link sudah dipakai atau masa approval telah berakhir." });
        const reqLike = { session: { user: { username: "HOST" } }, ip: req.ip };
        const data = action === "REJECT"
            ? await rejectVisitorExtension(update.rows[0].request_id, reqLike, "Host", reason)
            : await finalizeVisitorExtension(update.rows[0].request_id, reqLike);
        res.json({ success: true, data, message: action === "REJECT" ? "Perpanjangan ditolak." : (data?.status === "WAITING_APPROVAL" ? "Approval Host tersimpan. Menunggu approval BM." : "Perpanjangan telah disetujui dan diproses.") });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/invitations/:id/retry-access", requireAccessOperator, async (req, res) => {
    try {
        await selfRegistrationWorkflow.retry(Number(req.params.id), req.body?.email_only === true);
        res.json({ success: true, message: "Permintaan dikembalikan ke antrean. Nomor akses dan visitor tetap sama." });
    } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});

router.post("/api/invitations/:id/revoke-access", requireAccessOperator, async (req, res) => {
    try {
        await selfRegistrationWorkflow.revoke(Number(req.params.id));
        res.json({ success: true, message: "Pencabutan akses sedang diproses." });
    } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});

router.post("/api/invitations/:id/activate-access", requireAccessOperator, async (req, res) => {
    try {
        const state = await selfRegistrationWorkflow.activate(Number(req.params.id));
        const success = state?.status === "CHECKED_IN";
        res.status(success ? 200 : 409).json({ success, data: state, message: success ? "Check-in berhasil dan akses sudah aktif." : "Aktivasi akses gagal. Periksa status dan gunakan Retry Access." });
    } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});

router.post("/api/public/self-registration/check-in", async (req, res) => {
    try {
        const bookingCode = normalizeBookingCode(req.body?.booking_code);
        const publicStatusToken = String(req.body?.public_status_token || "").trim();
        const scannedQr = String(req.body?.location_qr || "").trim();
        if (!bookingCode || !publicStatusToken || !scannedQr) {
            return res.status(400).json({ success: false, message: "Data check-in belum lengkap. Buka kembali halaman registrasi lalu scan ulang QR lokasi." });
        }

        const settings = await getSelfRegistrationSettings();
        if (settings.access_mode !== "AUTOMATIC" || settings.activation_timing !== "ON_OPERATOR_CHECKIN") {
            return res.status(409).json({ success: false, message: "Check-in mandiri melalui QR lokasi sedang tidak aktif." });
        }
        if (!secureTextEqual(scannedQr, getLocationCheckinQrValue(settings))) {
            return res.status(403).json({ success: false, message: "QR Check-in Lokasi tidak valid atau sudah diganti." });
        }

        const current = await pool.query(
            `SELECT i.invitation_id, i.booking_code, i.status, i.access_mode, i.activation_timing,
                    i.approval_mode, i.bm_approval_status, i.host_approval_status,
                    i.start_date, i.expiry_date, j.qr_value AS access_code,
                    j.email_status AS access_email_status,
                    j.whatsapp_status AS access_whatsapp_status
             FROM visitor_invitations i
             LEFT JOIN self_registration_access_jobs j ON j.invitation_id = i.invitation_id
             WHERE i.booking_code = $1 AND i.public_status_token = $2
             LIMIT 1`,
            [bookingCode, publicStatusToken]
        );
        const invitation = current.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Registrasi tidak ditemukan atau sesi browser tidak valid." });
        if (invitation.access_mode !== "AUTOMATIC" || invitation.activation_timing !== "ON_OPERATOR_CHECKIN") {
            return res.status(409).json({ success: false, message: "Registrasi ini tidak memakai check-in mandiri QR lokasi." });
        }
        if (invitation.status === "CHECKED_IN") {
            return res.json({ success: true, data: invitation, message: "Visitor sudah berhasil Check-in." });
        }
        if (invitation.status !== "WAITING_ARRIVAL") {
            if (["ACCESS_FAILED", "ACCESS_PENDING"].includes(invitation.status)) {
                const pending = invitation.status === "ACCESS_PENDING";
                return res.status(pending ? 202 : 409).json({
                    success: false,
                    activation_status: invitation.status,
                    data: { ...invitation, access_code: null },
                    message: pending
                        ? "Aktivasi akses sedang diproses. Tunggu pembaruan status, tidak perlu scan ulang."
                        : "Approval sudah selesai, tetapi pengiriman akses gagal. Hubungi receptionist untuk memeriksa API dan melakukan Retry Access."
                });
            }
            return res.status(409).json({ success: false, message: "Visitor belum siap Check-in. Pastikan seluruh approval sudah selesai dan jadwal masih aktif." });
        }

        const state = await selfRegistrationWorkflow.activate(invitation.invitation_id);
        const refreshed = await pool.query(
            `SELECT i.invitation_id, i.booking_code, i.status, i.checked_in_time, i.approval_mode,
                    i.bm_approval_status, i.host_approval_status, i.approval_timeout_at,
                    i.access_mode, i.activation_timing, i.start_date, i.expiry_date,
                    CASE WHEN i.status='CHECKED_IN' AND i.expiry_date>NOW() THEN j.qr_value END AS access_code,
                    j.email_status AS access_email_status,
                    j.whatsapp_status AS access_whatsapp_status
             FROM visitor_invitations i
             LEFT JOIN self_registration_access_jobs j ON j.invitation_id=i.invitation_id
             WHERE i.invitation_id=$1`,
            [invitation.invitation_id]
        );
        const data = refreshed.rows[0] || state;
        const success = data?.status === "CHECKED_IN";
        await saveActivityLog(req, success ? "SELF_LOCATION_CHECKIN" : "SELF_LOCATION_CHECKIN_FAILED", `${bookingCode}: ${data?.status || "UNKNOWN"}`);
        return res.status(success ? 200 : 409).json({
            success,
            activation_status: data?.status,
            data,
            message: success ? "Check-in berhasil. QR akses sekarang sudah aktif." : data?.status === "ACCESS_PENDING"
                ? "Aktivasi akses sedang diproses. Tunggu pembaruan status, tidak perlu scan ulang."
                : "Approval sudah selesai, tetapi pengiriman akses gagal. Hubungi receptionist untuk memeriksa API dan melakukan Retry Access."
        });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

router.post("/api/invitations/:id/send-email", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        const invitation = result.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (invitation.access_mode === "AUTOMATIC") {
            return res.status(400).json({ success: false, message: "Mode otomatis mengirim QR akses setelah sinkronisasi berhasil. Gunakan Kirim Ulang Email pada status Akses Siap." });
        }
        if (invitation.status !== "PENDING") {
            return res.status(400).json({ success: false, message: "Email booking code hanya bisa dikirim setelah approval selesai." });
        }
        await sendBookingInvitationEmail(req, invitation);
        res.json({ success: true, message: "Email booking code berhasil dikirim." });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "INVITATION",
            status: "FAILED",
            title: "Email invitation gagal",
            message: error.message,
            detail: { invitation_id: req.params.id }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/invitations/:id/whatsapp-sent", async (req, res) => {
    try {
        const result = await pool.query(
            "UPDATE visitor_invitations SET sent_whatsapp_time = NOW(), modified_by = $1, modified_time = NOW() WHERE invitation_id = $2 RETURNING *",
            [getCurrentUsername(req), req.params.id]
        );
        const invitation = result.rows[0];
        if (invitation) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "INVITATION",
                status: "OPENED",
                visitor_name: getVisitorDisplayName(invitation),
                target: normalizeWhatsappPhone(invitation.phone_number) || invitation.phone_number || null,
                title: "WhatsApp invitation dibuka",
                message: `WhatsApp booking code ${invitation.booking_code} sudah dibuka. Operator perlu klik kirim.`,
                detail: { booking_code: invitation.booking_code, mode: "MANUAL" }
            });
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/:id/cancel", async (req, res) => {
    try {
        const reason = String(req.body?.reason || "").trim();
        const result = await pool.query(
            `UPDATE visitor_invitations
             SET status = 'CANCELLED',
                 cancel_reason = $1,
                 cancelled_time = NOW(),
                 modified_by = $2,
                 modified_time = NOW()
             WHERE invitation_id = $3
               AND status IN ('PENDING', 'EXPIRED', 'WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL', 'REJECTED', 'APPROVAL_TIMEOUT')
             RETURNING *`,
            [reason || null, getCurrentUsername(req), req.params.id]
        );
        if (!result.rows.length) return res.status(400).json({ success: false, message: "Invitation tidak bisa dicancel." });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/invitations/:id", async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        const current = await client.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1 FOR UPDATE", [req.params.id]);
        const invitation = current.rows[0];
        if (!invitation) {
            await client.query("ROLLBACK");
            return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        }
        if (!["CANCELLED", "EXPIRED", "REJECTED", "APPROVAL_TIMEOUT", "ACCESS_EXPIRED"].includes(invitation.status)) {
            await client.query("ROLLBACK");
            return res.status(400).json({ success: false, message: "Hanya invitation yang sudah selesai, ditolak, dibatalkan, atau kedaluwarsa yang bisa dihapus." });
        }

        await client.query("DELETE FROM self_registration_access_jobs WHERE invitation_id = $1", [req.params.id]);
        await client.query("DELETE FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        await client.query("COMMIT");
        await saveActivityLog(
            req,
            "DELETE_VISITOR_INVITATION",
            `Delete ${invitation.status.toLowerCase()} invitation ${invitation.booking_code} for ${getVisitorDisplayName(invitation)}`
        );
        res.json({ success: true });
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        res.status(500).json({ success: false, error: error.message });
    } finally {
        client.release();
    }
});

router.get("/api/invitations/booking/:code", async (req, res) => {
    try {
        const validation = await validatePendingInvitationByCode(req.params.code);
        if (!validation.ok) return res.status(validation.status).json({ success: false, message: validation.message });
        res.json({ success: true, data: validation.invitation });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/self-registration/status/:code", async (req, res) => {
    try {
        await selfRegistrationWorkflow.expireApprovals();
        const bookingCode = normalizeBookingCode(req.params.code);
        if (!bookingCode) return res.status(400).json({ success: false, message: "Booking code wajib diisi." });

        const result = await pool.query(
            `SELECT i.invitation_id,
                    i.booking_code,
                    CASE WHEN i.status = 'CHECKED_IN' AND i.access_mode <> 'AUTOMATIC'
                              AND v.check_out_time IS NOT NULL THEN 'CHECKED_OUT' ELSE i.status END AS status,
                    i.checked_in_time, i.approval_mode,
                    i.bm_approval_status, i.host_approval_status,
                    i.approval_starts_at, i.approval_timeout_at,
                    i.approval_operational_start, i.approval_operational_end, i.approval_operational_days,
                    i.approval_holiday_dates, i.approval_timeout_minutes, i.approval_timezone,
                    i.bm_reject_reason, i.host_reject_reason, i.cancel_reason,
                    i.access_mode, i.activation_timing,
                    CASE WHEN i.status IN ('ACCESS_READY','CHECKED_IN') AND i.expiry_date>NOW() THEN j.qr_value END AS access_code,
                    j.email_status AS access_email_status,
                    j.whatsapp_status AS access_whatsapp_status,
                    i.start_date, i.expiry_date
             FROM visitor_invitations i
             LEFT JOIN self_registration_access_jobs j ON j.invitation_id=i.invitation_id
             LEFT JOIN visitor_registration v ON v.visitor_id=i.checked_in_visitor_id
             WHERE booking_code = $1
               AND (i.access_mode <> 'AUTOMATIC' OR i.public_status_token = NULLIF($2,''))
             LIMIT 1`,
            [bookingCode, String(req.query.token || "")]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Booking code tidak ditemukan." });
        }

        let invitation = result.rows[0];
        if (["WAITING_BM_APPROVAL", "WAITING_HOST_APPROVAL"].includes(invitation.status)) {
            const expired = await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'APPROVAL_TIMEOUT',
                     modified_time = NOW()
                 WHERE booking_code = $1
                   AND approval_timeout_at IS NOT NULL
                   AND approval_timeout_at < NOW()
                   AND status IN ('WAITING_BM_APPROVAL', 'WAITING_HOST_APPROVAL')
                 RETURNING invitation_id, booking_code, status, checked_in_time, approval_mode,
                           bm_approval_status, host_approval_status,
                           approval_starts_at, approval_timeout_at,
                           approval_operational_start, approval_operational_end, approval_operational_days,
                           approval_holiday_dates, approval_timeout_minutes, approval_timezone,
                           bm_reject_reason, host_reject_reason, cancel_reason,
                           access_mode, activation_timing`,
                [bookingCode]
            );
            if (expired.rows.length) invitation = expired.rows[0];
        }

        const memberMap = typeof loadInvitationMembers === "function"
            ? await loadInvitationMembers(invitation.invitation_id, {
                includeAccess: ["ACCESS_READY", "CHECKED_IN", "WAITING_ARRIVAL"].includes(String(invitation.status || "").toUpperCase())
                    && invitation.expiry_date
                    && new Date(invitation.expiry_date) > new Date()
            })
            : new Map();
        invitation.members = memberMap.get(Number(invitation.invitation_id)) || [];
        invitation.group_member_count = invitation.members.length;

        res.json({ success: true, data: invitation });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/hosts", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT host_id, host_name, host_email, host_whatsapp, location, note, description,
                   approval_schedule_override, approval_operational_start, approval_operational_end, approval_operational_days,
                   approval_national_holidays_closed, approval_collective_leave_closed,
                   created_at, modified_at
            FROM visitor_hosts
            ORDER BY host_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/hosts", async (req, res) => {
    try {
        const hostName = String(req.body.host_name || "").trim();
        const hostEmail = String(req.body.host_email || "").trim();
        const hostWhatsapp = String(req.body.host_whatsapp || "").trim();
        const location = String(req.body.location || "").trim();
        const note = String(req.body.note || req.body.description || "").trim();
        const scheduleOverride = req.body.approval_schedule_override === true;
        const operationalStart = normalizeApprovalTime(req.body.approval_operational_start, DEFAULT_OPERATIONAL_START);
        const operationalEnd = normalizeApprovalTime(req.body.approval_operational_end, DEFAULT_OPERATIONAL_END);
        const operationalDays = normalizeApprovalDays(req.body.approval_operational_days, DEFAULT_OPERATIONAL_DAYS);
        const nationalHolidaysClosed = req.body.approval_national_holidays_closed !== false;
        const collectiveLeaveClosed = req.body.approval_collective_leave_closed !== false;

        if (!hostName) {
            return res.status(400).json({ success: false, message: "Nama host wajib diisi" });
        }
        if (scheduleOverride && operationalEnd <= operationalStart) {
            return res.status(400).json({ success: false, message: "Jam operasional Host selesai harus lebih besar dari jam mulai." });
        }

        const result = await pool.query(
            `INSERT INTO visitor_hosts (
                host_name, host_email, host_whatsapp, location, note, description,
                approval_schedule_override, approval_operational_start, approval_operational_end, approval_operational_days,
                approval_national_holidays_closed, approval_collective_leave_closed
             )
             VALUES ($1, $2, $3, $4, $5, $5, $6, $7, $8, $9, $10, $11)
             RETURNING *`,
            [hostName, hostEmail || null, hostWhatsapp || null, location || null, note || null, scheduleOverride, operationalStart, operationalEnd, operationalDays.join(","), nationalHolidaysClosed, collectiveLeaveClosed]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Host sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/hosts/:id", async (req, res) => {
    try {
        const hostName = String(req.body.host_name || "").trim();
        const hostEmail = String(req.body.host_email || "").trim();
        const hostWhatsapp = String(req.body.host_whatsapp || "").trim();
        const location = String(req.body.location || "").trim();
        const note = String(req.body.note || req.body.description || "").trim();
        const scheduleOverride = req.body.approval_schedule_override === true;
        const operationalStart = normalizeApprovalTime(req.body.approval_operational_start, DEFAULT_OPERATIONAL_START);
        const operationalEnd = normalizeApprovalTime(req.body.approval_operational_end, DEFAULT_OPERATIONAL_END);
        const operationalDays = normalizeApprovalDays(req.body.approval_operational_days, DEFAULT_OPERATIONAL_DAYS);
        const nationalHolidaysClosed = req.body.approval_national_holidays_closed !== false;
        const collectiveLeaveClosed = req.body.approval_collective_leave_closed !== false;

        if (!hostName) {
            return res.status(400).json({ success: false, message: "Nama host wajib diisi" });
        }
        if (scheduleOverride && operationalEnd <= operationalStart) {
            return res.status(400).json({ success: false, message: "Jam operasional Host selesai harus lebih besar dari jam mulai." });
        }

        const result = await pool.query(
            `UPDATE visitor_hosts
             SET host_name = $1,
                 host_email = $2,
                 host_whatsapp = $3,
                 location = $4,
                 note = $5,
                 description = $5,
                 approval_schedule_override = $6,
                 approval_operational_start = $7,
                 approval_operational_end = $8,
                 approval_operational_days = $9,
                 approval_national_holidays_closed = $10,
                 approval_collective_leave_closed = $11,
                 modified_at = NOW()
             WHERE host_id = $12
             RETURNING *`,
            [hostName, hostEmail || null, hostWhatsapp || null, location || null, note || null, scheduleOverride, operationalStart, operationalEnd, operationalDays.join(","), nationalHolidaysClosed, collectiveLeaveClosed, req.params.id]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Host tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Host sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.get("/api/hosts/:id/visitors", async (req, res) => {
    try {
        const hostResult = await pool.query(
            `SELECT host_id, host_name, host_email, host_whatsapp, location, note, description,
                    approval_schedule_override, approval_operational_start, approval_operational_end, approval_operational_days,
                    approval_national_holidays_closed, approval_collective_leave_closed,
                    created_at, modified_at
             FROM visitor_hosts
             WHERE host_id = $1`,
            [req.params.id]
        );

        if (!hostResult.rows.length) {
            return res.status(404).json({ success: false, message: "Host tidak ditemukan" });
        }

        const host = hostResult.rows[0];
        const visitorsResult = await pool.query(
            `SELECT visitor_id,
                    first_name,
                    second_name,
                    identity_number,
                    company_name,
                    email_address,
                    phone_number,
                    card_number,
                    permission_group,
                    purpose_note,
                    check_in_time,
                    check_out_time,
                    created_by,
                    created_time,
                    modified_by,
                    modified_time
             FROM visitor_registration
             WHERE host = $1
             ORDER BY check_in_time DESC NULLS LAST, visitor_id DESC`,
            [host.host_name]
        );

        const rows = visitorsResult.rows;
        const uniqueVisitors = new Set(
            rows.map(row => String(row.identity_number || "").trim()).filter(Boolean)
        );

        res.json({
            success: true,
            data: {
                host,
                summary: {
                    total_visits: rows.length,
                    active_visits: rows.filter(row => !row.check_out_time).length,
                    checked_out_visits: rows.filter(row => row.check_out_time).length,
                    unique_visitors: uniqueVisitors.size
                },
                visitors: rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/host-notification-settings", async (req, res) => {
    try {
        const settings = await getHostNotificationSettings();
        res.json({
            success: true,
            data: {
                enabled: settings?.enabled === true,
                email_subject: settings?.email_subject || "Visitor Check-In - {{visitor_name}}",
                email_body: settings?.email_body || "",
                whatsapp_enabled: settings?.whatsapp_enabled === true,
                whatsapp_body: settings?.whatsapp_body || ""
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/host-notification-settings", async (req, res) => {
    try {
        const emailSubject = String(req.body.email_subject || "Visitor Check-In - {{visitor_name}}").trim();
        const emailBody = String(req.body.email_body || "").trim()
            || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}";
        const whatsappBody = String(req.body.whatsapp_body || "").trim()
            || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}";

        const result = await pool.query(
            `UPDATE host_notification_settings
             SET enabled = $1,
                 email_subject = $2,
                 email_body = $3,
                 whatsapp_enabled = $4,
                 whatsapp_body = $5,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [req.body.enabled === true, emailSubject, emailBody, req.body.whatsapp_enabled === true, whatsappBody]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/hosts/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM visitor_hosts WHERE host_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/cloudflare-tunnel-health", (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json({ success: true, status: "ok", server_time: new Date().toISOString() });
});

router.get("/api/cloudflare-quick-tunnel/status", requireAccessOperator, async (req, res) => {
    try {
        await ensureVisitorSchema();
        res.json({ success: true, data: await cloudflareQuickTunnel.getStatus() });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/cloudflare-quick-tunnel/start", requireAccessOperator, async (req, res) => {
    try {
        await ensureVisitorSchema();
        const data = await cloudflareQuickTunnel.start({ replaceManual: req.body?.replace_manual === true });
        await saveActivityLog(req, "CLOUDFLARE_TUNNEL_START", `Quick Tunnel aktif: ${data.url || "-"}`);
        res.json({ success: true, data, message: "Quick Tunnel berhasil dibuat dan Public URL sudah diperbarui." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message, data: await cloudflareQuickTunnel.getStatus().catch(() => null) });
    }
});

router.post("/api/cloudflare-quick-tunnel/stop", requireAccessOperator, async (req, res) => {
    try {
        await ensureVisitorSchema();
        const data = await cloudflareQuickTunnel.stop();
        await saveActivityLog(req, "CLOUDFLARE_TUNNEL_STOP", "Quick Tunnel dihentikan oleh operator.");
        res.json({ success: true, data, message: "Quick Tunnel berhasil dihentikan." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/cloudflare-quick-tunnel/retry", requireAccessOperator, async (req, res) => {
    try {
        await ensureVisitorSchema();
        const data = await cloudflareQuickTunnel.restart({ replaceManual: req.body?.replace_manual === true });
        await saveActivityLog(req, "CLOUDFLARE_TUNNEL_RETRY", `Quick Tunnel dibuat ulang: ${data.url || "-"}`);
        res.json({ success: true, data, message: "Quick Tunnel berhasil dibuat ulang. URL publik baru sudah aktif." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message, data: await cloudflareQuickTunnel.getStatus().catch(() => null) });
    }
});

router.put("/api/cloudflare-quick-tunnel/auto-start", requireAccessOperator, async (req, res) => {
    try {
        await ensureVisitorSchema();
        const enabled = req.body?.enabled === true;
        const data = await cloudflareQuickTunnel.setAutoStart(enabled);
        await saveActivityLog(req, "CLOUDFLARE_TUNNEL_SETTING", `Auto-start Quick Tunnel ${enabled ? "diaktifkan" : "dinonaktifkan"}.`);
        res.json({ success: true, data, message: `Auto-start Quick Tunnel ${enabled ? "diaktifkan" : "dinonaktifkan"}.` });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/cloudflare-quick-tunnel/logs", requireAccessOperator, async (req, res) => {
    try {
        await ensureVisitorSchema();
        res.json({ success: true, data: cloudflareQuickTunnel.getLogs() });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/qr-settings", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/self-registration-settings", requireAccessOperator, async (req, res) => {
    try {
        const settings = await getSelfRegistrationSettings();
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/self-registration-settings", requireAccessOperator, async (req, res) => {
    try {
        const body = req.body || {};
        const current = await getSelfRegistrationSettings();
        const approvalTimezone = normalizeApprovalTimeZone(body.approval_timezone, current.approval_timezone || DEFAULT_TIME_ZONE);
        const bmOperationalStart = normalizeApprovalTime(body.bm_operational_start, current.bm_operational_start || DEFAULT_OPERATIONAL_START);
        const bmOperationalEnd = normalizeApprovalTime(body.bm_operational_end, current.bm_operational_end || DEFAULT_OPERATIONAL_END);
        const hostOperationalStart = normalizeApprovalTime(body.default_host_operational_start, current.default_host_operational_start || DEFAULT_OPERATIONAL_START);
        const hostOperationalEnd = normalizeApprovalTime(body.default_host_operational_end, current.default_host_operational_end || DEFAULT_OPERATIONAL_END);
        const bmOperationalDays = normalizeApprovalDays(body.bm_operational_days, current.bm_operational_days || DEFAULT_OPERATIONAL_DAYS);
        const hostOperationalDays = normalizeApprovalDays(body.default_host_operational_days, current.default_host_operational_days || DEFAULT_OPERATIONAL_DAYS);
        const nationalHolidaysClosed = body.national_holidays_closed === undefined ? current.national_holidays_closed : body.national_holidays_closed !== false;
        const collectiveLeaveClosed = body.collective_leave_closed === undefined ? current.collective_leave_closed : body.collective_leave_closed !== false;
        if (bmOperationalEnd <= bmOperationalStart || hostOperationalEnd <= hostOperationalStart) {
            return res.status(400).json({ success: false, message: "Jam operasional selesai harus lebih besar dari jam mulai." });
        }
        const result = await pool.query(
            `UPDATE self_registration_settings
             SET approval_mode = $1,
                 bm_timeout_minutes = $2,
                 host_timeout_minutes = $3,
                 approval_timezone = $4,
                 bm_operational_start = $5,
                 bm_operational_end = $6,
                 default_host_operational_start = $7,
                 default_host_operational_end = $8,
                 bm_operational_days = $9,
                 default_host_operational_days = $10,
                 national_holidays_closed = $11,
                 collective_leave_closed = $12,
                 host_email_enabled = $13,
                 host_whatsapp_enabled = $14,
                 group_registration_enabled = $15,
                 group_max_members = $16,
                 group_qr_mode = $17,
                 member_identity_photo_required = $18,
                 member_face_photo_required = $19,
                 updated_by = $20,
                 access_mode = $21,
                 activation_timing = $22,
                 checkin_qr_title = $23,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                normalizeSelfRegistrationApprovalMode(body.approval_mode),
                clampInteger(body.bm_timeout_minutes, 60, 1, 10080),
                clampInteger(body.host_timeout_minutes, 60, 1, 10080),
                approvalTimezone,
                bmOperationalStart,
                bmOperationalEnd,
                hostOperationalStart,
                hostOperationalEnd,
                bmOperationalDays.join(","),
                hostOperationalDays.join(","),
                nationalHolidaysClosed,
                collectiveLeaveClosed,
                body.host_email_enabled !== false,
                body.host_whatsapp_enabled === true,
                body.group_registration_enabled === true,
                clampInteger(body.group_max_members, 10, 1, 100),
                "PER_PERSON",
                body.member_identity_photo_required !== false,
                body.member_face_photo_required !== false,
                getCurrentUsername(req),
                body.access_mode === "AUTOMATIC" ? "AUTOMATIC" : "OPERATOR",
                body.activation_timing === "ON_OPERATOR_CHECKIN" ? "ON_OPERATOR_CHECKIN" : "AFTER_APPROVAL",
                String(body.checkin_qr_title || "Visitor Location Check-in").trim().slice(0, 150) || "Visitor Location Check-in"
            ]
        );
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/self-registration-settings/approval-schedule", requireAccessOperator, async (req, res) => {
    try {
        const body = req.body || {};
        const current = await getSelfRegistrationSettings();
        const approvalTimezone = normalizeApprovalTimeZone(body.approval_timezone, current.approval_timezone || DEFAULT_TIME_ZONE);
        const bmOperationalStart = normalizeApprovalTime(body.bm_operational_start, current.bm_operational_start || DEFAULT_OPERATIONAL_START);
        const bmOperationalEnd = normalizeApprovalTime(body.bm_operational_end, current.bm_operational_end || DEFAULT_OPERATIONAL_END);
        const hostOperationalStart = normalizeApprovalTime(body.default_host_operational_start, current.default_host_operational_start || DEFAULT_OPERATIONAL_START);
        const hostOperationalEnd = normalizeApprovalTime(body.default_host_operational_end, current.default_host_operational_end || DEFAULT_OPERATIONAL_END);
        const bmOperationalDays = normalizeApprovalDays(body.bm_operational_days, current.bm_operational_days || DEFAULT_OPERATIONAL_DAYS);
        const hostOperationalDays = normalizeApprovalDays(body.default_host_operational_days, current.default_host_operational_days || DEFAULT_OPERATIONAL_DAYS);
        if (bmOperationalEnd <= bmOperationalStart || hostOperationalEnd <= hostOperationalStart) {
            return res.status(400).json({ success: false, message: "Jam operasional selesai harus lebih besar dari jam mulai." });
        }

        const result = await pool.query(
            `UPDATE self_registration_settings
             SET approval_timezone = $1,
                 bm_operational_start = $2,
                 bm_operational_end = $3,
                 default_host_operational_start = $4,
                 default_host_operational_end = $5,
                 bm_operational_days = $6,
                 default_host_operational_days = $7,
                 national_holidays_closed = $8,
                 collective_leave_closed = $9,
                 updated_by = $10,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                approvalTimezone,
                bmOperationalStart,
                bmOperationalEnd,
                hostOperationalStart,
                hostOperationalEnd,
                bmOperationalDays.join(","),
                hostOperationalDays.join(","),
                body.national_holidays_closed === undefined ? current.national_holidays_closed : body.national_holidays_closed !== false,
                body.collective_leave_closed === undefined ? current.collective_leave_closed : body.collective_leave_closed !== false,
                getCurrentUsername(req)
            ]
        );
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/self-registration-holidays", requireAccessOperator, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT holiday_id, holiday_date::text AS holiday_date, holiday_name, holiday_type, is_active, created_by, created_at, modified_at
             FROM self_registration_holidays
             ORDER BY holiday_date ASC, holiday_id ASC`
        );
        res.json({
            success: true,
            data: result.rows.map(row => ({
                ...row,
                holiday_date: toDateKey(row.holiday_date)
            }))
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/self-registration-holidays", requireAccessOperator, async (req, res) => {
    try {
        const holidayDate = String(req.body?.holiday_date || "").trim();
        const holidayName = String(req.body?.holiday_name || "").trim().slice(0, 180);
        const holidayType = String(req.body?.holiday_type || "NATIONAL_HOLIDAY").trim().toUpperCase();
        const allowedTypes = ["NATIONAL_HOLIDAY", "COLLECTIVE_LEAVE", "CUSTOM_CLOSED", "OPEN_OVERRIDE"];
        if (!/^\d{4}-\d{2}-\d{2}$/.test(holidayDate)) {
            return res.status(400).json({ success: false, message: "Tanggal kalender libur tidak valid." });
        }
        if (!holidayName) return res.status(400).json({ success: false, message: "Nama kalender libur wajib diisi." });
        if (!allowedTypes.includes(holidayType)) {
            return res.status(400).json({ success: false, message: "Tipe kalender libur tidak valid." });
        }
        const result = await pool.query(
            `INSERT INTO self_registration_holidays (
                holiday_date, holiday_name, holiday_type, is_active, created_by, created_at
             ) VALUES ($1, $2, $3, TRUE, $4, NOW())
             ON CONFLICT (holiday_date) DO UPDATE
             SET holiday_name = EXCLUDED.holiday_name,
                 holiday_type = EXCLUDED.holiday_type,
                 is_active = TRUE,
                 created_by = EXCLUDED.created_by,
                modified_at = NOW()
             RETURNING holiday_id, holiday_date::text AS holiday_date, holiday_name, holiday_type, is_active, created_by, created_at, modified_at`,
            [holidayDate, holidayName, holidayType, getCurrentUsername(req)]
        );
        res.json({
            success: true,
            data: {
                ...result.rows[0],
                holiday_date: toDateKey(result.rows[0]?.holiday_date)
            },
            message: "Kalender libur berhasil disimpan."
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/self-registration-holidays/:id", requireAccessOperator, async (req, res) => {
    try {
        const result = await pool.query(
            "DELETE FROM self_registration_holidays WHERE holiday_id = $1 RETURNING holiday_id",
            [req.params.id]
        );
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Kalender libur tidak ditemukan." });
        res.json({ success: true, message: "Tanggal berhasil dihapus dari kalender operasional." });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/self-registration-settings/checkin-qr/regenerate", requireAccessOperator, async (req, res) => {
    try {
        if (String(req.session?.role_name || "").toUpperCase() !== "SUPERADMIN") {
            return res.status(403).json({ success: false, message: "Hanya SUPERADMIN yang bisa mengganti QR Check-in Lokasi." });
        }
        const result = await pool.query(
            `UPDATE self_registration_settings
             SET checkin_qr_token=$1, updated_by=$2, updated_at=NOW()
             WHERE setting_id=1 RETURNING *`,
            [crypto.randomBytes(32).toString("hex"), getCurrentUsername(req)]
        );
        res.json({ success: true, data: result.rows[0], message: "QR Check-in Lokasi baru berhasil dibuat. QR lama langsung tidak berlaku." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/qr-settings", async (req, res) => {
    try {
        const currentResult = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
        const currentSettings = currentResult.rows[0] || {};
        const digitLength = Math.min(Math.max(parseInt(req.body.digit_length, 10) || 10, 4), 24);
        const previewTitle = String(req.body.preview_title || "Visitor QR Code").trim();
        const previewSubtitle = String(req.body.preview_subtitle || "QR Code dibuat dari Card Number").trim();
        const showCardNumber = req.body.show_card_number !== false;
        const autoEmail = req.body.auto_email === true;
        const autoWhatsapp = req.body.auto_whatsapp === true;
        const autoSms = req.body.auto_sms === true;
        const publicBaseUrl = String(req.body.public_base_url || "").trim();
        const selfRegistrationQrTitle = String(req.body.self_registration_qr_title || "Visitor Self Registration").trim();
        const selfRegistrationQrSubtitle = String(req.body.self_registration_qr_subtitle || "Scan QR untuk isi form kunjungan mandiri").trim();
        const normalizePublicUrl = value => String(value || "").trim().replace(/\/+$/g, "");
        const normalizedPublicUrl = normalizePublicUrl(publicBaseUrl);
        const currentPublicUrl = normalizePublicUrl(currentSettings.public_base_url);
        const lastQuickTunnelUrl = normalizePublicUrl(currentSettings.quick_tunnel_last_url);
        const publicUrlChanged = normalizedPublicUrl !== currentPublicUrl;
        const publicBaseUrlSource = publicUrlChanged
            ? (normalizedPublicUrl && normalizedPublicUrl === lastQuickTunnelUrl ? "QUICK_TUNNEL" : "MANUAL")
            : (currentSettings.public_base_url_source || "MANUAL");
        const quickTunnelAutoStart = publicUrlChanged && publicBaseUrlSource === "MANUAL"
            ? false
            : currentSettings.quick_tunnel_auto_start === true;

        const result = await pool.query(
            `UPDATE qr_settings
             SET digit_length = $1,
                 preview_title = $2,
                 preview_subtitle = $3,
                 show_card_number = $4,
                 auto_email = $5,
                 auto_whatsapp = $6,
                 auto_sms = $7,
                 public_base_url = $8,
                 self_registration_qr_title = $9,
                 self_registration_qr_subtitle = $10,
                 public_base_url_source = $11,
                 quick_tunnel_auto_start = $12,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                digitLength,
                previewTitle,
                previewSubtitle,
                showCardNumber,
                autoEmail,
                autoWhatsapp,
                autoSms,
                publicBaseUrl || null,
                selfRegistrationQrTitle || "Visitor Self Registration",
                selfRegistrationQrSubtitle || "Scan QR untuk isi form kunjungan mandiri",
                publicBaseUrlSource,
                quickTunnelAutoStart
            ]
        );

        if (autoEmail) {
            await pool.query(`
                UPDATE self_registration_access_jobs j
                SET email_status='PENDING',
                    email_error=NULL,
                    updated_at=NOW()
                FROM visitor_invitations i
                WHERE i.invitation_id=j.invitation_id
                  AND i.status IN ('ACCESS_READY','CHECKED_IN')
                  AND i.expiry_date > NOW()
                  AND j.phase='PROVISION'
                  AND j.email_status IN ('SKIPPED','FAILED')
            `);
        }

        if (autoWhatsapp) {
            await pool.query(`
                UPDATE self_registration_access_jobs j
                SET whatsapp_status='PENDING',
                    whatsapp_error=NULL,
                    updated_at=NOW()
                FROM visitor_invitations i
                WHERE i.invitation_id=j.invitation_id
                  AND i.status IN ('ACCESS_READY','CHECKED_IN')
                  AND i.expiry_date > NOW()
                  AND j.phase='PROVISION'
                  AND j.whatsapp_status IN ('SKIPPED','FAILED')
            `);
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/card-format-settings", async (req, res) => {
    try {
        const settings = await getCardFormatSettings(pool);
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/card-format-settings", async (req, res) => {
    try {
        const settings = normalizeCardFormatSettings(req.body || {});
        const result = await pool.query(
            `UPDATE card_format_settings
             SET enabled = $1,
                 profile_name = $2,
                 format_mode = $3,
                 input_base = $4,
                 output_base = $5,
                 wiegand_preset = $6,
                 wiegand_total_bits = $7,
                 wiegand_facility_start = $8,
                 wiegand_facility_bits = $9,
                 wiegand_card_start = $10,
                 wiegand_card_bits = $11,
                 wiegand_bit_order = $12,
                 wiegand_output = $13,
                 remove_non_alnum = $14,
                 uppercase = $15,
                 reverse_bytes = $16,
                 slice_mode = $17,
                 slice_length = $18,
                 pad_side = $19,
                 pad_length = $20,
                 pad_char = $21,
                 prefix = $22,
                 suffix = $23,
                 max_length = $24,
                 max_length_keep = $25,
                 apply_to_api = $26,
                 apply_to_qr = $27,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                settings.enabled,
                settings.profile_name,
                settings.format_mode,
                settings.input_base,
                settings.output_base,
                settings.wiegand_preset,
                settings.wiegand_total_bits,
                settings.wiegand_facility_start,
                settings.wiegand_facility_bits,
                settings.wiegand_card_start,
                settings.wiegand_card_bits,
                settings.wiegand_bit_order,
                settings.wiegand_output,
                settings.remove_non_alnum,
                settings.uppercase,
                settings.reverse_bytes,
                settings.slice_mode,
                settings.slice_length,
                settings.pad_side,
                settings.pad_length,
                settings.pad_char,
                settings.prefix,
                settings.suffix,
                settings.max_length,
                settings.max_length_keep,
                settings.apply_to_api,
                settings.apply_to_qr
            ]
        );

        res.json({ success: true, data: normalizeCardFormatSettings(result.rows[0]) });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/card-format-settings/preview", async (req, res) => {
    try {
        const settings = normalizeCardFormatSettings(req.body?.settings || req.body || {});
        const preview = formatCardNumber(req.body?.card_number || req.body?.sample_card || "", settings);
        res.json({ success: true, data: preview });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/card-format-settings/analyze", async (req, res) => {
    try {
        const analysis = analyzeCardFormats(req.body?.samples || []);
        res.json({ success: true, data: analysis });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/smtp-settings", async (req, res) => {
    try {
        const settings = await getSmtpSettings();
        if (!settings) {
            return res.json({ success: true, data: null });
        }

        res.json({
            success: true,
            data: {
                smtp_host: settings.smtp_host || "",
                smtp_port: settings.smtp_port || 587,
                smtp_secure: settings.smtp_secure === true,
                smtp_user: settings.smtp_user || "",
                smtp_pass: settings.smtp_pass || "",
                password_configured: Boolean(settings.smtp_pass),
                from_email: settings.from_email || "",
                from_name: settings.from_name || "Visitor Registration",
                email_subject: settings.email_subject || "Visitor QR Code - {{visitor_name}}",
                email_body: settings.email_body || "",
                invitation_email_subject: settings.invitation_email_subject || "Visitor Invitation - {{booking_code}}",
                invitation_email_body: settings.invitation_email_body || "Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang."
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/smtp-settings", async (req, res) => {
    try {
        const current = await getSmtpSettings();
        const smtpHost = String(req.body.smtp_host || "").trim();
        const smtpPort = parseInt(req.body.smtp_port, 10) || 587;
        const smtpSecure = req.body.smtp_secure === true;
        const smtpUser = String(req.body.smtp_user || "").trim();
        const smtpPass = String(req.body.smtp_pass || "").trim();
        const fromEmail = String(req.body.from_email || "").trim();
        const fromName = String(req.body.from_name || "Visitor Registration").trim();
        const emailSubject = String(req.body.email_subject || "Visitor QR Code - {{visitor_name}}").trim();
        const emailBody = String(req.body.email_body || "").trim();
        const invitationEmailSubject = String(req.body.invitation_email_subject || "Visitor Invitation - {{booking_code}}").trim();
        const invitationEmailBody = String(req.body.invitation_email_body || "").trim();

        const result = await pool.query(
            `UPDATE smtp_settings
             SET smtp_host = $1,
                 smtp_port = $2,
                 smtp_secure = $3,
                 smtp_user = $4,
                 smtp_pass = $5,
                 from_email = $6,
                 from_name = $7,
                 email_subject = $8,
                 email_body = $9,
                 invitation_email_subject = $10,
                 invitation_email_body = $11,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                smtpHost || null,
                smtpPort,
                smtpSecure,
                smtpUser || null,
                smtpPass || current?.smtp_pass || null,
                fromEmail || null,
                fromName || "Visitor Registration",
                emailSubject || "Visitor QR Code - {{visitor_name}}",
                emailBody || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
                invitationEmailSubject || "Visitor Invitation - {{booking_code}}",
                invitationEmailBody || "Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang."
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/smtp-settings/test", async (req, res) => {
    try {
        const testEmail = String(req.body.test_email || "").trim();
        if (!testEmail) {
            return res.status(400).json({ success: false, message: "Email tujuan test wajib diisi." });
        }

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: testEmail,
            subject: "SMTP Test - Visitor Registration",
            text: "SMTP berhasil digunakan untuk mengirim email dari Visitor Registration Portal."
        });

        res.json({ success: true, message: "Test email berhasil dikirim." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/send-qr-email", async (req, res) => {
    try {
        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const {
            to_email,
            visitor_name,
            host,
            start,
            expiry,
            card_number,
            share_url,
            image_base64
        } = req.body;

        const targetEmail = String(to_email || "").trim();
        if (!targetEmail) {
            return res.status(400).json({ success: false, message: "Email visitor belum diisi." });
        }

        if (!image_base64) {
            return res.status(400).json({ success: false, message: "Gambar QR belum tersedia." });
        }

        const templateData = {
            visitor_name: visitor_name || "Visitor",
            host: host || "-",
            start: start || "-",
            expiry: expiry || "-",
            card_number: card_number || "-",
            share_url: share_url || "-"
        };

        const subject = buildTemplate(settings.email_subject, templateData);
        const body = buildTemplate(settings.email_body, templateData);
        const imageBuffer = Buffer.from(String(image_base64).replace(/^data:image\/png;base64,/, ""), "base64");

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body,
            attachments: [
                {
                    filename: `QR_${String(card_number || "visitor").replace(/[^a-z0-9_-]+/gi, "_")}.png`,
                    content: imageBuffer,
                    contentType: "image/png"
                }
            ]
        });

        await saveActivityLog(
            req,
            "SEND_QR_EMAIL",
            `Send QR email to ${targetEmail} for ${visitor_name || "Visitor"} (Card ${card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_name: visitor_name || "Visitor",
            target: targetEmail,
            title: "Email QR ke Visitor berhasil",
            message: `QR Code visitor berhasil dikirim ke ${targetEmail}.`,
            detail: { card_number: card_number || null, share_url: share_url || null }
        });

        res.json({ success: true, message: "Email QR berhasil dikirim." });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_name: req.body?.visitor_name || "Visitor",
            target: req.body?.to_email || null,
            title: "Email QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: req.body?.card_number || null }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/whatsapp-settings", requireAccessOperator, async (req, res) => {
    try {
        const settings = await getWhatsappSettings();
        res.json({
            success: true,
            data: {
                send_mode: settings?.send_mode || "manual",
                provider: normalizeWhatsappProvider(settings?.provider),
                phone_number_id: settings?.phone_number_id || "",
                base_url: settings?.base_url || VPSMURAH_CLOUDCHAT_BASE_URL,
                api_version: settings?.api_version || "v20.0",
                token_configured: Boolean(settings?.access_token),
                message_template: settings?.message_template || ""
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/whatsapp-settings", requireAccessOperator, async (req, res) => {
    try {
        const current = await getWhatsappSettings();
        const sendMode = ["manual", "api"].includes(req.body.send_mode) ? req.body.send_mode : "manual";
        const provider = normalizeWhatsappProvider(req.body.provider);
        if (!["meta", "vpsmurah"].includes(provider)) {
            return res.status(400).json({ success: false, message: "Provider WhatsApp belum didukung." });
        }
        const accessToken = String(req.body.access_token || "").trim();
        const currentProvider = normalizeWhatsappProvider(current?.provider);
        const effectiveAccessToken = accessToken || (currentProvider === provider ? current?.access_token : null);
        const phoneNumberId = String(req.body.phone_number_id || "").trim();
        const baseUrl = String(req.body.base_url || "").trim().replace(/\/+$/, "")
            || VPSMURAH_CLOUDCHAT_BASE_URL;
        if (provider === "vpsmurah" && !/^https:\/\//i.test(baseUrl)) {
            return res.status(400).json({ success: false, message: "Base URL VPSMurah CloudChat harus menggunakan HTTPS." });
        }
        const apiVersion = String(req.body.api_version || "v20.0").trim() || "v20.0";
        const messageTemplate = String(req.body.message_template || "").trim()
            || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}";
        if (sendMode === "api" && !effectiveAccessToken) {
            return res.status(400).json({
                success: false,
                message: provider === "vpsmurah" ? "API Key VPSMurah CloudChat wajib diisi." : "Access Token Meta wajib diisi."
            });
        }
        if (sendMode === "api" && provider === "meta" && !(phoneNumberId || current?.phone_number_id)) {
            return res.status(400).json({ success: false, message: "Phone Number ID Meta wajib diisi." });
        }

        const result = await pool.query(
            `UPDATE whatsapp_settings
             SET send_mode = $1,
                 provider = $2,
                 access_token = $3,
                 phone_number_id = $4,
                 base_url = $5,
                 api_version = $6,
                 message_template = $7,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                sendMode,
                provider,
                effectiveAccessToken,
                phoneNumberId || current?.phone_number_id || null,
                baseUrl,
                apiVersion,
                messageTemplate
            ]
        );

        const saved = result.rows[0] || {};
        res.json({
            success: true,
            data: {
                send_mode: saved.send_mode || sendMode,
                provider: saved.provider || provider,
                phone_number_id: saved.phone_number_id || "",
                base_url: saved.base_url || baseUrl,
                api_version: saved.api_version || apiVersion,
                token_configured: Boolean(saved.access_token),
                message_template: saved.message_template || messageTemplate
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/send-qr-whatsapp", requireAccessOperator, async (req, res) => {
    try {
        const settings = await getWhatsappSettings();

        if (!settings || settings.send_mode !== "api") {
            return res.status(400).json({ success: false, message: "Mode WhatsApp API belum aktif." });
        }

        try {
            assertWhatsappApiSettings(settings);
        } catch (error) {
            return res.status(400).json({ success: false, message: error.message });
        }

        const {
            to_phone,
            visitor_name,
            host,
            start,
            expiry,
            card_number,
            share_url,
            image_base64
        } = req.body;

        const targetPhone = normalizeWhatsappPhone(to_phone);
        if (!targetPhone) {
            return res.status(400).json({ success: false, message: "Nomor WhatsApp visitor belum diisi." });
        }

        if (normalizeWhatsappProvider(settings.provider) === "meta" && !image_base64) {
            return res.status(400).json({ success: false, message: "Gambar QR belum tersedia." });
        }

        const templateData = {
            visitor_name: visitor_name || "Visitor",
            host: host || "-",
            start: start || "-",
            expiry: expiry || "-",
            card_number: card_number || "-",
            share_url: share_url || "-"
        };
        const caption = buildTemplate(settings.message_template, templateData);
        const qrSettings = await getQrSettings();
        const publicImageUrl = buildPublicQrImageUrl(qrSettings, card_number, share_url);
        const imageBuffer = image_base64
            ? Buffer.from(String(image_base64).replace(/^data:image\/png;base64,/, ""), "base64")
            : null;
        const mediaResult = await sendWhatsappQrMedia(settings, {
            toPhone: targetPhone,
            caption,
            qrValue: card_number,
            publicImageUrl,
            imageBuffer
        });

        await saveActivityLog(
            req,
            "SEND_QR_WHATSAPP",
            `Send QR WhatsApp API to ${targetPhone} for ${visitor_name || "Visitor"} (Card ${card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_name: visitor_name || "Visitor",
            target: targetPhone,
            title: "WhatsApp QR berhasil",
            message: `QR Code visitor berhasil dikirim via WhatsApp Business API ke ${targetPhone}.`,
            detail: {
                provider: mediaResult.provider,
                card_number: card_number || null,
                media_url: mediaResult.mediaUrl || null,
                response: mediaResult.response
            }
        });

        res.json({ success: true, message: "WhatsApp QR berhasil dikirim via API.", data: mediaResult.response });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_name: req.body?.visitor_name || "Visitor",
            target: req.body?.to_phone || null,
            title: "WhatsApp QR gagal",
            message: error.message,
            detail: { provider: "WHATSAPP_API", card_number: req.body?.card_number || null }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/whatsapp-opened", requireAccessOperator, async (req, res) => {
    try {
        const targetPhone = normalizeWhatsappPhone(req.body?.to_phone);
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: req.body?.event_type || "QR_SHARE",
            status: "OPENED",
            visitor_id: req.body?.visitor_id || null,
            visitor_name: req.body?.visitor_name || "Visitor",
            target: targetPhone || req.body?.to_phone || null,
            title: "WhatsApp dibuka",
            message: targetPhone
                ? `WhatsApp dibuka ke nomor ${targetPhone}. Operator perlu klik kirim.`
                : "WhatsApp dibuka tanpa nomor tujuan. Operator perlu memilih nomor dan klik kirim.",
            detail: {
                mode: "MANUAL",
                card_number: req.body?.card_number || null,
                booking_code: req.body?.booking_code || null
            }
        });
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/auto-checkout-settings", async (req, res) => {
    try {
        const settings = await getAutoCheckoutSettings();
        res.json({
            success: true,
            data: {
                ...settings,
                schedule_date: normalizeDate(settings.schedule_date),
                schedule_time: normalizeTime(settings.schedule_time),
                schedule_type: normalizeScheduleType(settings.schedule_type)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/auto-checkout-settings", async (req, res) => {
    try {
        const body = req.body || {};
        const result = await pool.query(
            `UPDATE auto_checkout_settings
             SET enabled = $1,
                 schedule_date = $2,
                 schedule_time = $3,
                 schedule_type = $4,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                body.enabled === true,
                normalizeDate(body.schedule_date),
                normalizeTime(body.schedule_time),
                normalizeScheduleType(body.schedule_type)
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/auto-checkout/run-now", async (req, res) => {
    try {
        const result = await runAutoCheckout(getCurrentUsername(req), req.ip);
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update Check-In / Check-Out
router.post("/visitors/update-status", async (req, res) => {
    try {

        const { id, type } = req.body;
        if (type !== "checkin") {
            const visitor = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [id]);
            if (visitor.rows.length === 0) {
                return res.status(404).json({ success: false, message: "Visitor not found" });
            }
            const checkoutResult = await checkoutVisitorRecord(visitor.rows[0], req, "MANUAL_CHECKOUT");
            return res.status(checkoutResult.success ? 200 : 409).json(checkoutResult);
        }

        const column =
            (type === 'checkin')
            ? 'check_in_time'
            : 'check_out_time';

        const result = await pool.query(
            `UPDATE visitor_registration
             SET ${column} = NOW(),
                 modified_by = $2,
                 modified_time = NOW()
             WHERE visitor_id = $1
             RETURNING *`,
            [id, getCurrentUsername(req)]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            type === "checkin" ? "CHECK_IN_VISITOR" : "CHECK_OUT_VISITOR",
            `${type === "checkin" ? "Check in" : "Check out"} visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );
        if (type === "checkin") {
            runCheckinFollowupBackground(req, result.rows[0]);
            return res.json({
                success: true,
                api_results: [],
                background_processing: true
            });
        }

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "CHECKOUT", result.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY STATUS API ERROR:", apiError.message);
            }
        }

        if (shouldReleaseInnerrangeSlot(apiResults)) {
            await releaseThirdPartyUserSlot(result.rows[0].third_party_user_id, result.rows[0].visitor_id);
        }

        runBackgroundTask(`DEVICE CHECKOUT VISITOR ${result.rows[0].visitor_id || "-"}`, () =>
            runDeviceSyncBackground(createBackgroundReq(req), result.rows[0], "CHECKOUT")
        );

        res.json({
            success: true,
            api_results: apiResults
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});

// Checked-in visitors and approved automatic access awaiting arrival.
router.get("/visitors", async (req, res) => {
    try {

        const result = await pool.query(`
            SELECT v.*, j.invitation_id AS access_invitation_id, i.status AS access_status,
                   j.phase AS access_phase, j.error AS access_error, j.email_status AS access_email_status,
                   j.email_error AS access_email_error, j.whatsapp_status AS access_whatsapp_status,
                   j.whatsapp_error AS access_whatsapp_error,
                   CASE WHEN i.status IN ('ACCESS_READY','CHECKED_IN') AND v.expiry_date>NOW() AND j.phase<>'REVOKE' THEN j.qr_value END AS access_qr_value,
                   ext.request_id AS extension_request_id, ext.status AS extension_status,
                   ext.bm_status AS extension_bm_status, ext.host_status AS extension_host_status,
                   ext.requested_expiry AS extension_requested_expiry,
                   COALESCE(note_summary.note_count, 0) AS note_count,
                   COALESCE(note_summary.unread_note_count, 0) AS unread_note_count,
                   note_summary.latest_operator_note
            FROM visitor_registration v
            LEFT JOIN self_registration_access_jobs j ON j.visitor_id=v.visitor_id
            LEFT JOIN visitor_invitations i ON i.invitation_id=j.invitation_id
            LEFT JOIN LATERAL (
                SELECT er.request_id, er.status, er.bm_status, er.host_status, er.requested_expiry
                FROM visitor_extension_requests er
                WHERE er.visitor_id=v.visitor_id
                  AND er.status IN ('WAITING_APPROVAL','APPROVED_SYNC_PENDING','SYNC_FAILED')
                ORDER BY er.request_id DESC
                LIMIT 1
            ) ext ON TRUE
            LEFT JOIN LATERAL (
                SELECT COUNT(*)::int AS note_count,
                       COUNT(*) FILTER (
                           WHERE n.created_by <> $1
                             AND NOT EXISTS (
                                 SELECT 1
                                 FROM visitor_operator_note_reads r
                                 WHERE r.note_id = n.note_id
                                   AND r.username = $1
                             )
                       )::int AS unread_note_count,
                       (ARRAY_AGG(n.note_text ORDER BY n.created_at DESC, n.note_id DESC))[1] AS latest_operator_note
                FROM visitor_operator_notes n
                WHERE n.visitor_id = v.visitor_id
            ) note_summary ON TRUE
            WHERE (v.check_out_time IS NULL AND v.check_in_time IS NOT NULL)
               OR (i.access_mode='AUTOMATIC' AND i.status IN ('ACCESS_PENDING','WAITING_ARRIVAL','ACCESS_READY','ACCESS_FAILED'))
            ORDER BY v.check_in_time ASC, v.visitor_id ASC
        `, [getCurrentUsername(req)]);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});


// ALL VISITOR LOGS
router.get("/api/visitor-log-filter-options", async (req, res) => {
    try {
        const [operators, groups, hosts] = await Promise.all([
            pool.query(`
                SELECT DISTINCT created_by
                FROM visitor_registration
                WHERE created_by IS NOT NULL
                  AND TRIM(created_by) <> ''
                ORDER BY created_by ASC
            `),
            pool.query(`
                SELECT group_name
                FROM permission_groups
                ORDER BY group_name ASC
            `),
            pool.query(`
                SELECT host_name
                FROM visitor_hosts
                ORDER BY host_name ASC
            `)
        ]);

        res.json({
            success: true,
            data: {
                operators: operators.rows.map(row => row.created_by),
                groups: groups.rows.map(row => row.group_name),
                hosts: hosts.rows.map(row => row.host_name)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-logs", async (req, res) => {
    try {
        const {
            created_by,
            visitor_name,
            permission_group,
            host,
            check_in_from,
            check_in_to,
            check_out_from,
            check_out_to
        } = req.query;

        const filters = ["v.check_out_time IS NOT NULL"];
        const params = [];

        const addParam = (value) => {
            params.push(value);
            return `$${params.length}`;
        };

        if (created_by) {
            filters.push(`v.created_by = ${addParam(created_by)}`);
        }

        if (visitor_name) {
            filters.push(`CONCAT_WS(' ', v.first_name, v.second_name) ILIKE ${addParam(`%${visitor_name}%`)}`);
        }

        if (permission_group) {
            filters.push(`v.permission_group = ${addParam(permission_group)}`);
        }

        if (host) {
            filters.push(`v.host = ${addParam(host)}`);
        }

        if (check_in_from) {
            filters.push(`v.check_in_time >= ${addParam(check_in_from)}::timestamp`);
        }

        if (check_in_to) {
            filters.push(`v.check_in_time <= ${addParam(check_in_to)}::timestamp`);
        }

        if (check_out_from) {
            filters.push(`v.check_out_time >= ${addParam(check_out_from)}::timestamp`);
        }

        if (check_out_to) {
            filters.push(`v.check_out_time <= ${addParam(check_out_to)}::timestamp`);
        }

        const currentUsernameParam = addParam(getCurrentUsername(req));

        const result = await pool.query(`

            WITH visitor_base AS (
                SELECT source.*,
                       COALESCE(UPPER(NULLIF(BTRIM(source.identity_number), '')), CONCAT('__VISITOR__:', source.visitor_id)) AS identity_key,
                       COUNT(*) FILTER (WHERE source.check_out_time IS NOT NULL) OVER (
                           PARTITION BY COALESCE(UPPER(NULLIF(BTRIM(source.identity_number), '')), CONCAT('__VISITOR__:', source.visitor_id))
                       )::int AS visit_count
                FROM visitor_registration source
            ),
            filtered_visits AS (
                SELECT v.*
                FROM visitor_base v
                WHERE ${filters.join(" AND ")}
            ),
            ranked_visits AS (
                SELECT filtered_visits.*,
                       ROW_NUMBER() OVER (
                           PARTITION BY identity_key
                           ORDER BY check_in_time DESC NULLS LAST, visitor_id DESC
                       ) AS identity_rank
                FROM filtered_visits
            )
            SELECT v.*,
                   COALESCE(note_summary.note_count, 0) AS note_count,
                   COALESCE(note_summary.unread_note_count, 0) AS unread_note_count
            FROM ranked_visits v
            LEFT JOIN LATERAL (
                SELECT COUNT(*)::int AS note_count,
                       COUNT(*) FILTER (
                           WHERE n.created_by <> ${currentUsernameParam}
                             AND NOT EXISTS (
                                 SELECT 1
                                 FROM visitor_operator_note_reads r
                                 WHERE r.note_id = n.note_id
                                   AND r.username = ${currentUsernameParam}
                             )
                       )::int AS unread_note_count
                FROM visitor_operator_notes n
                WHERE n.visitor_id = v.visitor_id
            ) note_summary ON TRUE
            WHERE v.identity_rank = 1
            ORDER BY v.check_in_time DESC NULLS LAST, v.visitor_id DESC

        `, params);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});

router.get("/api/visitor-stats", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                COUNT(*) FILTER (WHERE check_in_time::date = CURRENT_DATE) AS check_in_today,
                COUNT(*) FILTER (WHERE check_out_time::date = CURRENT_DATE) AS check_out_today,
                COUNT(*) FILTER (WHERE check_in_time::date = CURRENT_DATE) AS visitors_today,
                COUNT(*) FILTER (WHERE check_out_time IS NULL AND check_in_time IS NOT NULL) AS active_visitors
            FROM visitor_registration
        `);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-analytics", async (req, res) => {
    try {
        const mode = ["daily", "monthly", "yearly"].includes(req.query.mode) ? req.query.mode : "daily";
        const dateExpression =
            mode === "yearly"
                ? "TO_CHAR(check_in_time, 'YYYY')"
                : mode === "monthly"
                    ? "TO_CHAR(check_in_time, 'YYYY-MM')"
                    : "TO_CHAR(check_in_time, 'YYYY-MM-DD')";

        const result = await pool.query(`
            SELECT ${dateExpression} AS period,
                   COUNT(*) AS check_in_count,
                   COUNT(*) FILTER (WHERE check_out_time IS NOT NULL) AS check_out_count
            FROM visitor_registration
            WHERE check_in_time IS NOT NULL
            GROUP BY period
            ORDER BY period ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// (Route sync-acs, sync-lift, dan export-excel Anda tetap di bawah sini...)
router.post("/sync-acs/:id", async (req, res) => { /* ... */ });
router.post("/sync-lift/:id", async (req, res) => { /* ... */ });
router.get("/export-excel", async (req, res) => { /* ... */ });
// 1. Route untuk daftar semua port COM yang aktif
router.get("/card-reader/list-ports", async (req, res) => {
    try {
        const ports = await SerialPort.list();
        // Mengembalikan daftar path port saja, contoh: ["COM1", "COM3"]
        res.json(ports.map(p => p.path));
    } catch (error) {
        res.status(500).json({ error: "Gagal mendeteksi port" });
    }
});

// 2. Route untuk konek ke port spesifik
// ... (kode sebelumnya) ...

// 2. Route untuk konek ke port spesifik
router.post("/card-reader/connect", (req, res) => {
    const { port, baudRate } = req.body;
    if (!port) return res.status(400).json({ success: false, message: "Port tidak dipilih" });

    try {
        // TANGANI KONEKSI LAMA
        if (activePort && activePort.isOpen) {
            activePort.close();
            activePort = null;
        }

        const selectedBaud = parseInt(baudRate) || 9600;
        
        // INISIALISASI BARU
        activePort = new SerialPort({ path: port, baudRate: selectedBaud });
        const parser = activePort.pipe(new ReadlineParser({ delimiter: '\r\n' }));

        activePort.on('open', () => {
            console.log("Koneksi berhasil ke:", port);
            res.json({ success: true, message: "Terhubung ke " + port });
        });

        parser.on('data', (data) => {
            lastCard = data.trim();
        });

        // TANGANI ERROR DALAM KONEKSI
        activePort.on('error', (err) => {
            console.error("Serial Error:", err);
            activePort = null; 
        });

        // TANGANI PENUTUPAN PORT
        activePort.on('close', () => {
            console.log("Port tertutup");
            activePort = null;
        });

    } catch (error) {
        console.error("Gagal inisialisasi:", error);
        activePort = null;
        res.status(500).json({ success: false, message: error.message });
    }
});

// Route untuk frontend mengambil data kartu (Polling)
router.get("/card-reader/data", (req, res) => {
    if (lastCard !== "") {
        res.json({ success: true, card: lastCard });
        lastCard = ""; 
    } else {
        res.json({ success: false });
    }
});


module.exports = router;
module.exports.ensureVisitorSchema = ensureVisitorSchema;
module.exports.startAutoCheckoutScheduler = startAutoCheckoutScheduler;
module.exports.sendHostApprovalEmail = sendHostApprovalEmail;
module.exports.startSelfRegistrationWorkflow = () => {
    ensureVisitorSchema().then(() => selfRegistrationWorkflow.start()).catch(error => console.error("SELF REGISTRATION START:", error.message));
};
module.exports.startCloudflareQuickTunnelManager = ({ port, host }) => {
    const targetHost = !host || host === "0.0.0.0" || host === "::" ? "127.0.0.1" : host;
    const formattedHost = targetHost.includes(":") ? `[${targetHost}]` : targetHost;
    cloudflareQuickTunnel.configure({ origin: `http://${formattedHost}:${port}` });
    ensureVisitorSchema()
        .then(() => cloudflareQuickTunnel.startFromSettings())
        .catch(error => console.error("QUICK TUNNEL MANAGER START:", error.message));
};
