const express = require("express");

const session = require("express-session");

const path = require("path");
const fs = require("fs");

const app = express();
const pool = require("./database/db");
const { getSessionSettings } = require("./utils/sessionSettings");

const visitorRoutes = require("./routes/visitorRoutes");

const authRoutes = require("./routes/authRoutes");

const apiIntegrationRoutes = require("./routes/apiIntegrationRoutes");
const gatewayRoutes = require("./routes/gatewayRoutes");
const middlewareSyncRoutes = require("./routes/middlewareSyncRoutes");
const deviceRoutes = require("./routes/deviceRoutes");
const monitoringApiActivityRoutes = require("./routes/monitoringApiActivityRoutes");
const serviceStatusRoutes = require("./routes/serviceStatusRoutes");
const softwareUpdateRoutes = require("./routes/softwareUpdateRoutes");
const {
    router: licenseRoutes,
    licenseGate
} = require("./routes/licenseRoutes");
const {
    router: maintenanceRoutes,
    getServerListenSettings,
    startMaintenanceScheduler
} = require("./routes/maintenanceRoutes");

app.use(express.json());

app.use(

    session({

        secret: "innersync_secret_key",

        resave: false,

        saveUninitialized: false,

        cookie: {

            secure: false,
            httpOnly: true,
            sameSite: "lax"

        }

    })

);

app.use("/", licenseRoutes);

app.use(licenseGate);

function wantsJsonResponse(req) {
    return req.path.startsWith("/api/")
        || req.path === "/current-user"
        || String(req.headers.accept || "").includes("application/json");
}

async function destroySessionAndRespond(req, res, reason) {
    const sessionId = req.sessionID;

    await new Promise(resolve => {
        req.session.destroy(() => resolve());
    });

    if (sessionId) {
        await pool.query("DELETE FROM active_account_sessions WHERE session_id = $1", [sessionId]).catch(() => {});
    }

    if (wantsJsonResponse(req)) {
        return res.status(401).json({ success: false, message: reason || "Session expired" });
    }

    return res.redirect("/login.html");
}

app.use(async (req, res, next) => {
    if (!req.session?.user_id) return next();

    try {
        const settings = await getSessionSettings();
        const timeoutMinutes = Math.max(Number(settings.idle_logout_minutes || 30), 1);
        const timeoutMs = timeoutMinutes * 60 * 1000;
        const now = Date.now();
        const lastActivity = Number(req.session.last_activity_at || now);

        if (settings.idle_logout_enabled === true && now - lastActivity > timeoutMs) {
            return destroySessionAndRespond(req, res, "Session expired karena tidak ada aktivitas");
        }

        const passivePaths = new Set([
            "/current-user",
            "/api/session-settings",
            "/api/service-status",
            "/api/license/status"
        ]);

        if (!passivePaths.has(req.path)) {
            req.session.last_activity_at = now;
        }
    } catch (error) {
        console.log("Session guard warning:", error.message);
    }

    next();
});

app.post("/api/session-touch", (req, res) => {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Session expired" });
    }

    req.session.last_activity_at = Date.now();
    res.json({ success: true });
});

const publicHtmlPages = new Set([
    "/login.html",
    "/license.html",
    "/setup-admin.html",
    "/forgot-password.html",
    "/register.html",
    "/qr-info.html",
    "/self-registration.html",
    "/login-design-options.html"
]);

app.use((req, res, next) => {
    if (req.method !== "GET") return next();

    let requestPath = decodeURIComponent(new URL(req.originalUrl, "http://localhost").pathname);
    const isTopLevelHtml = /^\/[^/]+\.html$/i.test(requestPath);
    if (requestPath === "/" && !req.session?.user_id) {
        return res.redirect("/login.html");
    }
    if (requestPath === "/") requestPath = "/index.html";
    if ((!isTopLevelHtml && requestPath !== "/index.html") || publicHtmlPages.has(requestPath)) return next();

    if (!req.session?.user_id) {
        return res.redirect("/login.html");
    }

    const filePath = path.join(__dirname, "public", path.basename(requestPath));
    fs.readFile(filePath, "utf8", (error, html) => {
        if (error) return next();
        const guardScript = '<script src="/session-guard.js"></script>';
        const bodyCloseIndex = html.toLowerCase().lastIndexOf("</body>");
        const output = bodyCloseIndex >= 0 && !html.includes("/session-guard.js")
            ? `${html.slice(0, bodyCloseIndex)}${guardScript}\n${html.slice(bodyCloseIndex)}`
            : html;

        res.setHeader("Cache-Control", "no-store");
        res.type("html").send(output);
    });
});

app.get("/docs/innersync-gateway-api.postman_collection.json", (req, res) => {
    res.download(
        path.join(__dirname, "public", "docs", "innersync-gateway-api.postman_collection.json"),
        "innersync-gateway-api.postman_collection.json"
    );
});

app.get("/docs/innersync-gateway-api.postman_environment.json", (req, res) => {
    res.download(
        path.join(__dirname, "public", "docs", "innersync-gateway-api.postman_environment.json"),
        "innersync-gateway-api.postman_environment.json"
    );
});

app.use(express.static(path.join(__dirname, "public")));

app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/", serviceStatusRoutes);

app.use("/", visitorRoutes);

app.use("/", authRoutes);

app.use("/", apiIntegrationRoutes);

app.use("/", gatewayRoutes);

app.use("/", middlewareSyncRoutes);

app.use("/", deviceRoutes.router);

app.use("/", monitoringApiActivityRoutes);

app.use("/", maintenanceRoutes);

app.use("/", softwareUpdateRoutes.router);

(async () => {
    const serverSettings = await getServerListenSettings();
    const port = Number(serverSettings.port || 3000);
    const host = serverSettings.host || "0.0.0.0";

    app.listen(port, host, () => {

        console.log("Innersync Middleware Running");

        console.log(`Server Host : ${host}`);

        console.log(`Server Port : ${port}`);

        startMaintenanceScheduler();
        if (typeof visitorRoutes.startAutoCheckoutScheduler === "function") {
            visitorRoutes.startAutoCheckoutScheduler();
        }
        if (typeof apiIntegrationRoutes.startApiHealthScheduler === "function") {
            apiIntegrationRoutes.startApiHealthScheduler();
        }
        if (typeof middlewareSyncRoutes.startMiddlewareSyncScheduler === "function") {
            middlewareSyncRoutes.startMiddlewareSyncScheduler();
        }

    });
})();
