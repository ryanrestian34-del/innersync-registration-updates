const express = require("express");
const router = express.Router();
const pool = require("../database/db");
const {
    sleep,
    isRetryableError,
    isRetryableResult,
    getDelayMs,
    getAttemptTimeoutMs,
    canRetry
} = require("../utils/apiRetry");

let deviceSchemaReady = false;

function getCurrentUsername(req) {
    return req?.session?.user?.username || req?.session?.username || "system";
}

function normalizeDeviceIds(value) {
    if (!Array.isArray(value)) return [];
    return [...new Set(value.map(item => Number(item)).filter(Number.isFinite))];
}

function normalizeAction(value) {
    const action = String(value || "").trim().toUpperCase();
    if (["CHECKIN", "CHECK_IN", "ADD"].includes(action)) return "CHECKIN";
    if (["EDIT", "UPDATE"].includes(action)) return "EDIT";
    if (["CHECKOUT", "CHECK_OUT", "CANCEL"].includes(action)) return "CHECKOUT";
    if (["DELETE", "REMOVE"].includes(action)) return "DELETE";
    return action || "CHECKIN";
}

function safeJoinUrl(baseUrl, endpointPath) {
    const base = String(baseUrl || "").trim().replace(/\/+$/, "");
    const endpoint = String(endpointPath || "").trim();
    if (!endpoint) return base;
    return `${base}/${endpoint.replace(/^\/+/, "")}`;
}

function safeJsonParse(value, fallback = {}) {
    if (!value) return fallback;
    if (typeof value === "object") return value;
    try {
        return JSON.parse(value);
    } catch {
        return fallback;
    }
}

function formatDateIso(value) {
    if (!value) return "";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "" : date.toISOString();
}

function renderTemplate(template, visitor = {}) {
    const firstName = visitor.first_name || "";
    const secondName = visitor.second_name || "";
    const visitorName = `${firstName} ${secondName}`.trim();
    const values = {
        visitor_id: visitor.visitor_id || "",
        first_name: firstName,
        second_name: secondName,
        visitor_name: visitorName,
        identity_number: visitor.identity_number || "",
        identity_type: visitor.identity_type || "",
        company_name: visitor.company_name || "",
        email_address: visitor.email_address || "",
        telephone_number: visitor.phone_number || visitor.telephone_number || "",
        phone_number: visitor.phone_number || visitor.telephone_number || "",
        host: visitor.host || "",
        card_number: visitor.card_number || "",
        permission_group: visitor.permission_group || "",
        purpose_note: visitor.purpose_note || "",
        start_date_iso: formatDateIso(visitor.start_date || visitor.check_in_time),
        expiry_date_iso: formatDateIso(visitor.expiry_date),
        check_in_time_iso: formatDateIso(visitor.check_in_time),
        check_out_time_iso: formatDateIso(visitor.check_out_time),
        status: visitor.check_out_time ? "CHECKED_OUT" : "CHECKED_IN"
    };

    return String(template || "").replace(/\{([a-zA-Z0-9_]+)\}/g, (match, key) => {
        return Object.prototype.hasOwnProperty.call(values, key) ? String(values[key]) : match;
    });
}

function getTemplateForAction(device, action) {
    const normalized = normalizeAction(action);
    if (normalized === "CHECKIN") return device.add_template;
    if (normalized === "EDIT") return device.update_template;
    if (normalized === "CHECKOUT") return device.checkout_template;
    if (normalized === "DELETE") return device.delete_template;
    return "";
}

async function ensureDeviceSchema() {
    if (deviceSchemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS devices (
            device_id SERIAL PRIMARY KEY,
            device_name VARCHAR(150) NOT NULL,
            device_type VARCHAR(60) NOT NULL DEFAULT 'CUSTOM_REST',
            provider_type VARCHAR(80) NOT NULL DEFAULT 'CUSTOM',
            base_url TEXT NOT NULL,
            endpoint_path TEXT DEFAULT '',
            http_method VARCHAR(10) NOT NULL DEFAULT 'POST',
            auth_type VARCHAR(30) NOT NULL DEFAULT 'NONE',
            api_key_header VARCHAR(100),
            api_key TEXT,
            username VARCHAR(150),
            password TEXT,
            bearer_token TEXT,
            custom_headers_json TEXT,
            request_timeout_ms INTEGER NOT NULL DEFAULT 5000,
            add_template TEXT,
            update_template TEXT,
            checkout_template TEXT,
            delete_template TEXT,
            health_endpoint TEXT,
            health_method VARCHAR(10) DEFAULT 'GET',
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS device_type VARCHAR(60) NOT NULL DEFAULT 'CUSTOM_REST'");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS provider_type VARCHAR(80) NOT NULL DEFAULT 'CUSTOM'");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS base_url TEXT NOT NULL DEFAULT ''");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS endpoint_path TEXT DEFAULT ''");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS http_method VARCHAR(10) NOT NULL DEFAULT 'POST'");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS auth_type VARCHAR(30) NOT NULL DEFAULT 'NONE'");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS api_key_header VARCHAR(100)");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS api_key TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS username VARCHAR(150)");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS password TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS bearer_token TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS custom_headers_json TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS request_timeout_ms INTEGER NOT NULL DEFAULT 5000");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS add_template TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS update_template TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS checkout_template TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS delete_template TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS health_endpoint TEXT");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS health_method VARCHAR(10) DEFAULT 'GET'");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE devices ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS permission_groups (
            group_id SERIAL PRIMARY KEY,
            group_name VARCHAR(100) UNIQUE NOT NULL,
            integration_id VARCHAR(80),
            floor_id INTEGER,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS permission_group_devices (
            group_id INTEGER NOT NULL REFERENCES permission_groups(group_id) ON DELETE CASCADE,
            device_id INTEGER NOT NULL REFERENCES devices(device_id) ON DELETE CASCADE,
            created_time TIMESTAMP DEFAULT NOW(),
            PRIMARY KEY (group_id, device_id)
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS device_sync_logs (
            log_id SERIAL PRIMARY KEY,
            visitor_id INTEGER,
            permission_group VARCHAR(100),
            device_id INTEGER,
            device_name VARCHAR(150),
            action_type VARCHAR(30),
            request_url TEXT,
            request_payload TEXT,
            response_status INTEGER,
            response_body TEXT,
            status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            error_message TEXT,
            retry_count INTEGER NOT NULL DEFAULT 0,
            duration_ms INTEGER,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("CREATE INDEX IF NOT EXISTS idx_permission_group_devices_group ON permission_group_devices(group_id)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_device_sync_logs_visitor ON device_sync_logs(visitor_id)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_device_sync_logs_status ON device_sync_logs(status)");

    deviceSchemaReady = true;
}

async function syncPermissionGroupDevices(groupId, deviceIds) {
    const ids = normalizeDeviceIds(deviceIds);
    await ensureDeviceSchema();
    await pool.query("DELETE FROM permission_group_devices WHERE group_id = $1", [groupId]);
    for (const deviceId of ids) {
        await pool.query(
            `INSERT INTO permission_group_devices (group_id, device_id)
             VALUES ($1, $2)
             ON CONFLICT (group_id, device_id) DO NOTHING`,
            [groupId, deviceId]
        );
    }
}

async function buildRequestHeaders(device) {
    const headers = { "Content-Type": "application/json" };
    Object.assign(headers, safeJsonParse(device.custom_headers_json, {}));

    const authType = String(device.auth_type || "NONE").toUpperCase();
    if (authType === "API_KEY" && device.api_key_header && device.api_key) {
        headers[device.api_key_header] = device.api_key;
    } else if (authType === "BASIC" && device.username) {
        headers.Authorization = `Basic ${Buffer.from(`${device.username}:${device.password || ""}`).toString("base64")}`;
    } else if (authType === "BEARER" && device.bearer_token) {
        headers.Authorization = `Bearer ${device.bearer_token}`;
    }

    return headers;
}

async function writeDeviceLog(data) {
    const result = await pool.query(
        `INSERT INTO device_sync_logs
         (visitor_id, permission_group, device_id, device_name, action_type, request_url, request_payload,
          response_status, response_body, status, error_message, retry_count, duration_ms, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
         RETURNING *`,
        [
            data.visitor_id || null,
            data.permission_group || null,
            data.device_id || null,
            data.device_name || null,
            data.action_type || null,
            data.request_url || null,
            data.request_payload || null,
            data.response_status || null,
            data.response_body || null,
            data.status || "PENDING",
            data.error_message || null,
            data.retry_count || 0,
            data.duration_ms || null,
            data.created_by || "system"
        ]
    );
    return result.rows[0];
}

async function sendToDevice(device, visitor, action, reqLike, retryCount = 0) {
    const started = Date.now();
    const actionType = normalizeAction(action);
    const template = getTemplateForAction(device, actionType);
    const requestUrl = safeJoinUrl(device.base_url, device.endpoint_path);
    const createdBy = getCurrentUsername(reqLike);

    if (!template) {
        return writeDeviceLog({
            visitor_id: visitor.visitor_id,
            permission_group: visitor.permission_group,
            device_id: device.device_id,
            device_name: device.device_name,
            action_type: actionType,
            request_url: requestUrl,
            status: "FAILED",
            error_message: `Template ${actionType} belum diisi.`,
            retry_count: retryCount,
            duration_ms: Date.now() - started,
            created_by: createdBy
        });
    }

    const payloadText = renderTemplate(template, visitor);
    const baseTimeoutMs = Math.max(Number(device.request_timeout_ms || 5000), 1000);
    const method = String(device.http_method || "POST").toUpperCase();
    const retryStarted = Date.now();
    let attemptNumber = 0;
    let finalRetryCount = retryCount;

    while (canRetry(attemptNumber, retryStarted) || attemptNumber === 0) {
        attemptNumber += 1;
        const attemptTimeoutMs = getAttemptTimeoutMs(baseTimeoutMs, attemptNumber, retryStarted);
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), attemptTimeoutMs);

        try {
            const response = await fetch(requestUrl, {
                method,
                headers: await buildRequestHeaders(device),
                body: ["GET", "DELETE"].includes(method) ? undefined : payloadText,
                signal: controller.signal
            });
            const responseBody = await response.text();
            const ok = response.status >= 200 && response.status < 300;

            if (!ok && isRetryableResult({ status: response.status, body: responseBody }) && canRetry(attemptNumber, retryStarted)) {
                finalRetryCount += 1;
                await sleep(getDelayMs(attemptNumber));
                continue;
            }

            return writeDeviceLog({
                visitor_id: visitor.visitor_id,
                permission_group: visitor.permission_group,
                device_id: device.device_id,
                device_name: device.device_name,
                action_type: actionType,
                request_url: requestUrl,
                request_payload: payloadText,
                response_status: response.status,
                response_body: responseBody,
                status: ok ? "SUCCESS" : "FAILED",
                error_message: ok ? null : `HTTP ${response.status}`,
                retry_count: finalRetryCount,
                duration_ms: Date.now() - started,
                created_by: createdBy
            });
        } catch (error) {
            const message = error.name === "AbortError" ? `Request timeout setelah ${attemptTimeoutMs} ms` : error.message;
            if (isRetryableError(message) && canRetry(attemptNumber, retryStarted)) {
                finalRetryCount += 1;
                await sleep(getDelayMs(attemptNumber));
                continue;
            }

            return writeDeviceLog({
                visitor_id: visitor.visitor_id,
                permission_group: visitor.permission_group,
                device_id: device.device_id,
                device_name: device.device_name,
                action_type: actionType,
                request_url: requestUrl,
                request_payload: payloadText,
                status: "FAILED",
                error_message: message,
                retry_count: finalRetryCount,
                duration_ms: Date.now() - started,
                created_by: createdBy
            });
        } finally {
            clearTimeout(timeout);
        }
    }

    return writeDeviceLog({
        visitor_id: visitor.visitor_id,
        permission_group: visitor.permission_group,
        device_id: device.device_id,
        device_name: device.device_name,
        action_type: actionType,
        request_url: requestUrl,
        request_payload: payloadText,
        status: "FAILED",
        error_message: "Retry API device selesai tanpa response.",
        retry_count: finalRetryCount,
        duration_ms: Date.now() - started,
        created_by: createdBy
    });
}

async function getDevicesForPermissionGroup(permissionGroupName) {
    await ensureDeviceSchema();
    if (!permissionGroupName) return [];
    const result = await pool.query(
        `SELECT d.*
         FROM permission_groups pg
         JOIN permission_group_devices pgd ON pgd.group_id = pg.group_id
         JOIN devices d ON d.device_id = pgd.device_id
         WHERE pg.group_name = $1
           AND d.is_active = TRUE
         ORDER BY d.device_name ASC, d.device_id ASC`,
        [permissionGroupName]
    );
    return result.rows;
}

async function executeDeviceSyncForVisitor(visitor, action, reqLike) {
    await ensureDeviceSchema();
    const devices = await getDevicesForPermissionGroup(visitor?.permission_group);
    if (!devices.length) return [];
    return Promise.all(devices.map(device => sendToDevice(device, visitor, action, reqLike)));
}

async function checkDeviceHealth(device) {
    const started = Date.now();
    const requestUrl = safeJoinUrl(device.base_url, device.health_endpoint || "");
    const timeoutMs = Math.min(Math.max(Number(device.request_timeout_ms || 3000), 1000), 5000);

    if (!requestUrl) {
        return {
            device_id: device.device_id,
            device_name: device.device_name,
            device_type: device.device_type,
            provider_type: device.provider_type,
            status: "UNKNOWN",
            http_status: null,
            duration_ms: 0,
            checked_at: new Date().toISOString(),
            error: "Base URL device belum diisi."
        };
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
        const response = await fetch(requestUrl, {
            method: String(device.health_method || "GET").toUpperCase(),
            headers: await buildRequestHeaders(device),
            signal: controller.signal
        });
        const online = response.status >= 200 && response.status < 400;
        return {
            device_id: device.device_id,
            device_name: device.device_name,
            device_type: device.device_type,
            provider_type: device.provider_type,
            status: online ? "ONLINE" : "OFFLINE",
            http_status: response.status,
            duration_ms: Date.now() - started,
            checked_at: new Date().toISOString(),
            error: online ? null : `HTTP ${response.status}`
        };
    } catch (error) {
        return {
            device_id: device.device_id,
            device_name: device.device_name,
            device_type: device.device_type,
            provider_type: device.provider_type,
            status: "OFFLINE",
            http_status: null,
            duration_ms: Date.now() - started,
            checked_at: new Date().toISOString(),
            error: error.name === "AbortError" ? `Request timeout setelah ${timeoutMs} ms` : error.message
        };
    } finally {
        clearTimeout(timeout);
    }
}

router.get("/api/device-status", async (req, res) => {
    try {
        await ensureDeviceSchema();
        const result = await pool.query(
            `SELECT device_id, device_name, device_type, provider_type, base_url, health_endpoint,
                    health_method, auth_type, api_key_header, api_key, username, password,
                    bearer_token, custom_headers_json, request_timeout_ms, is_active
             FROM devices
             WHERE is_active = TRUE
             ORDER BY device_name ASC, device_id ASC`
        );
        const devices = result.rows || [];
        const statuses = await Promise.all(devices.map(checkDeviceHealth));
        const summary = statuses.reduce((acc, item) => {
            acc.total += 1;
            const key = String(item.status || "UNKNOWN").toLowerCase();
            acc[key] = (acc[key] || 0) + 1;
            return acc;
        }, { total: 0, online: 0, offline: 0, unknown: 0 });
        res.json({ success: true, data: statuses, summary });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.use("/api/devices", async (req, res, next) => {
    try {
        await ensureDeviceSchema();
        next();
    } catch (error) {
        next(error);
    }
});

router.get("/api/devices", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM devices ORDER BY device_name ASC, device_id ASC");
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/devices", async (req, res) => {
    try {
        const body = req.body || {};
        const deviceName = String(body.device_name || "").trim();
        const baseUrl = String(body.base_url || "").trim();
        if (!deviceName || !baseUrl) {
            return res.status(400).json({ success: false, message: "Device name dan base URL wajib diisi." });
        }

        const result = await pool.query(
            `INSERT INTO devices
             (device_name, device_type, provider_type, base_url, endpoint_path, http_method, auth_type,
              api_key_header, api_key, username, password, bearer_token, custom_headers_json,
              request_timeout_ms, add_template, update_template, checkout_template, delete_template,
              health_endpoint, health_method, is_active, created_by)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)
             RETURNING *`,
            [
                deviceName,
                String(body.device_type || "CUSTOM_REST").trim().toUpperCase(),
                String(body.provider_type || "CUSTOM").trim().toUpperCase(),
                baseUrl,
                String(body.endpoint_path || "").trim(),
                String(body.http_method || "POST").trim().toUpperCase(),
                String(body.auth_type || "NONE").trim().toUpperCase(),
                body.api_key_header || null,
                body.api_key || null,
                body.username || null,
                body.password || null,
                body.bearer_token || null,
                body.custom_headers_json || "{}",
                Number(body.request_timeout_ms || 5000),
                body.add_template || null,
                body.update_template || null,
                body.checkout_template || null,
                body.delete_template || null,
                body.health_endpoint || null,
                String(body.health_method || "GET").trim().toUpperCase(),
                body.is_active !== false,
                getCurrentUsername(req)
            ]
        );

        res.json({ success: true, data: result.rows[0], message: "Device berhasil disimpan." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/devices/:id", async (req, res) => {
    try {
        const body = req.body || {};
        const deviceName = String(body.device_name || "").trim();
        const baseUrl = String(body.base_url || "").trim();
        if (!deviceName || !baseUrl) {
            return res.status(400).json({ success: false, message: "Device name dan base URL wajib diisi." });
        }

        const result = await pool.query(
            `UPDATE devices
             SET device_name = $1,
                 device_type = $2,
                 provider_type = $3,
                 base_url = $4,
                 endpoint_path = $5,
                 http_method = $6,
                 auth_type = $7,
                 api_key_header = $8,
                 api_key = $9,
                 username = $10,
                 password = $11,
                 bearer_token = $12,
                 custom_headers_json = $13,
                 request_timeout_ms = $14,
                 add_template = $15,
                 update_template = $16,
                 checkout_template = $17,
                 delete_template = $18,
                 health_endpoint = $19,
                 health_method = $20,
                 is_active = $21,
                 modified_by = $22,
                 modified_time = NOW()
             WHERE device_id = $23
             RETURNING *`,
            [
                deviceName,
                String(body.device_type || "CUSTOM_REST").trim().toUpperCase(),
                String(body.provider_type || "CUSTOM").trim().toUpperCase(),
                baseUrl,
                String(body.endpoint_path || "").trim(),
                String(body.http_method || "POST").trim().toUpperCase(),
                String(body.auth_type || "NONE").trim().toUpperCase(),
                body.api_key_header || null,
                body.api_key || null,
                body.username || null,
                body.password || null,
                body.bearer_token || null,
                body.custom_headers_json || "{}",
                Number(body.request_timeout_ms || 5000),
                body.add_template || null,
                body.update_template || null,
                body.checkout_template || null,
                body.delete_template || null,
                body.health_endpoint || null,
                String(body.health_method || "GET").trim().toUpperCase(),
                body.is_active !== false,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Device tidak ditemukan." });
        }

        res.json({ success: true, data: result.rows[0], message: "Device berhasil diupdate." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.delete("/api/devices/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM devices WHERE device_id = $1", [req.params.id]);
        res.json({ success: true, message: "Device berhasil dihapus." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/devices/:id/test", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM devices WHERE device_id = $1", [req.params.id]);
        const device = result.rows[0];
        if (!device) return res.status(404).json({ success: false, message: "Device tidak ditemukan." });

        const visitor = req.body?.visitor || {
            visitor_id: 0,
            first_name: "Test",
            second_name: "Visitor",
            identity_number: "TEST-ID",
            company_name: "Innersync",
            card_number: "123456",
            permission_group: "TEST",
            purpose_note: "Device test"
        };
        const log = await sendToDevice(device, visitor, req.body?.action || "CHECKIN", req);
        res.json({ success: log.status === "SUCCESS", data: log, message: log.status === "SUCCESS" ? "Test device berhasil." : "Test device gagal." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/device-sync-logs", async (req, res) => {
    try {
        await ensureDeviceSchema();
        const limit = Math.min(Math.max(Number(req.query.limit || 25), 10), 200);
        const result = await pool.query(
            `SELECT *
             FROM device_sync_logs
             ORDER BY created_time DESC, log_id DESC
             LIMIT $1`,
            [limit]
        );
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/device-sync-logs/:id/retry", async (req, res) => {
    try {
        await ensureDeviceSchema();
        const logResult = await pool.query("SELECT * FROM device_sync_logs WHERE log_id = $1", [req.params.id]);
        const log = logResult.rows[0];
        if (!log) return res.status(404).json({ success: false, message: "Log tidak ditemukan." });
        if (log.status !== "FAILED") {
            return res.status(400).json({ success: false, message: "Retry hanya untuk log FAILED." });
        }

        const deviceResult = await pool.query("SELECT * FROM devices WHERE device_id = $1", [log.device_id]);
        const visitorResult = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [log.visitor_id]);
        if (!deviceResult.rows[0] || !visitorResult.rows[0]) {
            return res.status(404).json({ success: false, message: "Device atau visitor tidak ditemukan." });
        }

        const retryLog = await sendToDevice(deviceResult.rows[0], visitorResult.rows[0], log.action_type, req, Number(log.retry_count || 0) + 1);
        res.json({ success: retryLog.status === "SUCCESS", data: retryLog });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = {
    router,
    ensureDeviceSchema,
    executeDeviceSyncForVisitor,
    syncPermissionGroupDevices,
    normalizeDeviceIds
};
