const express = require("express");
const pool = require("../database/db");

const router = express.Router();

const SOURCE_TABLES = [
    { table: "api_activity_logs", sourceType: "THIRD_PARTY_API", id: "log_id", order: ["created_time", "log_id"] },
    { table: "device_sync_logs", sourceType: "DEVICE_API", id: "log_id", order: ["created_time", "log_id"] },
    { table: "middleware_sync_events", sourceType: "MIDDLEWARE_SYNC", id: "event_id", order: ["created_time", "event_id"] },
    { table: "gateway_api_logs", sourceType: "GATEWAY_API", id: "log_id", order: ["created_time", "log_id"] }
];

function requireLogin(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }
    next();
}

function requireAdminMonitor(req, res, next) {
    const role = String(req.session?.role_name || req.session?.user?.role_name || "").toUpperCase();
    if (!["ADMIN", "SUPERADMIN"].includes(role)) {
        return res.status(403).json({ success: false, message: "Monitoring API Activity hanya untuk admin." });
    }
    next();
}

function safeNumber(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
}

function normalizeLimit(value, fallback = 100) {
    const parsed = Number(value || fallback);
    return Math.max(10, Math.min(Number.isFinite(parsed) ? parsed : fallback, 1000));
}

function pick(row, keys, fallback = null) {
    for (const key of keys) {
        if (Object.prototype.hasOwnProperty.call(row, key) && row[key] !== null && row[key] !== undefined && row[key] !== "") {
            return row[key];
        }
    }
    return fallback;
}

function safeJson(value) {
    if (!value) return null;
    if (typeof value === "object") return value;
    try {
        return JSON.parse(value);
    } catch {
        return value;
    }
}

function extractStatusFromApiResults(value) {
    const parsed = safeJson(value);
    if (!Array.isArray(parsed)) return null;
    const found = parsed.find(item => item && item.status !== undefined);
    return safeNumber(found?.status);
}

function inferFailed(row) {
    const status = String(row.status || row.sync_status || "").toUpperCase();
    const successValue = row.success;
    const responseStatus = safeNumber(row.response_status);

    if (successValue === false) return true;
    if (status.includes("FAILED") || status.includes("ERROR") || status.includes("TIMEOUT")) return true;
    if (responseStatus !== null && responseStatus >= 400) return true;
    return false;
}

function normalizeLog(row, sourceType) {
    if (sourceType === "THIRD_PARTY_API") {
        const failed = inferFailed(row);
        return {
            source_type: sourceType,
            log_id: row.log_id,
            created_time: row.created_time,
            completed_time: row.created_time,
            config_name: row.config_name || "-",
            provider_type: row.provider_type || "-",
            action_type: row.action_type || "-",
            http_method: row.http_method || "-",
            request_url: row.request_url || "-",
            response_status: safeNumber(row.response_status),
            status: failed ? "FAILED" : "SUCCESS",
            success: !failed,
            error_message: row.error_message || "-",
            duration_ms: safeNumber(row.duration_ms),
            retry_count: safeNumber(row.retry_count) || 0,
            created_by: row.created_by || "-",
            request_headers: safeJson(row.request_headers),
            request_payload: safeJson(row.request_payload),
            response_body: row.response_body || "-",
            raw_data: row
        };
    }

    if (sourceType === "DEVICE_API") {
        const failed = inferFailed(row);
        return {
            source_type: sourceType,
            log_id: row.log_id,
            created_time: row.created_time,
            completed_time: row.created_time,
            config_name: row.device_name || "-",
            provider_type: "DEVICE",
            action_type: row.action_type || "-",
            http_method: "-",
            request_url: row.request_url || "-",
            response_status: safeNumber(row.response_status),
            status: row.status || (failed ? "FAILED" : "SUCCESS"),
            success: !failed,
            error_message: row.error_message || "-",
            duration_ms: safeNumber(row.duration_ms),
            retry_count: safeNumber(row.retry_count) || 0,
            created_by: row.created_by || "-",
            request_headers: null,
            request_payload: safeJson(row.request_payload),
            response_body: row.response_body || "-",
            retry_available: failed,
            retry_type: "DEVICE",
            raw_data: row
        };
    }

    if (sourceType === "MIDDLEWARE_SYNC") {
        const failed = inferFailed(row);
        const apiResults = safeJson(row.api_results);
        return {
            source_type: sourceType,
            log_id: row.event_id,
            project_id: row.project_id || null,
            created_time: row.created_time,
            completed_time: row.processed_time,
            config_name: row.source_provider || "-",
            provider_type: row.source_provider || "MIDDLEWARE",
            action_type: row.event_type || "-",
            http_method: "-",
            request_url: "-",
            response_status: extractStatusFromApiResults(row.api_results),
            status: row.status || (failed ? "FAILED" : "SYNCED"),
            success: !failed,
            error_message: row.error_message || "-",
            duration_ms: null,
            retry_count: safeNumber(row.retry_count) || 0,
            created_by: row.created_by || "-",
            request_headers: null,
            request_payload: safeJson(row.payload),
            response_body: apiResults || "-",
            retry_available: failed,
            retry_type: "MIDDLEWARE",
            raw_data: row
        };
    }

    const failed = inferFailed(row);
    return {
        source_type: sourceType,
        log_id: row.log_id,
        created_time: row.created_time,
        completed_time: row.completed_time,
        config_name: row.source_system || "Gateway API",
        provider_type: row.source_system || "GATEWAY",
        action_type: row.action || row.trigger_event || "-",
        http_method: "POST",
        request_url: "/api/gateway/execute",
        response_status: failed ? 500 : 200,
        status: row.status || (failed ? "FAILED" : "SUCCESS"),
        success: !failed,
        error_message: row.error_message || "-",
        duration_ms: safeNumber(row.duration_ms),
        retry_count: 0,
        created_by: "GATEWAY",
        request_headers: safeJson(row.request_headers),
        request_payload: safeJson(row.request_payload),
        response_body: safeJson(row.result_payload) || "-",
        raw_data: row
    };
}

async function getColumns(tableName) {
    const result = await pool.query(
        `SELECT column_name
         FROM information_schema.columns
         WHERE table_schema = 'public' AND table_name = $1`,
        [tableName]
    );
    return result.rows.map(row => row.column_name);
}

function quoteIdentifier(value) {
    return `"${String(value).replace(/"/g, "\"\"")}"`;
}

async function readTableLogs(source, perTableLimit) {
    const columns = await getColumns(source.table);
    if (!columns.length) return [];

    const orderColumns = source.order.filter(column => columns.includes(column));
    const orderClause = orderColumns.length
        ? orderColumns.map(column => `${quoteIdentifier(column)} DESC`).join(", ")
        : `${quoteIdentifier(source.id)} DESC`;

    const result = await pool.query(
        `SELECT * FROM ${quoteIdentifier(source.table)}
         ORDER BY ${orderClause}
         LIMIT $1`,
        [perTableLimit]
    );
    return result.rows.map(row => normalizeLog(row, source.sourceType));
}

async function loadUnifiedLogs(limit) {
    const perTableLimit = Math.max(limit, 100);
    const chunks = await Promise.all(SOURCE_TABLES.map(source => readTableLogs(source, perTableLimit).catch(error => [{
        source_type: source.sourceType,
        log_id: "-",
        created_time: new Date().toISOString(),
        config_name: source.table,
        action_type: "READ_LOG",
        http_method: "-",
        request_url: source.table,
        response_status: 500,
        status: "FAILED",
        success: false,
        error_message: error.message,
        duration_ms: null,
        retry_count: 0,
        created_by: "SYSTEM",
        raw_data: { error: error.message }
    }])));

    return chunks
        .flat()
        .sort((a, b) => new Date(b.created_time || 0).getTime() - new Date(a.created_time || 0).getTime())
        .slice(0, limit);
}

router.use("/api/monitoring-api-activity", requireLogin, requireAdminMonitor);

router.get("/api/monitoring-api-activity/logs", async (req, res) => {
    try {
        const limit = normalizeLimit(req.query.limit, 100);
        const logs = await loadUnifiedLogs(limit);
        res.json({ success: true, data: logs });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/monitoring-api-activity/failed", async (req, res) => {
    try {
        const limit = normalizeLimit(req.query.limit, 100);
        const logs = await loadUnifiedLogs(Math.max(limit * 2, 200));
        const failed = logs.filter(inferFailed).slice(0, limit);
        res.json({ success: true, data: failed });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/monitoring-api-activity/summary", async (req, res) => {
    try {
        const logs = await loadUnifiedLogs(500);
        const failed = logs.filter(inferFailed);
        res.json({
            success: true,
            data: {
                total: logs.length,
                failed: failed.length,
                success: logs.filter(item => !inferFailed(item)).length,
                device_failed: failed.filter(item => item.source_type === "DEVICE_API").length,
                middleware_failed: failed.filter(item => item.source_type === "MIDDLEWARE_SYNC").length,
                last_time: logs[0]?.created_time || null
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/monitoring-api-activity/retry", async (req, res) => {
    try {
        const retryType = String(req.body?.retry_type || "").toUpperCase();
        const logId = req.body?.log_id;
        const projectId = req.body?.project_id;

        if (retryType === "DEVICE") {
            return res.status(409).json({
                success: false,
                message: "Retry Device tersedia dari Device page. Monitoring ini menampilkan pusat statusnya dahulu."
            });
        }

        if (retryType === "MIDDLEWARE") {
            return res.status(409).json({
                success: false,
                message: `Retry Middleware tersedia dari Middleware Sync project${projectId ? ` ID ${projectId}` : ""}.`
            });
        }

        res.status(400).json({ success: false, message: `Retry belum tersedia untuk log ${logId || "-"}.` });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router;
