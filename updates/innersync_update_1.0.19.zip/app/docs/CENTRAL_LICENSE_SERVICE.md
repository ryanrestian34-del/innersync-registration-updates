# Central License Service

Dokumen ini menjelaskan pemasangan layanan license pusat tanpa mengganggu license lama.

## Komponen

| Komponen | Versi | Fungsi |
|---|---:|---|
| Innersync Portal | 1.0.19 | Aktivasi, Installation ID, refresh sertifikat, dan fallback legacy license |
| WhatsApp Gateway | 1.5.0 | Menerima legacy license maupun sertifikat aktivasi pusat |
| License Service | 1.0.0 | Membuat license, aktivasi instalasi, perpindahan server, dan audit |

## Batas keamanan

Private key hanya boleh ada pada server License Service di `/etc/innersync-license/private_key.pem`. Jangan meletakkannya di GitHub, paket portal, WhatsApp Gateway, atau server customer. Portal dan Gateway hanya menggunakan `public_key.pem`.

Simpan backup private key di penyimpanan terenkripsi. Kehilangan private key membuat service tidak dapat menerbitkan sertifikat baru yang dipercaya oleh instalasi yang sudah beredar.

## Instalasi License Service

1. Upload `innersync-license-service-linux-v1.0.0.tar.gz` dan private key ke VPS pusat.
2. Batasi izin private key sebelum instalasi:

```bash
chmod 600 /home/innersyncadmin/innersync-license-private-key.pem
```

3. Ekstrak dan jalankan installer:

```bash
mkdir -p ~/innersync-license-service-setup
tar -xzf ~/innersync-license-service-linux-v1.0.0.tar.gz -C ~/innersync-license-service-setup
cd ~/innersync-license-service-setup/innersync-license-service-linux-v1.0.0
sudo bash install.sh
```

4. Pasang konfigurasi Nginx dari `deploy/nginx-license.innersync.my.id.conf`, aktifkan site, lalu terbitkan SSL untuk `license.innersync.my.id`.
5. Verifikasi:

```bash
curl -i http://127.0.0.1:8092/health
curl -i https://license.innersync.my.id/health
sudo systemctl status innersync-license --no-pager
```

Admin tersedia pada `https://license.innersync.my.id/admin`.

## Urutan rollout

1. Pasang License Service pusat dan pastikan health check sukses.
2. Update WhatsApp Gateway ke 1.5.0. Legacy license tetap diterima.
3. Update portal customer ke 1.0.19. License lama tetap aktif tanpa aktivasi ulang.
4. Buat license customer dari License Admin dan berikan Activation Code.
5. Customer membuka License Manager, memasukkan Activation Code, lalu menekan **Activate**.

Jika license masih aktif pada server lama dan batas instalasi sudah penuh, portal meminta konfirmasi. Setelah dikonfirmasi, instalasi lama berubah menjadi `REPLACED` dan instalasi baru menjadi `ACTIVE`.

## Penyimpanan di portal customer

- `config/installation_identity.json`: Installation ID dan pasangan Ed25519 milik instalasi.
- `config/central_activation.dat`: sertifikat aktivasi yang ditandatangani pusat.
- `config/license.dat`: legacy license; tetap dipertahankan untuk kompatibilitas.

Kedua file central tidak dimasukkan ke update package. Update software tidak mengganti identitas instalasi atau sertifikat yang sudah aktif.

## Operasi service

```bash
sudo systemctl restart innersync-license
sudo systemctl status innersync-license --no-pager
sudo journalctl -u innersync-license -n 100 --no-pager
```

Untuk mengganti akun admin:

```bash
sudo bash /opt/innersync-license/tools/configure-admin.sh
```
