ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS actor_type VARCHAR(30);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS module_name VARCHAR(80);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS action_name VARCHAR(80);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS entity_type VARCHAR(80);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS entity_id VARCHAR(120);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS request_method VARCHAR(10);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS request_path TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS result_status VARCHAR(20);
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS user_agent TEXT;

CREATE INDEX IF NOT EXISTS idx_activity_logs_module_created
    ON activity_logs(module_name, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_activity_logs_actor_created
    ON activity_logs(username, created_at DESC);
