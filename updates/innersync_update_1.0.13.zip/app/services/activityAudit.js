const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);

const EXPLICIT_AUTH_LOG_PATHS = [
    /^\/api\/setup-admin(?:\/|$)/,
    /^\/(?:login|logout|register-account|create-user)(?:\/|$)/,
    /^\/api\/roles(?:\/|$)/,
    /^\/api\/active-sessions\/[^/]+\/end-task(?:\/|$)/,
    /^\/(?:approve-user|reset-password|delete-user|edit-user|toggle-block|verify-reset-code|change-password)(?:\/|$)/
];

const TECHNICAL_NOISE_PATHS = [
    /^\/api\/session-touch(?:\/|$)/,
    /^\/api\/operator-presence\/heartbeat(?:\/|$)/,
    /^\/api\/system-notifications\/mark-read(?:\/|$)/
];

let schemaPromise = null;

function cleanText(value, maxLength = 500) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, maxLength);
}

function clientIp(req) {
    return cleanText(String(req.headers["x-forwarded-for"] || req.ip || req.socket?.remoteAddress || "").split(",")[0], 80)
        .replace(/^::ffff:/, "");
}

function safeRequestPath(pathValue) {
    return String(pathValue || "")
        .replace(/(\/api\/public\/approval\/)[^/]+/i, "$1:token")
        .replace(/(\/api\/public\/extension-approval\/)[^/]+/i, "$1:token")
        .replace(/(\/api\/public\/extension\/)[^/]+/i, "$1:token")
        .slice(0, 500);
}

function moduleForPath(pathValue) {
    const path = String(pathValue || "").toLowerCase();
    if (/visitor|invitation|extension|self-registration|\/api\/public\/approval/.test(path)) return "VISITOR";
    if (/host/.test(path)) return "HOST";
    if (/permission-group/.test(path)) return "PERMISSION_GROUP";
    if (/floor/.test(path)) return "FLOOR";
    if (/whatsapp/.test(path)) return "WHATSAPP";
    if (/smtp|send-qr-email/.test(path)) return "EMAIL";
    if (/third-party|monitoring-api/.test(path)) return "API_INTEGRATION";
    if (/middleware-sync/.test(path)) return "MIDDLEWARE_SYNC";
    if (/device|card-reader|sync-acs|sync-lift/.test(path)) return "DEVICE";
    if (/gateway/.test(path)) return "GATEWAY";
    if (/software-update/.test(path)) return "SOFTWARE_UPDATE";
    if (/maintenance|database/.test(path)) return "MAINTENANCE";
    if (/role|user|account|session/.test(path)) return "ACCOUNT";
    if (/setting|qr-|card-format|auto-checkout|cloudflare/.test(path)) return "SETTINGS";
    if (/notification|delivery-monitoring/.test(path)) return "NOTIFICATION";
    return "SYSTEM";
}

function actionForRequest(req) {
    const path = String(req.path || "").toLowerCase();
    const decision = cleanText(req.body?.action || req.body?.decision, 30).toUpperCase();
    if (decision === "APPROVE" || decision === "REJECT") return decision;
    if (req.method === "DELETE") return "DELETE";
    if (req.method === "PUT" || req.method === "PATCH") return "UPDATE";
    if (/retry/.test(path)) return "RETRY";
    if (/approve/.test(path)) return "APPROVE";
    if (/reject/.test(path)) return "REJECT";
    if (/cancel|revoke/.test(path)) return "CANCEL";
    if (/check-in|checkin/.test(path)) return "CHECK_IN";
    if (/check-out|checkout/.test(path)) return "CHECK_OUT";
    if (/activate|start/.test(path)) return "ACTIVATE";
    if (/stop|close/.test(path)) return "DEACTIVATE";
    if (/update|edit/.test(path)) return "UPDATE";
    if (/run-now|\/run(?:\/|$)/.test(path)) return "EXECUTE";
    if (/send-email|send-qr|whatsapp-sent/.test(path)) return "SEND";
    return "CREATE_OR_EXECUTE";
}

function entityForPath(pathValue) {
    const path = safeRequestPath(pathValue);
    if (/\/api\/public\/approval\/:token/i.test(path)) return { type: "INVITATION", id: null };
    if (/\/api\/public\/(?:extension|extension-approval)\/:token/i.test(path)) return { type: "EXTENSION_REQUEST", id: null };
    const pairs = [
        ["EXTENSION_REQUEST", /\/extension-requests\/([^/]+)/i],
        ["INVITATION", /\/invitations\/([^/]+)/i],
        ["VISITOR", /\/visitors\/([^/]+)/i],
        ["HOST", /\/hosts\/([^/]+)/i],
        ["PERMISSION_GROUP", /\/permission-groups\/([^/]+)/i],
        ["FLOOR", /\/floors\/([^/]+)/i],
        ["USER", /\/(?:approve-user|reset-password|delete-user|edit-user|toggle-block)\/([^/]+)/i]
    ];
    for (const [type, pattern] of pairs) {
        const match = path.match(pattern);
        if (match) return { type, id: cleanText(match[1], 120) };
    }
    return { type: moduleForPath(path), id: null };
}

function actorForRequest(req) {
    const override = cleanText(req.activityAuditActor, 120);
    if (override) return { username: override, actorType: cleanText(req.activityAuditActorType || "EXTERNAL", 30) };

    const sessionUser = req.session?.user;
    if (sessionUser?.username || sessionUser?.full_name) {
        return {
            username: cleanText(sessionUser.username || sessionUser.full_name, 120),
            actorType: cleanText(sessionUser.role_name || req.session?.role_name || "USER", 30)
        };
    }

    const path = String(req.path || "").toLowerCase();
    if (/\/api\/public\/(?:approval|extension-approval)\//.test(path)) return { username: "HOST", actorType: "HOST" };
    if (/register-visitor|self-registration|\/api\/public\/extension\//.test(path)) return { username: "PUBLIC_VISITOR", actorType: "VISITOR" };
    return { username: "PUBLIC", actorType: "PUBLIC" };
}

function shouldSkip(req) {
    if (!MUTATING_METHODS.has(String(req.method || "").toUpperCase())) return true;
    const path = String(req.path || "");
    return EXPLICIT_AUTH_LOG_PATHS.some(pattern => pattern.test(path))
        || TECHNICAL_NOISE_PATHS.some(pattern => pattern.test(path));
}

async function ensureActivityAuditSchema(pool) {
    if (!schemaPromise) {
        schemaPromise = (async () => {
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS actor_type VARCHAR(30)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS module_name VARCHAR(80)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS action_name VARCHAR(80)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS entity_type VARCHAR(80)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS entity_id VARCHAR(120)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS request_method VARCHAR(10)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS request_path TEXT");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS result_status VARCHAR(20)");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb");
            await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS user_agent TEXT");
            await pool.query("CREATE INDEX IF NOT EXISTS idx_activity_logs_module_created ON activity_logs(module_name, created_at DESC)");
            await pool.query("CREATE INDEX IF NOT EXISTS idx_activity_logs_actor_created ON activity_logs(username, created_at DESC)");
        })().catch(error => {
            schemaPromise = null;
            throw error;
        });
    }
    return schemaPromise;
}

async function writeActivityLog(pool, entry = {}) {
    const username = cleanText(entry.username || "SYSTEM", 120) || "SYSTEM";
    const activityType = cleanText(entry.activityType || entry.actionName || "ACTIVITY", 120) || "ACTIVITY";
    const description = cleanText(entry.description || activityType, 4000);
    const ipAddress = cleanText(entry.ipAddress, 80);

    try {
        await ensureActivityAuditSchema(pool);
        await pool.query(
            `INSERT INTO activity_logs
             (username, activity_type, description, ip_address, actor_type, module_name,
              action_name, entity_type, entity_id, request_method, request_path,
              result_status, metadata, user_agent, created_at, created_time)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb,$14,NOW(),NOW())`,
            [
                username,
                activityType,
                description,
                ipAddress || null,
                cleanText(entry.actorType || "USER", 30) || null,
                cleanText(entry.moduleName, 80) || null,
                cleanText(entry.actionName || activityType, 80) || null,
                cleanText(entry.entityType, 80) || null,
                cleanText(entry.entityId, 120) || null,
                cleanText(entry.requestMethod, 10) || null,
                safeRequestPath(entry.requestPath) || null,
                cleanText(entry.resultStatus || "SUCCESS", 20) || "SUCCESS",
                JSON.stringify(entry.metadata && typeof entry.metadata === "object" ? entry.metadata : {}),
                cleanText(entry.userAgent, 1000) || null
            ]
        );
    } catch (error) {
        console.log("ACTIVITY AUDIT WRITE ERROR:", error.message);
    }
}

function createActivityAuditMiddleware(pool) {
    return function activityAuditMiddleware(req, res, next) {
        if (shouldSkip(req)) return next();

        let responseBody = null;
        const originalJson = res.json.bind(res);
        res.json = body => {
            responseBody = body;
            return originalJson(body);
        };

        res.once("finish", () => {
            if (req.activityAuditLogged || req.activityAuditSkip) return;

            const actor = actorForRequest(req);
            const entity = entityForPath(req.path);
            const action = actionForRequest(req);
            const reason = cleanText(req.body?.reason, 300);
            const responseMessage = cleanText(responseBody?.message || responseBody?.error, 500);
            const successful = res.statusCode < 400 && responseBody?.success !== false;
            const path = safeRequestPath(req.path);
            const detailParts = [`${action} ${entity.type}`];
            if (entity.id) detailParts.push(`#${entity.id}`);
            if (reason) detailParts.push(`Alasan: ${reason}`);
            if (responseMessage) detailParts.push(responseMessage);

            setImmediate(() => {
                writeActivityLog(pool, {
                    username: actor.username,
                    actorType: actor.actorType,
                    activityType: `${action}_${entity.type}`.slice(0, 120),
                    description: detailParts.join(" - "),
                    ipAddress: clientIp(req),
                    moduleName: moduleForPath(path),
                    actionName: action,
                    entityType: entity.type,
                    entityId: entity.id,
                    requestMethod: req.method,
                    requestPath: path,
                    resultStatus: successful ? "SUCCESS" : "FAILED",
                    metadata: {
                        http_status: res.statusCode,
                        decision: cleanText(req.body?.action || req.body?.decision, 30) || null,
                        reason: reason || null,
                        response_message: responseMessage || null
                    },
                    userAgent: req.headers["user-agent"]
                });
            });
        });

        next();
    };
}

module.exports = {
    createActivityAuditMiddleware,
    ensureActivityAuditSchema,
    writeActivityLog,
    safeRequestPath,
    moduleForPath,
    entityForPath
};
