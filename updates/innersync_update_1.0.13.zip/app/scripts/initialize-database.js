const pool = require("../database/db");
const authRoutes = require("../routes/authRoutes");
const visitorRoutes = require("../routes/visitorRoutes");
const { ensureApiSchema } = require("../routes/apiIntegrationRoutes");
const { ensureGatewaySchema } = require("../routes/gatewayRoutes");
const { ensureSyncSchema } = require("../routes/middlewareSyncRoutes");
const { ensureMaintenanceSchema } = require("../routes/maintenanceRoutes");
const { ensureSoftwareUpdateSchema } = require("../routes/softwareUpdateRoutes");
const { ensureSystemNotificationSchema } = require("../routes/notificationService");
const { ensureDeviceSchema } = require("../routes/deviceRoutes");
const { ensureCardFormatSchema } = require("../utils/cardFormatMapping");
const { ensureSessionSettingsSchema } = require("../utils/sessionSettings");

async function ensureBaseSchema() {
    await pool.query(`
        CREATE TABLE IF NOT EXISTS system_users (
            user_id SERIAL PRIMARY KEY,
            username VARCHAR(120) UNIQUE NOT NULL,
            password TEXT NOT NULL,
            full_name VARCHAR(160),
            role_name VARCHAR(80) NOT NULL DEFAULT 'OPERATOR',
            approval_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
            is_blocked BOOLEAN NOT NULL DEFAULT FALSE,
            created_by VARCHAR(120),
            created_at TIMESTAMP DEFAULT NOW(),
            created_date TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(120),
            modified_at TIMESTAMP,
            modified_date TIMESTAMP,
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            is_permanent BOOLEAN NOT NULL DEFAULT TRUE,
            last_login TIMESTAMP,
            must_change_password BOOLEAN NOT NULL DEFAULT FALSE
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS activity_logs (
            log_id SERIAL PRIMARY KEY,
            username VARCHAR(120),
            activity_type VARCHAR(120),
            description TEXT,
            ip_address VARCHAR(80),
            actor_type VARCHAR(30),
            module_name VARCHAR(80),
            action_name VARCHAR(80),
            entity_type VARCHAR(80),
            entity_id VARCHAR(120),
            request_method VARCHAR(10),
            request_path TEXT,
            result_status VARCHAR(20),
            metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT NOW(),
            created_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_registration (
            visitor_id SERIAL PRIMARY KEY,
            first_name VARCHAR(100),
            second_name VARCHAR(100),
            identity_number VARCHAR(120),
            identity_type VARCHAR(80),
            company_name VARCHAR(180),
            email_address VARCHAR(255),
            phone_number VARCHAR(80),
            host VARCHAR(150),
            card_number VARCHAR(120),
            permission_group VARCHAR(120),
            purpose_note TEXT,
            visitor_photo TEXT,
            identity_photo TEXT,
            qr_code TEXT,
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            check_in_time TIMESTAMP,
            check_out_time TIMESTAMP,
            status VARCHAR(30) NOT NULL DEFAULT 'CHECKED_IN',
            third_party_user_id VARCHAR(100),
            schindler_person_id VARCHAR(100),
            watchlist_status VARCHAR(20),
            watchlist_entry_id INTEGER,
            watchlist_note TEXT,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE system_users ADD COLUMN IF NOT EXISTS approval_status VARCHAR(30) NOT NULL DEFAULT 'PENDING'");
    await pool.query("ALTER TABLE system_users ADD COLUMN IF NOT EXISTS modified_at TIMESTAMP");
    await pool.query("ALTER TABLE system_users ADD COLUMN IF NOT EXISTS modified_date TIMESTAMP");
    await pool.query("ALTER TABLE system_users ADD COLUMN IF NOT EXISTS created_date TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE system_users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS actor_type VARCHAR(30)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS module_name VARCHAR(80)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS action_name VARCHAR(80)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS entity_type VARCHAR(80)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS entity_id VARCHAR(120)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS request_method VARCHAR(10)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS request_path TEXT");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS result_status VARCHAR(20)");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb");
    await pool.query("ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS user_agent TEXT");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS qr_code TEXT");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS status VARCHAR(30) NOT NULL DEFAULT 'CHECKED_IN'");

    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_users_username ON system_users (LOWER(username))");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs (created_at DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_activity_logs_created_time ON activity_logs (created_time DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_activity_logs_module_created ON activity_logs (module_name, created_at DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_activity_logs_actor_created ON activity_logs (username, created_at DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_registration_identity ON visitor_registration (identity_number)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_registration_card ON visitor_registration (card_number)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_registration_check_in ON visitor_registration (check_in_time DESC)");
}

async function initializeDatabase() {
    console.log("Initializing Innersync database schema...");
    await ensureBaseSchema();
    await ensureSystemNotificationSchema();
    await ensureCardFormatSchema(pool);
    await authRoutes.ensureRoleSchema();
    await authRoutes.ensureActiveSessionSchema();
    await visitorRoutes.ensureVisitorSchema();
    await ensureDeviceSchema();
    await ensureApiSchema();
    await ensureGatewaySchema();
    await ensureSyncSchema();
    await ensureMaintenanceSchema();
    await ensureSessionSettingsSchema();
    await ensureSoftwareUpdateSchema();
    console.log("Database schema is ready.");
}

if (require.main === module) {
    initializeDatabase()
        .then(() => pool.end())
        .catch(async (error) => {
            console.error("Database initialization failed:", error.message);
            console.error(error.stack);
            await pool.end().catch(() => {});
            process.exit(1);
        });
}

module.exports = {
    initializeDatabase,
    ensureBaseSchema
};
