(function initializeWhatsappCreditAlerts(global) {
    "use strict";

    const POLL_INTERVAL_MS = 30000;
    let alerts = [];
    let loading = false;
    let acknowledging = false;

    function installStyles() {
        if (document.getElementById("whatsappCreditAlertStyles")) return;
        const style = document.createElement("style");
        style.id = "whatsappCreditAlertStyles";
        style.textContent = `
            .wa-credit-alert-overlay {
                position:fixed; inset:0; z-index:999990; display:none; align-items:center; justify-content:center;
                padding:20px; background:rgba(15,23,42,.58); backdrop-filter:blur(3px);
            }
            .wa-credit-alert-overlay.open { display:flex; }
            .wa-credit-alert-dialog {
                width:min(480px,100%); max-height:calc(100vh - 40px); overflow:auto; background:#fff;
                border:1px solid #dbe3ee; border-radius:8px; box-shadow:0 24px 70px rgba(15,23,42,.3);
            }
            .wa-credit-alert-accent { height:6px; background:#eab308; }
            .wa-credit-alert-dialog.critical .wa-credit-alert-accent,
            .wa-credit-alert-dialog.urgent .wa-credit-alert-accent { background:#dc2626; }
            .wa-credit-alert-body { padding:24px; }
            .wa-credit-alert-head { display:flex; align-items:flex-start; gap:14px; }
            .wa-credit-alert-icon {
                flex:0 0 44px; width:44px; height:44px; display:grid; place-items:center; border-radius:50%;
                background:#fff7d6; color:#a16207; font-size:22px; font-weight:900;
            }
            .critical .wa-credit-alert-icon,.urgent .wa-credit-alert-icon { background:#fee2e2; color:#b91c1c; }
            .wa-credit-alert-title { margin:0; color:#172033; font-size:21px; line-height:1.25; }
            .wa-credit-alert-subtitle { margin:5px 0 0; color:#64748b; font-size:13px; }
            .wa-credit-alert-balance { margin:22px 0 6px; color:#0d47b5; font-size:38px; font-weight:900; }
            .critical .wa-credit-alert-balance,.urgent .wa-credit-alert-balance { color:#c81e32; }
            .wa-credit-alert-label { color:#64748b; font-size:12px; font-weight:800; text-transform:uppercase; }
            .wa-credit-alert-message { margin:18px 0; padding:14px; color:#334155; line-height:1.5; background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; }
            .wa-credit-alert-meta { display:flex; justify-content:space-between; gap:12px; color:#64748b; font-size:12px; }
            .wa-credit-alert-error { min-height:18px; margin-top:12px; color:#c81e32; font-size:13px; font-weight:700; }
            .wa-credit-alert-actions { display:grid; grid-template-columns:1fr 1.5fr; gap:10px; margin-top:18px; }
            .wa-credit-alert-actions a,.wa-credit-alert-actions button {
                min-height:44px; border:0; border-radius:6px; padding:10px 14px; display:flex; align-items:center;
                justify-content:center; text-decoration:none; font:inherit; font-weight:800; cursor:pointer;
                transition:background-color .18s ease,color .18s ease,box-shadow .18s ease,transform .18s ease;
            }
            .wa-credit-alert-topup { color:#334155; background:#e8edf5; }
            .wa-credit-alert-ack { color:#fff; background:#0d47b5; }
            .wa-credit-alert-ack:disabled { opacity:.6; cursor:wait; }
            @media(hover:hover) {
                .wa-credit-alert-topup:hover { color:#172033; background:#d7e0ed; box-shadow:0 6px 14px rgba(51,65,85,.16); transform:translateY(-1px); }
                .wa-credit-alert-ack:hover:not(:disabled) { background:#093a98; box-shadow:0 7px 16px rgba(13,71,181,.26); transform:translateY(-1px); }
            }
            .wa-credit-alert-actions a:focus-visible,.wa-credit-alert-actions button:focus-visible {
                outline:3px solid rgba(37,99,235,.32); outline-offset:2px;
            }
            .wa-credit-alert-actions a:active,.wa-credit-alert-actions button:active:not(:disabled) {
                box-shadow:none; transform:translateY(1px);
            }
            @media(max-width:520px) {
                .wa-credit-alert-overlay { padding:12px; }
                .wa-credit-alert-body { padding:20px; }
                .wa-credit-alert-actions { grid-template-columns:1fr; }
                .wa-credit-alert-balance { font-size:32px; }
            }
        `;
        document.head.appendChild(style);
    }

    function buildDialog() {
        if (document.getElementById("whatsappCreditAlertOverlay")) return;
        const overlay = document.createElement("div");
        overlay.id = "whatsappCreditAlertOverlay";
        overlay.className = "wa-credit-alert-overlay";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-modal", "true");
        overlay.setAttribute("aria-labelledby", "whatsappCreditAlertTitle");
        overlay.innerHTML = `
            <div class="wa-credit-alert-dialog" id="whatsappCreditAlertDialog">
                <div class="wa-credit-alert-accent"></div>
                <div class="wa-credit-alert-body">
                    <div class="wa-credit-alert-head">
                        <div class="wa-credit-alert-icon" aria-hidden="true">!</div>
                        <div>
                            <h2 class="wa-credit-alert-title" id="whatsappCreditAlertTitle">Kredit WhatsApp Menipis</h2>
                            <p class="wa-credit-alert-subtitle" id="whatsappCreditAlertPosition"></p>
                        </div>
                    </div>
                    <div class="wa-credit-alert-balance" id="whatsappCreditAlertBalance">0</div>
                    <div class="wa-credit-alert-label">Kredit tersisa</div>
                    <div class="wa-credit-alert-message" id="whatsappCreditAlertMessage"></div>
                    <div class="wa-credit-alert-meta">
                        <span id="whatsappCreditAlertThreshold"></span>
                        <span id="whatsappCreditAlertTime"></span>
                    </div>
                    <div class="wa-credit-alert-error" id="whatsappCreditAlertError" role="alert"></div>
                    <div class="wa-credit-alert-actions">
                        <a class="wa-credit-alert-topup" href="/license.html#whatsapp-credit-topup">Ajukan Top-up</a>
                        <button class="wa-credit-alert-ack" id="whatsappCreditAlertAcknowledge" type="button">Acknowledge / Sudah Dipahami</button>
                    </div>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        document.getElementById("whatsappCreditAlertAcknowledge").addEventListener("click", acknowledgeCurrentAlert);
    }

    function number(value) {
        return Number(value || 0).toLocaleString("id-ID");
    }

    function date(value) {
        if (!value) return "-";
        const parsed = new Date(value);
        return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleString("id-ID");
    }

    function render() {
        buildDialog();
        const overlay = document.getElementById("whatsappCreditAlertOverlay");
        const alert = alerts[0];
        overlay.classList.toggle("open", Boolean(alert));
        if (!alert) return;

        const detail = alert.detail || {};
        const severity = String(detail.severity || alert.status || "INFO").toLowerCase();
        document.getElementById("whatsappCreditAlertDialog").className = `wa-credit-alert-dialog ${severity}`;
        document.getElementById("whatsappCreditAlertPosition").textContent = alerts.length > 1
            ? `Ada ${alerts.length} warning yang perlu dikonfirmasi`
            : "Konfirmasi diperlukan agar informasi tercatat diterima";
        document.getElementById("whatsappCreditAlertBalance").textContent = number(detail.current_balance ?? detail.alert_balance);
        document.getElementById("whatsappCreditAlertMessage").textContent = alert.message || "Saldo WhatsApp perlu segera diisi ulang.";
        document.getElementById("whatsappCreditAlertThreshold").textContent = `Threshold: ${number(detail.threshold)}`;
        document.getElementById("whatsappCreditAlertTime").textContent = date(alert.created_time);
        document.getElementById("whatsappCreditAlertError").textContent = "";
        document.getElementById("whatsappCreditAlertAcknowledge").focus({ preventScroll:true });
    }

    async function loadAlerts() {
        if (loading || acknowledging) return;
        loading = true;
        try {
            const response = await fetch("/api/whatsapp-credit-alerts/pending", { cache:"no-store" });
            if (response.status === 401) return;
            const result = await response.json();
            if (!response.ok || result.success === false) throw new Error(result.message || "Gagal memuat credit warning.");
            alerts = Array.isArray(result.data) ? result.data : [];
            render();
        } catch (error) {
            console.warn("WhatsApp credit alert sync:", error.message);
        } finally {
            loading = false;
        }
    }

    async function acknowledgeCurrentAlert() {
        const alert = alerts[0];
        if (!alert || acknowledging) return;
        acknowledging = true;
        const button = document.getElementById("whatsappCreditAlertAcknowledge");
        const errorBox = document.getElementById("whatsappCreditAlertError");
        button.disabled = true;
        button.textContent = "Menyimpan...";
        errorBox.textContent = "";
        try {
            const response = await fetch(`/api/whatsapp-credit-alerts/${encodeURIComponent(alert.notification_id)}/acknowledge`, {
                method:"POST",
                headers:{ "Content-Type":"application/json" },
                body:JSON.stringify({})
            });
            const result = await response.json();
            if (!response.ok || result.success === false) throw new Error(result.message || "Acknowledge gagal.");
            alerts.shift();
            render();
            if (typeof global.loadNotifications === "function") global.loadNotifications();
            global.dispatchEvent(new CustomEvent("innersync:credit-alert-acknowledged", { detail:{ notification_id:alert.notification_id } }));
        } catch (error) {
            errorBox.textContent = `${error.message} Silakan coba kembali.`;
        } finally {
            acknowledging = false;
            button.disabled = false;
            button.textContent = "Acknowledge / Sudah Dipahami";
        }
    }

    function start() {
        if (/\/license(?:\.html)?\/?$/i.test(global.location.pathname)) return;
        installStyles();
        buildDialog();
        loadAlerts();
        global.setInterval(loadAlerts, POLL_INTERVAL_MS);
        global.addEventListener("focus", loadAlerts);
    }

    global.InnersyncWhatsappCreditAlerts = { refresh:loadAlerts };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once:true });
    else start();
})(window);
