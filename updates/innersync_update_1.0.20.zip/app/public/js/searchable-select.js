(function initializeSearchableSelect(global) {
    "use strict";

    const instances = new WeakMap();
    let instanceSequence = 0;

    function installStyles() {
        if (document.getElementById("innersyncSearchableSelectStyles")) return;
        const style = document.createElement("style");
        style.id = "innersyncSearchableSelectStyles";
        style.textContent = `
            .innersync-search-select { position:relative; width:100%; min-width:0; }
            .innersync-search-select-native {
                position:absolute !important;
                width:1px !important;
                height:1px !important;
                margin:0 !important;
                padding:0 !important;
                opacity:0 !important;
                pointer-events:none !important;
            }
            .innersync-search-select-input { width:100%; padding-right:42px !important; box-sizing:border-box; }
            .innersync-search-select-toggle {
                position:absolute !important;
                top:0 !important;
                right:0 !important;
                width:42px !important;
                height:100% !important;
                min-width:42px !important;
                margin:0 !important;
                padding:0 !important;
                border:0 !important;
                border-radius:0 !important;
                background:transparent !important;
                color:#52657b !important;
                box-shadow:none !important;
                transform:none !important;
                filter:none !important;
                z-index:2;
            }
            .innersync-search-select-toggle::before {
                content:"";
                display:block;
                width:8px;
                height:8px;
                margin:auto;
                border-right:2px solid currentColor;
                border-bottom:2px solid currentColor;
                transform:translateY(-2px) rotate(45deg);
                transition:transform 0.18s ease;
            }
            .innersync-search-select[data-open="true"] .innersync-search-select-toggle::before {
                transform:translateY(2px) rotate(225deg);
            }
            .innersync-search-select-list {
                position:absolute;
                top:calc(100% + 6px);
                left:0;
                right:0;
                z-index:1300;
                display:none;
                max-height:240px;
                overflow:auto;
                padding:6px;
                border:1px solid #cad7e7;
                border-radius:12px;
                background:#fff;
                box-shadow:0 16px 36px rgba(15,23,42,0.18);
            }
            .innersync-search-select[data-open="true"] .innersync-search-select-list { display:block; }
            .innersync-search-select-option {
                display:block !important;
                width:100% !important;
                min-height:40px;
                padding:10px 12px !important;
                border:0 !important;
                border-radius:8px !important;
                background:#fff !important;
                color:#172b47 !important;
                font:inherit !important;
                font-weight:700 !important;
                text-align:left !important;
                justify-content:flex-start !important;
                box-shadow:none !important;
                transform:none !important;
                filter:none !important;
                cursor:pointer;
                white-space:normal;
                overflow-wrap:anywhere;
            }
            .innersync-search-select-option:hover,
            .innersync-search-select-option[data-active="true"] { background:#eaf2ff !important; color:#0d47b5 !important; }
            .innersync-search-select-option[aria-selected="true"] { background:#dceaff !important; color:#0b3f98 !important; }
            .innersync-search-select-empty { padding:12px; color:#64748b; font-size:13px; font-weight:700; text-align:center; }
            @media (max-width:600px) {
                .innersync-search-select-list { max-height:210px; }
                .innersync-search-select-option { min-height:44px; }
            }
            @media (prefers-reduced-motion:reduce) {
                .innersync-search-select-toggle::before { transition:none; }
            }
        `;
        document.head.appendChild(style);
    }

    function normalize(value) {
        return String(value || "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLocaleLowerCase("id-ID")
            .trim();
    }

    class SearchableSelectControl {
        constructor(select) {
            this.select = select;
            this.originalRequired = select.required;
            this.activeIndex = -1;
            this.filteredOptions = [];
            this.instanceId = `innersync-search-select-${++instanceSequence}`;

            this.wrapper = document.createElement("div");
            this.wrapper.className = "innersync-search-select";
            this.wrapper.dataset.open = "false";
            select.parentNode.insertBefore(this.wrapper, select);
            this.wrapper.appendChild(select);

            select.classList.add("innersync-search-select-native");
            select.tabIndex = -1;
            select.setAttribute("aria-hidden", "true");
            select.required = false;

            this.input = document.createElement("input");
            this.input.type = "text";
            this.input.className = [
                "innersync-search-select-input",
                ...[...select.classList].filter(className => className !== "innersync-search-select-native")
            ].join(" ");
            this.input.style.cssText = select.style.cssText;
            this.input.style.cursor = "text";
            this.input.autocomplete = "off";
            this.input.spellcheck = false;
            this.input.setAttribute("role", "combobox");
            this.input.setAttribute("aria-autocomplete", "list");
            this.input.setAttribute("aria-expanded", "false");
            this.input.setAttribute("aria-controls", `${this.instanceId}-list`);
            this.input.required = this.originalRequired;
            this.wrapper.appendChild(this.input);

            this.toggle = document.createElement("button");
            this.toggle.type = "button";
            this.toggle.className = "innersync-search-select-toggle";
            this.toggle.setAttribute("aria-label", "Buka pilihan Host");
            this.toggle.tabIndex = -1;
            this.wrapper.appendChild(this.toggle);

            this.list = document.createElement("div");
            this.list.id = `${this.instanceId}-list`;
            this.list.className = "innersync-search-select-list";
            this.list.setAttribute("role", "listbox");
            this.wrapper.appendChild(this.list);

            this.bindEvents();
            this.refresh();
            this.optionObserver = new MutationObserver(() => this.refresh());
            this.optionObserver.observe(select, { childList: true, subtree: true, attributes: true });
            select.form?.addEventListener("reset", () => setTimeout(() => this.syncFromSelect(), 0));
        }

        getOptions() {
            return [...this.select.options].filter(option => option.value !== "" && !option.disabled);
        }

        getPlaceholder() {
            return this.select.dataset.searchPlaceholder
                || [...this.select.options].find(option => option.value === "")?.textContent?.trim()
                || "Cari dan pilih Host";
        }

        bindEvents() {
            this.input.addEventListener("focus", () => {
                this.open();
                if (this.select.value) this.input.select();
            });
            this.input.addEventListener("input", () => this.handleInput());
            this.input.addEventListener("keydown", event => this.handleKeydown(event));
            this.toggle.addEventListener("click", () => {
                if (this.isOpen()) this.close();
                else {
                    this.open();
                    this.input.focus();
                }
            });
            this.select.addEventListener("change", () => this.syncFromSelect());
            document.addEventListener("pointerdown", event => {
                if (!this.wrapper.contains(event.target)) this.close();
            });
        }

        refresh() {
            this.input.placeholder = this.getPlaceholder();
            this.input.disabled = this.select.disabled;
            this.syncFromSelect();
            if (this.isOpen()) this.renderOptions(this.input.value);
        }

        syncFromSelect() {
            const selected = this.select.selectedOptions[0];
            this.input.value = selected && selected.value !== "" ? selected.textContent.trim() : "";
            this.validate();
        }

        validate() {
            const invalid = this.originalRequired && !this.select.value;
            this.input.setCustomValidity(invalid ? "Pilih Host dari daftar." : "");
        }

        handleInput() {
            const typed = normalize(this.input.value);
            const exact = this.getOptions().find(option => normalize(option.textContent) === typed);
            this.select.value = exact ? exact.value : "";
            this.validate();
            this.open();
            this.renderOptions(this.input.value);
        }

        handleKeydown(event) {
            if (event.key === "ArrowDown" || event.key === "ArrowUp") {
                event.preventDefault();
                if (!this.isOpen()) this.open();
                if (!this.filteredOptions.length) return;
                const direction = event.key === "ArrowDown" ? 1 : -1;
                this.activeIndex = (this.activeIndex + direction + this.filteredOptions.length) % this.filteredOptions.length;
                this.updateActiveOption();
                return;
            }
            if (event.key === "Enter" && this.isOpen() && this.activeIndex >= 0) {
                event.preventDefault();
                this.choose(this.filteredOptions[this.activeIndex]);
                return;
            }
            if (event.key === "Escape") {
                event.preventDefault();
                this.syncFromSelect();
                this.close();
            }
        }

        renderOptions(query = "") {
            const term = normalize(query);
            this.filteredOptions = this.getOptions().filter(option => !term || normalize(option.textContent).includes(term));
            this.activeIndex = -1;
            this.list.replaceChildren();
            if (!this.filteredOptions.length) {
                const empty = document.createElement("div");
                empty.className = "innersync-search-select-empty";
                empty.textContent = "Host tidak ditemukan";
                this.list.appendChild(empty);
                return;
            }

            this.filteredOptions.forEach((option, index) => {
                const button = document.createElement("button");
                button.type = "button";
                button.id = `${this.instanceId}-option-${index}`;
                button.className = "innersync-search-select-option";
                button.setAttribute("role", "option");
                button.setAttribute("aria-selected", String(option.value === this.select.value));
                button.textContent = option.textContent.trim();
                button.addEventListener("pointerdown", event => event.preventDefault());
                button.addEventListener("click", () => this.choose(option));
                this.list.appendChild(button);
            });
        }

        updateActiveOption() {
            const buttons = [...this.list.querySelectorAll(".innersync-search-select-option")];
            buttons.forEach((button, index) => button.dataset.active = String(index === this.activeIndex));
            const active = buttons[this.activeIndex];
            if (!active) return;
            this.input.setAttribute("aria-activedescendant", active.id);
            active.scrollIntoView({ block: "nearest" });
        }

        choose(option) {
            this.select.value = option.value;
            this.input.value = option.textContent.trim();
            this.validate();
            this.select.dispatchEvent(new Event("change", { bubbles: true }));
            this.close();
            this.input.focus({ preventScroll: true });
        }

        open() {
            if (this.input.disabled) return;
            this.wrapper.dataset.open = "true";
            this.input.setAttribute("aria-expanded", "true");
            this.renderOptions(this.input.value === this.select.selectedOptions[0]?.textContent?.trim() ? "" : this.input.value);
        }

        close() {
            this.wrapper.dataset.open = "false";
            this.input.setAttribute("aria-expanded", "false");
            this.input.removeAttribute("aria-activedescendant");
            this.activeIndex = -1;
        }

        isOpen() {
            return this.wrapper.dataset.open === "true";
        }
    }

    function enhance(select) {
        if (!(select instanceof HTMLSelectElement)) return null;
        if (instances.has(select)) return instances.get(select);
        installStyles();
        const instance = new SearchableSelectControl(select);
        instances.set(select, instance);
        return instance;
    }

    function enhanceAll(root = document) {
        if (root.matches?.("select[data-searchable-select]")) enhance(root);
        root.querySelectorAll?.("select[data-searchable-select]").forEach(enhance);
    }

    function start() {
        installStyles();
        enhanceAll(document);
        new MutationObserver(mutations => {
            mutations.forEach(mutation => mutation.addedNodes.forEach(node => {
                if (node.nodeType === Node.ELEMENT_NODE) enhanceAll(node);
            }));
        }).observe(document.body, { childList: true, subtree: true });
    }

    global.InnersyncSearchableSelect = { enhance, enhanceAll };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
})(window);
