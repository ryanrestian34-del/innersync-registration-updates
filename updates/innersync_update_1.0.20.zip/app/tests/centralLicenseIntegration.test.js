const assert = require("assert");
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");

const temp = fs.mkdtempSync(path.join(os.tmpdir(), "innersync-central-license-test-"));
process.env.INNERSYNC_INSTALLATION_IDENTITY_FILE = path.join(temp, "installation_identity.json");
process.env.INNERSYNC_CENTRAL_CERTIFICATE_FILE = path.join(temp, "central_activation.dat");
process.env.INNERSYNC_LICENSE_PUBLIC_KEY_FILE = path.join(__dirname, "..", "license", "public_key.pem");
process.env.LICENSE_PRIVATE_KEY_FILE = path.join(__dirname, "..", "license", "private_key.pem");
process.env.LICENSE_PUBLIC_KEY_FILE = path.join(__dirname, "..", "license", "public_key.pem");

try {
    const identity = require("../license/installationIdentity").getOrCreateInstallationIdentity();
    const serviceCertificate = require("../central-license-service/src/certificate");
    const portalCertificate = require("../license/centralActivation");
    const token = serviceCertificate.issue({
        license_id:crypto.randomUUID(),
        customer:"Portal Integration Test",
        edition:"ENTERPRISE",
        features:["visitor_registration", "whatsapp"],
        max_users:100,
        max_installations:1,
        license_type:"PERMANENT",
        expires_at:null
    }, {
        installation_id:identity.installation_id,
        public_key_hash:serviceCertificate.publicKeyHash(identity.public_key)
    });
    assert.equal(portalCertificate.saveCertificate(token).valid, true);
    const status = require("../license/licenseManager").getStoredLicenseStatus();
    assert.equal(status.valid, true);
    assert.equal(status.license_valid, true);
    assert.equal(status.access_mode, "CENTRAL_LICENSE");
    assert.equal(status.installation.installation_id, identity.installation_id);
    assert.equal(status.payload.customer, "Portal Integration Test");
    console.log("centralLicenseIntegration.test: PASS");
} finally {
    fs.rmSync(temp, { recursive:true, force:true });
}
