const fs = require("fs");
const os = require("os");
const path = require("path");
const packageInfo = require("../package.json");
const { getMachineFingerprint } = require("../license/licenseManager");
const { getOrCreateInstallationIdentity } = require("../license/installationIdentity");
const {
    readCertificateToken,
    verifyCertificate,
    saveCertificate,
    createRefreshProof
} = require("../license/centralActivation");

const DEFAULT_LICENSE_SERVICE_URL = "https://license.innersync.my.id/v1";
let refreshTimer = null;

function serviceBaseUrl() {
    const value = String(process.env.INNERSYNC_LICENSE_SERVICE_URL || DEFAULT_LICENSE_SERVICE_URL)
        .trim().replace(/\/+$/, "");
    let parsed;
    try { parsed = new URL(value); } catch { throw new Error("URL License Service tidak valid."); }
    const local = ["127.0.0.1", "localhost", "::1"].includes(parsed.hostname);
    if (parsed.protocol !== "https:" && !local && process.env.INNERSYNC_LICENSE_ALLOW_HTTP !== "true") {
        throw new Error("License Service wajib menggunakan HTTPS.");
    }
    return value;
}

function appVersion() {
    try {
        const value = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "config", "current_version.json"), "utf8"));
        if (value?.version) return String(value.version);
    } catch { /* package version is the fallback */ }
    return String(packageInfo.version || "1.0.0");
}

async function requestLicenseService(pathname, body) {
    const timeoutMs = Math.max(3000, Number(process.env.INNERSYNC_LICENSE_TIMEOUT_MS || 15000));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    let response;
    try {
        response = await fetch(`${serviceBaseUrl()}/${String(pathname).replace(/^\/+/, "")}`, {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify(body || {}),
            signal:controller.signal
        });
    } catch (error) {
        const wrapped = new Error("License Service tidak dapat dihubungi. Periksa internet dan coba lagi.");
        wrapped.code = "LICENSE_SERVICE_UNAVAILABLE";
        wrapped.httpStatus = 503;
        wrapped.cause = error;
        throw wrapped;
    } finally {
        clearTimeout(timeout);
    }
    const raw = await response.text();
    let result;
    try { result = raw ? JSON.parse(raw) : {}; } catch { result = { message:raw }; }
    if (!response.ok || result?.success === false) {
        const error = new Error(result?.message || `License Service error ${response.status}`);
        error.code = result?.reason || "LICENSE_SERVICE_ERROR";
        error.httpStatus = response.status;
        error.active_installations = result?.active_installations;
        throw error;
    }
    return result;
}

async function activateCentralLicense(activationCode, options = {}) {
    const code = String(activationCode || "").trim();
    if (!code) throw new Error("Activation Code wajib diisi.");
    const identity = getOrCreateInstallationIdentity();
    const machine = getMachineFingerprint();
    const result = await requestLicenseService("activate", {
        activation_code:code,
        installation_id:identity.installation_id,
        public_key:identity.public_key,
        hostname:os.hostname(),
        platform:`${os.platform()} ${os.release()} ${os.arch()}`,
        app_version:appVersion(),
        hardware_audit:{ machine_id:machine.machine_id, ...machine.parts },
        replace_existing:options.replace_existing === true
    });
    const saved = saveCertificate(result?.data?.certificate);
    if (!saved.valid) throw new Error(saved.message || "Sertifikat dari License Service tidak valid.");
    return saved;
}

async function refreshCentralLicense(options = {}) {
    const token = readCertificateToken();
    const status = verifyCertificate(token);
    if (!token) return status;
    if (status.valid && !status.refresh_due && options.force !== true) return status;
    const proof = createRefreshProof(token);
    const result = await requestLicenseService("refresh", {
        certificate:token,
        ...proof,
        app_version:appVersion()
    });
    const saved = saveCertificate(result?.data?.certificate);
    if (!saved.valid) throw new Error(saved.message || "Sertifikat refresh tidak valid.");
    return saved;
}

function startCentralLicenseRefreshScheduler() {
    if (refreshTimer) return;
    const intervalMs = Math.max(60 * 60 * 1000,
        Number(process.env.INNERSYNC_LICENSE_REFRESH_INTERVAL_MS || 24 * 60 * 60 * 1000));
    const run = () => refreshCentralLicense().catch(error => {
        console.warn("Central license refresh warning:", error.message);
    });
    setTimeout(run, 15000).unref?.();
    refreshTimer = setInterval(run, intervalMs);
    refreshTimer.unref?.();
}

module.exports = {
    DEFAULT_LICENSE_SERVICE_URL,
    serviceBaseUrl,
    activateCentralLicense,
    refreshCentralLicense,
    startCentralLicenseRefreshScheduler
};
