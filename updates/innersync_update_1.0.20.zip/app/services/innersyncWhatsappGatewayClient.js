const {
    getMachineFingerprint,
    getStoredLicenseStatus,
    getStoredLicenseToken,
    getStoredCentralCertificateToken
} = require("../license/licenseManager");

const DEFAULT_GATEWAY_URL = "https://api.innersync.my.id/v1";

function gatewayBaseUrl() {
    const value = String(process.env.INNERSYNC_GATEWAY_URL || DEFAULT_GATEWAY_URL).trim().replace(/\/+$/,"");
    let parsed;
    try {
        parsed = new URL(value);
    } catch {
        throw new Error("URL Innersync Gateway tidak valid.");
    }
    const local = ["127.0.0.1","localhost","::1"].includes(parsed.hostname);
    if (parsed.protocol !== "https:" && !local && process.env.INNERSYNC_GATEWAY_ALLOW_HTTP !== "true") {
        throw new Error("Innersync Gateway wajib menggunakan HTTPS.");
    }
    return value;
}

function credentials() {
    const status = getStoredLicenseStatus();
    const central = status.access_mode === "CENTRAL_LICENSE";
    const token = central ? getStoredCentralCertificateToken() : getStoredLicenseToken();
    if (!status.license_valid || !token) {
        const error = new Error("License penuh harus aktif untuk menggunakan Innersync WhatsApp Service.");
        error.code = "FULL_LICENSE_REQUIRED";
        throw error;
    }
    const machine = status.machine || getMachineFingerprint();
    return {
        token,
        machine_id:String(status.payload?.machine_id || machine.machine_id || "").replace(/-/g,"").toUpperCase(),
        license_id:status.payload?.license_id || null,
        installation_id:central ? status.installation?.installation_id || null : null
    };
}

async function requestGateway(pathname, options = {}) {
    const auth = credentials();
    const timeoutMs = Math.max(Number(process.env.INNERSYNC_GATEWAY_TIMEOUT_MS || 20000),3000);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(),timeoutMs);
    let response;
    try {
        response = await fetch(gatewayBaseUrl() + "/" + String(pathname).replace(/^\/+/,""),{
            method:options.method || "GET",
            headers:{
                Authorization:"Bearer " + auth.token,
                "X-Innersync-Machine-ID":auth.machine_id,
                "X-Innersync-License-ID":auth.license_id || "",
                ...(auth.installation_id ? { "X-Innersync-Installation-ID":auth.installation_id } : {}),
                ...(options.idempotencyKey ? { "Idempotency-Key":String(options.idempotencyKey) } : {}),
                ...(options.body !== undefined ? { "Content-Type":"application/json" } : {})
            },
            body:options.body === undefined ? undefined : JSON.stringify(options.body),
            signal:controller.signal
        });
    } catch (error) {
        const gatewayError = new Error(options.isSend
            ? "Gateway Innersync tidak dapat dihubungi. Retry aman karena transaksi memakai Idempotency Key."
            : "Gateway Innersync tidak dapat dihubungi.");
        gatewayError.code = "GATEWAY_UNAVAILABLE";
        gatewayError.deliveryStatus = options.isSend ? "UNCONFIRMED" : undefined;
        gatewayError.cause = error;
        throw gatewayError;
    } finally {
        clearTimeout(timeout);
    }

    const raw = await response.text();
    let result = {};
    try {
        result = raw ? JSON.parse(raw) : {};
    } catch {
        result = { message:raw };
    }
    if (!response.ok || result?.success === false) {
        const error = new Error(result?.message || ("Innersync Gateway error " + response.status));
        error.code = result?.reason || "GATEWAY_ERROR";
        error.httpStatus = response.status;
        error.transaction_id = result?.transaction_id || null;
        if (error.code === "DELIVERY_UNCONFIRMED") error.deliveryStatus = "UNCONFIRMED";
        throw error;
    }
    return result;
}

async function sendTextMessage(payload) {
    return requestGateway("/whatsapp/messages",{
        method:"POST",
        idempotencyKey:payload.idempotency_key,
        isSend:true,
        body:{
            to:payload.to,
            text:payload.text,
            reference_type:payload.reference_type,
            reference_id:payload.reference_id
        }
    });
}

async function sendMediaMessage(payload) {
    return requestGateway("/whatsapp/media",{
        method:"POST",
        idempotencyKey:payload.idempotency_key,
        isSend:true,
        body:{
            to:payload.to,
            url:payload.url,
            caption:payload.caption,
            reference_type:payload.reference_type,
            reference_id:payload.reference_id
        }
    });
}

async function getCreditSummary(limit = 25) {
    const result = await requestGateway("/credits/balance?limit=" + Math.max(1,Math.min(Number(limit)||25,100)));
    return result.data || {};
}

async function createCreditOrder(credits) {
    const result = await requestGateway("/credits/orders",{
        method:"POST",
        body:{ credits:Number(credits) }
    });
    return result.data || {};
}

async function getCreditAlerts(options = {}) {
    const params = new URLSearchParams();
    if (options.status) params.set("status", String(options.status));
    params.set("limit", String(Math.max(1, Math.min(Number(options.limit) || 50, 200))));
    const result = await requestGateway("/credits/alerts?" + params.toString());
    return Array.isArray(result.data) ? result.data : [];
}

async function acknowledgeCreditAlert(alertId, acknowledgement = {}) {
    const result = await requestGateway(`/credits/alerts/${encodeURIComponent(alertId)}/acknowledge`, {
        method:"POST",
        body:{
            actor:String(acknowledgement.actor || "OPERATOR"),
            note:String(acknowledgement.note || "")
        }
    });
    return result.data || {};
}

async function getGatewayConnectionStatus() {
    try {
        const summary = await getCreditSummary(1);
        return {
            online:true,
            gateway_url:gatewayBaseUrl(),
            balance:Number(summary.balance || 0),
            routing_mode:summary.routing_mode || "LEGACY_SHARED",
            channels:Array.isArray(summary.channels) ? summary.channels : []
        };
    } catch (error) {
        return {
            online:false,
            gateway_url:gatewayBaseUrl(),
            error:error.message,
            reason:error.code || "GATEWAY_UNAVAILABLE"
        };
    }
}

module.exports = {
    DEFAULT_GATEWAY_URL,
    gatewayBaseUrl,
    requestGateway,
    sendTextMessage,
    sendMediaMessage,
    getCreditSummary,
    createCreditOrder,
    getCreditAlerts,
    acknowledgeCreditAlert,
    getGatewayConnectionStatus
};
