const pool = require("../database/db");

let notificationSchemaReady = false;

function getCurrentUsername(req) {
    return req?.session?.user?.username || req?.session?.user?.full_name || "SYSTEM";
}

async function ensureSystemNotificationSchema() {
    if (notificationSchemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS system_notifications (
            notification_id SERIAL PRIMARY KEY,
            channel VARCHAR(80) NOT NULL,
            event_type VARCHAR(80),
            provider_type VARCHAR(80),
            status VARCHAR(30) NOT NULL,
            visitor_id INTEGER,
            visitor_name VARCHAR(200),
            target VARCHAR(255),
            title TEXT NOT NULL,
            message TEXT,
            detail JSONB DEFAULT '{}'::jsonb,
            is_read BOOLEAN NOT NULL DEFAULT FALSE,
            read_by VARCHAR(100),
            read_time TIMESTAMP,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_read_time ON system_notifications (is_read, created_time DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_created_time ON system_notifications (created_time DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_channel ON system_notifications (channel)");
    await pool.query("ALTER TABLE system_notifications ADD COLUMN IF NOT EXISTS external_reference VARCHAR(200)");
    await pool.query("ALTER TABLE system_notifications ADD COLUMN IF NOT EXISTS acknowledgement_required BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE system_notifications ADD COLUMN IF NOT EXISTS acknowledgement_status VARCHAR(30) NOT NULL DEFAULT 'NOT_REQUIRED'");
    await pool.query("ALTER TABLE system_notifications ADD COLUMN IF NOT EXISTS acknowledged_by VARCHAR(100)");
    await pool.query("ALTER TABLE system_notifications ADD COLUMN IF NOT EXISTS acknowledged_time TIMESTAMP");
    await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS uq_system_notifications_external_reference " +
        "ON system_notifications(external_reference) WHERE external_reference IS NOT NULL");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_acknowledgement " +
        "ON system_notifications(acknowledgement_required,acknowledgement_status,created_time DESC)");

    notificationSchemaReady = true;
}

async function createSystemNotification(req, notification) {
    try {
        await ensureSystemNotificationSchema();
        const detail = notification.detail && typeof notification.detail === "object"
            ? notification.detail
            : {};

        const result = await pool.query(
            `INSERT INTO system_notifications (
                channel,
                event_type,
                provider_type,
                status,
                visitor_id,
                visitor_name,
                target,
                title,
                message,
                detail,
                created_by,
                created_time,
                external_reference,
                acknowledgement_required,
                acknowledgement_status
             )
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, NOW(), $12, $13, $14)
             ON CONFLICT (external_reference) WHERE external_reference IS NOT NULL
             DO UPDATE SET
                status = EXCLUDED.status,
                title = EXCLUDED.title,
                message = EXCLUDED.message,
                detail = EXCLUDED.detail,
                acknowledgement_required = EXCLUDED.acknowledgement_required,
                acknowledgement_status = CASE
                    WHEN system_notifications.acknowledgement_status = 'ACKNOWLEDGED'
                    THEN system_notifications.acknowledgement_status
                    ELSE EXCLUDED.acknowledgement_status
                END
             RETURNING *`,
            [
                String(notification.channel || "SYSTEM").toUpperCase(),
                notification.event_type ? String(notification.event_type).toUpperCase() : null,
                notification.provider_type ? String(notification.provider_type).toUpperCase() : null,
                String(notification.status || "INFO").toUpperCase(),
                notification.visitor_id || null,
                notification.visitor_name || null,
                notification.target || null,
                notification.title || "System Notification",
                notification.message || null,
                detail,
                notification.created_by || getCurrentUsername(req),
                notification.external_reference ? String(notification.external_reference).slice(0, 200) : null,
                notification.acknowledgement_required === true,
                notification.acknowledgement_required === true
                    ? String(notification.acknowledgement_status || "UNACKNOWLEDGED").toUpperCase()
                    : "NOT_REQUIRED"
            ]
        );
        return result.rows[0] || null;
    } catch (error) {
        console.log("CREATE SYSTEM NOTIFICATION ERROR:", error.message);
        return null;
    }
}

module.exports = {
    ensureSystemNotificationSchema,
    createSystemNotification
};
