const express = require("express");
const pool = require("../database/db");
const {
    getCreditAlerts,
    acknowledgeCreditAlert
} = require("../services/innersyncWhatsappGatewayClient");
const {
    ensureSystemNotificationSchema,
    createSystemNotification
} = require("./notificationService");

const router = express.Router();
let syncPromise = null;
let lastSuccessfulSyncAt = 0;
const SYNC_INTERVAL_MS = 30000;

function requireSession(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success:false, message:"Session expired" });
    }
    next();
}

function currentUsername(req) {
    return String(req.session?.user?.username || req.session?.user?.full_name || "OPERATOR").slice(0, 100);
}

function alertStatus(severity) {
    const normalized = String(severity || "INFO").toUpperCase();
    return ["INFO", "WARNING", "CRITICAL", "URGENT"].includes(normalized) ? normalized : "INFO";
}

async function synchronizeAlerts(req) {
    if (syncPromise) return syncPromise;
    if (Date.now() - lastSuccessfulSyncAt < SYNC_INTERVAL_MS) return [];
    syncPromise = (async () => {
        await ensureSystemNotificationSchema();
        const alerts = await getCreditAlerts({ status:"UNACKNOWLEDGED", limit:100 });
        for (const alert of alerts) {
            const threshold = Number(alert.threshold || 0);
            const balance = Number(alert.balance || 0);
            const currentBalance = Number(alert.current_balance ?? balance);
            await createSystemNotification(req, {
                channel:"WHATSAPP_CREDIT",
                event_type:"LOW_CREDIT",
                provider_type:"INNERSYNC_GATEWAY",
                status:alertStatus(alert.severity),
                target:`${currentBalance} kredit`,
                title:`Kredit WhatsApp tersisa ${currentBalance.toLocaleString("id-ID")}`,
                message:`Saldo telah melewati batas ${threshold.toLocaleString("id-ID")} kredit. Lakukan top-up sebelum layanan WhatsApp berhenti.`,
                detail:{
                    gateway_alert_id:Number(alert.alert_id),
                    threshold,
                    alert_balance:balance,
                    current_balance:currentBalance,
                    severity:alertStatus(alert.severity),
                    gateway_created_at:alert.created_at
                },
                created_by:"INNERSYNC_GATEWAY",
                external_reference:`WHATSAPP_CREDIT_ALERT:${alert.alert_id}`,
                acknowledgement_required:true,
                acknowledgement_status:"UNACKNOWLEDGED"
            });
        }
        lastSuccessfulSyncAt = Date.now();
        return alerts;
    })().finally(() => {
        syncPromise = null;
    });
    return syncPromise;
}

async function localPendingAlerts() {
    await ensureSystemNotificationSchema();
    const result = await pool.query(
        `SELECT notification_id,channel,event_type,status,title,message,detail,created_time,
                acknowledgement_status
         FROM system_notifications
         WHERE channel='WHATSAPP_CREDIT'
           AND acknowledgement_required=TRUE
           AND acknowledgement_status='UNACKNOWLEDGED'
         ORDER BY
           CASE status WHEN 'URGENT' THEN 1 WHEN 'CRITICAL' THEN 2 WHEN 'WARNING' THEN 3 ELSE 4 END,
           created_time DESC`
    );
    return result.rows;
}

router.get("/api/whatsapp-credit-alerts/pending", requireSession, async (req, res) => {
    let syncError = null;
    try {
        await synchronizeAlerts(req);
    } catch (error) {
        syncError = error.message;
    }
    try {
        const data = await localPendingAlerts();
        res.json({ success:true, data, gateway_online:!syncError, sync_error:syncError });
    } catch (error) {
        res.status(500).json({ success:false, message:error.message });
    }
});

router.post("/api/whatsapp-credit-alerts/:notificationId/acknowledge", requireSession, async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationId = Number(req.params.notificationId || 0);
        const notification = await pool.query(
            `SELECT notification_id,detail,acknowledgement_status
             FROM system_notifications
             WHERE notification_id=$1 AND channel='WHATSAPP_CREDIT' AND acknowledgement_required=TRUE`,
            [notificationId]
        );
        if (!notification.rowCount) {
            return res.status(404).json({ success:false, message:"Credit warning tidak ditemukan." });
        }
        if (notification.rows[0].acknowledgement_status === "ACKNOWLEDGED") {
            return res.json({ success:true, message:"Credit warning sudah di-acknowledge." });
        }

        const gatewayAlertId = Number(notification.rows[0].detail?.gateway_alert_id || 0);
        if (!gatewayAlertId) throw new Error("Gateway Alert ID tidak tersedia.");
        const actor = currentUsername(req);
        const gatewayAlert = await acknowledgeCreditAlert(gatewayAlertId, {
            actor,
            note:req.body?.note
        });
        await pool.query(
            `UPDATE system_notifications
             SET acknowledgement_status='ACKNOWLEDGED', acknowledged_by=$2, acknowledged_time=NOW(),
                 is_read=TRUE, read_by=$2, read_time=NOW(), detail=detail || $3::jsonb
             WHERE notification_id=$1`,
            [notificationId, actor, JSON.stringify({
                gateway_acknowledged_at:gatewayAlert.acknowledged_at || new Date().toISOString()
            })]
        );
        res.json({ success:true, message:"Informasi kredit sudah diterima dan tercatat di Gateway." });
    } catch (error) {
        const status = error.code === "GATEWAY_UNAVAILABLE" ? 503 : 400;
        res.status(status).json({ success:false, message:error.message });
    }
});

module.exports = router;
