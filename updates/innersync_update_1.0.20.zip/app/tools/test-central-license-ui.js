const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");

async function run() {
    const browser = await chromium.launch({ channel:"chrome", headless:true });
    const output = path.join(os.tmpdir(), "innersync-central-license-qa");
    await fs.mkdir(output, { recursive:true });
    try {
        for (const testCase of [
            { name:"desktop", viewport:{ width:1280, height:900 } },
            { name:"mobile", viewport:{ width:390, height:844 } }
        ]) {
            const context = await browser.newContext({ viewport:testCase.viewport });
            const page = await context.newPage();
            const errors = [];
            const requests = [];
            page.on("pageerror", error => errors.push(error.message));
            page.on("dialog", dialog => dialog.accept());
            await page.route("**/*", async route => {
                const url = new URL(route.request().url());
                if (url.hostname !== "portal.test") return route.fulfill({ contentType:"text/css", body:"" });
                if (url.pathname === "/license.html") return route.fulfill({ contentType:"text/html", body:await fs.readFile(path.resolve(__dirname, "../public/license.html")) });
                if (url.pathname === "/logo.png") return route.fulfill({ contentType:"image/png", body:await fs.readFile(path.resolve(__dirname, "../public/logo.png")) });
                if (url.pathname === "/api/license/status") return route.fulfill({ json:{
                    success:true, valid:true, license_valid:true, access_mode:"CENTRAL_LICENSE", app_version:"1.0.19",
                    central_certificate:true, installation:{ installation_id:"8fa51444-046d-4e71-a84a-9a0f5e7ad513" },
                    machine:{ machine_id:"AABB", display_id:"AABB", hostname:"SERVER-01" },
                    license:{ customer:"PT Customer Test", edition:"ENTERPRISE", expires_at:null }
                } });
                if (url.pathname === "/api/license/whatsapp-credits") return route.fulfill({ json:{ success:true, data:{ balance:500, lifetime_topup:500, lifetime_used:0, transactions:[] } } });
                if (url.pathname === "/api/license/central/activate") {
                    const body = route.request().postDataJSON();
                    requests.push(body);
                    if (!body.replace_existing) return route.fulfill({ status:409, json:{ success:false, reason:"DEVICE_LIMIT", message:"Konfirmasi penggantian server lama." } });
                    return route.fulfill({ json:{ success:true, message:"License berhasil dipindahkan." } });
                }
                return route.fulfill({ status:404, json:{ success:false } });
            });
            await page.goto("http://portal.test/license.html", { waitUntil:"networkidle" });
            assert.equal(await page.locator("#identityLabel").textContent(), "Installation ID");
            assert.equal(await page.locator("#machineId").textContent(), "8fa51444-046d-4e71-a84a-9a0f5e7ad513");
            await page.locator("#activationCode").fill("IS-ACT-TEST-CODE");
            await page.locator("#centralActivateButton").click();
            await page.locator("#messageBox.ok").waitFor();
            assert.deepEqual(requests.map(item => item.replace_existing), [false, true]);
            assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth), true);
            assert.deepEqual(errors, []);
            await page.screenshot({ path:path.join(output, `portal-${testCase.name}.png`), fullPage:true });
            await context.close();
        }

        const context = await browser.newContext({ viewport:{ width:1440, height:900 } });
        const page = await context.newPage();
        const errors = [];
        page.on("pageerror", error => errors.push(error.message));
        await page.route("**/*", async route => {
            const url = new URL(route.request().url());
            if (url.pathname === "/admin") return route.fulfill({ contentType:"text/html", body:await fs.readFile(path.resolve(__dirname, "../central-license-service/public/admin.html")) });
            if (url.pathname === "/admin/api/session") return route.fulfill({ json:{ success:true, data:{ username:"licenseadmin" } } });
            if (url.pathname === "/admin/api/overview") return route.fulfill({ json:{ success:true, data:{ licenses:2, active_licenses:2, active_installations:2, online_24h:1 } } });
            if (url.pathname.startsWith("/admin/api/licenses")) return route.fulfill({ json:{ success:true, data:[] } });
            if (url.pathname.startsWith("/admin/api/audit")) return route.fulfill({ json:{ success:true, data:[] } });
            return route.fulfill({ status:404, json:{ success:false } });
        });
        await page.goto("http://license.test/admin", { waitUntil:"networkidle" });
        assert.equal(await page.locator("#statLicenses").textContent(), "2");
        assert.equal(await page.locator("#existingLicenseId").getAttribute("placeholder"), "UUID dari license customer yang sedang aktif");
        assert.deepEqual(errors, []);
        await page.screenshot({ path:path.join(output, "license-admin.png"), fullPage:true });
        await context.close();
        console.log(`central-license-ui: PASS; screenshots: ${output}`);
    } finally {
        await browser.close();
    }
}

run().catch(error => { console.error(error); process.exit(1); });
