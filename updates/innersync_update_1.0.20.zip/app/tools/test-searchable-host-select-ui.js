const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");

async function main() {
    const publicRoot = path.resolve(__dirname, "../public");
    const output = path.join(os.tmpdir(), "innersync-searchable-host-qa");
    const jsQrSource = await fs.readFile(path.resolve(__dirname, "../node_modules/jsqr/dist/jsQR.js"), "utf8");
    const browser = await chromium.launch({ channel: "chrome", headless: true });
    const pageErrors = [];
    const hosts = ["Andi Finance", "Budi Security", "Citra Human Resources", "Dewi Engineering"];

    async function openPage(viewport) {
        const context = await browser.newContext({ viewport });
        const page = await context.newPage();
        page.on("pageerror", error => pageErrors.push(error.message));
        await page.route("**/*", async route => {
            const url = new URL(route.request().url());
            if (url.hostname !== "innersync.test") return route.abort();
            if (url.pathname === "/vendor/jsqr/jsQR.js") {
                return route.fulfill({ contentType: "text/javascript", body: jsQrSource });
            }
            if (url.pathname === "/api/public/self-registration/options") {
                return route.fulfill({ json: {
                    success: true,
                    data: { hosts: hosts.map(host_name => ({ host_name })), permission_groups: [], settings: {} }
                } });
            }
            if (url.pathname.includes("operator-presence")) {
                return route.fulfill({ contentType: "text/event-stream", body: "event: presence\ndata: {\"online\":1}\n\n" });
            }
            if (url.pathname.startsWith("/api/")) {
                return route.fulfill({ json: { success: true, data: [] } });
            }

            const filename = path.resolve(publicRoot, `.${url.pathname}`);
            if (!filename.startsWith(publicRoot + path.sep)) return route.abort();
            try {
                const contentType = filename.endsWith(".html")
                    ? "text/html"
                    : filename.endsWith(".js")
                        ? "text/javascript"
                        : "image/png";
                return route.fulfill({ body: await fs.readFile(filename), contentType });
            } catch {
                return route.fulfill({ status: 404, body: "" });
            }
        });
        await page.goto("http://innersync.test/self-registration.html", { waitUntil: "load" });
        await page.locator("#host option").nth(4).waitFor({ state: "attached" });
        await page.locator("#newVisitorModeBtn").click();
        await page.locator(".innersync-search-select-input").waitFor();
        return { page, context };
    }

    async function openVisitorLogsPage(viewport) {
        const context = await browser.newContext({ viewport });
        const page = await context.newPage();
        page.on("pageerror", error => pageErrors.push(error.message));
        await page.route("**/*", async route => {
            const url = new URL(route.request().url());
            if (url.hostname !== "innersync.test") return route.abort();
            if (url.pathname === "/api/visitor-log-filter-options") {
                return route.fulfill({ json: {
                    success: true,
                    data: { operators: [], groups: [], hosts }
                } });
            }
            if (url.pathname === "/api/visitor-logs") {
                return route.fulfill({ json: { success: true, data: [] } });
            }

            const filename = path.resolve(publicRoot, `.${url.pathname}`);
            if (!filename.startsWith(publicRoot + path.sep)) return route.abort();
            try {
                const contentType = filename.endsWith(".html")
                    ? "text/html"
                    : filename.endsWith(".js")
                        ? "text/javascript"
                        : "image/png";
                return route.fulfill({ body: await fs.readFile(filename), contentType });
            } catch {
                return route.fulfill({ status: 404, body: "" });
            }
        });
        await page.goto("http://innersync.test/visitor-logs.html", { waitUntil: "load" });
        await page.locator("#toggleFilterBtn").click();
        await page.locator("#filterTypeSelect").selectOption("host");
        await page.locator("#hostFilter option").nth(4).waitFor({ state: "attached" });
        await page.waitForTimeout(400);
        return { page, context };
    }

    try {
        await fs.mkdir(output, { recursive: true });
        for (const testCase of [
            { name: "desktop", viewport: { width: 1440, height: 1000 } },
            { name: "mobile", viewport: { width: 390, height: 844 } }
        ]) {
            const { page, context } = await openPage(testCase.viewport);
            const search = page.locator(".innersync-search-select-input").first();
            const nativeSelect = page.locator("#host");
            assert.equal(await search.getAttribute("placeholder"), "Cari nama Host...");
            assert.equal(await nativeSelect.getAttribute("aria-hidden"), "true");

            await search.focus();
            await search.fill("finance");
            const options = page.locator(".innersync-search-select-option");
            assert.equal(await options.count(), 1);
            assert.equal(await options.first().textContent(), "Andi Finance");
            await options.first().click();
            assert.equal(await nativeSelect.inputValue(), "Andi Finance");
            assert.equal(await search.inputValue(), "Andi Finance");

            await search.fill("security");
            await search.press("ArrowDown");
            await search.press("Enter");
            assert.equal(await nativeSelect.inputValue(), "Budi Security");

            await search.fill("tidak ada");
            assert.equal(await page.locator(".innersync-search-select-empty").textContent(), "Host tidak ditemukan");
            assert.equal(await nativeSelect.inputValue(), "");
            assert.equal(await search.evaluate(element => element.validationMessage), "Pilih Host dari daftar.");

            await page.evaluate(() => {
                const select = document.createElement("select");
                select.id = "dynamicHost";
                select.dataset.searchableSelect = "";
                select.dataset.searchPlaceholder = "Cari Host dinamis...";
                select.innerHTML = '<option value="">Select Host</option><option value="Host Dynamic">Host Dynamic</option>';
                document.body.appendChild(select);
            });
            await page.locator("#dynamicHost + .innersync-search-select-input").waitFor().catch(() => {});
            assert.equal(await page.locator("#dynamicHost").evaluate(element => element.closest(".innersync-search-select") !== null), true);
            await page.locator("#dynamicHost").evaluate(element => element.closest(".innersync-search-select")?.remove());

            await search.fill("dewi");
            await page.locator(".innersync-search-select-option", { hasText: "Dewi Engineering" }).click();
            await page.screenshot({ path: path.join(output, `${testCase.name}.png`), fullPage: true });
            assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth), true);
            await context.close();
        }

        {
            const { page, context } = await openVisitorLogsPage({ width: 1365, height: 768 });
            const filterTypeBox = await page.locator("#filterTypeSelect").boundingBox();
            const hostSearch = page.locator("#hostFilter + .innersync-search-select-input");
            const hostBox = await hostSearch.boundingBox();
            assert.ok(filterTypeBox && hostBox, "Filter controls must be visible");
            assert.ok(Math.abs(filterTypeBox.width - hostBox.width) <= 1, "Host search width must match filter type");
            assert.ok(Math.abs(filterTypeBox.height - hostBox.height) <= 1, "Host search height must match filter type");

            await hostSearch.click();
            const firstOption = page.locator(".innersync-search-select-option").first();
            await firstOption.waitFor();
            const optionBox = await firstOption.boundingBox();
            assert.ok(optionBox, "Host dropdown option must be visible");
            const topElementClass = await page.evaluate(({ x, y }) => {
                return document.elementFromPoint(x, y)?.className || "";
            }, { x: optionBox.x + optionBox.width / 2, y: optionBox.y + optionBox.height / 2 });
            assert.match(String(topElementClass), /innersync-search-select-option/, "Host dropdown must render above the table");
            await page.screenshot({ path: path.join(output, "visitor-logs-filter.png"), fullPage: false });
            await context.close();
        }

        const integrationFiles = ["self-registration.html", "invitation-booking.html", "index.html", "visitor-logs.html"];
        for (const filename of integrationFiles) {
            const html = await fs.readFile(path.join(publicRoot, filename), "utf8");
            assert.match(html, /searchable-select\.js/, `${filename} must load the shared component`);
            assert.match(html, /data-searchable-select/, `${filename} must mark its Host select as searchable`);
        }
        assert.deepEqual(pageErrors, [], `Browser errors: ${pageErrors.join(" | ")}`);
        console.log(`PASS searchable Host select on desktop/mobile, keyboard, dynamic options, validation, and all Host forms; screenshots: ${output}`);
    } finally {
        await browser.close();
    }
}

main().catch(error => {
    console.error(error);
    process.exitCode = 1;
});
