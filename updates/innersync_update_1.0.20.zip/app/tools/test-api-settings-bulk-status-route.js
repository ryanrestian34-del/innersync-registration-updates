const assert = require("node:assert/strict");
const pool = require("../database/db");
const router = require("../routes/apiIntegrationRoutes");

const layer = router.stack.find(item => item.route?.path === "/api/third-party-settings/bulk-status" && item.route.methods.patch);
assert(layer, "Bulk status PATCH route not found");
const handler = layer.route.stack.at(-1).handle;

function responseRecorder() {
    return {
        statusCode: 200,
        body: null,
        status(code) { this.statusCode = code; return this; },
        json(body) { this.body = body; return this; }
    };
}

async function main() {
    const originalConnect = pool.connect;
    const calls = [];
    const client = {
        async query(sql, params) {
            calls.push({ sql: String(sql).replace(/\s+/g, " ").trim(), params });
            if (String(sql).includes("UPDATE third_party_api_configs")) {
                return { rows: params[2].map(configId => ({ config_id: configId, config_name: `Config ${configId}`, is_active: params[0] })) };
            }
            return { rows: [] };
        },
        release() { calls.push({ sql: "RELEASE" }); }
    };
    pool.connect = async () => client;

    try {
        const req = {
            body: { config_ids: [17, 16, 17], is_active: false },
            session: { user: { username: "admin" } }
        };
        const res = responseRecorder();
        await handler(req, res);
        assert.equal(res.statusCode, 200);
        assert.equal(res.body.success, true);
        assert.equal(res.body.data.updated_count, 2);
        assert.deepEqual(res.body.data.config_ids, [17, 16]);
        assert.deepEqual(calls.map(call => call.sql), [
            "BEGIN",
            calls[1].sql,
            "DELETE FROM api_token_cache WHERE config_id = ANY($1::int[])",
            "COMMIT",
            "RELEASE"
        ]);
        assert.match(calls[1].sql, /UPDATE third_party_api_configs/);
        assert.deepEqual(calls[1].params, [false, "admin", [17, 16]]);

        const missingCalls = [];
        pool.connect = async () => ({
            async query(sql) {
                const normalized = String(sql).replace(/\s+/g, " ").trim();
                missingCalls.push(normalized);
                if (normalized.includes("UPDATE third_party_api_configs")) return { rows: [{ config_id: 17 }] };
                return { rows: [] };
            },
            release() { missingCalls.push("RELEASE"); }
        });
        const missingRes = responseRecorder();
        await handler({ body: { config_ids: [17, 999], is_active: true }, session: { user: { username: "admin" } } }, missingRes);
        assert.equal(missingRes.statusCode, 404);
        assert.deepEqual(missingCalls, ["BEGIN", missingCalls[1], "ROLLBACK", "RELEASE"]);
        assert.match(missingCalls[1], /UPDATE third_party_api_configs/);
        assert.equal(missingCalls.some(sql => sql.includes("DELETE FROM api_token_cache")), false);
        assert.equal(missingCalls.includes("COMMIT"), false);

        let connectCalled = false;
        pool.connect = async () => { connectCalled = true; return client; };
        const invalidRes = responseRecorder();
        await handler({ body: { config_ids: [], is_active: false }, session: {} }, invalidRes);
        assert.equal(invalidRes.statusCode, 400);
        assert.equal(connectCalled, false);
        console.log("PASS API bulk status validates selection, updates atomically, and rolls back missing IDs");
    } finally {
        pool.connect = originalConnect;
        await pool.end();
    }
}

main().catch(error => {
    console.error(error);
    process.exitCode = 1;
    pool.end().catch(() => {});
});
