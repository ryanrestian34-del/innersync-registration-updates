const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");

async function main() {
    const publicRoot = path.resolve(__dirname, "../public");
    const output = path.join(os.tmpdir(), "innersync-api-bulk-status-qa");
    const browser = await chromium.launch({ channel: "chrome", headless: true });
    const pageErrors = [];
    const patchRequests = [];
    let configs = [
        { config_id: 17, config_name: "SCHINDLER - SYNC CANCELLED", provider_type: "SCHINDLER", execution_order: 100, trigger_event: "SYNC_CANCEL", action_type: "CANCEL", http_method: "POST", is_active: true },
        { config_id: 16, config_name: "SCHINDLER SYNC DELETE", provider_type: "SCHINDLER", execution_order: 100, trigger_event: "SYNC_DELETE", action_type: "DELETE", http_method: "POST", is_active: true },
        { config_id: 12, config_name: "API SERVER STATUS INNERRANGE", provider_type: "INNERRANGE", execution_order: 100, trigger_event: "HEALTH_CHECK", action_type: "GET", http_method: "GET", is_active: true }
    ];

    async function openPage(viewport) {
        const context = await browser.newContext({ viewport });
        const page = await context.newPage();
        page.on("pageerror", error => pageErrors.push(error.message));
        page.on("dialog", dialog => dialog.accept());
        await page.route("**/*", async route => {
            const url = new URL(route.request().url());
            if (url.hostname !== "innersync.test") return route.abort();
            if (url.pathname === "/api/third-party-settings" && route.request().method() === "GET") {
                return route.fulfill({ json: { success: true, data: configs } });
            }
            if (url.pathname === "/api/third-party-settings/bulk-status" && route.request().method() === "PATCH") {
                const body = route.request().postDataJSON();
                patchRequests.push(body);
                configs = configs.map(config => body.config_ids.includes(config.config_id)
                    ? { ...config, is_active: body.is_active }
                    : config);
                return route.fulfill({ json: { success: true, data: { updated_count: body.config_ids.length } } });
            }
            if (url.pathname === "/api/api-templates") {
                return route.fulfill({ json: { success: true, data: [] } });
            }
            if (url.pathname.startsWith("/api/") || url.pathname === "/current-user") {
                return route.fulfill({ json: { success: true, data: [] } });
            }
            const filename = path.resolve(publicRoot, `.${url.pathname}`);
            if (!filename.startsWith(publicRoot + path.sep)) return route.abort();
            try {
                return route.fulfill({
                    body: await fs.readFile(filename),
                    contentType: filename.endsWith(".html") ? "text/html" : "image/png"
                });
            } catch {
                return route.fulfill({ status: 404, body: "" });
            }
        });
        await page.goto("http://innersync.test/api-settings.html", { waitUntil: "load" });
        await page.locator("#configTable tr").first().waitFor();
        return { page, context };
    }

    try {
        await fs.mkdir(output, { recursive: true });
        const desktop = await openPage({ width: 1600, height: 1000 });
        const checks = desktop.page.locator(".config-select");
        assert.equal(await checks.count(), 3);
        assert.equal(await desktop.page.locator("#bulkDisableBtn").isDisabled(), true);
        await checks.nth(0).check();
        await checks.nth(2).check();
        assert.equal(await desktop.page.locator("#bulkSelectionCount").textContent(), "2 setting dipilih");
        assert.equal(await desktop.page.locator("#selectAllConfigs").evaluate(element => element.indeterminate), true);
        await desktop.page.locator("#bulkDisableBtn").click();
        await desktop.page.waitForFunction(() => document.querySelectorAll("#configTable .status-pill.inactive").length === 2);
        assert.deepEqual(patchRequests[0], { config_ids: [12, 17], is_active: false });
        assert.equal(await desktop.page.locator("#bulkSelectionCount").textContent(), "0 setting dipilih");

        await desktop.page.locator("#selectAllConfigs").check();
        assert.equal(await desktop.page.locator("#bulkSelectionCount").textContent(), "3 setting dipilih");
        assert.equal(await desktop.page.locator(".config-select:checked").count(), 3);
        await desktop.page.screenshot({ path: path.join(output, "desktop-select-all.png"), fullPage: true });
        await desktop.context.close();

        const mobile = await openPage({ width: 390, height: 844 });
        await mobile.page.locator(".config-select").first().check();
        const toolbar = await mobile.page.locator(".bulk-toolbar").boundingBox();
        assert(toolbar && toolbar.x >= 0 && toolbar.x + toolbar.width <= 390, "Bulk toolbar must fit mobile viewport");
        await mobile.page.screenshot({ path: path.join(output, "mobile-selection.png"), fullPage: true });
        await mobile.context.close();

        assert.deepEqual(pageErrors, [], `Browser errors: ${pageErrors.join(" | ")}`);
        console.log(`PASS API bulk status selection, Select All, PATCH payload, status refresh, and responsive toolbar; screenshots: ${output}`);
    } finally {
        await browser.close();
    }
}

main().catch(error => {
    console.error(error);
    process.exitCode = 1;
});
