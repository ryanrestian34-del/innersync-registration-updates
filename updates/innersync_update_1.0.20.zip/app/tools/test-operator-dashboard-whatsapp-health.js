const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const html = fs.readFileSync(path.resolve(__dirname, "../public/operator-dashboard.html"), "utf8");
const start = html.indexOf("function healthRow(");
const end = html.indexOf("async function refreshHealth(", start);
assert(start >= 0 && end > start, "WhatsApp health renderer not found");

const context = vm.createContext({
    escapeHtml: value => String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;")
});
vm.runInContext(`${html.slice(start, end)}; this.communicationHealthRows = communicationHealthRows;`, context);

function whatsappRow(input) {
    return context.communicationHealthRows({
        email_configured: true,
        whatsapp_pending: 0,
        whatsapp_failed: 0,
        ...input
    })[1];
}

const emailActive = context.communicationHealthRows({ email_configured: true })[0];
assert.match(emailActive, />Aktif<\/span>/);
assert.doesNotMatch(emailActive, /Configured/);

const emailFailed = context.communicationHealthRows({ email_configured: true, email_failed: 1 })[0];
assert.match(emailFailed, />Periksa<\/span>/);

const gateway = whatsappRow({ whatsapp_mode: "gateway", whatsapp_configured: true });
assert.match(gateway, /mode Innersync Service/);
assert.match(gateway, />Aktif<\/span>/);
assert.doesNotMatch(gateway, />Manual<\/span>/);
assert.match(gateway, /health-status ok/);

const legacy = whatsappRow({ whatsapp_mode: "api", whatsapp_configured: true });
assert.match(legacy, /mode Legacy API/);
assert.match(legacy, />Aktif<\/span>/);

const manual = whatsappRow({ whatsapp_mode: "manual", whatsapp_configured: false });
assert.match(manual, /mode Manual/);
assert.match(manual, />Manual<\/span>/);
assert.match(manual, /health-status warn/);

const failed = whatsappRow({ whatsapp_mode: "gateway", whatsapp_configured: true, whatsapp_failed: 2 });
assert.match(failed, />Periksa<\/span>/);
assert.match(failed, /health-status error/);

console.log("PASS WhatsApp health distinguishes Innersync Service, Legacy API, Manual, and failed delivery");
