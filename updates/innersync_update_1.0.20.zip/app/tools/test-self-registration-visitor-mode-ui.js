const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");

async function main() {
    const publicRoot = path.resolve(__dirname, "../public");
    const output = path.join(os.tmpdir(), "innersync-visitor-mode-qa");
    const jsQrSource = await fs.readFile(path.resolve(__dirname, "../node_modules/jsqr/dist/jsQR.js"), "utf8");
    const approvalCountdownSource = await fs.readFile(path.join(publicRoot, "js/approval-countdown.js"), "utf8");
    const browser = await chromium.launch({ channel: "chrome", headless: true });
    const errors = [];

    async function openPage(viewport) {
        const context = await browser.newContext({ viewport });
        const page = await context.newPage();
        page.on("pageerror", error => errors.push(error.message));
        await page.route("**/*", async route => {
            const url = new URL(route.request().url());
            const json = value => route.fulfill({ json: { success: true, ...value } });
            if (url.hostname !== "innersync.test") return route.abort();
            if (url.pathname === "/vendor/jsqr/jsQR.js") {
                return route.fulfill({ contentType: "text/javascript", body: jsQrSource });
            }
            if (url.pathname === "/js/approval-countdown.js") {
                return route.fulfill({ contentType: "text/javascript", body: approvalCountdownSource });
            }
            if (url.pathname === "/api/public/self-registration/options") {
                return json({ data: { hosts: [], permission_groups: [], settings: {} } });
            }
            if (url.pathname.includes("operator-presence")) {
                return route.fulfill({
                    contentType: "text/event-stream",
                    body: "event: presence\ndata: {\"online\":0}\n\n"
                });
            }
            if (url.pathname.startsWith("/api/")) return json({ data: [] });

            const filename = path.resolve(publicRoot, `.${url.pathname}`);
            if (!filename.startsWith(publicRoot + path.sep)) return route.abort();
            try {
                const contentType = filename.endsWith(".html")
                    ? "text/html"
                    : filename.endsWith(".js")
                        ? "text/javascript"
                        : "image/png";
                return route.fulfill({ body: await fs.readFile(filename), contentType });
            } catch {
                return route.fulfill({ status: 404, body: "" });
            }
        });
        await page.goto("http://innersync.test/self-registration.html", { waitUntil: "load" });
        return { page, context };
    }

    try {
        await fs.mkdir(output, { recursive: true });
        for (const testCase of [
            { name: "desktop", viewport: { width: 1440, height: 1000 } },
            { name: "mobile", viewport: { width: 390, height: 844 } }
        ]) {
            const { page, context } = await openPage(testCase.viewport);
            const choice = page.locator("#visitorModeChoice");
            const lookup = page.locator("#returningLookupPanel");

            assert.equal(await choice.getAttribute("aria-hidden"), "false");
            assert.equal(await lookup.getAttribute("aria-hidden"), "true");
            assert.equal(await choice.evaluate(element => getComputedStyle(element).visibility), "visible");
            assert.notEqual(await choice.evaluate(element => getComputedStyle(element).transitionDuration), "0s");

            await page.locator("#returningVisitorModeBtn").click();
            await page.waitForFunction(() => getComputedStyle(document.getElementById("visitorModeChoice")).visibility === "hidden");
            await page.waitForTimeout(120);
            assert.equal(await page.locator("#entryPanel").evaluate(element => element.classList.contains("returning-mode")), true);
            assert.equal(await choice.getAttribute("aria-hidden"), "true");
            assert.equal(await lookup.getAttribute("aria-hidden"), "false");
            assert.equal(await choice.getAttribute("inert"), "");
            assert.equal(await lookup.getAttribute("inert"), null);
            assert.equal(await choice.evaluate(element => getComputedStyle(element).visibility), "hidden");
            assert.equal(await lookup.evaluate(element => getComputedStyle(element).visibility), "visible");
            assert.equal(await page.evaluate(() => document.activeElement?.id), "returning_identity_number");
            const modeHeights = await page.evaluate(() => ({
                stage: document.querySelector(".entry-mode-stage").getBoundingClientRect().height,
                lookup: document.getElementById("returningLookupPanel").getBoundingClientRect().height,
                inline: document.querySelector(".entry-mode-stage").style.height
            }));
            assert(
                Math.abs(modeHeights.stage - modeHeights.lookup) <= 2,
                `Mode stage must collapse to lookup height (${testCase.name}: ${JSON.stringify(modeHeights)})`
            );
            assert(
                modeHeights.lookup < 250,
                `Lookup view should not retain the option-card height (${testCase.name}: ${JSON.stringify(modeHeights)})`
            );

            const loadBox = await page.locator("#loadReturningBtn").boundingBox();
            const backBox = await page.locator("#backToVisitorChoiceBtn").boundingBox();
            assert(loadBox && backBox, "Lookup action buttons must be visible");
            assert(backBox.x > loadBox.x, "Back must sit beside and after Load Data");
            assert(
                Math.abs(backBox.y - loadBox.y) <= 3,
                `Lookup buttons must share one row (${testCase.name}: load=${JSON.stringify(loadBox)}, back=${JSON.stringify(backBox)})`
            );
            assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth), true);
            await page.screenshot({ path: path.join(output, `${testCase.name}-returning.png`), fullPage: true });

            await page.locator("#backToVisitorChoiceBtn").click();
            await page.waitForFunction(() => getComputedStyle(document.getElementById("returningLookupPanel")).visibility === "hidden");
            await page.waitForTimeout(120);
            assert.equal(await page.locator("#entryPanel").evaluate(element => element.classList.contains("returning-mode")), false);
            assert.equal(await choice.getAttribute("aria-hidden"), "false");
            assert.equal(await lookup.getAttribute("aria-hidden"), "true");
            assert.equal(await page.evaluate(() => document.activeElement?.id), "returningVisitorModeBtn");
            assert.equal(await page.locator("#returning_identity_number").inputValue(), "");
            await page.locator("#newVisitorModeBtn").click();
            assert.equal(await page.locator("#selfForm").isVisible(), true);
            assert.equal(await page.locator("#entryPanel").isVisible(), false);
            await context.close();
        }
        assert.deepEqual(errors, [], `Browser errors: ${errors.join(" | ")}`);
        console.log(`PASS visitor mode transition on desktop/mobile; screenshots: ${output}`);
    } finally {
        await browser.close();
    }
}

main().catch(error => {
    console.error(error);
    process.exitCode = 1;
});
