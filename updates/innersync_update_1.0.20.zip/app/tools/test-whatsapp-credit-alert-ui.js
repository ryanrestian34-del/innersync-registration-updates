const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");

async function run() {
    const browser = await chromium.launch({ channel:"chrome", headless:true });
    const output = path.join(os.tmpdir(), "innersync-credit-alert-qa");
    const script = await fs.readFile(path.resolve(__dirname, "../public/js/whatsapp-credit-alerts.js"), "utf8");
    await fs.mkdir(output, { recursive:true });

    try {
        for (const testCase of [
            { name:"desktop", viewport:{ width:1280, height:800 } },
            { name:"mobile", viewport:{ width:390, height:844 } }
        ]) {
            const context = await browser.newContext({ viewport:testCase.viewport });
            const page = await context.newPage();
            let acknowledged = false;
            const pageErrors = [];
            page.on("pageerror", error => pageErrors.push(error.message));
            await page.route("**/api/whatsapp-credit-alerts/**", async route => {
                if (route.request().method() === "POST") {
                    acknowledged = true;
                    return route.fulfill({ json:{ success:true, message:"Acknowledged" } });
                }
                return route.fulfill({ json:{
                    success:true,
                    gateway_online:true,
                    data:acknowledged ? [] : [{
                        notification_id:77,
                        status:"CRITICAL",
                        title:"Kredit WhatsApp tersisa 25",
                        message:"Saldo telah melewati batas 25 kredit. Lakukan top-up sebelum layanan WhatsApp berhenti.",
                        created_time:"2026-10-11T10:00:00.000Z",
                        detail:{ threshold:25, alert_balance:25, current_balance:25, severity:"CRITICAL" }
                    }]
                } });
            });
            await page.setContent(`<!doctype html><html><head><base href="http://innersync.test/"></head><body><main><h1>Operator Dashboard</h1></main><script>${script.replace(/<\/script/gi, "<\\/script")}</script></body></html>`);
            const overlay = page.locator("#whatsappCreditAlertOverlay");
            await overlay.waitFor({ state:"visible" });
            assert.equal(await page.locator("#whatsappCreditAlertBalance").textContent(), "25");
            assert.match(await page.locator("#whatsappCreditAlertMessage").textContent(), /melewati batas 25/);
            await page.keyboard.press("Escape");
            assert.equal(await overlay.isVisible(), true, "Escape must not dismiss an unacknowledged alert");
            assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth), true);
            await page.screenshot({ path:path.join(output, `${testCase.name}.png`), fullPage:true });
            await page.locator("#whatsappCreditAlertAcknowledge").click();
            await overlay.waitFor({ state:"hidden" });
            assert.equal(acknowledged, true);
            assert.deepEqual(pageErrors, []);
            await context.close();
        }

        {
            const context = await browser.newContext({ viewport:{ width:1440, height:900 } });
            const page = await context.newPage();
            const pageErrors = [];
            page.on("pageerror", error => pageErrors.push(error.message));
            await page.route("**/*", async route => {
                const url = new URL(route.request().url());
                if (url.hostname !== "gateway.test") return route.abort();
                if (url.pathname === "/admin") {
                    return route.fulfill({
                        contentType:"text/html",
                        body:await fs.readFile(path.resolve(__dirname, "../central-gateway/public/admin.html"))
                    });
                }
                if (url.pathname === "/admin/api/session") {
                    return route.fulfill({ json:{ success:true, data:{ username:"admin", display_name:"Gateway Admin", role:"SUPERADMIN" } } });
                }
                if (url.pathname === "/admin/api/overview") {
                    return route.fulfill({ json:{ success:true, data:{
                        customers:{ total:2 }, channels:{ active:1 }, messages:{ today:10, failed:0 }, orders:{ pending:0 }
                    } } });
                }
                if (url.pathname === "/admin/api/channels") return route.fulfill({ json:{ success:true, data:[] } });
                if (url.pathname === "/admin/api/shared-channel") return route.fulfill({ json:{ success:true, data:null } });
                if (url.pathname === "/admin/api/credit-alert-settings") {
                    return route.fulfill({ json:{ success:true, data:{ enabled:true, thresholds:[500,200,100,50,25,10] } } });
                }
                if (url.pathname === "/admin/api/credit-alerts") {
                    return route.fulfill({ json:{ success:true, data:[{
                        alert_id:1,
                        created_at:"2026-10-11T10:00:00.000Z",
                        customer:"PT Innersync Indonesia",
                        license_id:"LIC-001",
                        threshold:25,
                        balance:25,
                        current_balance:24,
                        severity:"CRITICAL",
                        status:"ACKNOWLEDGED",
                        acknowledged_by:"operator01",
                        acknowledged_at:"2026-10-11T10:05:00.000Z",
                        acknowledged_ip:"103.147.33.10",
                        acknowledged_machine_id:"AABBCCDD"
                    }] } });
                }
                return route.fulfill({ status:404, json:{ success:false, message:"Not mocked" } });
            });
            await page.goto("http://gateway.test/admin", { waitUntil:"load" });
            await page.locator('[data-section="credit-alerts"]').click();
            await page.locator("#creditAlertsTable", { hasText:"operator01" }).waitFor();
            assert.equal(await page.locator("#creditAlertThresholds").inputValue(), "500, 200, 100, 50, 25, 10");
            assert.equal(await page.locator("#creditAlertsTable").getByText("ACKNOWLEDGED", { exact:true }).count(), 1);
            assert.deepEqual(pageErrors, []);
            await page.screenshot({ path:path.join(output, "gateway-admin.png"), fullPage:true });
            await context.close();
        }
        console.log(`whatsapp-credit-alert-ui: PASS; screenshots: ${output}`);
    } finally {
        await browser.close();
    }
}

run().catch(error => {
    console.error(error);
    process.exit(1);
});
