const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { getOrCreateInstallationIdentity, signInstallationProof } = require("./installationIdentity");

const ROOT_DIR = path.join(__dirname, "..");
const PRODUCT_ID = "INNERSYNC_REGISTRATION_PORTAL";
const CERTIFICATE_TYPE = "CENTRAL_ACTIVATION";
const CERTIFICATE_FILE = process.env.INNERSYNC_CENTRAL_CERTIFICATE_FILE
    || path.join(ROOT_DIR, "config", "central_activation.dat");
const PUBLIC_KEY_FILE = process.env.INNERSYNC_LICENSE_PUBLIC_KEY_FILE
    || path.join(__dirname, "public_key.pem");

function normalizeToken(value) {
    return String(value || "").replace(/\s+/g, "").trim();
}

function parseCertificate(token) {
    const normalized = normalizeToken(token);
    const parts = normalized.split(".");
    if (parts.length !== 2) throw new Error("Format sertifikat aktivasi tidak valid.");
    return {
        token:normalized,
        payloadB64:parts[0],
        payload:JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8")),
        signature:Buffer.from(parts[1], "base64url")
    };
}

function readCertificateToken() {
    try { return normalizeToken(fs.readFileSync(CERTIFICATE_FILE, "utf8")); } catch { return ""; }
}

function publicKeyHash(value) {
    const key = crypto.createPublicKey(String(value || ""));
    return crypto.createHash("sha256")
        .update(key.export({ type:"spki", format:"der" }))
        .digest("hex");
}

function verifyCertificate(token = readCertificateToken()) {
    if (!token) return { valid:false, reason:"CENTRAL_CERTIFICATE_NOT_FOUND", message:"Aktivasi pusat belum tersedia." };
    try {
        const parsed = parseCertificate(token);
        const publicKey = fs.readFileSync(PUBLIC_KEY_FILE, "utf8");
        if (!crypto.verify(null, Buffer.from(parsed.payloadB64), publicKey, parsed.signature)) {
            return { valid:false, reason:"INVALID_SIGNATURE", message:"Signature sertifikat aktivasi pusat tidak valid." };
        }
        const payload = parsed.payload || {};
        if (payload.product !== PRODUCT_ID || payload.type !== CERTIFICATE_TYPE ||
            !payload.license_id || !payload.installation_id) {
            return { valid:false, reason:"INVALID_CENTRAL_CERTIFICATE", message:"Isi sertifikat aktivasi pusat tidak valid.", payload };
        }
        const identity = getOrCreateInstallationIdentity();
        if (String(payload.installation_id) !== identity.installation_id ||
            String(payload.installation_public_key_hash) !== publicKeyHash(identity.public_key)) {
            return { valid:false, reason:"INSTALLATION_MISMATCH", message:"Sertifikat aktivasi bukan untuk instalasi ini.", payload };
        }
        if (payload.expires_at) {
            const expiry = new Date(payload.expires_at);
            if (Number.isNaN(expiry.getTime()) || Date.now() > expiry.getTime()) {
                return { valid:false, reason:"LICENSE_EXPIRED", message:"License sudah expired.", payload };
            }
        }
        const graceUntil = new Date(payload.grace_until || 0);
        if (Number.isNaN(graceUntil.getTime()) || Date.now() > graceUntil.getTime()) {
            return { valid:false, reason:"CENTRAL_REFRESH_REQUIRED", message:"Sertifikat aktivasi perlu terhubung kembali ke License Service.", payload };
        }
        const refreshAfter = new Date(payload.refresh_after || 0);
        return {
            valid:true,
            reason:"VALID",
            message:"License pusat valid.",
            payload,
            token:parsed.token,
            refresh_due:Number.isNaN(refreshAfter.getTime()) || Date.now() >= refreshAfter.getTime(),
            grace_days_remaining:Math.max(0, Math.ceil((graceUntil.getTime() - Date.now()) / 86400000))
        };
    } catch (error) {
        return { valid:false, reason:"INVALID_CENTRAL_CERTIFICATE", message:error.message };
    }
}

function saveCertificate(token) {
    const validation = verifyCertificate(token);
    if (!validation.valid) return validation;
    fs.mkdirSync(path.dirname(CERTIFICATE_FILE), { recursive:true });
    const temporary = `${CERTIFICATE_FILE}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(temporary, validation.token, { encoding:"utf8", mode:0o600 });
    fs.renameSync(temporary, CERTIFICATE_FILE);
    try { fs.chmodSync(CERTIFICATE_FILE, 0o600); } catch { /* Windows ACL is managed by the OS. */ }
    return validation;
}

function createRefreshProof(token = readCertificateToken()) {
    const timestamp = Date.now();
    const nonce = crypto.randomBytes(24).toString("base64url");
    const message = `${normalizeToken(token)}.${timestamp}.${nonce}`;
    return { timestamp, nonce, signature:signInstallationProof(message) };
}

module.exports = {
    PRODUCT_ID,
    CERTIFICATE_TYPE,
    CERTIFICATE_FILE,
    readCertificateToken,
    verifyCertificate,
    saveCertificate,
    createRefreshProof
};
