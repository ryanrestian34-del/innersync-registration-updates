const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const ROOT_DIR = path.join(__dirname, "..");
const IDENTITY_FILE = process.env.INNERSYNC_INSTALLATION_IDENTITY_FILE
    || path.join(ROOT_DIR, "config", "installation_identity.json");

let cachedIdentity = null;

function normalizeIdentity(value) {
    const identity = value && typeof value === "object" ? value : {};
    const installationId = String(identity.installation_id || "").trim().toLowerCase();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(installationId)) {
        throw new Error("Installation ID tersimpan tidak valid.");
    }
    const privateKey = crypto.createPrivateKey(String(identity.private_key || ""));
    if (privateKey.asymmetricKeyType !== "ed25519") {
        throw new Error("Installation private key tersimpan bukan Ed25519.");
    }
    const publicKey = crypto.createPublicKey(String(identity.public_key || ""));
    if (publicKey.asymmetricKeyType !== "ed25519") {
        throw new Error("Installation public key tersimpan bukan Ed25519.");
    }
    const derivedPublic = crypto.createPublicKey(privateKey).export({ type:"spki", format:"pem" });
    const storedPublic = publicKey.export({ type:"spki", format:"pem" });
    if (derivedPublic !== storedPublic) throw new Error("Pasangan installation key tidak sesuai.");
    return {
        installation_id:installationId,
        public_key:storedPublic,
        private_key:privateKey.export({ type:"pkcs8", format:"pem" }),
        created_at:identity.created_at || new Date().toISOString()
    };
}

function writeAtomic(filePath, content) {
    fs.mkdirSync(path.dirname(filePath), { recursive:true });
    const temporary = `${filePath}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(temporary, content, { encoding:"utf8", mode:0o600 });
    fs.renameSync(temporary, filePath);
    try { fs.chmodSync(filePath, 0o600); } catch { /* Windows ACL is managed by the OS. */ }
}

function createIdentity() {
    const keys = crypto.generateKeyPairSync("ed25519");
    return normalizeIdentity({
        installation_id:crypto.randomUUID(),
        public_key:keys.publicKey.export({ type:"spki", format:"pem" }),
        private_key:keys.privateKey.export({ type:"pkcs8", format:"pem" }),
        created_at:new Date().toISOString()
    });
}

function getOrCreateInstallationIdentity() {
    if (cachedIdentity) return cachedIdentity;
    try {
        cachedIdentity = normalizeIdentity(JSON.parse(fs.readFileSync(IDENTITY_FILE, "utf8")));
    } catch (error) {
        if (error.code !== "ENOENT") throw error;
        cachedIdentity = createIdentity();
        writeAtomic(IDENTITY_FILE, JSON.stringify(cachedIdentity, null, 2));
    }
    return cachedIdentity;
}

function signInstallationProof(message) {
    const identity = getOrCreateInstallationIdentity();
    return crypto.sign(null, Buffer.from(String(message || "")), identity.private_key).toString("base64url");
}

module.exports = {
    IDENTITY_FILE,
    getOrCreateInstallationIdentity,
    signInstallationProof
};
