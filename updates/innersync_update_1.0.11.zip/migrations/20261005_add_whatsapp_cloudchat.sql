ALTER TABLE whatsapp_settings
ADD COLUMN IF NOT EXISTS base_url TEXT;
