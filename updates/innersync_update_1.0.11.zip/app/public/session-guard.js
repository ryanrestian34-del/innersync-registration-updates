(function () {
    const LOGIN_MARKER = "innersync_browser_session_active";
    const PUBLIC_PATHS = new Set([
        "/login.html",
        "/license.html",
        "/forgot-password.html",
        "/register.html",
        "/qr-info.html",
        "/login-design-options.html"
    ]);

    if (PUBLIC_PATHS.has(window.location.pathname)) return;

    let idleEnabled = false;
    let idleMs = 0;
    let idleTimer = null;
    let lastTouchAt = 0;
    let redirecting = false;

    async function sendOperatorPresenceHeartbeat() {
        if (redirecting || document.hidden) return;
        try {
            const response = await fetch("/api/operator-presence/heartbeat", {
                method: "POST",
                cache: "no-store",
                keepalive: true
            });
            if (response.status === 401) goLogin("session");
        } catch {}
    }

    function goLogin(reason) {
        if (redirecting) return;
        redirecting = true;
        sessionStorage.removeItem(LOGIN_MARKER);
        const query = reason ? `?reason=${encodeURIComponent(reason)}` : "";
        window.location.replace(`/login.html${query}`);
    }

    async function logoutAndGoLogin(reason) {
        try {
            await fetch("/logout", { method: "POST", keepalive: true });
        } catch {}
        goLogin(reason);
    }

    async function checkSession() {
        try {
            const response = await fetch("/current-user", { cache: "no-store" });
            if (response.status === 401) {
                goLogin("session");
                return false;
            }
            return true;
        } catch {
            return true;
        }
    }

    async function touchSession() {
        const now = Date.now();
        if (now - lastTouchAt < 60000) return;
        lastTouchAt = now;

        try {
            const response = await fetch("/api/session-touch", { method: "POST", cache: "no-store" });
            if (response.status === 401) goLogin("session");
        } catch {}
    }

    function armIdleTimer() {
        if (idleTimer) clearTimeout(idleTimer);
        if (!idleEnabled || idleMs <= 0) return;

        idleTimer = setTimeout(() => {
            logoutAndGoLogin("idle");
        }, idleMs);
    }

    function handleActivity() {
        if (redirecting) return;
        armIdleTimer();
        touchSession();
    }

    async function loadSessionSettings() {
        try {
            const response = await fetch("/api/session-settings", { cache: "no-store" });
            if (response.status === 401) {
                goLogin("session");
                return;
            }

            const result = await response.json();
            const data = result.data || {};
            idleEnabled = data.idle_logout_enabled === true;
            idleMs = Math.max(Number(data.idle_logout_minutes || 30), 1) * 60 * 1000;
            armIdleTimer();
        } catch {}
    }

    if (sessionStorage.getItem(LOGIN_MARKER) !== "1") {
        logoutAndGoLogin("browser");
        return;
    }

    ["click", "keydown", "mousemove", "scroll", "touchstart"].forEach(eventName => {
        window.addEventListener(eventName, handleActivity, { passive: true });
    });

    window.addEventListener("focus", () => {
        checkSession();
        loadSessionSettings();
        sendOperatorPresenceHeartbeat();
    });

    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) {
            checkSession();
            loadSessionSettings();
            sendOperatorPresenceHeartbeat();
        }
    });

    checkSession();
    loadSessionSettings();
    sendOperatorPresenceHeartbeat();
    setInterval(checkSession, 3000);
    setInterval(loadSessionSettings, 60000);
    setInterval(sendOperatorPresenceHeartbeat, 30000);
})();
