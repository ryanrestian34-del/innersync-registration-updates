(function () {
    let offset = 0;
    function sync(serverTime) {
        const time = Date.parse(serverTime);
        if (Number.isFinite(time)) offset = time - Date.now();
    }
    function zoneLabel(timeZone) {
        if (timeZone === "Asia/Makassar") return "WITA";
        if (timeZone === "Asia/Jayapura") return "WIT";
        return timeZone === "Asia/Jakarta" ? "WIB" : timeZone || "";
    }
    function formatStart(value, timeZone) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return "-";
        try {
            const text = date.toLocaleString("id-ID", {
                timeZone: timeZone || "Asia/Jakarta",
                dateStyle: "medium",
                timeStyle: "short"
            });
            return `${text} ${zoneLabel(timeZone || "Asia/Jakarta")}`.trim();
        } catch {
            return date.toLocaleString("id-ID");
        }
    }
    function timeZoneParts(value, timeZone) {
        const parts = new Intl.DateTimeFormat("en-CA", {
            timeZone,
            year:"numeric", month:"2-digit", day:"2-digit",
            hour:"2-digit", minute:"2-digit", second:"2-digit",
            hourCycle:"h23"
        }).formatToParts(new Date(value));
        return Object.fromEntries(parts.filter(part => part.type !== "literal").map(part => [part.type, Number(part.value)]));
    }
    function zonedToUtc(parts, timeZone) {
        const target = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour || 0, parts.minute || 0, parts.second || 0);
        let timestamp = target;
        for (let attempt = 0; attempt < 4; attempt += 1) {
            const actual = timeZoneParts(timestamp, timeZone);
            const actualUtc = Date.UTC(actual.year, actual.month - 1, actual.day, actual.hour, actual.minute, actual.second);
            const adjustment = target - actualUtc;
            timestamp += adjustment;
            if (!adjustment) break;
        }
        return timestamp;
    }
    function shiftDate(parts, amount) {
        const date = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + amount));
        return { year:date.getUTCFullYear(), month:date.getUTCMonth() + 1, day:date.getUTCDate() };
    }
    function dateKey(parts) {
        return `${parts.year}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`;
    }
    function isoWeekday(parts) {
        return new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay() || 7;
    }
    function scheduleOptions(options) {
        const days = new Set((Array.isArray(options.operationalDays) ? options.operationalDays : String(options.operationalDays || "").split(",")).map(Number).filter(day => day >= 1 && day <= 7));
        let holidays = options.holidayDates || {};
        if (typeof holidays === "string") {
            try { holidays = JSON.parse(holidays); } catch { holidays = {}; }
        }
        return {
            enabled: Number(options.timeoutMinutes) > 0 && days.size > 0 && /^\d{2}:\d{2}$/.test(options.operationalStart || "") && /^\d{2}:\d{2}$/.test(options.operationalEnd || ""),
            timeZone: options.timeZone || "Asia/Jakarta",
            days,
            closed: new Set(holidays.closed || []),
            open: new Set(holidays.open || []),
            opening: options.operationalStart,
            closing: options.operationalEnd,
            timeoutSeconds: Math.max(1, Number(options.timeoutMinutes) || 1) * 60
        };
    }
    function isOperationalDate(parts, schedule) {
        const key = dateKey(parts);
        if (schedule.open.has(key)) return true;
        if (schedule.closed.has(key)) return false;
        return schedule.days.has(isoWeekday(parts));
    }
    function timeForDate(parts, value, schedule) {
        const [hour, minute] = value.split(":").map(Number);
        return zonedToUtc({ ...parts, hour, minute, second:0 }, schedule.timeZone);
    }
    function operationalElapsedSeconds(start, target, schedule) {
        if (target <= start) return 0;
        let cursor = start;
        let elapsed = 0;
        for (let attempt = 0; attempt < 3700 && cursor < target; attempt += 1) {
            const parts = timeZoneParts(cursor, schedule.timeZone);
            if (isOperationalDate(parts, schedule)) {
                const opening = timeForDate(parts, schedule.opening, schedule);
                const closing = timeForDate(parts, schedule.closing, schedule);
                const segmentStart = Math.max(cursor, opening);
                const segmentEnd = Math.min(target, closing);
                if (segmentEnd > segmentStart) elapsed += (segmentEnd - segmentStart) / 1000;
            }
            const next = shiftDate(parts, 1);
            cursor = zonedToUtc({ ...next, hour:0, minute:0, second:0 }, schedule.timeZone);
        }
        return elapsed;
    }
    function nextOperationalOpening(now, schedule) {
        let parts = timeZoneParts(now, schedule.timeZone);
        for (let attempt = 0; attempt < 3700; attempt += 1) {
            if (isOperationalDate(parts, schedule)) {
                const opening = timeForDate(parts, schedule.opening, schedule);
                const closing = timeForDate(parts, schedule.closing, schedule);
                if (now < opening) return opening;
                if (now < closing) return now;
            }
            parts = shiftDate(parts, 1);
            now = zonedToUtc({ ...parts, hour:0, minute:0, second:0 }, schedule.timeZone);
        }
        return NaN;
    }
    function isOperationalNow(now, schedule) {
        const parts = timeZoneParts(now, schedule.timeZone);
        return isOperationalDate(parts, schedule)
            && now >= timeForDate(parts, schedule.opening, schedule)
            && now < timeForDate(parts, schedule.closing, schedule);
    }
    function durationText(seconds) {
        const safe = Math.max(0, Math.ceil(seconds));
        const hours = Math.floor(safe / 3600);
        const minutes = Math.floor(safe % 3600 / 60);
        const rest = safe % 60;
        return `${hours ? String(hours).padStart(2, "0") + ":" : ""}${String(minutes).padStart(2, "0")}:${String(rest).padStart(2, "0")}`;
    }
    function mount(element, deadline, onExpire, options = {}) {
        const end = Date.parse(deadline);
        const start = Date.parse(options.startAt);
        const schedule = scheduleOptions(options);
        let fired = false;
        let active = true;
        let timer;
        element.hidden = !Number.isFinite(end);
        if (!Number.isFinite(end)) return () => {};
        function tick() {
            const now = Date.now() + offset;
            if (Number.isFinite(start) && now < start) {
                element.textContent = `Countdown mulai ${formatStart(start, options.timeZone)}`;
                element.dataset.urgent = "false";
                element.dataset.scheduled = "true";
                return;
            }
            const seconds = schedule.enabled && Number.isFinite(start)
                ? Math.max(0, Math.min(schedule.timeoutSeconds - operationalElapsedSeconds(start, Math.min(now, end), schedule), (end - now) / 1000))
                : Math.max(0, Math.ceil((end - now) / 1000));
            const paused = schedule.enabled && now < end && !isOperationalNow(now, schedule);
            const resumeAt = paused ? nextOperationalOpening(now, schedule) : NaN;
            element.textContent = paused && Number.isFinite(resumeAt) && resumeAt < end
                ? `Countdown dijeda, lanjut ${formatStart(resumeAt, schedule.timeZone)} | Sisa waktu ${durationText(seconds)}`
                : `Sisa waktu ${durationText(seconds)}`;
            element.dataset.urgent = seconds <= 300 ? "true" : "false";
            element.dataset.scheduled = paused ? "true" : "false";
            if ((now >= end || !seconds) && !fired) {
                fired = true;
                clearInterval(timer);
                queueMicrotask(() => { if (active) onExpire?.(); });
            }
        }
        timer = setInterval(tick, 1000);
        tick();
        return () => { active = false; clearInterval(timer); };
    }
    window.ApprovalCountdown = { sync, mount };
}());
