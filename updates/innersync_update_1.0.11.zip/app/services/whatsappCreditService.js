const crypto = require("crypto");
const pool = require("../database/db");
const { getMachineFingerprint, getStoredLicenseStatus, verifyWhatsappCreditTopupToken } = require("../license/licenseManager");

const CREDIT_PACKAGES = [100, 500, 1000, 5000];
let schemaPromise = null;

function normalizeServiceMode(value) {
    return String(value || "CUSTOMER_PROVIDER").trim().toUpperCase() === "INNERSYNC_SERVICE"
        ? "INNERSYNC_SERVICE"
        : "CUSTOMER_PROVIDER";
}

function cleanTransactionKey(value) {
    const normalized = String(value || "").trim();
    if (!normalized) throw new Error("Transaction key WhatsApp wajib tersedia.");
    return normalized.slice(0, 180);
}

async function ensureWhatsappCreditSchema() {
    if (!schemaPromise) {
        schemaPromise = (async () => {
            await pool.query(`
                CREATE TABLE IF NOT EXISTS whatsapp_credit_wallet (
                    wallet_id INTEGER PRIMARY KEY DEFAULT 1,
                    balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
                    lifetime_topup INTEGER NOT NULL DEFAULT 0 CHECK (lifetime_topup >= 0),
                    lifetime_used INTEGER NOT NULL DEFAULT 0 CHECK (lifetime_used >= 0),
                    low_balance_threshold INTEGER NOT NULL DEFAULT 50 CHECK (low_balance_threshold >= 0),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
            `);
            await pool.query(`
                CREATE TABLE IF NOT EXISTS whatsapp_credit_orders (
                    order_id VARCHAR(100) PRIMARY KEY,
                    license_id VARCHAR(160),
                    machine_id VARCHAR(128) NOT NULL,
                    requested_credits INTEGER NOT NULL CHECK (requested_credits > 0),
                    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
                    created_by VARCHAR(100),
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    activated_at TIMESTAMP
                )
            `);
            await pool.query(`
                CREATE TABLE IF NOT EXISTS whatsapp_credit_transactions (
                    transaction_id BIGSERIAL PRIMARY KEY,
                    transaction_key VARCHAR(180) UNIQUE NOT NULL,
                    transaction_type VARCHAR(20) NOT NULL,
                    status VARCHAR(20) NOT NULL,
                    amount INTEGER NOT NULL,
                    balance_after INTEGER,
                    order_id VARCHAR(100),
                    reference_type VARCHAR(60),
                    reference_id VARCHAR(160),
                    target VARCHAR(100),
                    description TEXT,
                    provider_reference TEXT,
                    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                    created_by VARCHAR(100),
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
            `);
            await pool.query("CREATE INDEX IF NOT EXISTS idx_whatsapp_credit_transactions_created ON whatsapp_credit_transactions (created_at DESC)");
            await pool.query("CREATE INDEX IF NOT EXISTS idx_whatsapp_credit_orders_status ON whatsapp_credit_orders (status, created_at DESC)");
            await pool.query("INSERT INTO whatsapp_credit_wallet (wallet_id) VALUES (1) ON CONFLICT (wallet_id) DO NOTHING");
        })().catch(error => {
            schemaPromise = null;
            throw error;
        });
    }
    return schemaPromise;
}

async function getCreditSummary(limit = 20) {
    await ensureWhatsappCreditSchema();
    const safeLimit = Math.max(1, Math.min(Number(limit) || 20, 100));
    const [walletResult, transactionResult, orderResult] = await Promise.all([
        pool.query("SELECT * FROM whatsapp_credit_wallet WHERE wallet_id=1"),
        pool.query(`SELECT transaction_key, transaction_type, status, amount, balance_after,
                           order_id, reference_type, reference_id, target, description,
                           provider_reference, created_by, created_at
                    FROM whatsapp_credit_transactions ORDER BY transaction_id DESC LIMIT $1`, [safeLimit]),
        pool.query(`SELECT order_id, requested_credits, status, created_by, created_at, activated_at
                    FROM whatsapp_credit_orders ORDER BY created_at DESC LIMIT 10`)
    ]);
    const wallet = walletResult.rows[0] || {};
    return {
        balance: Number(wallet.balance || 0),
        lifetime_topup: Number(wallet.lifetime_topup || 0),
        lifetime_used: Number(wallet.lifetime_used || 0),
        low_balance_threshold: Number(wallet.low_balance_threshold || 50),
        low_balance: Number(wallet.balance || 0) <= Number(wallet.low_balance_threshold || 50),
        transactions: transactionResult.rows,
        orders: orderResult.rows,
        packages: CREDIT_PACKAGES
    };
}

async function reserveManagedCredit(transactionKey, metadata = {}) {
    await ensureWhatsappCreditSchema();
    const key = cleanTransactionKey(transactionKey);
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        const existingResult = await client.query("SELECT * FROM whatsapp_credit_transactions WHERE transaction_key=$1 FOR UPDATE", [key]);
        const existing = existingResult.rows[0];
        if (existing?.status === "DEBITED") {
            await client.query("COMMIT");
            return { shouldSend: false, alreadyCompleted: true, balance: Number(existing.balance_after || 0) };
        }
        if (existing?.status === "PENDING") {
            throw new Error("Transaksi WhatsApp ini sedang diproses. Tunggu hasil pengiriman sebelum mencoba lagi.");
        }
        const walletResult = await client.query("SELECT * FROM whatsapp_credit_wallet WHERE wallet_id=1 FOR UPDATE");
        const wallet = walletResult.rows[0];
        if (!wallet || Number(wallet.balance) < 1) {
            const error = new Error("Kredit WhatsApp Innersync habis. Silakan top-up melalui License Manager.");
            error.code = "WHATSAPP_CREDIT_EMPTY";
            throw error;
        }
        const newBalance = Number(wallet.balance) - 1;
        await client.query("UPDATE whatsapp_credit_wallet SET balance=$1, updated_at=NOW() WHERE wallet_id=1", [newBalance]);
        const values = [key, metadata.reference_type || null,
            metadata.reference_id == null ? null : String(metadata.reference_id), metadata.target || null,
            metadata.description || "Pengiriman WhatsApp Business API", JSON.stringify(metadata),
            metadata.created_by || "SYSTEM", newBalance];
        if (existing) {
            await client.query(`UPDATE whatsapp_credit_transactions
                SET status='PENDING', amount=-1, balance_after=$8, reference_type=$2,
                    reference_id=$3, target=$4, description=$5, metadata=$6::jsonb,
                    created_by=$7, provider_reference=NULL, updated_at=NOW()
                WHERE transaction_key=$1`, values);
        } else {
            await client.query(`INSERT INTO whatsapp_credit_transactions
                (transaction_key, transaction_type, status, amount, balance_after,
                 reference_type, reference_id, target, description, metadata, created_by)
                VALUES ($1, 'MESSAGE', 'PENDING', -1, $8, $2, $3, $4, $5, $6::jsonb, $7)`, values);
        }
        await client.query("COMMIT");
        return { shouldSend: true, alreadyCompleted: false, balance: newBalance };
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

async function commitManagedCredit(transactionKey, providerReference = null) {
    await ensureWhatsappCreditSchema();
    const key = cleanTransactionKey(transactionKey);
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        const rowResult = await client.query("SELECT status FROM whatsapp_credit_transactions WHERE transaction_key=$1 FOR UPDATE", [key]);
        if (rowResult.rows[0]?.status === "PENDING") {
            await client.query("UPDATE whatsapp_credit_transactions SET status='DEBITED', provider_reference=$2, updated_at=NOW() WHERE transaction_key=$1", [key, providerReference ? String(providerReference).slice(0, 4000) : null]);
            await client.query("UPDATE whatsapp_credit_wallet SET lifetime_used=lifetime_used+1, updated_at=NOW() WHERE wallet_id=1");
        }
        await client.query("COMMIT");
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

async function releaseManagedCredit(transactionKey, reason = "") {
    await ensureWhatsappCreditSchema();
    const key = cleanTransactionKey(transactionKey);
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        const rowResult = await client.query("SELECT status FROM whatsapp_credit_transactions WHERE transaction_key=$1 FOR UPDATE", [key]);
        if (rowResult.rows[0]?.status === "PENDING") {
            const walletResult = await client.query("UPDATE whatsapp_credit_wallet SET balance=balance+1, updated_at=NOW() WHERE wallet_id=1 RETURNING balance");
            await client.query(`UPDATE whatsapp_credit_transactions
                SET status='RELEASED', amount=0, balance_after=$2,
                    description=CASE WHEN $3='' THEN description ELSE description || ' - ' || $3 END,
                    updated_at=NOW() WHERE transaction_key=$1`,
                [key, Number(walletResult.rows[0]?.balance || 0), String(reason || "").slice(0, 500)]);
        }
        await client.query("COMMIT");
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

function providerReferenceFromResult(result) {
    return result?.messages?.[0]?.id || result?.response?.messages?.[0]?.id || result?.message_id || result?.id || null;
}

async function withManagedWhatsappCredit(settings, transactionKey, metadata, sendFn) {
    if (normalizeServiceMode(settings?.service_mode) !== "INNERSYNC_SERVICE") return sendFn();
    const reservation = await reserveManagedCredit(transactionKey, metadata);
    if (!reservation.shouldSend) {
        return { success: true, idempotent: true, provider: "INNERSYNC_WHATSAPP_SERVICE",
            response: { message: "Transaksi WhatsApp sebelumnya sudah berhasil." } };
    }
    try {
        const result = await sendFn();
        await commitManagedCredit(transactionKey, providerReferenceFromResult(result));
        return result;
    } catch (error) {
        if (error?.deliveryStatus === "UNCONFIRMED") {
            await commitManagedCredit(transactionKey, "UNCONFIRMED: " + error.message).catch(commitError => {
                console.error("WhatsApp credit commit failed:", commitError.message);
            });
        } else {
            await releaseManagedCredit(transactionKey, error.message).catch(releaseError => {
                console.error("WhatsApp credit release failed:", releaseError.message);
            });
        }
        throw error;
    }
}

function makeOrderId() {
    const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    return `WA-${date}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
}

async function createCreditOrder(requestedCredits, username = "SYSTEM") {
    await ensureWhatsappCreditSchema();
    const credits = Number(requestedCredits);
    if (!CREDIT_PACKAGES.includes(credits)) throw new Error(`Paket kredit harus salah satu dari: ${CREDIT_PACKAGES.join(", ")}.`);
    const machine = getMachineFingerprint();
    const license = getStoredLicenseStatus();
    const orderId = makeOrderId();
    await pool.query(`INSERT INTO whatsapp_credit_orders (order_id, license_id, machine_id, requested_credits, created_by)
                      VALUES ($1, $2, $3, $4, $5)`,
        [orderId, license.payload?.license_id || null, machine.machine_id, credits, username]);
    const message = ["Permintaan Top-up Kredit WhatsApp Innersync", "Order ID: " + orderId,
        "Jumlah: " + credits + " kredit", "Machine ID: " + machine.display_id,
        "License ID: " + (license.payload?.license_id || "-"),
        "Customer: " + (license.payload?.customer || username)].join("\n");
    const salesPhone = String(process.env.INNERSYNC_SALES_WHATSAPP || "").replace(/\D/g, "");
    return { order_id: orderId, requested_credits: credits, machine_id: machine.display_id,
        license_id: license.payload?.license_id || null, message,
        whatsapp_url: salesPhone ? "https://wa.me/" + salesPhone + "?text=" + encodeURIComponent(message) : null };
}

async function redeemCreditTopup(token, username = "SYSTEM") {
    await ensureWhatsappCreditSchema();
    const verification = verifyWhatsappCreditTopupToken(token);
    if (!verification.valid) {
        const error = new Error(verification.message || "Kode top-up tidak valid.");
        error.code = verification.reason || "INVALID_TOPUP";
        throw error;
    }
    const payload = verification.payload;
    const transactionKey = `TOPUP:${payload.topup_id}`;
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        const used = await client.query("SELECT transaction_id FROM whatsapp_credit_transactions WHERE transaction_key=$1 FOR UPDATE", [transactionKey]);
        if (used.rowCount) throw new Error("Kode top-up sudah pernah digunakan.");
        const walletResult = await client.query(`UPDATE whatsapp_credit_wallet
            SET balance=balance+$1, lifetime_topup=lifetime_topup+$1, updated_at=NOW()
            WHERE wallet_id=1 RETURNING balance`, [payload.credits]);
        const balance = Number(walletResult.rows[0]?.balance || 0);
        await client.query(`INSERT INTO whatsapp_credit_transactions
            (transaction_key, transaction_type, status, amount, balance_after, order_id,
             reference_type, reference_id, description, metadata, created_by)
            VALUES ($1, 'TOPUP', 'APPLIED', $2, $3, $4, 'TOPUP', $5,
                    'Top-up kredit WhatsApp', $6::jsonb, $7)`,
            [transactionKey, payload.credits, balance, payload.order_id || null, payload.topup_id, JSON.stringify(payload), username]);
        if (payload.order_id) {
            await client.query("UPDATE whatsapp_credit_orders SET status='ACTIVATED', activated_at=NOW() WHERE order_id=$1 AND machine_id=$2", [payload.order_id, verification.machine.machine_id]);
        }
        await client.query("COMMIT");
        return { credits: payload.credits, balance, order_id: payload.order_id || null };
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

module.exports = { CREDIT_PACKAGES, normalizeServiceMode, ensureWhatsappCreditSchema,
    getCreditSummary, withManagedWhatsappCredit, createCreditOrder, redeemCreditTopup };
