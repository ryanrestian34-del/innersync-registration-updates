const crypto = require("node:crypto");

function approvalsComplete(invitation) {
    const mode = invitation.approval_mode || "NO_APPROVAL";
    return (!["BM_ONLY", "BM_AND_HOST"].includes(mode) || invitation.bm_approval_status === "APPROVED")
        && (!["HOST_ONLY", "BM_AND_HOST"].includes(mode) || invitation.host_approval_status === "APPROVED");
}

function activationTiming(invitation) {
    return invitation.activation_timing === "ON_OPERATOR_CHECKIN" ? "ON_OPERATOR_CHECKIN" : "AFTER_APPROVAL";
}

function createSelfRegistrationWorkflow(pool, dependencies) {
    const systemRequest = { session: { user: { username: "SELF_REGISTRATION", full_name: "Self Registration" } }, ip: "127.0.0.1" };
    let running = false;
    let timer;

    async function ensureSchema() {
        await pool.query("ALTER TABLE self_registration_settings ADD COLUMN IF NOT EXISTS access_mode VARCHAR(20) NOT NULL DEFAULT 'OPERATOR'");
        await pool.query("ALTER TABLE self_registration_settings ADD COLUMN IF NOT EXISTS activation_timing VARCHAR(30) NOT NULL DEFAULT 'AFTER_APPROVAL'");
        await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS access_mode VARCHAR(20) NOT NULL DEFAULT 'OPERATOR'");
        await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS activation_timing VARCHAR(30) NOT NULL DEFAULT 'AFTER_APPROVAL'");
        await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS public_status_token TEXT");
        await pool.query(`CREATE TABLE IF NOT EXISTS self_registration_access_jobs (
            invitation_id INTEGER PRIMARY KEY REFERENCES visitor_invitations(invitation_id),
            visitor_id INTEGER REFERENCES visitor_registration(visitor_id) ON DELETE SET NULL,
            access_code VARCHAR(40) UNIQUE,
            qr_value TEXT,
            stages JSONB NOT NULL DEFAULT '[]'::jsonb,
            revoke_stages JSONB NOT NULL DEFAULT '[]'::jsonb,
            phase VARCHAR(20) NOT NULL DEFAULT 'PROVISION',
            error TEXT,
            email_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            email_error TEXT,
            whatsapp_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            whatsapp_error TEXT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )`);
        await pool.query("ALTER TABLE self_registration_access_jobs ADD COLUMN IF NOT EXISTS whatsapp_status VARCHAR(20) NOT NULL DEFAULT 'PENDING'");
        await pool.query("ALTER TABLE self_registration_access_jobs ADD COLUMN IF NOT EXISTS whatsapp_error TEXT");
        await pool.query(`CREATE TABLE IF NOT EXISTS visitor_invitation_members (
            member_id SERIAL PRIMARY KEY,
            invitation_id INTEGER NOT NULL REFERENCES visitor_invitations(invitation_id) ON DELETE CASCADE,
            member_name VARCHAR(180) NOT NULL,
            identity_number VARCHAR(120),
            identity_type VARCHAR(80),
            company_name VARCHAR(150),
            email_address VARCHAR(255),
            phone_number VARCHAR(50),
            visitor_photo VARCHAR(255),
            identity_photo VARCHAR(255),
            access_code VARCHAR(40),
            status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            created_at TIMESTAMP DEFAULT NOW(),
            modified_at TIMESTAMP
        )`);
        await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS visitor_id INTEGER");
        await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS qr_value TEXT");
        await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
        await pool.query("ALTER TABLE visitor_invitation_members ADD COLUMN IF NOT EXISTS phone_number VARCHAR(50)");
        await pool.query(`DO $$
            BEGIN
                IF EXISTS (
                    SELECT 1 FROM pg_constraint
                    WHERE conname='self_registration_access_jobs_visitor_id_fkey'
                      AND conrelid='self_registration_access_jobs'::regclass
                      AND confdeltype<>'n'
                ) THEN
                    ALTER TABLE self_registration_access_jobs
                        DROP CONSTRAINT self_registration_access_jobs_visitor_id_fkey;
                    ALTER TABLE self_registration_access_jobs
                        ADD CONSTRAINT self_registration_access_jobs_visitor_id_fkey
                        FOREIGN KEY (visitor_id) REFERENCES visitor_registration(visitor_id)
                        ON DELETE SET NULL;
                ELSIF NOT EXISTS (
                    SELECT 1 FROM pg_constraint
                    WHERE conname='self_registration_access_jobs_visitor_id_fkey'
                      AND conrelid='self_registration_access_jobs'::regclass
                ) THEN
                    ALTER TABLE self_registration_access_jobs
                        ADD CONSTRAINT self_registration_access_jobs_visitor_id_fkey
                        FOREIGN KEY (visitor_id) REFERENCES visitor_registration(visitor_id)
                        ON DELETE SET NULL;
                END IF;
            END $$`);
        await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS self_registration_access_qr_uq ON self_registration_access_jobs(qr_value)");
    }

    async function expireApprovals() {
        // The UPDATE is conditional so approval and expiry cannot both win.
        const expired = await pool.query(`UPDATE visitor_invitations SET status='APPROVAL_TIMEOUT', modified_time=NOW()
            WHERE status IN ('WAITING_BM_APPROVAL','WAITING_HOST_APPROVAL') AND approval_timeout_at <= NOW()
            RETURNING invitation_id, booking_code`);
        if (expired.rows.length) {
            await pool.query(`UPDATE visitor_approval_tokens SET status='EXPIRED'
                WHERE invitation_id=ANY($1::int[]) AND status='ACTIVE'`, [expired.rows.map(row => row.invitation_id)]);
            for (const row of expired.rows) await dependencies.notify(systemRequest, {
                channel: "SELF_REGISTRATION", event_type: "APPROVAL_TIMEOUT", status: "EXPIRED",
                title: "Self Registration: approval timeout", message: `${row.booking_code} kedaluwarsa. Visitor perlu membuat pengajuan baru.`
            });
        }
    }

    async function queueApproved() {
        await pool.query(`WITH ready AS (
            UPDATE visitor_invitations SET status='ACCESS_PENDING', modified_time=NOW()
            WHERE access_mode='AUTOMATIC' AND status='PENDING'
              AND (approval_mode NOT IN ('BM_ONLY','BM_AND_HOST') OR bm_approval_status='APPROVED')
              AND (approval_mode NOT IN ('HOST_ONLY','BM_AND_HOST') OR host_approval_status='APPROVED')
            RETURNING invitation_id
        ) INSERT INTO self_registration_access_jobs (invitation_id) SELECT invitation_id FROM ready ON CONFLICT DO NOTHING`);
    }

    async function setFailure(id, error) {
        await pool.query("UPDATE self_registration_access_jobs SET error=$2, updated_at=NOW() WHERE invitation_id=$1", [id, error.message]);
        const current = (await pool.query(
            `SELECT i.status,j.phase FROM visitor_invitations i
             JOIN self_registration_access_jobs j USING(invitation_id)
             WHERE i.invitation_id=$1`, [id]
        )).rows[0];
        const localAccessActive = current?.status === "CHECKED_IN" && current?.phase === "PROVISION";
        const localAccessExpired = current?.status === "ACCESS_EXPIRED" && current?.phase === "REVOKE";
        if (!localAccessActive && !localAccessExpired) {
            await pool.query("UPDATE visitor_invitations SET status='ACCESS_FAILED', modified_time=NOW() WHERE invitation_id=$1", [id]);
        }
        await dependencies.notify(systemRequest, { channel: "SELF_REGISTRATION", event_type: "ACCESS_FAILED", status: "FAILED",
            title: localAccessExpired ? "Pencabutan akses perlu diperiksa" : localAccessActive ? "Sinkronisasi akses perlu diperiksa" : "Akses otomatis perlu diperiksa",
            message: error.message, detail: { invitation_id: id, local_access_active: localAccessActive, local_access_expired: localAccessExpired } });
    }

    async function prepare(client, invitation, job) {
        if (job.visitor_id) return job;
        if (!approvalsComplete(invitation)) throw new Error("Approval belum lengkap.");
        if (!invitation.expiry_date || new Date(invitation.expiry_date) <= new Date()) throw new Error("Jadwal kunjungan sudah berakhir atau belum lengkap.");
        if (await dependencies.isBlacklisted(invitation.identity_number)) throw new Error("ID Number masuk blacklist aktif.");
        const plan = await dependencies.plan(invitation);
        await client.query("BEGIN");
        try {
            await client.query("SELECT pg_advisory_xact_lock(hashtext('self_access_allocation'))");
            // A revoked visit that never checked in has no checkout timestamp, but is no longer active.
            const active = await client.query(`SELECT visitor_id FROM visitor_registration WHERE identity_number=$1
                AND check_out_time IS NULL AND (check_in_time IS NOT NULL
                    OR status IN ('ACCESS_PENDING','ACCESS_READY','ACCESS_FAILED','WAITING_ARRIVAL')) LIMIT 1`, [invitation.identity_number]);
            if (active.rows.length) throw new Error("Visitor masih memiliki kunjungan atau akses aktif. Periksa kunjungan sebelumnya.");
            const digits = Math.min(24, Math.max(4, Number(plan.digits) || 10));
            let code;
            for (let attempt = 0; attempt < 30; attempt++) {
                code = String(crypto.randomInt(1, 10));
                for (let i = 1; i < digits; i++) code += String(crypto.randomInt(0, 10));
                const duplicate = await client.query(`SELECT 1 FROM visitor_registration WHERE card_number=$1
                    UNION ALL SELECT 1 FROM self_registration_access_jobs WHERE access_code=$1 LIMIT 1`, [code]);
                if (!duplicate.rows.length) break;
                code = null;
            }
            if (!code) throw new Error("Nomor akses unik belum tersedia.");
            const qrValue = await dependencies.qrValue(code, plan);
            if (!/^\d+$/.test(qrValue)) throw new Error("Format QR akses otomatis harus berupa angka. Periksa Card Format Mapping.");
            const qrDuplicate = await client.query("SELECT 1 FROM self_registration_access_jobs WHERE qr_value=$1 UNION ALL SELECT 1 FROM visitor_registration WHERE card_number=$1 LIMIT 1", [qrValue]);
            if (qrDuplicate.rows.length) throw new Error("Nomor akses hasil mapping sudah digunakan. Periksa format nomor sebelum retry.");
            const visitor = await client.query(`INSERT INTO visitor_registration (
                first_name,second_name,identity_number,identity_type,company_name,email_address,phone_number,host,
                permission_group,purpose_note,visitor_photo,identity_photo,start_date,expiry_date,card_number,
                schindler_person_id,created_by,created_time,check_in_time,status)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'SELF_REGISTRATION',NOW(),NULL,'ACCESS_PENDING') RETURNING *`,
            [invitation.first_name,invitation.second_name,invitation.identity_number,invitation.identity_type,invitation.company_name,
                invitation.email_address,invitation.phone_number,invitation.host,invitation.permission_group,invitation.purpose_note,
                invitation.visitor_photo,invitation.identity_photo,invitation.start_date,invitation.expiry_date,code,crypto.randomUUID().replace(/-/g, "").toUpperCase()]);
            const phase = activationTiming(invitation) === "ON_OPERATOR_CHECKIN" ? "WAITING_ARRIVAL" : "PROVISION";
            const result = await client.query(`UPDATE self_registration_access_jobs SET visitor_id=$2,access_code=$3,qr_value=$4,
                stages=$5::jsonb,revoke_stages=$6::jsonb,phase=$7,updated_at=NOW() WHERE invitation_id=$1 RETURNING *`,
            [invitation.invitation_id,visitor.rows[0].visitor_id,code,qrValue,JSON.stringify(plan.add),JSON.stringify(plan.remove),phase]);
            if (typeof dependencies.prepareMembers === "function") {
                await dependencies.prepareMembers(client, invitation, {
                    leaderVisitor: visitor.rows[0],
                    plan,
                    phase,
                    qrValue
                });
            }
            await client.query("COMMIT");
            return result.rows[0];
        } catch (error) { await client.query("ROLLBACK"); throw error; }
    }

    async function runStages(job, revoke) {
        const column = revoke ? "revoke_stages" : "stages";
        const stages = job[column];
        for (const stage of stages) {
            if (stage.state === "DONE") continue;
            if (stage.state === "SENDING") throw new Error("Pengiriman sebelumnya terputus. Periksa target sebelum Retry Access.");
            stage.state = "SENDING";
            await pool.query(`UPDATE self_registration_access_jobs SET ${column}=$2::jsonb,updated_at=NOW() WHERE invitation_id=$1`, [job.invitation_id, JSON.stringify(stages)]);
            const visitor = (await pool.query("SELECT * FROM visitor_registration WHERE visitor_id=$1", [job.visitor_id])).rows[0];
            try {
                const result = await dependencies.send(stage, visitor, revoke, systemRequest);
                if (!result.success) throw new Error(result.error || "Pengiriman akses gagal. Periksa Monitoring API Activity.");
                stage.state = "DONE";
                stage.error = null;
            } catch (error) {
                let confirmed = false;
                if (typeof dependencies.confirm === "function") {
                    try {
                        confirmed = await dependencies.confirm(stage, visitor, revoke, systemRequest, job) === true;
                    } catch (confirmError) {
                        console.log(`ACCESS RECONCILE ${job.invitation_id}/${stage.kind}/${stage.id}:`, confirmError.message);
                    }
                }
                if (confirmed) {
                    stage.state = "DONE";
                    stage.error = null;
                } else {
                    stage.state = "FAILED";
                    stage.error = error.message;
                    throw error;
                }
            } finally {
                await pool.query(`UPDATE self_registration_access_jobs SET ${column}=$2::jsonb,updated_at=NOW() WHERE invitation_id=$1`, [job.invitation_id, JSON.stringify(stages)]);
            }
        }
    }

    async function sendEmail(job, invitation) {
        const currentStatus = String(job.email_status || "PENDING").toUpperCase();
        if (currentStatus !== "PENDING") return currentStatus;
        await pool.query("UPDATE self_registration_access_jobs SET email_status='SENDING',updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id]);
        try {
            const result = await dependencies.email(invitation, job.qr_value);
            const status = result?.skipped ? "SKIPPED" : "SENT";
            await pool.query("UPDATE self_registration_access_jobs SET email_status=$2,email_error=NULL,updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id, status]);
            return status;
        } catch (error) {
            await pool.query("UPDATE self_registration_access_jobs SET email_status='FAILED',email_error=$2,updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id,error.message]);
            await dependencies.notify(systemRequest, { channel: "EMAIL_VISITOR", event_type: "ACCESS_QR", status: "FAILED", title: "Email QR akses gagal", message: error.message, detail: { invitation_id: job.invitation_id } });
            return "FAILED";
        }
    }

    async function sendWhatsApp(job, invitation) {
        const currentStatus = String(job.whatsapp_status || "PENDING").toUpperCase();
        if (currentStatus !== "PENDING") return currentStatus;
        if (typeof dependencies.whatsapp !== "function") {
            await pool.query("UPDATE self_registration_access_jobs SET whatsapp_status='SKIPPED',updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id]);
            return "SKIPPED";
        }
        await pool.query("UPDATE self_registration_access_jobs SET whatsapp_status='SENDING',updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id]);
        try {
            const result = await dependencies.whatsapp(invitation, job.qr_value);
            const status = result?.skipped ? "SKIPPED" : "SENT";
            await pool.query("UPDATE self_registration_access_jobs SET whatsapp_status=$2,whatsapp_error=NULL,updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id, status]);
            return status;
        } catch (error) {
            const deliveryStatus = error?.deliveryStatus === "UNCONFIRMED" ? "UNCONFIRMED" : "FAILED";
            await pool.query("UPDATE self_registration_access_jobs SET whatsapp_status=$2,whatsapp_error=$3,updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id,deliveryStatus,error.message]);
            await dependencies.notify(systemRequest, { channel: "WHATSAPP", event_type: "ACCESS_QR", status: deliveryStatus === "FAILED" ? "FAILED" : "WARNING", title: deliveryStatus === "FAILED" ? "WhatsApp QR akses gagal" : "Status WhatsApp QR belum terkonfirmasi", message: error.message, detail: { invitation_id: job.invitation_id } });
            return deliveryStatus;
        }
    }

    async function sendQrShares(job, invitation) {
        await Promise.allSettled([
            sendEmail(job, invitation),
            sendWhatsApp(job, invitation)
        ]);
    }

    async function removeAccess(client, job) {
        const wasProvisioned = (job.stages || []).some(stage => ["DONE", "SENDING", "FAILED"].includes(stage.state));
        await client.query("UPDATE self_registration_access_jobs SET phase='REVOKE',updated_at=NOW() WHERE invitation_id=$1", [job.invitation_id]);
        if (job.visitor_id) {
            await client.query(`UPDATE visitor_registration SET
                check_out_time=CASE WHEN check_in_time IS NOT NULL THEN COALESCE(check_out_time,NOW()) ELSE check_out_time END,
                status='ACCESS_EXPIRED',modified_time=NOW() WHERE visitor_id=$1`, [job.visitor_id]);
            await dependencies.release(job.visitor_id);
        }
        if (typeof dependencies.removeMembersAccess === "function") {
            await dependencies.removeMembersAccess(client, job.invitation_id);
        }
        await client.query("UPDATE visitor_invitations SET status='ACCESS_EXPIRED',modified_time=NOW() WHERE invitation_id=$1", [job.invitation_id]);
        if (wasProvisioned) await runStages(job, true);
        await client.query("UPDATE self_registration_access_jobs SET error=NULL WHERE invitation_id=$1", [job.invitation_id]);
    }

    async function processJob(id) {
        const client = await pool.connect();
        let locked = false;
        try {
            locked = (await client.query("SELECT pg_try_advisory_lock(hashtext('self_access_job'),$1) AS locked", [id])).rows[0].locked;
            if (!locked) return;
            let invitation = (await client.query("SELECT * FROM visitor_invitations WHERE invitation_id=$1", [id])).rows[0];
            let job = (await client.query("SELECT * FROM self_registration_access_jobs WHERE invitation_id=$1", [id])).rows[0];
            if (!invitation || !job) return;
            const expired = !invitation.expiry_date || new Date(invitation.expiry_date) <= new Date();
            const blocked = await dependencies.isBlacklisted(invitation.identity_number);
            const revoke = job.phase === "REVOKE" || expired || blocked;
            if (revoke) {
                await removeAccess(client, job);
                return;
            }
            if (!["ACCESS_PENDING", "WAITING_ARRIVAL", "ACCESS_READY", "CHECKED_IN"].includes(invitation.status)) return;
            if (invitation.status === "WAITING_ARRIVAL") {
                return;
            }
            if (invitation.status === "ACCESS_PENDING") {
                job = await prepare(client, invitation, job);
                if (job.phase === "WAITING_ARRIVAL") {
                    await client.query("UPDATE visitor_registration SET status='WAITING_ARRIVAL',modified_time=NOW() WHERE visitor_id=$1", [job.visitor_id]);
                    await client.query("UPDATE visitor_invitations SET status='WAITING_ARRIVAL',modified_time=NOW() WHERE invitation_id=$1 AND status='ACCESS_PENDING'", [id]);
                    await client.query("UPDATE self_registration_access_jobs SET error=NULL WHERE invitation_id=$1", [id]);
                    return;
                }
                // QR access belongs to Innersync. External targets are synchronized afterwards.
                const current = (await client.query("SELECT * FROM visitor_invitations WHERE invitation_id=$1", [id])).rows[0];
                if (await dependencies.isBlacklisted(current.identity_number) || new Date(current.expiry_date) <= new Date()) {
                    await removeAccess(client, job);
                    return;
                }
                const checkedInVisitor = await client.query("UPDATE visitor_registration SET status='CHECKED_IN',check_in_time=COALESCE(check_in_time,NOW()),modified_time=NOW() WHERE visitor_id=$1 RETURNING *", [job.visitor_id]);
                if (typeof dependencies.notifyCheckin === "function" && checkedInVisitor.rows[0]) {
                    dependencies.notifyCheckin(checkedInVisitor.rows[0]);
                }
                if (typeof dependencies.markMembersCheckedIn === "function") {
                    await dependencies.markMembersCheckedIn(client, id);
                }
                await client.query("UPDATE visitor_invitations SET status='CHECKED_IN',checked_in_time=COALESCE(checked_in_time,NOW()),modified_time=NOW() WHERE invitation_id=$1 AND status='ACCESS_PENDING'", [id]);
                await client.query("UPDATE self_registration_access_jobs SET error=NULL WHERE invitation_id=$1", [id]);
                invitation = current;
            }
            if (invitation.status === "ACCESS_READY" && activationTiming(invitation) === "AFTER_APPROVAL") {
                const checkedInVisitor = await client.query("UPDATE visitor_registration SET status='CHECKED_IN',check_in_time=COALESCE(check_in_time,NOW()),modified_time=NOW() WHERE visitor_id=$1 RETURNING *", [job.visitor_id]);
                if (typeof dependencies.notifyCheckin === "function" && checkedInVisitor.rows[0]) {
                    dependencies.notifyCheckin(checkedInVisitor.rows[0]);
                }
                if (typeof dependencies.markMembersCheckedIn === "function") {
                    await dependencies.markMembersCheckedIn(client, id);
                }
                await client.query("UPDATE visitor_invitations SET status='CHECKED_IN',checked_in_time=COALESCE(checked_in_time,NOW()),modified_time=NOW() WHERE invitation_id=$1", [id]);
            }
            await sendQrShares(job, invitation);
            await runStages(job, false);
            const afterSync = (await client.query("SELECT * FROM visitor_invitations WHERE invitation_id=$1", [id])).rows[0];
            if (await dependencies.isBlacklisted(afterSync.identity_number) || new Date(afterSync.expiry_date) <= new Date()) {
                await removeAccess(client, job);
                return;
            }
            await client.query("UPDATE self_registration_access_jobs SET error=NULL WHERE invitation_id=$1", [id]);
        } catch (error) {
            if (locked) await setFailure(id, error);
        } finally {
            try {
                if (locked) {
                    try { await client.query("UPDATE self_registration_access_jobs SET updated_at=NOW() WHERE invitation_id=$1", [id]); }
                    finally { await client.query("SELECT pg_advisory_unlock(hashtext('self_access_job'),$1)", [id]); }
                }
                client.release();
            } catch (error) { client.release(true); throw error; }
        }
    }

    async function tick() {
        if (running) return;
        running = true;
        try {
            await expireApprovals();
            await queueApproved();
            const jobs = await pool.query(`SELECT j.invitation_id FROM self_registration_access_jobs j
                JOIN visitor_invitations i ON i.invitation_id=j.invitation_id
                WHERE i.status IN ('ACCESS_PENDING','WAITING_ARRIVAL','ACCESS_READY')
                   OR (i.status='CHECKED_IN' AND j.phase='PROVISION'
                       AND (COALESCE(j.email_status,'PENDING')='PENDING'
                         OR COALESCE(j.whatsapp_status,'PENDING')='PENDING'))
                   OR (i.status='CHECKED_IN' AND j.phase='PROVISION' AND j.error IS NULL
                       AND EXISTS (
                           SELECT 1 FROM jsonb_array_elements(j.stages) stage
                           WHERE stage->>'state'<>'DONE'
                       ))
                   OR (i.status='ACCESS_EXPIRED' AND j.phase='REVOKE' AND j.error IS NULL
                       AND EXISTS (
                           SELECT 1 FROM jsonb_array_elements(j.revoke_stages) stage
                           WHERE stage->>'state'<>'DONE'
                       ))
                   OR (i.status='ACCESS_FAILED' AND j.phase<>'REVOKE' AND i.expiry_date<=NOW())
                ORDER BY j.updated_at ASC LIMIT 25`);
            for (const row of jobs.rows) await processJob(row.invitation_id);
        } finally { running = false; }
    }

    async function retry(id, emailOnly = false) {
        const client = await pool.connect();
        try {
            await client.query("BEGIN");
            await client.query("SELECT pg_advisory_xact_lock(hashtext('self_access_job'),$1)", [id]);
            const current = await client.query(`SELECT i.*,j.email_status,j.email_error,j.stages,j.revoke_stages,j.phase,j.error FROM visitor_invitations i
                JOIN self_registration_access_jobs j ON j.invitation_id=i.invitation_id WHERE i.invitation_id=$1 FOR UPDATE`, [id]);
            const row = current.rows[0];
            if (!row) throw new Error("Antrean akses tidak ditemukan.");
            if (emailOnly) {
                if (!["ACCESS_READY","CHECKED_IN"].includes(row.status) || new Date(row.expiry_date)<=new Date()) throw new Error("QR belum tersedia atau sudah kedaluwarsa.");
                await client.query("UPDATE self_registration_access_jobs SET email_status='PENDING',email_error=NULL WHERE invitation_id=$1", [id]);
            } else {
                const integrationFailed = row.status === "CHECKED_IN" && !!row.error && row.phase === "PROVISION";
                const revokeFailed = row.status === "ACCESS_EXPIRED" && !!row.error && row.phase === "REVOKE";
                if (row.status !== "ACCESS_FAILED" && !integrationFailed && !revokeFailed) throw new Error("Sinkronisasi akses tidak berstatus gagal.");
                for (const stage of [...row.stages,...row.revoke_stages]) if (stage.state !== "DONE") stage.state = "PENDING";
                await client.query("UPDATE self_registration_access_jobs SET stages=$2::jsonb,revoke_stages=$3::jsonb,error=NULL WHERE invitation_id=$1", [id,JSON.stringify(row.stages),JSON.stringify(row.revoke_stages)]);
                if (!integrationFailed && !revokeFailed) await client.query("UPDATE visitor_invitations SET status='ACCESS_PENDING' WHERE invitation_id=$1", [id]);
            }
            await client.query("COMMIT");
        } catch (error) { await client.query("ROLLBACK"); throw error; }
        finally { client.release(); }
    }

    async function revoke(id) {
        const client = await pool.connect();
        try {
            await client.query("BEGIN");
            await client.query("SELECT pg_advisory_xact_lock(hashtext('self_access_job'),$1)", [id]);
            const result = await client.query("UPDATE self_registration_access_jobs SET phase='REVOKE',updated_at=NOW() WHERE invitation_id=$1 RETURNING invitation_id", [id]);
            if (!result.rows.length) throw new Error("Antrean akses tidak ditemukan.");
            await client.query("UPDATE visitor_invitations SET status='ACCESS_PENDING' WHERE invitation_id=$1 AND status<>'ACCESS_EXPIRED'", [id]);
            await client.query("COMMIT");
        } catch (error) { await client.query("ROLLBACK"); throw error; }
        finally { client.release(); }
    }

    async function activate(id) {
        const client = await pool.connect();
        try {
            await client.query("BEGIN");
            await client.query("SELECT pg_advisory_xact_lock(hashtext('self_access_job'),$1)", [id]);
            const current = await client.query(`SELECT i.*,j.visitor_id,j.phase FROM visitor_invitations i
                JOIN self_registration_access_jobs j ON j.invitation_id=i.invitation_id
                WHERE i.invitation_id=$1 FOR UPDATE`, [id]);
            const row = current.rows[0];
            if (!row) throw new Error("Data visitor otomatis tidak ditemukan.");
            if (row.access_mode !== "AUTOMATIC" || activationTiming(row) !== "ON_OPERATOR_CHECKIN") throw new Error("Visitor ini tidak memakai aktivasi melalui QR Check-in Lokasi.");
            if (row.status !== "WAITING_ARRIVAL" || row.phase !== "WAITING_ARRIVAL") throw new Error("Visitor tidak berstatus Menunggu Kedatangan.");
            if (!approvalsComplete(row)) throw new Error("Approval visitor belum lengkap.");
            if (!row.expiry_date || new Date(row.expiry_date) <= new Date()) throw new Error("Jadwal kunjungan sudah berakhir.");
            await client.query("UPDATE self_registration_access_jobs SET phase='PROVISION',error=NULL,updated_at=NOW() WHERE invitation_id=$1", [id]);
            await client.query("UPDATE visitor_invitations SET status='CHECKED_IN',checked_in_time=COALESCE(checked_in_time,NOW()),modified_time=NOW() WHERE invitation_id=$1", [id]);
            const checkedInVisitor = await client.query("UPDATE visitor_registration SET status='CHECKED_IN',check_in_time=COALESCE(check_in_time,NOW()),modified_time=NOW() WHERE visitor_id=$1 RETURNING *", [row.visitor_id]);
            if (typeof dependencies.notifyCheckin === "function" && checkedInVisitor.rows[0]) {
                dependencies.notifyCheckin(checkedInVisitor.rows[0]);
            }
            if (typeof dependencies.markMembersCheckedIn === "function") {
                await dependencies.markMembersCheckedIn(client, id);
            }
            await client.query("COMMIT");
        } catch (error) { await client.query("ROLLBACK"); throw error; }
        finally { client.release(); }
        setImmediate(() => processJob(id).catch(error => console.error("SELF ACCESS SYNC:", error.message)));
        return (await pool.query("SELECT status FROM visitor_invitations WHERE invitation_id=$1", [id])).rows[0];
    }

    function start() {
        if (timer) return;
        const run = () => tick().catch(error => console.error("SELF REGISTRATION WORKFLOW:", error.message));
        timer = setInterval(run, 5000);
        timer.unref();
        run();
    }
    return { ensureSchema, expireApprovals, queueApproved, processJob, tick, retry, revoke, activate, start };
}

module.exports = { createSelfRegistrationWorkflow, approvalsComplete, activationTiming };
