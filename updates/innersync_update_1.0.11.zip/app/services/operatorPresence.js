const OPERATOR_ROLE = "OPERATOR";
const PRESENCE_TIMEOUT_MS = 90 * 1000;
const CLEANUP_INTERVAL_MS = 10 * 1000;
const STREAM_KEEPALIVE_MS = 25 * 1000;

const activeSessions = new Map();
const streamClients = new Set();
let cleanupTimer = null;
let lastBroadcastCount = 0;

function isOperatorRole(roleName) {
    return String(roleName || "").trim().toUpperCase() === OPERATOR_ROLE;
}

function pruneExpired(now = Date.now()) {
    for (const [sessionId, presence] of activeSessions) {
        if (now - presence.lastSeenAt >= PRESENCE_TIMEOUT_MS) {
            activeSessions.delete(sessionId);
        }
    }
}

function getOnlineOperatorCount(now = Date.now()) {
    pruneExpired(now);
    const operatorIds = new Set();

    for (const presence of activeSessions.values()) {
        if (isOperatorRole(presence.roleName) && now - presence.lastSeenAt < PRESENCE_TIMEOUT_MS) {
            operatorIds.add(String(presence.userId));
        }
    }

    return operatorIds.size;
}

function buildPayload(now = Date.now()) {
    return {
        online_count: getOnlineOperatorCount(now),
        updated_at: new Date(now).toISOString(),
        timeout_seconds: Math.round(PRESENCE_TIMEOUT_MS / 1000)
    };
}

function sendSse(res, eventName, payload) {
    res.write(`event: ${eventName}\n`);
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
}

function broadcastIfChanged(now = Date.now()) {
    const payload = buildPayload(now);
    if (payload.online_count === lastBroadcastCount) return payload;

    lastBroadcastCount = payload.online_count;
    for (const res of streamClients) {
        try {
            sendSse(res, "operator-presence", payload);
        } catch {
            streamClients.delete(res);
        }
    }

    return payload;
}

function touchOperatorPresence(req, options = {}) {
    const sessionId = String(req?.sessionID || "").trim();
    const userId = req?.session?.user_id || req?.session?.user?.user_id;
    const roleName = req?.session?.role_name || req?.session?.user?.role_name;

    if (!sessionId || !userId || !isOperatorRole(roleName) || options.canOperate === false) {
        if (sessionId) activeSessions.delete(sessionId);
        return broadcastIfChanged();
    }

    activeSessions.set(sessionId, {
        userId,
        roleName,
        lastSeenAt: Date.now()
    });

    return broadcastIfChanged();
}

function removeOperatorPresence(sessionId) {
    const normalizedSessionId = String(sessionId || "").trim();
    if (normalizedSessionId) activeSessions.delete(normalizedSessionId);
    return broadcastIfChanged();
}

function attachOperatorPresenceStream(req, res) {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders?.();

    streamClients.add(res);
    sendSse(res, "operator-presence", buildPayload());

    const keepAlive = setInterval(() => {
        try {
            sendSse(res, "ping", { time: new Date().toISOString() });
        } catch {
            clearInterval(keepAlive);
            streamClients.delete(res);
        }
    }, STREAM_KEEPALIVE_MS);

    req.on("close", () => {
        clearInterval(keepAlive);
        streamClients.delete(res);
    });
}

function startOperatorPresenceMonitor() {
    if (cleanupTimer) return;
    lastBroadcastCount = getOnlineOperatorCount();
    cleanupTimer = setInterval(() => broadcastIfChanged(), CLEANUP_INTERVAL_MS);
    cleanupTimer.unref?.();
}

module.exports = {
    PRESENCE_TIMEOUT_MS,
    attachOperatorPresenceStream,
    getOnlineOperatorCount,
    removeOperatorPresence,
    startOperatorPresenceMonitor,
    touchOperatorPresence
};
