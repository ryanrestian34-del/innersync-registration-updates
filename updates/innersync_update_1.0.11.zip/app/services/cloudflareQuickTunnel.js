const { spawn, execFile } = require("node:child_process");
const fs = require("node:fs");
const https = require("node:https");
const path = require("node:path");
const { promisify } = require("node:util");

const execFileAsync = promisify(execFile);
const QUICK_TUNNEL_URL_PATTERN = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/gi;
const MAX_LOG_LINES = 200;
const START_TIMEOUT_MS = 45000;
const HEALTH_INTERVAL_MS = 30000;
const AUTO_RETRY_MS = 30000;

function extractTryCloudflareUrl(value) {
    const matches = String(value || "").match(QUICK_TUNNEL_URL_PATTERN);
    return matches?.[0] || "";
}

function stripAnsi(value) {
    return String(value || "").replace(/\u001b\[[0-9;]*m/g, "");
}

function normalizeUrl(value) {
    return String(value || "").trim().replace(/\/+$/g, "");
}

async function resolveIpv4ViaCloudflare(hostname) {
    const response = await fetch(`https://1.1.1.1/dns-query?name=${encodeURIComponent(hostname)}&type=A`, {
        headers: { Accept: "application/dns-json" },
        signal: AbortSignal.timeout(10000)
    });
    if (!response.ok) throw new Error(`DNS over HTTPS ${response.status}`);
    const result = await response.json();
    return (result.Answer || []).filter(answer => answer.type === 1).map(answer => answer.data).filter(Boolean);
}

function requestHealthViaAddress(url, address) {
    const parsed = new URL(url);
    return new Promise((resolve, reject) => {
        const request = https.request({
            host: address,
            servername: parsed.hostname,
            path: `${parsed.pathname}${parsed.search}`,
            method: "GET",
            headers: { Host: parsed.hostname, "User-Agent": "Innersync-Tunnel-Health/1.0" },
            timeout: 10000
        }, response => {
            response.resume();
            response.once("end", () => resolve({ ok: response.statusCode >= 200 && response.statusCode < 300, status: response.statusCode }));
        });
        request.once("timeout", () => request.destroy(new Error("Health check timeout")));
        request.once("error", reject);
        request.end();
    });
}

async function checkPublicHealth(url) {
    let directError;
    try {
        const response = await fetch(url, {
            method: "GET",
            cache: "no-store",
            signal: AbortSignal.timeout(10000),
            headers: { "User-Agent": "Innersync-Tunnel-Health/1.0" }
        });
        if (response.ok) return;
        directError = new Error(`HTTP ${response.status}`);
    } catch (error) {
        directError = error;
    }

    const addresses = await resolveIpv4ViaCloudflare(new URL(url).hostname);
    for (const address of addresses) {
        try {
            const response = await requestHealthViaAddress(url, address);
            if (response.ok) return;
            directError = new Error(`HTTP ${response.status}`);
        } catch (error) {
            directError = error;
        }
    }
    throw directError || new Error("URL publik belum dapat diakses.");
}

function createCloudflareQuickTunnelManager({ pool, appRoot, logger = console }) {
    const logFilePath = path.join(appRoot, "logs", "cloudflare-quick-tunnel.log");
    let originUrl = "";
    let tunnelProcess = null;
    let tunnelUrl = "";
    let status = "NOT_STARTED";
    let lastError = "";
    let startedAt = null;
    let lastCheckedAt = null;
    let healthTimer = null;
    let healthCheckRunning = false;
    let restartTimer = null;
    let startPromise = null;
    let pendingStart = null;
    let manualStopRequested = false;
    let cachedExecutable = "";
    let outputBuffer = "";
    let gracefulShutdownStarted = false;
    const logs = [];

    function resetPersistentLog() {
        try {
            fs.mkdirSync(path.dirname(logFilePath), { recursive: true });
            fs.writeFileSync(logFilePath, `# Innersync Quick Tunnel Log - ${new Date().toISOString()}\r\n`, "utf8");
        } catch (_error) {
            // Logging must never prevent the tunnel from starting.
        }
    }

    function addLog(source, value) {
        const timestamp = new Date().toISOString();
        stripAnsi(value).split(/\r?\n/).map(line => line.trim()).filter(Boolean).forEach(line => {
            const entry = { timestamp, source, message: line.slice(0, 2000) };
            logs.push(entry);
            try {
                fs.appendFileSync(logFilePath, `[${timestamp}] ${source}: ${entry.message}\r\n`, "utf8");
            } catch (_error) {
                // Keep the in-memory log available when the file is not writable.
            }
        });
        if (logs.length > MAX_LOG_LINES) logs.splice(0, logs.length - MAX_LOG_LINES);
    }

    function processIsRunning(processRef = tunnelProcess) {
        return Boolean(processRef && processRef.exitCode === null && !processRef.killed);
    }

    async function readSettings() {
        const result = await pool.query(
            `SELECT public_base_url,
                    public_base_url_source,
                    quick_tunnel_auto_start,
                    quick_tunnel_last_url,
                    quick_tunnel_last_started_at,
                    quick_tunnel_last_error
             FROM qr_settings
             WHERE setting_id = 1`
        );
        return result.rows[0] || {};
    }

    async function persistStartedUrl(url) {
        await pool.query(
            `UPDATE qr_settings
             SET public_base_url = $1,
                 public_base_url_source = 'QUICK_TUNNEL',
                 quick_tunnel_last_url = $1,
                 quick_tunnel_last_started_at = NOW(),
                 quick_tunnel_last_error = NULL,
                 updated_at = NOW()
             WHERE setting_id = 1`,
            [url]
        );
    }

    async function persistError(error) {
        await pool.query(
            `UPDATE qr_settings
             SET quick_tunnel_last_error = $1,
                 updated_at = NOW()
             WHERE setting_id = 1`,
            [String(error || "").slice(0, 2000) || null]
        ).catch(() => {});
    }

    async function clearPublishedQuickUrl(url, error = null) {
        const normalized = normalizeUrl(url);
        await pool.query(
            `UPDATE qr_settings
             SET public_base_url = CASE
                     WHEN public_base_url_source = 'QUICK_TUNNEL'
                      AND ($1 = '' OR RTRIM(COALESCE(public_base_url, ''), '/') = $1)
                     THEN NULL
                     ELSE public_base_url
                 END,
                 quick_tunnel_last_error = $2,
                 updated_at = NOW()
             WHERE setting_id = 1`,
            [normalized, error ? String(error).slice(0, 2000) : null]
        ).catch(() => {});
    }

    function candidateExecutables() {
        const programFiles = process.env.ProgramFiles || "C:/Program Files";
        const programFilesX86 = process.env["ProgramFiles(x86)"] || "C:/Program Files (x86)";
        return [
            process.env.CLOUDFLARED_PATH,
            path.join(appRoot, "tools", "cloudflared", "cloudflared.exe"),
            path.join(appRoot, "tools", "cloudflared.exe"),
            path.join(appRoot, "cloudflared.exe"),
            path.join(programFilesX86, "cloudflared", "cloudflared.exe"),
            path.join(programFiles, "cloudflared", "cloudflared.exe")
        ].filter(Boolean);
    }

    async function resolveExecutable() {
        if (cachedExecutable && fs.existsSync(cachedExecutable)) return cachedExecutable;
        const candidate = candidateExecutables().find(filePath => {
            try {
                return fs.statSync(filePath).isFile();
            } catch (_error) {
                return false;
            }
        });
        if (candidate) {
            cachedExecutable = candidate;
            return cachedExecutable;
        }

        try {
            const result = await execFileAsync("where.exe", ["cloudflared"], { windowsHide: true, timeout: 5000 });
            const found = String(result.stdout || "").split(/\r?\n/).map(line => line.trim()).find(Boolean);
            if (found && fs.existsSync(found)) {
                cachedExecutable = found;
                return cachedExecutable;
            }
        } catch (_error) {
            // The error below gives the operator a clearer installation instruction.
        }

        throw new Error("cloudflared.exe tidak ditemukan. Install Cloudflare Tunnel atau simpan cloudflared.exe di folder tools/cloudflared.");
    }

    function settlePendingStart(error = null) {
        if (!pendingStart) return;
        clearTimeout(pendingStart.timer);
        const waiter = pendingStart;
        pendingStart = null;
        if (error) waiter.reject(error);
        else getStatus().then(waiter.resolve, waiter.reject);
    }

    async function publishUrl(url) {
        if (!url || tunnelUrl === url) return;
        tunnelUrl = normalizeUrl(url);
        startedAt = new Date().toISOString();
        lastCheckedAt = null;
        lastError = "";
        status = "STARTING";
        addLog("SYSTEM", `Quick Tunnel mendapat URL: ${tunnelUrl}`);
        try {
            await persistStartedUrl(tunnelUrl);
            settlePendingStart();
            startHealthMonitor();
        } catch (error) {
            lastError = error.message;
            status = "ERROR";
            settlePendingStart(error);
        }
    }

    function consumeOutput(source, chunk) {
        const text = stripAnsi(chunk);
        addLog(source, text);
        outputBuffer = `${outputBuffer}${text}`.slice(-16000);
        const url = extractTryCloudflareUrl(outputBuffer);
        if (url) publishUrl(url).catch(error => logger.error("QUICK TUNNEL URL:", error.message));
        if (/Registered tunnel connection/i.test(text) && tunnelUrl) {
            setTimeout(() => runHealthCheck().catch(() => {}), 1200);
        }
    }

    async function runHealthCheck() {
        if (healthCheckRunning || !processIsRunning() || !tunnelUrl) return;
        healthCheckRunning = true;
        lastCheckedAt = new Date().toISOString();
        try {
            await checkPublicHealth(`${tunnelUrl}/api/public/cloudflare-tunnel-health?t=${Date.now()}`);
            status = "ONLINE";
            lastError = "";
        } catch (error) {
            status = "RECONNECTING";
            lastError = `URL publik belum dapat diakses: ${error.message}`;
        } finally {
            healthCheckRunning = false;
        }
    }

    function stopHealthMonitor() {
        if (healthTimer) clearInterval(healthTimer);
        healthTimer = null;
        healthCheckRunning = false;
    }

    function startHealthMonitor() {
        stopHealthMonitor();
        setTimeout(() => runHealthCheck().catch(() => {}), 2500);
        healthTimer = setInterval(() => runHealthCheck().catch(() => {}), HEALTH_INTERVAL_MS);
        healthTimer.unref?.();
    }

    async function shouldAutoRestart() {
        try {
            const settings = await readSettings();
            return settings.quick_tunnel_auto_start === true;
        } catch (_error) {
            return false;
        }
    }

    function clearRestartTimer() {
        if (restartTimer) clearTimeout(restartTimer);
        restartTimer = null;
    }

    async function scheduleAutoRestart() {
        if (manualStopRequested || restartTimer || !(await shouldAutoRestart())) return;
        addLog("SYSTEM", `Quick Tunnel akan dicoba kembali dalam ${AUTO_RETRY_MS / 1000} detik.`);
        restartTimer = setTimeout(() => {
            restartTimer = null;
            start({ automatic: true }).catch(error => {
                logger.error("QUICK TUNNEL AUTO RETRY:", error.message);
                scheduleAutoRestart().catch(() => {});
            });
        }, AUTO_RETRY_MS);
        restartTimer.unref?.();
    }

    async function handleProcessClose(processRef, code, signal) {
        if (tunnelProcess !== processRef) return;
        const previousUrl = tunnelUrl;
        const wasManualStop = manualStopRequested;
        tunnelProcess = null;
        tunnelUrl = "";
        stopHealthMonitor();
        const message = wasManualStop
            ? "Quick Tunnel dihentikan oleh operator."
            : `Proses cloudflared berhenti${code !== null ? ` dengan kode ${code}` : ""}${signal ? ` (${signal})` : ""}.`;
        const diagnostic = [...logs].reverse().find(entry =>
            entry.source === "ERROR" || /\bERR\b|error=|failed|fatal/i.test(entry.message)
        );
        status = wasManualStop ? "OFFLINE" : "ERROR";
        lastError = wasManualStop ? "" : `${message}${diagnostic ? ` ${diagnostic.message}` : ""}`.slice(0, 2000);
        addLog("SYSTEM", message);
        settlePendingStart(wasManualStop ? new Error("Quick Tunnel dihentikan sebelum URL tersedia.") : new Error(message));
        await clearPublishedQuickUrl(previousUrl, lastError || null);
        if (!wasManualStop) await scheduleAutoRestart();
    }

    function configure({ origin }) {
        originUrl = normalizeUrl(origin);
    }

    async function start({ automatic = false, replaceManual = false } = {}) {
        if (!originUrl) throw new Error("Alamat server lokal untuk Quick Tunnel belum tersedia.");
        if (processIsRunning() && tunnelUrl) return getStatus();
        if (startPromise) return startPromise;

        const currentSettings = await readSettings();
        if (currentSettings.public_base_url && currentSettings.public_base_url_source !== "QUICK_TUNNEL" && replaceManual !== true) {
            throw new Error("URL publik manual sedang digunakan. Konfirmasi penggantian URL manual diperlukan.");
        }

        if (processIsRunning() && !tunnelUrl) {
            await stop();
        }

        manualStopRequested = false;
        clearRestartTimer();
        stopHealthMonitor();
        status = "STARTING";
        lastError = "";
        outputBuffer = "";
        logs.splice(0, logs.length);
        resetPersistentLog();
        addLog("SYSTEM", `${automatic ? "Auto-start" : "Start"} Quick Tunnel ke ${originUrl}.`);

        startPromise = (async () => {
            try {
                const executable = await resolveExecutable();
                const processRef = spawn(executable, ["tunnel", "--no-autoupdate", "--protocol", "http2", "--url", originUrl], {
                    cwd: appRoot,
                    windowsHide: true,
                    shell: false,
                    stdio: ["ignore", "pipe", "pipe"]
                });
                tunnelProcess = processRef;
                processRef.stdout?.on("data", chunk => consumeOutput("STDOUT", chunk));
                processRef.stderr?.on("data", chunk => consumeOutput("STDERR", chunk));
                processRef.once("error", error => {
                    lastError = error.message;
                    status = "ERROR";
                    addLog("ERROR", error.message);
                    settlePendingStart(error);
                    persistError(error.message).catch(() => {});
                });
                processRef.once("close", (code, signal) => {
                    handleProcessClose(processRef, code, signal).catch(error => logger.error("QUICK TUNNEL CLOSE:", error.message));
                });

                return await new Promise((resolve, reject) => {
                    pendingStart = {
                        resolve,
                        reject,
                        timer: setTimeout(() => {
                            const error = new Error("Cloudflare belum memberikan URL setelah 45 detik. Periksa koneksi internet dan logs.");
                            lastError = error.message;
                            status = "ERROR";
                            addLog("ERROR", error.message);
                            reject(error);
                            pendingStart = null;
                            if (processIsRunning(processRef)) processRef.kill();
                        }, START_TIMEOUT_MS)
                    };
                });
            } catch (error) {
                status = "ERROR";
                lastError = error.message;
                addLog("ERROR", error.message);
                await persistError(error.message);
                if (automatic) await scheduleAutoRestart();
                throw error;
            } finally {
                startPromise = null;
            }
        })();

        return startPromise;
    }

    async function stop() {
        manualStopRequested = true;
        clearRestartTimer();
        stopHealthMonitor();
        const processRef = tunnelProcess;
        const previousUrl = tunnelUrl;
        status = "STOPPING";

        if (processIsRunning(processRef)) {
            await new Promise(resolve => {
                let completed = false;
                const finish = () => {
                    if (completed) return;
                    completed = true;
                    resolve();
                };
                processRef.once("close", finish);
                processRef.kill();
                const forceTimer = setTimeout(() => {
                    if (processIsRunning(processRef)) processRef.kill("SIGKILL");
                    finish();
                }, 6000);
                forceTimer.unref?.();
            });
        }

        tunnelProcess = null;
        tunnelUrl = "";
        status = "OFFLINE";
        lastError = "";
        await clearPublishedQuickUrl(previousUrl, null);
        return getStatus();
    }

    async function restart({ replaceManual = false } = {}) {
        await stop();
        manualStopRequested = false;
        return start({ automatic: false, replaceManual });
    }

    async function setAutoStart(enabled) {
        clearRestartTimer();
        const settings = await readSettings();
        if (enabled === true && settings.public_base_url && settings.public_base_url_source !== "QUICK_TUNNEL") {
            throw new Error("URL publik manual sedang digunakan. Jalankan Generate Free URL dahulu sebelum mengaktifkan auto-start Quick Tunnel.");
        }
        await pool.query(
            `UPDATE qr_settings
             SET quick_tunnel_auto_start = $1,
                 updated_at = NOW()
             WHERE setting_id = 1`,
            [enabled === true]
        );
        return getStatus();
    }

    async function startFromSettings() {
        const settings = await readSettings();
        if (String(settings.public_base_url_source || "MANUAL") === "QUICK_TUNNEL") {
            await clearPublishedQuickUrl(settings.public_base_url || settings.quick_tunnel_last_url || "", null);
            status = "OFFLINE";
        }
        if (settings.quick_tunnel_auto_start === true) {
            try {
                await start({ automatic: true });
            } catch (error) {
                logger.error("QUICK TUNNEL AUTO START:", error.message);
            }
        }
        return getStatus();
    }

    async function getStatus() {
        const settings = await readSettings();
        return {
            status,
            running: processIsRunning(),
            url: tunnelUrl || null,
            origin_url: originUrl || null,
            auto_start: settings.quick_tunnel_auto_start === true,
            public_base_url: settings.public_base_url || null,
            public_base_url_source: settings.public_base_url_source || "MANUAL",
            last_url: settings.quick_tunnel_last_url || null,
            started_at: startedAt || settings.quick_tunnel_last_started_at || null,
            last_checked_at: lastCheckedAt,
            error: lastError || settings.quick_tunnel_last_error || null,
            logs_available: logs.length > 0
        };
    }

    function getLogs() {
        return logs.slice();
    }

    function shutdown() {
        manualStopRequested = true;
        clearRestartTimer();
        stopHealthMonitor();
        if (processIsRunning()) tunnelProcess.kill();
    }

    async function gracefulShutdown() {
        if (gracefulShutdownStarted) return;
        gracefulShutdownStarted = true;
        try {
            await stop();
        } catch (error) {
            logger.error("QUICK TUNNEL SHUTDOWN:", error.message);
        } finally {
            process.exit(0);
        }
    }

    process.once("SIGINT", gracefulShutdown);
    process.once("SIGTERM", gracefulShutdown);
    process.once("exit", shutdown);

    return {
        configure,
        start,
        stop,
        restart,
        setAutoStart,
        startFromSettings,
        getStatus,
        getLogs,
        shutdown,
        resolveExecutable
    };
}

module.exports = {
    createCloudflareQuickTunnelManager,
    extractTryCloudflareUrl
};
