const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();
const packageInfo = require("../package.json");
const {
    getMachineFingerprint,
    getStoredLicenseStatus,
    saveLicenseToken
} = require("../license/licenseManager");
const {
    getCreditSummary,
    createCreditOrder
} = require("../services/innersyncWhatsappGatewayClient");

const ALWAYS_ALLOWED_PREFIXES = [
    "/api/license",
    "/api/service-status"
];

const ALWAYS_ALLOWED_PATHS = new Set([
    "/license.html",
    "/logo.png",
    "/favicon.ico"
]);

const CURRENT_VERSION_FILE = path.join(process.cwd(), "config", "current_version.json");

function getAppVersion() {
    try {
        const currentVersion = JSON.parse(fs.readFileSync(CURRENT_VERSION_FILE, "utf8"));
        if (currentVersion?.version) return currentVersion.version;
    } catch {
        // Fallback to package.json when no applied update version exists yet.
    }
    return packageInfo.version || "1.0.0";
}

function isAlwaysAllowedPath(pathname) {
    if (ALWAYS_ALLOWED_PATHS.has(pathname)) return true;
    return ALWAYS_ALLOWED_PREFIXES.some(prefix => pathname === prefix || pathname.startsWith(`${prefix}/`));
}

function wantsHtml(req) {
    return req.method === "GET" && (
        req.path === "/" ||
        req.path.endsWith(".html") ||
        String(req.headers.accept || "").includes("text/html")
    );
}

function licenseGate(req, res, next) {
    if (isAlwaysAllowedPath(req.path)) return next();

    const status = getStoredLicenseStatus();
    if (status.valid) return next();

    if (wantsHtml(req)) {
        return res.redirect("/license.html");
    }

    return res.status(403).json({
        success: false,
        license_required: true,
        reason: status.reason,
        message: status.message
    });
}

router.get("/api/license/status", (req, res) => {
    const status = getStoredLicenseStatus();
    res.json({
        success: true,
        valid: status.valid,
        reason: status.reason,
        message: status.message,
        access_mode: status.access_mode,
        license_valid: status.license_valid,
        license_days_until_expiry: status.license_days_until_expiry ?? null,
        expiry_warning: status.expiry_warning === true,
        has_license_file: status.has_license_file,
        license: status.payload || null,
        trial: status.trial || null,
        trial_active: status.trial_active,
        trial_remaining_days: status.trial_remaining_days || 0,
        app_version: getAppVersion(),
        machine: {
            machine_id: status.machine?.machine_id || getMachineFingerprint().machine_id,
            display_id: status.machine?.display_id || getMachineFingerprint().display_id,
            hostname: status.machine?.parts?.hostname || null
        }
    });
});

router.post("/api/license/activate", (req, res) => {
    const token = req.body?.license_key;
    const result = saveLicenseToken(token);
    if (!result.valid) {
        return res.status(400).json({
            success: false,
            valid: false,
            reason: result.reason,
            message: result.message
        });
    }

    res.json({
        success: true,
        valid: true,
        message: "License berhasil diaktifkan.",
        license: result.payload,
        machine: {
            machine_id: result.machine.machine_id,
            display_id: result.machine.display_id,
            hostname: result.machine.parts.hostname
        }
    });
});

function requireFullLicense(req, res) {
    const status = getStoredLicenseStatus();
    if (status.license_valid) return status;
    res.status(403).json({
        success: false,
        reason: "FULL_LICENSE_REQUIRED",
        message: "Kredit WhatsApp tersedia setelah license penuh diaktifkan."
    });
    return null;
}

router.get("/api/license/whatsapp-credits", async (req, res) => {
    try {
        const status = requireFullLicense(req, res);
        if (!status) return;
        const summary = await getCreditSummary(25);
        res.json({
            success: true,
            data: {
                ...summary,
                license_id: status.payload?.license_id || null,
                machine_id: status.machine?.display_id || null
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/license/whatsapp-credits/orders", async (req, res) => {
    try {
        if (!requireFullLicense(req, res)) return;
        const username = req.session?.user?.username || req.session?.user?.full_name || "LICENSE_MANAGER";
        const order = await createCreditOrder(req.body?.credits, username);
        res.status(201).json({
            success: true,
            message: "Order top-up berhasil dibuat.",
            data: order
        });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

router.post("/api/license/whatsapp-credits/topup", async (req, res) => {
    res.status(410).json({
        success:false,
        reason:"CENTRAL_TOPUP",
        message:"Top-up sekarang diproses langsung oleh administrator pada Gateway pusat."
    });
});
module.exports = {
    router,
    licenseGate
};
