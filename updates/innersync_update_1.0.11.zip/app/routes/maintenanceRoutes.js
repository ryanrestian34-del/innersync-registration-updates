const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawn } = require("child_process");
const pool = require("../database/db");
const { getSessionSettings, saveSessionSettings } = require("../utils/sessionSettings");

const router = express.Router();
const upload = multer({ dest: path.join(os.tmpdir(), "innersync-restore") });

let schemaReady = false;
let schedulerStarted = false;
let runningBackup = false;
let runningCleanup = false;
let runningDbGuard = false;
let databaseCapacityCache = null;
let databaseCapacityCacheAt = 0;
let databaseCapacityRefreshPromise = null;

const DEFAULT_BACKUP_FOLDER = path.join(process.cwd(), "backups");
const DEFAULT_CLEANUP_FOLDER = path.join(process.cwd(), "exports", "cleanup");
const DEFAULT_DB_LIMIT_MB = 51200;
const DB_CAPACITY_CACHE_TTL_MS = Math.max(Number(process.env.DB_CAPACITY_CACHE_TTL_MS || 60000), 5000);
const DATABASE_INITIALIZER_SCRIPT = path.join(process.cwd(), "scripts", "initialize-database.js");

const DATABASE_HEALTH_SCHEMA = [
    {
        table: "system_users",
        label: "System Users",
        columns: ["user_id", "username", "password", "full_name", "role_name", "approval_status", "is_blocked", "created_at", "modified_at"]
    },
    {
        table: "activity_logs",
        label: "Activity Logs",
        columns: ["log_id", "username", "activity_type", "description", "ip_address", "created_at", "created_time"]
    },
    {
        table: "visitor_registration",
        label: "Visitor Registration",
        columns: ["visitor_id", "first_name", "second_name", "identity_number", "visitor_photo", "identity_photo", "card_number", "permission_group", "host", "status", "check_in_time", "check_out_time"]
    },
    {
        table: "visitor_invitations",
        label: "Invitation Booking",
        columns: ["invitation_id", "booking_code", "status", "first_name", "identity_number", "visitor_photo", "identity_photo", "checked_in_visitor_id", "approval_starts_at", "approval_timeout_at", "approval_operational_start", "approval_operational_end", "approval_operational_days", "approval_holiday_dates", "approval_timeout_minutes", "approval_timezone"]
    },
    {
        table: "visitor_hosts",
        label: "Host",
        columns: ["host_id", "host_name", "host_email", "host_whatsapp", "location", "note", "approval_schedule_override", "approval_operational_start", "approval_operational_end", "approval_operational_days", "approval_national_holidays_closed", "approval_collective_leave_closed"]
    },
    {
        table: "self_registration_settings",
        label: "Self Registration Settings",
        columns: ["setting_id", "approval_mode", "bm_timeout_minutes", "host_timeout_minutes", "approval_timezone", "bm_operational_start", "bm_operational_end", "default_host_operational_start", "default_host_operational_end", "bm_operational_days", "default_host_operational_days", "national_holidays_closed", "collective_leave_closed"]
    },
    {
        table: "self_registration_holidays",
        label: "Self Registration Holiday Calendar",
        columns: ["holiday_id", "holiday_date", "holiday_name", "holiday_type", "is_active", "created_by", "created_at"]
    },
    {
        table: "permission_groups",
        label: "Permission Group",
        columns: ["group_id", "group_name", "integration_id", "floor_id"]
    },
    {
        table: "devices",
        label: "Device",
        columns: ["device_id", "device_name", "device_type", "provider_type", "base_url", "endpoint_path", "http_method", "auth_type", "is_active"]
    },
    {
        table: "permission_group_devices",
        label: "Permission Group Device Mapping",
        columns: ["group_id", "device_id", "created_time"]
    },
    {
        table: "device_sync_logs",
        label: "Device Sync Logs",
        columns: ["log_id", "device_id", "visitor_id", "action_type", "request_url", "response_status", "status", "created_time"]
    },
    {
        table: "maintenance_settings",
        label: "Maintenance Settings",
        columns: ["setting_id", "backup_enabled", "cleanup_enabled", "db_limit_mb", "operation_mode", "idle_logout_enabled"]
    },
    {
        table: "maintenance_jobs",
        label: "Software Activity Log",
        columns: ["job_id", "job_type", "status", "message", "created_by", "started_at", "finished_at"]
    },
    {
        table: "third_party_api_configs",
        label: "API Configuration",
        columns: ["config_id", "config_name", "provider_type", "trigger_event", "is_active", "project_id"]
    },
    {
        table: "api_activity_logs",
        label: "API Activity Log",
        columns: ["log_id", "config_name", "action_type", "request_url", "response_status", "created_time"]
    },
    {
        table: "gateway_api_logs",
        label: "Gateway API Logs",
        columns: ["log_id", "request_id", "source_system", "action", "trigger_event", "status", "created_time"]
    },
    {
        table: "gateway_api_settings",
        label: "Gateway API",
        columns: ["setting_id", "enabled", "api_key", "gateway_username", "gateway_password", "default_mode"]
    },
    {
        table: "middleware_projects",
        label: "Middleware Project",
        columns: ["project_id", "project_name", "project_code", "source_system", "destination_system", "is_active"]
    },
    {
        table: "middleware_source_configs",
        label: "Middleware Source",
        columns: ["config_id", "project_id", "config_name", "provider_type", "entity_type", "is_active"]
    },
    {
        table: "middleware_sync_events",
        label: "Middleware Sync Logs",
        columns: ["event_id", "project_id", "source_user_id", "event_type", "status", "created_time"]
    },
    {
        table: "system_notifications",
        label: "Notifications",
        columns: ["notification_id", "channel", "event_type", "title", "message", "status", "created_time"]
    },
    {
        table: "software_update_jobs",
        label: "Software Update",
        columns: ["job_id", "action", "status", "version_from", "version_to", "message", "started_at"]
    }
];

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function isSuperAdmin(req) {
    return String(req.session?.role_name || "").toUpperCase() === "SUPERADMIN";
}

function requireSuperAdmin(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    if (!isSuperAdmin(req)) {
        return res.status(403).json({ success: false, message: "Hanya SUPERADMIN yang bisa mengubah pengaturan ini" });
    }

    next();
}

function requireLoggedIn(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    next();
}

function getDbConfig() {
    return {
        user: pool.options.user,
        host: pool.options.host,
        database: pool.options.database,
        password: pool.options.password,
        port: pool.options.port
    };
}

function normalizeTime(value, fallback = "23:00") {
    const text = String(value || "").trim();
    return /^\d{2}:\d{2}$/.test(text) ? text : fallback;
}

function normalizeDate(value) {
    const text = String(value || "").trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : new Date().toISOString().slice(0, 10);
}

function normalizeScheduleType(value, fallback) {
    const type = String(value || fallback || "DAILY").trim().toUpperCase();
    return ["ONCE", "DAILY", "MONTHLY", "YEARLY"].includes(type) ? type : fallback;
}

function normalizeFolder(value, fallback) {
    const folder = String(value || "").trim();
    return folder || fallback;
}

function normalizeDbGuardAction(value) {
    const action = String(value || "LOG_ONLY").trim().toUpperCase();
    return ["LOG_ONLY", "BACKUP_ONLY", "CLEANUP_LOGS", "BACKUP_CLEANUP_LOGS"].includes(action) ? action : "LOG_ONLY";
}

function normalizeOperationMode(value) {
    const mode = String(value || "VISITOR_REGISTRATION").trim().toUpperCase();
    return ["VISITOR_REGISTRATION", "MIDDLEWARE_SYNC"].includes(mode) ? mode : "VISITOR_REGISTRATION";
}

function clampNumber(value, fallback, min, max) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.min(Math.max(number, min), max);
}

function ensureDirectory(folder) {
    fs.mkdirSync(folder, { recursive: true });
}

function pad2(value) {
    return String(value).padStart(2, "0");
}

function timestampForFile(date = new Date()) {
    return [
        date.getFullYear(),
        pad2(date.getMonth() + 1),
        pad2(date.getDate())
    ].join("-") + "_" + [
        pad2(date.getHours()),
        pad2(date.getMinutes()),
        pad2(date.getSeconds())
    ].join("");
}

function findPgExecutable(name) {
    const executableName = process.platform === "win32" ? `${name}.exe` : name;
    const candidates = [
        process.env.PG_BIN_DIR ? path.join(process.env.PG_BIN_DIR, executableName) : null,
        `C:\\Program Files\\PostgreSQL\\17\\bin\\${executableName}`,
        `C:\\Program Files\\PostgreSQL\\16\\bin\\${executableName}`,
        `C:\\Program Files\\PostgreSQL\\15\\bin\\${executableName}`,
        `C:\\Program Files\\PostgreSQL\\14\\bin\\${executableName}`,
        `C:\\Program Files\\PostgreSQL\\13\\bin\\${executableName}`,
        executableName
    ].filter(Boolean);

    for (const candidate of candidates) {
        if (candidate === executableName || fs.existsSync(candidate)) return candidate;
    }

    return executableName;
}

function runProcess(command, args, options = {}) {
    return new Promise((resolve, reject) => {
        const child = spawn(command, args, {
            windowsHide: true,
            ...options,
            env: {
                ...process.env,
                ...(options.env || {})
            }
        });

        let stdout = "";
        let stderr = "";

        child.stdout?.on("data", chunk => {
            stdout += chunk.toString();
        });

        child.stderr?.on("data", chunk => {
            stderr += chunk.toString();
        });

        child.on("error", reject);
        child.on("close", code => {
            if (code === 0) {
                resolve({ stdout, stderr });
                return;
            }
            reject(new Error(stderr || stdout || `${command} exited with code ${code}`));
        });
    });
}

async function ensureMaintenanceSchema() {
    if (schemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS maintenance_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            backup_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            backup_folder TEXT,
            backup_date DATE DEFAULT CURRENT_DATE,
            backup_time VARCHAR(5) NOT NULL DEFAULT '23:00',
            backup_schedule_type VARCHAR(20) NOT NULL DEFAULT 'DAILY',
            backup_keep_files INTEGER NOT NULL DEFAULT 30,
            cleanup_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            cleanup_date DATE DEFAULT CURRENT_DATE,
            cleanup_time VARCHAR(5) NOT NULL DEFAULT '23:30',
            cleanup_schedule_type VARCHAR(20) NOT NULL DEFAULT 'MONTHLY',
            cleanup_export_before_delete BOOLEAN NOT NULL DEFAULT TRUE,
            cleanup_export_folder TEXT,
            cleanup_activity_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            cleanup_api_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            cleanup_sync_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            cleanup_visitor_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            cleanup_all_activity BOOLEAN NOT NULL DEFAULT FALSE,
            cleanup_all_api BOOLEAN NOT NULL DEFAULT FALSE,
            cleanup_all_sync BOOLEAN NOT NULL DEFAULT FALSE,
            cleanup_all_visitor BOOLEAN NOT NULL DEFAULT FALSE,
            retention_activity_days INTEGER NOT NULL DEFAULT 180,
            retention_api_days INTEGER NOT NULL DEFAULT 90,
            retention_sync_days INTEGER NOT NULL DEFAULT 90,
            retention_visitor_days INTEGER NOT NULL DEFAULT 365,
            web_host VARCHAR(80) NOT NULL DEFAULT '0.0.0.0',
            web_port INTEGER NOT NULL DEFAULT 3000,
            db_guard_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            db_limit_mb INTEGER NOT NULL DEFAULT 51200,
            db_warning_percent INTEGER NOT NULL DEFAULT 80,
            db_critical_percent INTEGER NOT NULL DEFAULT 95,
            db_critical_action VARCHAR(30) NOT NULL DEFAULT 'LOG_ONLY',
            db_guard_cleanup_activity_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            db_guard_cleanup_api_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            db_guard_cleanup_sync_enabled BOOLEAN NOT NULL DEFAULT TRUE,
            db_guard_cleanup_visitor_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            operation_mode VARCHAR(30) NOT NULL DEFAULT 'VISITOR_REGISTRATION',
            db_guard_last_status VARCHAR(20),
            db_guard_last_log_at TIMESTAMP,
            last_backup_at TIMESTAMP,
            last_cleanup_at TIMESTAMP,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS maintenance_jobs (
            job_id SERIAL PRIMARY KEY,
            job_type VARCHAR(30) NOT NULL,
            status VARCHAR(20) NOT NULL,
            message TEXT,
            file_path TEXT,
            file_size BIGINT,
            records_exported INTEGER DEFAULT 0,
            records_deleted INTEGER DEFAULT 0,
            created_by VARCHAR(100),
            started_at TIMESTAMP DEFAULT NOW(),
            finished_at TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS backup_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS backup_folder TEXT");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS backup_date DATE DEFAULT CURRENT_DATE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS backup_time VARCHAR(5) NOT NULL DEFAULT '23:00'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS backup_schedule_type VARCHAR(20) NOT NULL DEFAULT 'DAILY'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS backup_keep_files INTEGER NOT NULL DEFAULT 30");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_date DATE DEFAULT CURRENT_DATE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_time VARCHAR(5) NOT NULL DEFAULT '23:30'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_schedule_type VARCHAR(20) NOT NULL DEFAULT 'MONTHLY'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_export_before_delete BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_export_folder TEXT");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_activity_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_api_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_sync_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_visitor_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_all_activity BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_all_api BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_all_sync BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS cleanup_all_visitor BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS retention_activity_days INTEGER NOT NULL DEFAULT 180");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS retention_api_days INTEGER NOT NULL DEFAULT 90");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS retention_sync_days INTEGER NOT NULL DEFAULT 90");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS retention_visitor_days INTEGER NOT NULL DEFAULT 365");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS web_host VARCHAR(80) NOT NULL DEFAULT '0.0.0.0'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS web_port INTEGER NOT NULL DEFAULT 3000");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_limit_mb INTEGER NOT NULL DEFAULT 51200");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_warning_percent INTEGER NOT NULL DEFAULT 80");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_critical_percent INTEGER NOT NULL DEFAULT 95");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_critical_action VARCHAR(30) NOT NULL DEFAULT 'LOG_ONLY'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_cleanup_activity_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_cleanup_api_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_cleanup_sync_enabled BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_cleanup_visitor_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS operation_mode VARCHAR(30) NOT NULL DEFAULT 'VISITOR_REGISTRATION'");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_last_status VARCHAR(20)");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS db_guard_last_log_at TIMESTAMP");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS last_backup_at TIMESTAMP");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS last_cleanup_at TIMESTAMP");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS idle_logout_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS idle_logout_minutes INTEGER NOT NULL DEFAULT 30");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO maintenance_settings (setting_id, backup_folder, cleanup_export_folder)
        VALUES (1, $1, $2)
        ON CONFLICT (setting_id) DO NOTHING
    `, [DEFAULT_BACKUP_FOLDER, DEFAULT_CLEANUP_FOLDER]);

    schemaReady = true;
}

async function getMaintenanceSettings() {
    await ensureMaintenanceSchema();
    const result = await pool.query("SELECT * FROM maintenance_settings WHERE setting_id = 1");
    return result.rows[0] || {};
}

async function createJob(jobType, createdBy) {
    const result = await pool.query(
        `INSERT INTO maintenance_jobs (job_type, status, created_by, started_at)
         VALUES ($1, 'RUNNING', $2, NOW())
         RETURNING *`,
        [jobType, createdBy]
    );
    return result.rows[0];
}

async function finishJob(jobId, detail) {
    await pool.query(
        `UPDATE maintenance_jobs
         SET status = $1,
             message = $2,
             file_path = $3,
             file_size = $4,
             records_exported = $5,
             records_deleted = $6,
             finished_at = NOW()
         WHERE job_id = $7`,
        [
            detail.status,
            detail.message || null,
            detail.file_path || null,
            detail.file_size || null,
            detail.records_exported || 0,
            detail.records_deleted || 0,
            jobId
        ]
    );
}

async function createInstantJob(jobType, status, message, createdBy, extra = {}) {
    const result = await pool.query(
        `INSERT INTO maintenance_jobs
            (job_type, status, message, file_path, file_size, records_exported, records_deleted, created_by, started_at, finished_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
         RETURNING *`,
        [
            jobType,
            status,
            message || null,
            extra.file_path || null,
            extra.file_size || null,
            extra.records_exported || 0,
            extra.records_deleted || 0,
            createdBy
        ]
    );
    return result.rows[0];
}

function cleanupOldBackupFiles(folder, keepFiles) {
    const keep = Number(keepFiles || 30);
    if (!keep || keep < 1) return;
    if (!fs.existsSync(folder)) return;

    const files = fs.readdirSync(folder)
        .filter(file => /^innersync_full_backup_.*\.backup$/i.test(file))
        .map(file => {
            const fullPath = path.join(folder, file);
            const stat = fs.statSync(fullPath);
            return { fullPath, mtimeMs: stat.mtimeMs };
        })
        .sort((a, b) => b.mtimeMs - a.mtimeMs);

    files.slice(keep).forEach(file => {
        try {
            fs.unlinkSync(file.fullPath);
        } catch (error) {
            console.log("DELETE OLD BACKUP ERROR:", error.message);
        }
    });
}

async function runFullBackup(createdBy = "SYSTEM") {
    if (runningBackup) {
        throw new Error("Backup sedang berjalan. Tunggu proses sebelumnya selesai.");
    }

    runningBackup = true;
    let job;
    try {
        await ensureMaintenanceSchema();
        const settings = await getMaintenanceSettings();
        const folder = normalizeFolder(settings.backup_folder, DEFAULT_BACKUP_FOLDER);
        ensureDirectory(folder);

        job = await createJob("BACKUP", createdBy);
        const db = getDbConfig();
        const filePath = path.join(folder, `innersync_full_backup_${timestampForFile()}.backup`);
        const pgDump = findPgExecutable("pg_dump");
        const args = [
            "-h", db.host,
            "-p", String(db.port),
            "-U", db.user,
            "-F", "c",
            "-b",
            "-v",
            "-f", filePath,
            db.database
        ];

        await runProcess(pgDump, args, { env: { PGPASSWORD: db.password } });
        const stat = fs.statSync(filePath);
        cleanupOldBackupFiles(folder, settings.backup_keep_files);
        await pool.query("UPDATE maintenance_settings SET last_backup_at = NOW() WHERE setting_id = 1");
        await finishJob(job.job_id, {
            status: "SUCCESS",
            message: "Full database backup berhasil.",
            file_path: filePath,
            file_size: stat.size
        });
        return { file_path: filePath, file_size: stat.size };
    } catch (error) {
        if (job?.job_id) {
            await finishJob(job.job_id, {
                status: "FAILED",
                message: error.message
            });
        }
        throw error;
    } finally {
        runningBackup = false;
    }
}

async function getDatabaseHealthReport() {
    const items = [];
    const initializerExists = fs.existsSync(DATABASE_INITIALIZER_SCRIPT);

    items.push({
        object_type: "FILE",
        object_name: "scripts/initialize-database.js",
        label: "Database Initializer",
        status: initializerExists ? "OK" : "MISSING",
        detail: initializerExists
            ? "Initializer repair tersedia."
            : "File initializer tidak ditemukan, repair otomatis tidak bisa dijalankan."
    });

    for (const schema of DATABASE_HEALTH_SCHEMA) {
        const tableName = schema.table;
        const tableResult = await pool.query("SELECT to_regclass($1) AS table_ref", [`public.${tableName}`]);
        const tableExists = Boolean(tableResult.rows[0]?.table_ref);

        items.push({
            object_type: "TABLE",
            object_name: tableName,
            label: schema.label,
            status: tableExists ? "OK" : "MISSING",
            detail: tableExists ? "Tabel tersedia." : "Tabel belum ditemukan."
        });

        if (!tableExists) continue;

        const columnResult = await pool.query(
            `SELECT column_name
             FROM information_schema.columns
             WHERE table_schema = 'public'
               AND table_name = $1`,
            [tableName]
        );
        const existingColumns = new Set(columnResult.rows.map(row => String(row.column_name || "").toLowerCase()));

        for (const columnName of schema.columns || []) {
            const exists = existingColumns.has(String(columnName).toLowerCase());
            items.push({
                object_type: "COLUMN",
                object_name: `${tableName}.${columnName}`,
                label: schema.label,
                status: exists ? "OK" : "MISSING",
                detail: exists ? "Kolom tersedia." : "Kolom belum ditemukan."
            });
        }
    }

    const summary = items.reduce((acc, item) => {
        const key = String(item.status || "UNKNOWN").toLowerCase();
        acc.total += 1;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
    }, { total: 0, ok: 0, missing: 0, failed: 0, warning: 0 });

    return {
        checked_at: new Date().toISOString(),
        summary,
        items
    };
}

function runDatabaseInitializerProcess() {
    if (!fs.existsSync(DATABASE_INITIALIZER_SCRIPT)) {
        throw new Error(`File initializer tidak ditemukan: ${DATABASE_INITIALIZER_SCRIPT}`);
    }

    return runProcess(process.execPath, [DATABASE_INITIALIZER_SCRIPT], {
        cwd: process.cwd()
    });
}

async function runDatabaseRepair(createdBy = "SYSTEM") {
    await ensureMaintenanceSchema();
    const before = await getDatabaseHealthReport();
    const job = await createJob("DB_REPAIR", createdBy);
    let backupResult = null;
    let backupWarning = null;

    try {
        try {
            backupResult = await runFullBackup(`${createdBy}_DB_REPAIR`);
        } catch (backupError) {
            backupWarning = `Backup sebelum repair gagal: ${backupError.message}`;
        }

        const processResult = await runDatabaseInitializerProcess();
        const after = await getDatabaseHealthReport();
        const stillMissing = Number(after.summary?.missing || 0);
        const status = stillMissing > 0 ? "FAILED" : "SUCCESS";
        const messageParts = [
            stillMissing > 0
                ? `Repair selesai, tetapi masih ada ${stillMissing} item database yang belum tersedia.`
                : "Repair database selesai. Semua item utama tersedia."
        ];
        if (backupWarning) messageParts.push(backupWarning);

        await finishJob(job.job_id, {
            status,
            message: messageParts.join(" "),
            file_path: backupResult?.file_path || null,
            file_size: backupResult?.file_size || null
        });

        return {
            before,
            after,
            backup: backupResult,
            backup_warning: backupWarning,
            stdout: processResult.stdout,
            stderr: processResult.stderr
        };
    } catch (error) {
        await finishJob(job.job_id, {
            status: "FAILED",
            message: error.message,
            file_path: backupResult?.file_path || null,
            file_size: backupResult?.file_size || null
        });
        throw error;
    }
}

function csvEscape(value) {
    if (value === null || value === undefined) return "";
    const text = String(value);
    if (/[",\r\n]/.test(text)) {
        return `"${text.replace(/"/g, '""')}"`;
    }
    return text;
}

async function exportRowsToCsv(filePath, rows) {
    ensureDirectory(path.dirname(filePath));
    if (!rows.length) {
        fs.writeFileSync(filePath, "", "utf8");
        return;
    }

    const columns = Object.keys(rows[0]);
    const lines = [
        columns.map(csvEscape).join(","),
        ...rows.map(row => columns.map(column => csvEscape(row[column])).join(","))
    ];
    fs.writeFileSync(filePath, lines.join("\r\n"), "utf8");
}

async function cleanupTable(client, options) {
    const { tableName, label, dateColumn, whereSql, days, exportBeforeDelete, exportFolder, allRows, beforeDelete } = options;
    const retentionDays = Number(days || 0);
    if (!allRows && (!retentionDays || retentionDays < 1)) {
        return { exported: 0, deleted: 0, files: [] };
    }

    const tableCheck = await client.query("SELECT to_regclass($1) AS table_name", [tableName]);
    if (!tableCheck.rows[0]?.table_name) {
        return { exported: 0, deleted: 0, files: [] };
    }

    const filters = [];
    const params = [];
    if (!allRows) {
        const cutoffSql = `NOW() - ($1::int * INTERVAL '1 day')`;
        filters.push(`${dateColumn} < ${cutoffSql}`);
        params.push(retentionDays);
    }
    if (whereSql) filters.push(`(${whereSql})`);
    const whereClause = filters.length ? filters.join(" AND ") : "TRUE";

    const selectResult = await client.query(`SELECT * FROM ${tableName} WHERE ${whereClause}`, params);
    const rows = selectResult.rows;
    const files = [];

    if (exportBeforeDelete && rows.length > 0) {
        const filePath = path.join(exportFolder, `${label}_${timestampForFile()}.csv`);
        await exportRowsToCsv(filePath, rows);
        files.push(filePath);
    }

    if (rows.length > 0 && typeof beforeDelete === "function") {
        await beforeDelete(client, rows);
    }

    const deleteResult = await client.query(`DELETE FROM ${tableName} WHERE ${whereClause}`, params);
    return {
        exported: rows.length,
        deleted: deleteResult.rowCount || 0,
        files
    };
}

async function runCleanup(createdBy = "SYSTEM", overrideOptions = {}) {
    if (runningCleanup) {
        throw new Error("Cleanup sedang berjalan. Tunggu proses sebelumnya selesai.");
    }

    runningCleanup = true;
    let job;
    const client = await pool.connect();
    try {
        await ensureMaintenanceSchema();
        const settings = await getMaintenanceSettings();
        const exportFolder = normalizeFolder(settings.cleanup_export_folder, DEFAULT_CLEANUP_FOLDER);
        ensureDirectory(exportFolder);

        const cleanupActivityEnabled = overrideOptions.activityEnabled ?? (settings.cleanup_activity_enabled || settings.cleanup_all_activity);
        const cleanupApiEnabled = overrideOptions.apiEnabled ?? (settings.cleanup_api_enabled || settings.cleanup_all_api);
        const cleanupSyncEnabled = overrideOptions.syncEnabled ?? (settings.cleanup_sync_enabled || settings.cleanup_all_sync);
        const cleanupVisitorEnabled = overrideOptions.visitorEnabled ?? (settings.cleanup_visitor_enabled || settings.cleanup_all_visitor);

        job = await createJob(overrideOptions.jobType || "CLEANUP", createdBy);
        await client.query("BEGIN");

        const results = [];
        if (cleanupActivityEnabled) {
            results.push(await cleanupTable(client, {
                tableName: "activity_logs",
                label: "activity_logs",
                dateColumn: "created_at",
                days: settings.retention_activity_days,
                allRows: settings.cleanup_all_activity === true,
                exportBeforeDelete: settings.cleanup_export_before_delete,
                exportFolder
            }));
        }

        if (cleanupApiEnabled) {
            results.push(await cleanupTable(client, {
                tableName: "api_activity_logs",
                label: "api_activity_logs",
                dateColumn: "created_time",
                days: settings.retention_api_days,
                allRows: settings.cleanup_all_api === true,
                exportBeforeDelete: settings.cleanup_export_before_delete,
                exportFolder
            }));
            results.push(await cleanupTable(client, {
                tableName: "gateway_api_logs",
                label: "gateway_api_logs",
                dateColumn: "created_time",
                days: settings.retention_api_days,
                allRows: settings.cleanup_all_api === true,
                exportBeforeDelete: settings.cleanup_export_before_delete,
                exportFolder
            }));
            results.push(await cleanupTable(client, {
                tableName: "device_sync_logs",
                label: "device_sync_logs",
                dateColumn: "created_time",
                days: settings.retention_api_days,
                allRows: settings.cleanup_all_api === true,
                exportBeforeDelete: settings.cleanup_export_before_delete,
                exportFolder
            }));
        }

        if (cleanupSyncEnabled) {
            results.push(await cleanupTable(client, {
                tableName: "middleware_sync_events",
                label: "middleware_sync_events",
                dateColumn: "created_time",
                days: settings.retention_sync_days,
                allRows: settings.cleanup_all_sync === true,
                exportBeforeDelete: settings.cleanup_export_before_delete,
                exportFolder
            }));
        }

        if (cleanupVisitorEnabled) {
            results.push(await cleanupTable(client, {
                tableName: "visitor_registration",
                label: "visitor_registration",
                dateColumn: "check_out_time",
                whereSql: "check_out_time IS NOT NULL",
                days: settings.retention_visitor_days,
                allRows: settings.cleanup_all_visitor === true,
                exportBeforeDelete: settings.cleanup_export_before_delete,
                exportFolder,
                beforeDelete: async (cleanupClient, rows) => {
                    const visitorIds = rows.map(row => Number(row.visitor_id)).filter(Number.isInteger);
                    if (!visitorIds.length) return;
                    const relations = (await cleanupClient.query(
                        "SELECT to_regclass('self_registration_access_jobs') AS jobs, to_regclass('visitor_invitations') AS invitations"
                    )).rows[0];
                    if (relations?.jobs) {
                        await cleanupClient.query(
                            "UPDATE self_registration_access_jobs SET visitor_id=NULL,updated_at=NOW() WHERE visitor_id=ANY($1::int[])",
                            [visitorIds]
                        );
                    }
                    if (relations?.invitations) {
                        await cleanupClient.query(
                            "UPDATE visitor_invitations SET checked_in_visitor_id=NULL,modified_time=NOW() WHERE checked_in_visitor_id=ANY($1::int[])",
                            [visitorIds]
                        );
                    }
                }
            }));
        }

        await client.query("COMMIT");
        await pool.query("UPDATE maintenance_settings SET last_cleanup_at = NOW() WHERE setting_id = 1");

        const recordsExported = results.reduce((sum, item) => sum + item.exported, 0);
        const recordsDeleted = results.reduce((sum, item) => sum + item.deleted, 0);
        const files = results.flatMap(item => item.files);
        await finishJob(job.job_id, {
            status: "SUCCESS",
            message: `${overrideOptions.messagePrefix || "Cleanup selesai."} ${recordsDeleted} record dihapus.`,
            file_path: files.join("; "),
            records_exported: recordsExported,
            records_deleted: recordsDeleted
        });

        return { records_exported: recordsExported, records_deleted: recordsDeleted, files };
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        if (job?.job_id) {
            await finishJob(job.job_id, { status: "FAILED", message: error.message });
        }
        throw error;
    } finally {
        client.release();
        runningCleanup = false;
    }
}

function bytesToText(bytes) {
    const value = Number(bytes || 0);
    if (value >= 1024 ** 3) return `${(value / (1024 ** 3)).toFixed(2)} GB`;
    if (value >= 1024 ** 2) return `${(value / (1024 ** 2)).toFixed(2)} MB`;
    if (value >= 1024) return `${(value / 1024).toFixed(2)} KB`;
    return `${value} B`;
}

async function getDatabaseCapacitySnapshot(settingsOverride = null) {
    await ensureMaintenanceSchema();
    const settings = settingsOverride || await getMaintenanceSettings();
    const sizeResult = await pool.query("SELECT pg_database_size(current_database())::bigint AS total_size_bytes");
    const tableResult = await pool.query(`
        SELECT
            schemaname,
            relname AS table_name,
            n_live_tup::bigint AS row_estimate,
            pg_relation_size((quote_ident(schemaname) || '.' || quote_ident(relname))::regclass)::bigint AS table_size_bytes,
            pg_indexes_size((quote_ident(schemaname) || '.' || quote_ident(relname))::regclass)::bigint AS index_size_bytes,
            pg_total_relation_size((quote_ident(schemaname) || '.' || quote_ident(relname))::regclass)::bigint AS total_size_bytes
        FROM pg_stat_user_tables
        ORDER BY pg_total_relation_size((quote_ident(schemaname) || '.' || quote_ident(relname))::regclass) DESC
    `);

    const limitMb = clampNumber(settings.db_limit_mb, DEFAULT_DB_LIMIT_MB, 1, 1048576);
    const warningPercent = clampNumber(settings.db_warning_percent, 80, 1, 99);
    const criticalPercent = clampNumber(settings.db_critical_percent, 95, warningPercent + 1, 100);
    const limitBytes = limitMb * 1024 * 1024;
    const totalSizeBytes = Number(sizeResult.rows[0]?.total_size_bytes || 0);
    const usedPercent = limitBytes > 0 ? (totalSizeBytes / limitBytes) * 100 : 0;
    const status = usedPercent >= criticalPercent ? "CRITICAL" : usedPercent >= warningPercent ? "WARNING" : "NORMAL";

    const tables = tableResult.rows.map(row => ({
        ...row,
        row_estimate: Number(row.row_estimate || 0),
        table_size_bytes: Number(row.table_size_bytes || 0),
        index_size_bytes: Number(row.index_size_bytes || 0),
        total_size_bytes: Number(row.total_size_bytes || 0),
        database_percent: totalSizeBytes ? (Number(row.total_size_bytes || 0) / totalSizeBytes) * 100 : 0
    }));

    return {
        database: getDbConfig().database,
        total_size_bytes: totalSizeBytes,
        total_size_text: bytesToText(totalSizeBytes),
        limit_mb: limitMb,
        limit_bytes: limitBytes,
        limit_text: bytesToText(limitBytes),
        used_percent: Number(usedPercent.toFixed(2)),
        warning_percent: warningPercent,
        critical_percent: criticalPercent,
        status,
        guard_enabled: settings.db_guard_enabled === true,
        critical_action: normalizeDbGuardAction(settings.db_critical_action),
        table_count: tables.length,
        tables
    };
}

function cloneDatabaseCapacitySnapshot(snapshot, meta = {}) {
    if (!snapshot) return null;
    return {
        ...snapshot,
        tables: Array.isArray(snapshot.tables) ? snapshot.tables.map(row => ({ ...row })) : [],
        cache: {
            cached_at: databaseCapacityCacheAt ? new Date(databaseCapacityCacheAt).toISOString() : null,
            ttl_ms: DB_CAPACITY_CACHE_TTL_MS,
            age_ms: databaseCapacityCacheAt ? Date.now() - databaseCapacityCacheAt : null,
            ...meta
        }
    };
}

function setDatabaseCapacityCache(snapshot) {
    databaseCapacityCache = cloneDatabaseCapacitySnapshot(snapshot, { from_cache: false });
    if (databaseCapacityCache?.cache) delete databaseCapacityCache.cache;
    databaseCapacityCacheAt = Date.now();
}

function clearDatabaseCapacityCache() {
    databaseCapacityCache = null;
    databaseCapacityCacheAt = 0;
}

async function refreshDatabaseCapacityCache(settingsOverride = null) {
    if (databaseCapacityRefreshPromise) return databaseCapacityRefreshPromise;
    databaseCapacityRefreshPromise = getDatabaseCapacitySnapshot(settingsOverride)
        .then(snapshot => {
            setDatabaseCapacityCache(snapshot);
            return cloneDatabaseCapacitySnapshot(snapshot, { from_cache: false, refreshing: false });
        })
        .finally(() => {
            databaseCapacityRefreshPromise = null;
        });
    return databaseCapacityRefreshPromise;
}

async function getCachedDatabaseCapacitySnapshot(options = {}) {
    const force = options.force === true;
    const allowStale = options.allowStale !== false;
    const now = Date.now();
    const hasCache = Boolean(databaseCapacityCache);
    const cacheAge = now - databaseCapacityCacheAt;
    const cacheFresh = hasCache && cacheAge < DB_CAPACITY_CACHE_TTL_MS;

    if (!force && cacheFresh) {
        return cloneDatabaseCapacitySnapshot(databaseCapacityCache, { from_cache: true, stale: false, refreshing: false });
    }

    if (!force && hasCache && allowStale) {
        if (!databaseCapacityRefreshPromise) {
            refreshDatabaseCapacityCache().catch(error => console.log("DB CAPACITY CACHE REFRESH ERROR:", error.message));
        }
        return cloneDatabaseCapacitySnapshot(databaseCapacityCache, { from_cache: true, stale: true, refreshing: true });
    }

    return refreshDatabaseCapacityCache(options.settingsOverride || null);
}

function isSameLocalDate(dateValue) {
    if (!dateValue) return false;
    const date = new Date(dateValue);
    const now = new Date();
    return date.getFullYear() === now.getFullYear()
        && date.getMonth() === now.getMonth()
        && date.getDate() === now.getDate();
}

async function runDatabaseCapacityGuard(createdBy = "SCHEDULER", forceLog = false) {
    if (runningDbGuard) return null;
    runningDbGuard = true;
    try {
        const settings = await getMaintenanceSettings();
        const snapshot = await getDatabaseCapacitySnapshot(settings);
        setDatabaseCapacityCache(snapshot);
        if (settings.db_guard_enabled !== true || snapshot.status === "NORMAL") {
            if (snapshot.status === "NORMAL" && settings.db_guard_last_status !== "NORMAL") {
                await pool.query(
                    "UPDATE maintenance_settings SET db_guard_last_status = 'NORMAL', db_guard_last_log_at = NULL WHERE setting_id = 1"
                );
            }
            return snapshot;
        }

        const alreadyLoggedToday = settings.db_guard_last_status === snapshot.status && isSameLocalDate(settings.db_guard_last_log_at);
        if (!forceLog && alreadyLoggedToday) return snapshot;

        const action = normalizeDbGuardAction(settings.db_critical_action);
        const actionText = snapshot.status === "CRITICAL" ? ` Action: ${action}.` : "";
        await createInstantJob(
            "DB_CAPACITY",
            snapshot.status,
            `Database ${snapshot.database} ${snapshot.status}. Terpakai ${snapshot.total_size_text} dari limit ${snapshot.limit_text} (${snapshot.used_percent}%).${actionText}`,
            createdBy,
            { file_size: snapshot.total_size_bytes }
        );

        await pool.query(
            "UPDATE maintenance_settings SET db_guard_last_status = $1, db_guard_last_log_at = NOW() WHERE setting_id = 1",
            [snapshot.status]
        );

        if (snapshot.status === "CRITICAL") {
            if (action === "BACKUP_ONLY" || action === "BACKUP_CLEANUP_LOGS") {
                await runFullBackup("DB_CAPACITY_GUARD").catch(error => console.log("DB GUARD BACKUP ERROR:", error.message));
            }
            if (action === "CLEANUP_LOGS" || action === "BACKUP_CLEANUP_LOGS") {
                await runCleanup("DB_CAPACITY_GUARD", {
                    jobType: "CLEANUP",
                    messagePrefix: "Database capacity guard cleanup selesai.",
                    activityEnabled: settings.db_guard_cleanup_activity_enabled,
                    apiEnabled: settings.db_guard_cleanup_api_enabled,
                    syncEnabled: settings.db_guard_cleanup_sync_enabled,
                    visitorEnabled: settings.db_guard_cleanup_visitor_enabled
                }).catch(error => console.log("DB GUARD CLEANUP ERROR:", error.message));
            }
        }

        return snapshot;
    } finally {
        runningDbGuard = false;
    }
}

async function runRestore(filePath, createdBy = "SYSTEM") {
    let job;
    try {
        await ensureMaintenanceSchema();
        job = await createJob("RESTORE", createdBy);
        const db = getDbConfig();
        const pgRestore = findPgExecutable("pg_restore");
        const args = [
            "-h", db.host,
            "-p", String(db.port),
            "-U", db.user,
            "-d", db.database,
            "--clean",
            "--if-exists",
            "--no-owner",
            "--no-privileges",
            filePath
        ];

        await runProcess(pgRestore, args, { env: { PGPASSWORD: db.password } });
        await finishJob(job.job_id, {
            status: "SUCCESS",
            message: "Restore database berhasil. Restart service disarankan.",
            file_path: filePath
        });
        return { restored_file: filePath };
    } catch (error) {
        if (job?.job_id) {
            await finishJob(job.job_id, { status: "FAILED", message: error.message, file_path: filePath });
        }
        throw error;
    }
}

function shouldRunSchedule(lastRun, scheduledDate, scheduledTime) {
    const now = new Date();
    const todayKey = now.toISOString().slice(0, 10);
    const currentTime = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
    const lastRunKey = lastRun ? new Date(lastRun).toISOString().slice(0, 10) : "";
    const scheduleDateKey = normalizeDate(scheduledDate);
    return todayKey >= scheduleDateKey && currentTime === scheduledTime && lastRunKey !== todayKey;
}

function addScheduleInterval(dateValue, scheduleType) {
    const date = new Date(`${normalizeDate(dateValue)}T00:00:00`);
    if (scheduleType === "MONTHLY") date.setMonth(date.getMonth() + 1);
    else if (scheduleType === "YEARLY") date.setFullYear(date.getFullYear() + 1);
    else date.setDate(date.getDate() + 1);
    return date.toISOString().slice(0, 10);
}

async function advanceScheduleDate(columnName, enabledColumnName, scheduleType, currentDateValue) {
    const allowedColumns = ["backup_date", "cleanup_date"];
    const allowedEnabledColumns = ["backup_enabled", "cleanup_enabled"];
    if (!allowedColumns.includes(columnName)) return;
    if (!allowedEnabledColumns.includes(enabledColumnName)) return;

    if (scheduleType === "ONCE") {
        await pool.query(`UPDATE maintenance_settings SET ${enabledColumnName} = FALSE WHERE setting_id = 1`);
        return;
    }

    const nextDate = addScheduleInterval(currentDateValue, scheduleType);
    await pool.query(`UPDATE maintenance_settings SET ${columnName} = $1 WHERE setting_id = 1`, [nextDate]);
}

async function runSchedulerTick() {
    try {
        const settings = await getMaintenanceSettings();
        const backupScheduleType = normalizeScheduleType(settings.backup_schedule_type, "DAILY");
        const cleanupScheduleType = normalizeScheduleType(settings.cleanup_schedule_type, "MONTHLY");
        if (settings.backup_enabled && shouldRunSchedule(settings.last_backup_at, settings.backup_date, normalizeTime(settings.backup_time))) {
            runFullBackup("SCHEDULER")
                .then(() => advanceScheduleDate("backup_date", "backup_enabled", backupScheduleType, settings.backup_date))
                .catch(error => console.log("AUTO BACKUP ERROR:", error.message));
        }
        if (settings.cleanup_enabled && shouldRunSchedule(settings.last_cleanup_at, settings.cleanup_date, normalizeTime(settings.cleanup_time, "23:30"))) {
            runCleanup("SCHEDULER")
                .then(() => advanceScheduleDate("cleanup_date", "cleanup_enabled", cleanupScheduleType, settings.cleanup_date))
                .catch(error => console.log("AUTO CLEANUP ERROR:", error.message));
        }
        runDatabaseCapacityGuard("SCHEDULER").catch(error => console.log("DB CAPACITY GUARD ERROR:", error.message));
    } catch (error) {
        console.log("MAINTENANCE SCHEDULER ERROR:", error.message);
    }
}

function startMaintenanceScheduler() {
    if (schedulerStarted) return;
    schedulerStarted = true;
    setInterval(runSchedulerTick, 60 * 1000);
    setTimeout(runSchedulerTick, 5000);
    setTimeout(() => {
        refreshDatabaseCapacityCache().catch(error => console.log("DB CAPACITY CACHE WARMUP ERROR:", error.message));
    }, 1500);
}

async function getServerListenSettings() {
    try {
        const settings = await getMaintenanceSettings();
        return {
            host: settings.web_host || process.env.HOST || "0.0.0.0",
            port: Number(settings.web_port || process.env.PORT || 3000)
        };
    } catch (error) {
        return {
            host: process.env.HOST || "0.0.0.0",
            port: Number(process.env.PORT || 3000)
        };
    }
}

const MAINTENANCE_SCHEMA_PATHS = [
    "/api/maintenance-settings",
    "/api/operation-mode",
    "/api/database-capacity",
    "/api/database-health",
    "/api/maintenance",
    "/api/maintenance-jobs"
];

router.use(MAINTENANCE_SCHEMA_PATHS, async (req, res, next) => {
    try {
        await ensureMaintenanceSchema();
        next();
    } catch (error) {
        next(error);
    }
});

router.get("/api/maintenance-settings", async (req, res) => {
    try {
        const settings = await getMaintenanceSettings();
        res.json({
            success: true,
            data: {
                ...settings,
                backup_folder: settings.backup_folder || DEFAULT_BACKUP_FOLDER,
                cleanup_export_folder: settings.cleanup_export_folder || DEFAULT_CLEANUP_FOLDER
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/operation-mode", async (req, res) => {
    try {
        const settings = await getMaintenanceSettings();
        res.json({
            success: true,
            data: {
                operation_mode: normalizeOperationMode(settings.operation_mode)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/operation-mode", requireSuperAdmin, async (req, res) => {
    try {
        const mode = normalizeOperationMode(req.body?.operation_mode);
        const result = await pool.query(
            `UPDATE maintenance_settings
             SET operation_mode = $1,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING operation_mode`,
            [mode]
        );

        await pool.query(`
            UPDATE middleware_sync_settings
            SET is_active = $1,
                auto_run = $1,
                modified_by = $2,
                modified_time = NOW()
            WHERE setting_id = 1
        `, [mode === "MIDDLEWARE_SYNC", getCurrentUsername(req)]).catch(() => {});

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/session-settings", requireLoggedIn, async (req, res) => {
    try {
        const settings = await getSessionSettings();
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/session-settings", requireSuperAdmin, async (req, res) => {
    try {
        const settings = await saveSessionSettings(req.body || {});
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/maintenance-settings", async (req, res) => {
    try {
        const body = req.body || {};
        const backupKeepFiles = Math.min(Math.max(Number(body.backup_keep_files || 30), 1), 365);
        const webPort = Math.min(Math.max(Number(body.web_port || 3000), 1), 65535);
        const webHost = String(body.web_host || "0.0.0.0").trim();
        const dbWarningPercent = clampNumber(body.db_warning_percent, 80, 1, 99);
        const dbCriticalPercent = clampNumber(body.db_critical_percent, 95, dbWarningPercent + 1, 100);

        const currentSettings = await getMaintenanceSettings();
        const superAdmin = isSuperAdmin(req);
        const operationMode = superAdmin
            ? normalizeOperationMode(body.operation_mode)
            : normalizeOperationMode(currentSettings.operation_mode);
        const cleanupApiEnabled = superAdmin ? body.cleanup_api_enabled !== false : currentSettings.cleanup_api_enabled !== false;
        const cleanupSyncEnabled = superAdmin ? body.cleanup_sync_enabled !== false : currentSettings.cleanup_sync_enabled !== false;
        const cleanupAllApi = superAdmin ? body.cleanup_all_api === true : currentSettings.cleanup_all_api === true;
        const cleanupAllSync = superAdmin ? body.cleanup_all_sync === true : currentSettings.cleanup_all_sync === true;
        const retentionApiDays = superAdmin
            ? Math.max(Number(body.retention_api_days || 90), 1)
            : Math.max(Number(currentSettings.retention_api_days || 90), 1);
        const retentionSyncDays = superAdmin
            ? Math.max(Number(body.retention_sync_days || 90), 1)
            : Math.max(Number(currentSettings.retention_sync_days || 90), 1);
        const dbGuardCleanupApiEnabled = superAdmin ? body.db_guard_cleanup_api_enabled !== false : currentSettings.db_guard_cleanup_api_enabled !== false;
        const dbGuardCleanupSyncEnabled = superAdmin ? body.db_guard_cleanup_sync_enabled !== false : currentSettings.db_guard_cleanup_sync_enabled !== false;
        const result = await pool.query(
            `UPDATE maintenance_settings
             SET backup_enabled = $1,
                 backup_folder = $2,
                 backup_date = $3,
                 backup_time = $4,
                 backup_schedule_type = $5,
                 backup_keep_files = $6,
                 cleanup_enabled = $7,
                 cleanup_date = $8,
                 cleanup_time = $9,
                 cleanup_schedule_type = $10,
                 cleanup_export_before_delete = $11,
                 cleanup_export_folder = $12,
                 cleanup_activity_enabled = $13,
                 cleanup_api_enabled = $14,
                 cleanup_sync_enabled = $15,
                 cleanup_visitor_enabled = $16,
                 cleanup_all_activity = $17,
                 cleanup_all_api = $18,
                 cleanup_all_sync = $19,
                 cleanup_all_visitor = $20,
                 retention_activity_days = $21,
                 retention_api_days = $22,
                 retention_sync_days = $23,
                 retention_visitor_days = $24,
                 web_host = $25,
                 web_port = $26,
                 db_guard_enabled = $27,
                 db_limit_mb = $28,
                 db_warning_percent = $29,
                 db_critical_percent = $30,
                 db_critical_action = $31,
                 db_guard_cleanup_activity_enabled = $32,
                 db_guard_cleanup_api_enabled = $33,
                 db_guard_cleanup_sync_enabled = $34,
                 db_guard_cleanup_visitor_enabled = $35,
                 operation_mode = $36,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                body.backup_enabled === true,
                normalizeFolder(body.backup_folder, DEFAULT_BACKUP_FOLDER),
                normalizeDate(body.backup_date),
                normalizeTime(body.backup_time),
                normalizeScheduleType(body.backup_schedule_type, "DAILY"),
                backupKeepFiles,
                body.cleanup_enabled === true,
                normalizeDate(body.cleanup_date),
                normalizeTime(body.cleanup_time, "23:30"),
                normalizeScheduleType(body.cleanup_schedule_type, "MONTHLY"),
                body.cleanup_export_before_delete !== false,
                normalizeFolder(body.cleanup_export_folder, DEFAULT_CLEANUP_FOLDER),
                body.cleanup_activity_enabled !== false,
                cleanupApiEnabled,
                cleanupSyncEnabled,
                body.cleanup_visitor_enabled === true,
                body.cleanup_all_activity === true,
                cleanupAllApi,
                cleanupAllSync,
                body.cleanup_all_visitor === true,
                Math.max(Number(body.retention_activity_days || 180), 1),
                retentionApiDays,
                retentionSyncDays,
                Math.max(Number(body.retention_visitor_days || 365), 1),
                webHost,
                webPort,
                body.db_guard_enabled !== false,
                clampNumber(body.db_limit_mb, DEFAULT_DB_LIMIT_MB, 1, 1048576),
                dbWarningPercent,
                dbCriticalPercent,
                normalizeDbGuardAction(body.db_critical_action),
                body.db_guard_cleanup_activity_enabled !== false,
                dbGuardCleanupApiEnabled,
                dbGuardCleanupSyncEnabled,
                body.db_guard_cleanup_visitor_enabled === true,
                operationMode
            ]
        );

        await pool.query(`
            UPDATE middleware_sync_settings
            SET is_active = $1,
                auto_run = $1,
                modified_by = $2,
                modified_time = NOW()
            WHERE setting_id = 1
        `, [operationMode === "MIDDLEWARE_SYNC", getCurrentUsername(req)]).catch(() => {});

        clearDatabaseCapacityCache();
        res.json({ success: true, data: result.rows[0], restart_required: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/database-capacity", async (req, res) => {
    try {
        const force = String(req.query?.force || "").toLowerCase() === "true";
        const snapshot = await getCachedDatabaseCapacitySnapshot({ force, allowStale: true });
        res.json({ success: true, data: snapshot });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/database-capacity/check-now", async (req, res) => {
    try {
        const snapshot = await runDatabaseCapacityGuard(getCurrentUsername(req), true);
        setDatabaseCapacityCache(snapshot);
        res.json({ success: true, data: snapshot });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/database-health", requireSuperAdmin, async (req, res) => {
    try {
        const report = await getDatabaseHealthReport();
        res.json({ success: true, data: report });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/database-health/repair", requireSuperAdmin, async (req, res) => {
    try {
        const result = await runDatabaseRepair(getCurrentUsername(req));
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/maintenance/backup-now", async (req, res) => {
    try {
        const result = await runFullBackup(getCurrentUsername(req));
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/maintenance/cleanup-now", async (req, res) => {
    try {
        const result = await runCleanup(
            getCurrentUsername(req),
            isSuperAdmin(req) ? {} : { apiEnabled: false, syncEnabled: false }
        );
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/maintenance/restore", upload.single("backup_file"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "Pilih file backup .backup terlebih dahulu." });
        }

        const result = await runRestore(req.file.path, getCurrentUsername(req));
        res.json({ success: true, data: result, restart_required: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/maintenance-jobs", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT *
            FROM maintenance_jobs
            ORDER BY job_id DESC
            LIMIT 500
        `);
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = {
    router,
    ensureMaintenanceSchema,
    getServerListenSettings,
    startMaintenanceScheduler,
    runFullBackup
};
