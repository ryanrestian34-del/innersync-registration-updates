const express = require("express");
const crypto = require("crypto");
const path = require("path");
const pool = require("../database/db");
const QRCode = require("qrcode");
const { executeActiveThirdPartyConfigs } = require("./apiIntegrationRoutes");

const router = express.Router();
let gatewaySchemaReady = false;

const DEFAULT_ACTION_MAP = {
    CHECKIN: "CHECKIN",
    ADD: "CHECKIN",
    CREATE: "CHECKIN",
    EDIT: "EDIT",
    UPDATE: "EDIT",
    DELETE: "DELETE",
    CANCEL: "DELETE",
    CHECKOUT: "CHECKOUT",
    CHECK_OUT: "CHECKOUT",
    SYNC_ADD: "SYNC_ADD",
    SYNC_UPDATE: "SYNC_UPDATE",
    SYNC_DELETE: "SYNC_DELETE",
    SYNC_CANCEL: "SYNC_CANCEL"
};

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function requireSuperAdmin(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    const isDeveloperSuperAdmin =
        String(req.session?.user?.username || "").toLowerCase() === "admin" &&
        String(req.session?.role_name || req.session?.user?.role_name || "").toUpperCase() === "SUPERADMIN";

    if (!isDeveloperSuperAdmin) {
        return res.status(403).json({ success: false, message: "Gateway API hanya bisa diatur oleh developer/system superadmin" });
    }
    next();
}

function safeJson(value, fallback) {
    if (!value) return fallback;
    if (typeof value === "object") return value;
    try {
        return JSON.parse(value);
    } catch {
        return fallback;
    }
}

async function ensureGatewaySchema() {
    if (gatewaySchemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS gateway_api_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            gateway_name VARCHAR(120) NOT NULL DEFAULT 'Innersync Gateway',
            api_key TEXT,
            gateway_username VARCHAR(120),
            gateway_password TEXT,
            default_mode VARCHAR(20) NOT NULL DEFAULT 'SYNC',
            gateway_behavior VARCHAR(40) NOT NULL DEFAULT 'FORWARD_ONLY',
            allowed_actions JSONB DEFAULT '["CHECKIN","EDIT","DELETE","CHECKOUT"]'::jsonb,
            action_trigger_map JSONB DEFAULT '{}'::jsonb,
            field_mapping JSONB DEFAULT '{}'::jsonb,
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS gateway_api_logs (
            log_id SERIAL PRIMARY KEY,
            request_id VARCHAR(120),
            source_system VARCHAR(120),
            action VARCHAR(40),
            trigger_event VARCHAR(40),
            mode VARCHAR(20),
            request_headers JSONB DEFAULT '{}'::jsonb,
            request_payload JSONB DEFAULT '{}'::jsonb,
            mapped_payload JSONB DEFAULT '{}'::jsonb,
            result_payload JSONB DEFAULT '{}'::jsonb,
            status VARCHAR(30) NOT NULL DEFAULT 'RECEIVED',
            success BOOLEAN NOT NULL DEFAULT FALSE,
            error_message TEXT,
            duration_ms INTEGER,
            created_time TIMESTAMP DEFAULT NOW(),
            completed_time TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS gateway_name VARCHAR(120) NOT NULL DEFAULT 'Innersync Gateway'");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS api_key TEXT");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS gateway_username VARCHAR(120)");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS gateway_password TEXT");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS default_mode VARCHAR(20) NOT NULL DEFAULT 'SYNC'");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS gateway_behavior VARCHAR(40) NOT NULL DEFAULT 'FORWARD_ONLY'");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS allowed_actions JSONB DEFAULT '[\"CHECKIN\",\"EDIT\",\"DELETE\",\"CHECKOUT\"]'::jsonb");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS action_trigger_map JSONB DEFAULT '{}'::jsonb");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS field_mapping JSONB DEFAULT '{}'::jsonb");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE gateway_api_settings ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_gateway_api_logs_request_id ON gateway_api_logs (request_id)");

    await pool.query(`
        INSERT INTO gateway_api_settings (setting_id, api_key, action_trigger_map)
        VALUES (1, $1, $2::jsonb)
        ON CONFLICT (setting_id) DO NOTHING
    `, [crypto.randomBytes(24).toString("hex"), JSON.stringify(DEFAULT_ACTION_MAP)]);

    gatewaySchemaReady = true;
}

async function getGatewaySettings() {
    await ensureGatewaySchema();
    const result = await pool.query("SELECT * FROM gateway_api_settings WHERE setting_id = 1");
    const row = result.rows[0] || {};
    return {
        enabled: row.enabled === true,
        gateway_name: row.gateway_name || "Innersync Gateway",
        api_key: row.api_key || "",
        api_key_masked: row.api_key ? `${String(row.api_key).slice(0, 6)}******${String(row.api_key).slice(-4)}` : "",
        gateway_username: row.gateway_username || "",
        gateway_password: row.gateway_password || "",
        gateway_auth_configured: Boolean(row.gateway_username && row.gateway_password),
        default_mode: String(row.default_mode || "SYNC").toUpperCase(),
        gateway_behavior: String(row.gateway_behavior || "FORWARD_ONLY").toUpperCase(),
        allowed_actions: safeJson(row.allowed_actions, ["CHECKIN", "EDIT", "DELETE", "CHECKOUT"]),
        action_trigger_map: { ...DEFAULT_ACTION_MAP, ...safeJson(row.action_trigger_map, {}) },
        field_mapping: safeJson(row.field_mapping, {}),
        modified_by: row.modified_by || null,
        modified_time: row.modified_time || null
    };
}

async function getOperationMode() {
    try {
        const result = await pool.query("SELECT operation_mode FROM maintenance_settings WHERE setting_id = 1");
        return String(result.rows[0]?.operation_mode || "VISITOR_REGISTRATION").toUpperCase();
    } catch {
        return "VISITOR_REGISTRATION";
    }
}

async function getMiddlewareRuntimeGuard(operationMode = null) {
    const mode = String(operationMode || await getOperationMode()).toUpperCase();
    if (mode !== "MIDDLEWARE_SYNC") {
        return { active: false, setting_active: false, active_projects: 0 };
    }

    try {
        const settings = await pool.query("SELECT is_active FROM middleware_sync_settings WHERE setting_id = 1");
        const projects = await pool.query("SELECT COUNT(*)::int AS total FROM middleware_projects WHERE is_active = TRUE");
        const settingActive = settings.rows[0]?.is_active === true;
        const activeProjects = Number(projects.rows[0]?.total || 0);
        return {
            active: settingActive && activeProjects > 0,
            setting_active: settingActive,
            active_projects: activeProjects
        };
    } catch {
        return { active: false, setting_active: false, active_projects: 0 };
    }
}

async function getGatewayRuntimeStatus() {
    const settings = await getGatewaySettings();
    const operationMode = await getOperationMode();
    const middlewareGuard = await getMiddlewareRuntimeGuard(operationMode);
    const statsResult = await pool.query(`
        SELECT
            COUNT(*)::int AS total_logs,
            MAX(created_time) AS last_request_time,
            MAX(completed_time) FILTER (WHERE success = TRUE) AS last_success_time,
            MAX(completed_time) FILTER (WHERE success = FALSE OR status = 'FAILED') AS last_failed_time
        FROM gateway_api_logs
    `);
    const stats = statsResult.rows[0] || {};
    const apiKeyConfigured = String(settings.api_key || "").trim() !== "";
    let status = "STOPPED";
    let message = "Gateway API belum aktif.";

    if (settings.enabled && apiKeyConfigured) {
        status = "RUNNING";
        message = settings.gateway_auth_configured
            ? "Gateway API aktif dengan API key dan username/password."
            : "Gateway API aktif dan siap menerima request.";
        if (middlewareGuard.active) {
            status = "BLOCKED";
            message = "Gateway API diblokir karena Middleware Sync sedang aktif dengan project aktif untuk mencegah double command.";
        } else if (operationMode === "MIDDLEWARE_SYNC") {
            message = "Gateway API aktif. Middleware Sync tidak berjalan karena belum ada project aktif.";
        }
    } else if (settings.enabled && !apiKeyConfigured) {
        status = "NOT_READY";
        message = "Gateway aktif, tetapi API key belum disiapkan.";
    }

    return {
        service_running: true,
        gateway_enabled: settings.enabled,
        api_key_configured: apiKeyConfigured,
        gateway_auth_configured: settings.gateway_auth_configured,
        gateway_name: settings.gateway_name,
        default_mode: settings.default_mode,
        gateway_behavior: settings.gateway_behavior,
        operation_mode: operationMode,
        middleware_active: middlewareGuard.active,
        middleware_active_projects: middlewareGuard.active_projects,
        status,
        message,
        total_logs: Number(stats.total_logs || 0),
        last_request_time: stats.last_request_time || null,
        last_success_time: stats.last_success_time || null,
        last_failed_time: stats.last_failed_time || null
    };
}

function getRequestApiKey(req) {
    const auth = String(req.headers.authorization || "");
    if (auth.toLowerCase().startsWith("bearer ")) return auth.slice(7).trim();
    return String(req.headers["x-innersync-gateway-key"] || req.headers["x-api-key"] || req.query.api_key || "").trim();
}

function getRequestGatewayCredentials(req) {
    const auth = String(req.headers.authorization || "");
    if (auth.toLowerCase().startsWith("basic ")) {
        try {
            const decoded = Buffer.from(auth.slice(6).trim(), "base64").toString("utf8");
            const separatorIndex = decoded.indexOf(":");
            if (separatorIndex >= 0) {
                return {
                    username: decoded.slice(0, separatorIndex),
                    password: decoded.slice(separatorIndex + 1)
                };
            }
        } catch {
            return { username: "", password: "" };
        }
    }

    return {
        username: String(req.headers["x-innersync-gateway-username"] || req.query.gateway_username || "").trim(),
        password: String(req.headers["x-innersync-gateway-password"] || req.query.gateway_password || "").trim()
    };
}

async function requireGatewayApiKey(req, res, next) {
    try {
        const settings = await getGatewaySettings();
        if (!settings.enabled) {
            return res.status(403).json({ success: false, message: "Gateway API belum aktif." });
        }
        const incomingKey = getRequestApiKey(req);
        if (!incomingKey || incomingKey !== settings.api_key) {
            return res.status(401).json({ success: false, message: "Gateway API key tidak valid." });
        }
        if (settings.gateway_auth_configured) {
            const credentials = getRequestGatewayCredentials(req);
            if (credentials.username !== settings.gateway_username || credentials.password !== settings.gateway_password) {
                return res.status(401).json({ success: false, message: "Gateway username/password tidak valid." });
            }
        }
        req.gatewaySettings = settings;
        next();
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
}

function getByPath(source, path) {
    if (!path) return undefined;
    const parts = String(path).replace(/\[(\d+)\]/g, ".$1").split(".").filter(Boolean);
    let current = source;
    for (const part of parts) {
        if (current == null) return undefined;
        current = current[part];
    }
    return current;
}

function firstValue(...values) {
    return values.find(value => value !== undefined && value !== null && String(value).trim() !== "");
}

function splitName(fullName = "") {
    const parts = String(fullName || "").trim().split(/\s+/).filter(Boolean);
    return {
        first_name: parts[0] || "",
        second_name: parts.slice(1).join(" ")
    };
}

function normalizeGatewayPayload(body, fieldMapping = {}) {
    const source = body?.visitor || body?.data || body?.payload || body || {};
    const mapped = {};

    Object.entries(fieldMapping || {}).forEach(([targetField, sourcePath]) => {
        const value = getByPath(body, sourcePath);
        if (value !== undefined) mapped[targetField] = value;
    });

    const nameParts = splitName(firstValue(mapped.visitor_name, source.visitor_name, source.name, source.full_name));

    return {
        request_id: firstValue(body.request_id, source.request_id) || `GW-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`,
        source_system: firstValue(body.source_system, body.source, source.source_system) || "EXTERNAL_SYSTEM",
        first_name: firstValue(mapped.first_name, source.first_name, source.firstName, nameParts.first_name) || "",
        second_name: firstValue(mapped.second_name, source.second_name, source.secondName, nameParts.second_name) || "",
        company_name: firstValue(mapped.company_name, source.company_name, source.company, source.companyName) || "",
        host: firstValue(mapped.host, source.host, source.host_name, source.hostName) || "",
        email_address: firstValue(mapped.email_address, source.email_address, source.email, source.emailAddress) || "",
        telephone_number: firstValue(mapped.telephone_number, source.telephone_number, source.phone, source.mobile, source.whatsapp) || "",
        identity_number: firstValue(mapped.identity_number, source.identity_number, source.id_number, source.idNumber) || "",
        identity_type: firstValue(mapped.identity_type, source.identity_type, source.identityType) || "",
        card_number: firstValue(mapped.card_number, source.card_number, source.card, source.cardNo, source.badgeNo1) || "",
        permission_group: firstValue(mapped.permission_group, source.permission_group, source.grouping, source.group) || "",
        purpose_note: firstValue(mapped.purpose_note, source.purpose_note, source.purpose, source.notes) || "",
        start_date: firstValue(mapped.start_date, source.start_date, source.startDate, source.entryDate) || "",
        expiry_date: firstValue(mapped.expiry_date, source.expiry_date, source.expiryDate, source.exitDate) || "",
        innerrange_user_id: firstValue(mapped.innerrange_user_id, source.innerrange_user_id, source.innerRangeId, source.user_id) || "",
        schindler_person_id: firstValue(mapped.schindler_person_id, source.schindler_person_id, source.personID, source.person_id) || "",
        raw_gateway_payload: body
    };
}

function normalizeAction(action) {
    return String(action || "CHECKIN").trim().toUpperCase().replace(/\s+/g, "_");
}

function resolveTriggerEvent(action, settings) {
    const map = settings.action_trigger_map || DEFAULT_ACTION_MAP;
    return String(map[action] || DEFAULT_ACTION_MAP[action] || action).toUpperCase();
}

function sanitizeHeaders(headers = {}) {
    const safe = {};
    ["user-agent", "content-type", "x-forwarded-for", "x-real-ip"].forEach(key => {
        if (headers[key]) safe[key] = headers[key];
    });
    return safe;
}

async function createGatewayLog(detail) {
    const result = await pool.query(
        `INSERT INTO gateway_api_logs (
            request_id, source_system, action, trigger_event, mode,
            request_headers, request_payload, mapped_payload, status
         )
         VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb,$8::jsonb,$9)
         RETURNING *`,
        [
            detail.request_id,
            detail.source_system,
            detail.action,
            detail.trigger_event,
            detail.mode,
            JSON.stringify(detail.request_headers || {}),
            JSON.stringify(detail.request_payload || {}),
            JSON.stringify(detail.mapped_payload || {}),
            detail.status || "RECEIVED"
        ]
    );
    return result.rows[0];
}

async function updateGatewayLog(logId, detail) {
    await pool.query(
        `UPDATE gateway_api_logs
         SET result_payload = $2::jsonb,
             status = $3,
             success = $4,
             error_message = $5,
             duration_ms = $6,
             completed_time = NOW()
         WHERE log_id = $1`,
        [
            logId,
            JSON.stringify(detail.result_payload || {}),
            detail.status,
            detail.success === true,
            detail.error_message || null,
            detail.duration_ms || 0
        ]
    );
}

async function processGatewayRequest(req, logRow, triggerEvent, mappedPayload) {
    const started = Date.now();
    const gatewayReq = {
        ...req,
        session: {
            ...(req.session || {}),
            user: { username: "GATEWAY_API", full_name: "Gateway API" },
            role_name: "SYSTEM"
        }
    };

    try {
        const results = await executeActiveThirdPartyConfigs(gatewayReq, triggerEvent, mappedPayload, {});
        const success = results.length > 0 && results.every(item => item.success === true || item.skipped === true);
        await updateGatewayLog(logRow.log_id, {
            result_payload: { results },
            status: success ? "COMPLETED" : "FAILED",
            success,
            error_message: success ? null : (results.find(item => item.error)?.error || "Salah satu destination gagal."),
            duration_ms: Date.now() - started
        });
        return results;
    } catch (error) {
        await updateGatewayLog(logRow.log_id, {
            result_payload: {},
            status: "FAILED",
            success: false,
            error_message: error.message,
            duration_ms: Date.now() - started
        });
        throw error;
    }
}

async function ensureVisitorGatewayColumns() {
    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS host VARCHAR(150)
    `);
    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS schindler_person_id VARCHAR(100)
    `);
    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS created_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW(),
        ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP
    `);
}

async function generateSchindlerPersonId() {
    return crypto.randomBytes(16).toString("hex").toUpperCase();
}

async function createGatewayVisitor(mappedPayload) {
    await ensureVisitorGatewayColumns();
    const qrData = JSON.stringify({
        first_name: mappedPayload.first_name,
        second_name: mappedPayload.second_name,
        company_name: mappedPayload.company_name,
        host: mappedPayload.host,
        card_number: mappedPayload.card_number,
        start_date: mappedPayload.start_date,
        expiry_date: mappedPayload.expiry_date,
        request_id: mappedPayload.request_id
    });
    const qrCode = await QRCode.toDataURL(qrData);
    const schindlerPersonId = mappedPayload.schindler_person_id || await generateSchindlerPersonId();

    const result = await pool.query(
        `INSERT INTO visitor_registration (
            first_name, second_name, identity_number, identity_type,
            company_name, email_address, phone_number, host,
            card_number, permission_group, purpose_note,
            visitor_photo, identity_photo, qr_code,
            start_date, expiry_date, schindler_person_id,
            created_by, created_time, check_in_time
         )
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NULL,NULL,$12,$13,$14,$15,'GATEWAY_API',NOW(),NOW())
         RETURNING *`,
        [
            mappedPayload.first_name,
            mappedPayload.second_name,
            mappedPayload.identity_number,
            mappedPayload.identity_type,
            mappedPayload.company_name,
            mappedPayload.email_address,
            mappedPayload.telephone_number,
            mappedPayload.host,
            mappedPayload.card_number,
            mappedPayload.permission_group,
            mappedPayload.purpose_note,
            qrCode,
            mappedPayload.start_date || null,
            mappedPayload.expiry_date || null,
            schindlerPersonId
        ]
    );
    return result.rows[0];
}

async function upsertGatewayVisitor(mappedPayload) {
    await ensureVisitorGatewayColumns();
    const existing = await pool.query(
        `SELECT *
         FROM visitor_registration
         WHERE ($1 <> '' AND card_number = $1)
            OR ($2 <> '' AND identity_number = $2)
         ORDER BY visitor_id DESC
         LIMIT 1`,
        [String(mappedPayload.card_number || ""), String(mappedPayload.identity_number || "")]
    );

    if (!existing.rows.length) return createGatewayVisitor(mappedPayload);

    const schindlerPersonId = mappedPayload.schindler_person_id || existing.rows[0].schindler_person_id || await generateSchindlerPersonId();
    const result = await pool.query(
        `UPDATE visitor_registration
         SET first_name = $1,
             second_name = $2,
             identity_number = $3,
             identity_type = $4,
             company_name = $5,
             email_address = $6,
             phone_number = $7,
             host = $8,
             card_number = $9,
             permission_group = $10,
             purpose_note = $11,
             start_date = $12,
             expiry_date = $13,
             schindler_person_id = $14,
             modified_by = 'GATEWAY_API',
             modified_time = NOW()
         WHERE visitor_id = $15
         RETURNING *`,
        [
            mappedPayload.first_name,
            mappedPayload.second_name,
            mappedPayload.identity_number,
            mappedPayload.identity_type,
            mappedPayload.company_name,
            mappedPayload.email_address,
            mappedPayload.telephone_number,
            mappedPayload.host,
            mappedPayload.card_number,
            mappedPayload.permission_group,
            mappedPayload.purpose_note,
            mappedPayload.start_date || null,
            mappedPayload.expiry_date || null,
            schindlerPersonId,
            existing.rows[0].visitor_id
        ]
    );
    return result.rows[0];
}

async function applyGatewayBehavior(settings, action, mappedPayload) {
    const behavior = String(settings.gateway_behavior || "FORWARD_ONLY").toUpperCase();
    if (behavior === "FORWARD_ONLY") {
        return { behavior, visitor: null, mappedPayload };
    }

    if (!["CHECKIN", "ADD", "CREATE", "EDIT", "UPDATE"].includes(action)) {
        return { behavior, visitor: null, mappedPayload };
    }

    const visitor = behavior === "CREATE_VISITOR_AND_FORWARD"
        ? await createGatewayVisitor(mappedPayload)
        : await upsertGatewayVisitor(mappedPayload);

    return {
        behavior,
        visitor,
        mappedPayload: {
            ...mappedPayload,
            visitor_id: visitor.visitor_id,
            schindler_person_id: visitor.schindler_person_id || mappedPayload.schindler_person_id
        }
    };
}

router.get("/api/gateway-settings", requireSuperAdmin, async (req, res) => {
    try {
        const settings = await getGatewaySettings();
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/gateway-runtime-status", async (req, res) => {
    try {
        res.json({ success: true, data: await getGatewayRuntimeStatus() });
    } catch (error) {
        res.status(500).json({
            success: false,
            data: {
                service_running: true,
                gateway_enabled: false,
                api_key_configured: false,
                status: "ERROR",
                message: error.message
            },
            error: error.message
        });
    }
});

router.get("/docs/innersync-gateway-api.postman_collection.json", (req, res) => {
    res.download(
        path.join(__dirname, "..", "public", "docs", "innersync-gateway-api.postman_collection.json"),
        "innersync-gateway-api.postman_collection.json"
    );
});

router.get("/docs/innersync-gateway-api.postman_environment.json", (req, res) => {
    res.download(
        path.join(__dirname, "..", "public", "docs", "innersync-gateway-api.postman_environment.json"),
        "innersync-gateway-api.postman_environment.json"
    );
});

router.put("/api/gateway-settings", requireSuperAdmin, async (req, res) => {
    try {
        await ensureGatewaySchema();
        const current = await getGatewaySettings();
        const apiKey = req.body?.regenerate_api_key === true
            ? crypto.randomBytes(24).toString("hex")
            : String(req.body?.api_key || current.api_key || crypto.randomBytes(24).toString("hex")).trim();
        const settings = {
            enabled: req.body?.enabled === true,
            gateway_name: String(req.body?.gateway_name || "Innersync Gateway").trim() || "Innersync Gateway",
            api_key: apiKey,
            gateway_username: String(req.body?.gateway_username || "").trim(),
            gateway_password: String(req.body?.gateway_password || "").trim(),
            default_mode: ["SYNC", "ASYNC"].includes(String(req.body?.default_mode || "").toUpperCase())
                ? String(req.body.default_mode).toUpperCase()
                : "SYNC",
            gateway_behavior: ["FORWARD_ONLY", "CREATE_VISITOR_AND_FORWARD", "UPSERT_VISITOR_AND_FORWARD"].includes(String(req.body?.gateway_behavior || "").toUpperCase())
                ? String(req.body.gateway_behavior).toUpperCase()
                : current.gateway_behavior,
            allowed_actions: Array.isArray(req.body?.allowed_actions) ? req.body.allowed_actions.map(normalizeAction) : current.allowed_actions,
            action_trigger_map: req.body?.action_trigger_map && typeof req.body.action_trigger_map === "object"
                ? req.body.action_trigger_map
                : current.action_trigger_map,
            field_mapping: req.body?.field_mapping && typeof req.body.field_mapping === "object"
                ? req.body.field_mapping
                : current.field_mapping
        };

        await pool.query(
            `UPDATE gateway_api_settings
             SET enabled = $1,
                 gateway_name = $2,
                 api_key = $3,
                 gateway_username = $4,
                 gateway_password = $5,
                 default_mode = $6,
                 gateway_behavior = $7,
                 allowed_actions = $8::jsonb,
                 action_trigger_map = $9::jsonb,
                 field_mapping = $10::jsonb,
                 modified_by = $11,
                 modified_time = NOW()
             WHERE setting_id = 1`,
            [
                settings.enabled,
                settings.gateway_name,
                settings.api_key,
                settings.gateway_username,
                settings.gateway_password,
                settings.default_mode,
                settings.gateway_behavior,
                JSON.stringify(settings.allowed_actions),
                JSON.stringify(settings.action_trigger_map),
                JSON.stringify(settings.field_mapping),
                getCurrentUsername(req)
            ]
        );

        res.json({ success: true, data: await getGatewaySettings() });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/gateway-logs", requireSuperAdmin, async (req, res) => {
    try {
        await ensureGatewaySchema();
        const result = await pool.query(`
            SELECT *
            FROM gateway_api_logs
            ORDER BY log_id DESC
            LIMIT 1000
        `);
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/gateway/status/:requestId", requireGatewayApiKey, async (req, res) => {
    try {
        await ensureGatewaySchema();
        const result = await pool.query(
            "SELECT * FROM gateway_api_logs WHERE request_id = $1 ORDER BY log_id DESC LIMIT 1",
            [req.params.requestId]
        );
        res.json({ success: true, data: result.rows[0] || null });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/gateway/execute", requireGatewayApiKey, async (req, res) => {
    try {
        const settings = req.gatewaySettings || await getGatewaySettings();
        const operationMode = await getOperationMode();
        const middlewareGuard = await getMiddlewareRuntimeGuard(operationMode);
        if (middlewareGuard.active) {
            return res.status(409).json({
                success: false,
                message: "Gateway API tidak bisa execute saat Middleware Sync sedang aktif dengan project aktif untuk mencegah bentrok/double command.",
                operation_mode: operationMode,
                middleware_active_projects: middlewareGuard.active_projects
            });
        }
        const action = normalizeAction(req.body?.action || req.body?.event || "CHECKIN");
        const allowed = (settings.allowed_actions || []).map(normalizeAction);
        if (allowed.length && !allowed.includes(action)) {
            return res.status(400).json({ success: false, message: `Action ${action} tidak diizinkan.` });
        }

        const triggerEvent = resolveTriggerEvent(action, settings);
        const normalizedPayload = normalizeGatewayPayload(req.body, settings.field_mapping);
        const behaviorResult = await applyGatewayBehavior(settings, action, normalizedPayload);
        const mappedPayload = behaviorResult.mappedPayload;
        const mode = String(req.body?.mode || settings.default_mode || "SYNC").toUpperCase() === "ASYNC" ? "ASYNC" : "SYNC";
        const logRow = await createGatewayLog({
            request_id: mappedPayload.request_id,
            source_system: mappedPayload.source_system,
            action,
            trigger_event: triggerEvent,
            mode,
            request_headers: sanitizeHeaders(req.headers),
            request_payload: req.body,
            mapped_payload: {
                ...mappedPayload,
                gateway_behavior: behaviorResult.behavior,
                created_visitor_id: behaviorResult.visitor?.visitor_id || null
            },
            status: mode === "ASYNC" ? "QUEUED" : "PROCESSING"
        });

        if (mode === "ASYNC") {
            setImmediate(() => {
                processGatewayRequest(req, logRow, triggerEvent, mappedPayload).catch(() => {});
            });
            return res.json({
                success: true,
                accepted: true,
                mode,
                request_id: mappedPayload.request_id,
                log_id: logRow.log_id,
                visitor_id: behaviorResult.visitor?.visitor_id || null,
                status_url: `/api/gateway/status/${encodeURIComponent(mappedPayload.request_id)}`
            });
        }

        const results = await processGatewayRequest(req, logRow, triggerEvent, mappedPayload);
        const success = results.length > 0 && results.every(item => item.success === true || item.skipped === true);
        res.status(success ? 200 : 207).json({
            success,
            request_id: mappedPayload.request_id,
            log_id: logRow.log_id,
            visitor_id: behaviorResult.visitor?.visitor_id || null,
            action,
            trigger_event: triggerEvent,
            mode,
            results
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = router;
module.exports.ensureGatewaySchema = ensureGatewaySchema;
