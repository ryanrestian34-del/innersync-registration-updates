const express = require("express");
const { checkSession } = require("../middleware/authMiddleware");
const { getRolePermissions } = require("../middleware/roleAuthorization");
const {
    attachOperatorPresenceStream,
    getOnlineOperatorCount,
    touchOperatorPresence
} = require("../services/operatorPresence");

const router = express.Router();

router.post("/api/operator-presence/heartbeat", checkSession, async (req, res) => {
    try {
        const permissions = await getRolePermissions(req.session.role_name);
        const canOperate = permissions.visitor_registration?.can_view === true
            || permissions.operator_dashboard?.can_view === true;
        const presence = touchOperatorPresence(req, { canOperate });
        res.json({ success: true, data: presence });
    } catch (error) {
        console.error("Operator presence heartbeat error:", error.message);
        res.status(500).json({ success: false, message: "Gagal memperbarui status operator." });
    }
});

router.get("/api/public/operator-presence", (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json({
        success: true,
        data: {
            online_count: getOnlineOperatorCount()
        }
    });
});

router.get("/api/public/operator-presence/stream", (req, res) => {
    attachOperatorPresenceStream(req, res);
});

module.exports = router;
