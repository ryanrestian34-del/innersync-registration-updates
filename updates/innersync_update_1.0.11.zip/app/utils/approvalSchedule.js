const DEFAULT_TIME_ZONE = "Asia/Jakarta";
const DEFAULT_OPERATIONAL_START = "08:00";
const DEFAULT_OPERATIONAL_END = "17:00";
const DEFAULT_OPERATIONAL_DAYS = [1, 2, 3, 4, 5];

function normalizeApprovalTime(value, fallback = DEFAULT_OPERATIONAL_START) {
    const match = String(value || "").trim().match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return fallback;
    const hour = Number(match[1]);
    const minute = Number(match[2]);
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return fallback;
    return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

function normalizeApprovalTimeZone(value, fallback = DEFAULT_TIME_ZONE) {
    const candidate = String(value || "").trim() || fallback;
    try {
        new Intl.DateTimeFormat("en-US", { timeZone: candidate }).format(new Date());
        return candidate;
    } catch {
        return fallback;
    }
}

function normalizeApprovalDays(value, fallback = DEFAULT_OPERATIONAL_DAYS) {
    const source = Array.isArray(value) ? value : String(value || "").split(",");
    const days = [...new Set(source.map(Number).filter(day => Number.isInteger(day) && day >= 1 && day <= 7))].sort((a, b) => a - b);
    return days.length ? days : [...fallback];
}

function getTimeZoneParts(value, timeZone = DEFAULT_TIME_ZONE) {
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) throw new Error("Tanggal approval tidak valid.");
    const formatter = new Intl.DateTimeFormat("en-CA", {
        timeZone: normalizeApprovalTimeZone(timeZone),
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23"
    });
    const parts = Object.fromEntries(
        formatter.formatToParts(date)
            .filter(part => part.type !== "literal")
            .map(part => [part.type, Number(part.value)])
    );
    return parts;
}

function zonedDateTimeToUtc({ year, month, day, hour, minute, second = 0 }, timeZone = DEFAULT_TIME_ZONE) {
    const zone = normalizeApprovalTimeZone(timeZone);
    const target = Date.UTC(year, month - 1, day, hour, minute, second);
    let timestamp = target;
    for (let attempt = 0; attempt < 4; attempt += 1) {
        const actual = getTimeZoneParts(new Date(timestamp), zone);
        const actualAsUtc = Date.UTC(actual.year, actual.month - 1, actual.day, actual.hour, actual.minute, actual.second);
        const adjustment = target - actualAsUtc;
        timestamp += adjustment;
        if (adjustment === 0) break;
    }
    return new Date(timestamp);
}

function dateKey(parts) {
    return `${parts.year}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`;
}

function shiftDateParts(parts, amount) {
    const date = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + amount));
    return { year: date.getUTCFullYear(), month: date.getUTCMonth() + 1, day: date.getUTCDate() };
}

function isoWeekday(parts) {
    return new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay() || 7;
}

function normalizeDateKeys(value) {
    return new Set((Array.isArray(value) ? value : []).map(item => String(item || "").slice(0, 10)).filter(item => /^\d{4}-\d{2}-\d{2}$/.test(item)));
}

function isOperationalDate(parts, days, closedDates, openDates) {
    const key = dateKey(parts);
    if (openDates.has(key)) return true;
    if (closedDates.has(key)) return false;
    return days.includes(isoWeekday(parts));
}

function openingForDate(parts, opening, zone) {
    const [hour, minute] = opening.split(":").map(Number);
    return zonedDateTimeToUtc({ ...parts, hour, minute }, zone);
}

function closingForDate(parts, closing, zone) {
    const [hour, minute] = closing.split(":").map(Number);
    return zonedDateTimeToUtc({ ...parts, hour, minute }, zone);
}

function findNextOperationalOpening(parts, days, closedDates, openDates, opening, zone, includeCurrent = true) {
    let candidate = includeCurrent ? parts : shiftDateParts(parts, 1);
    for (let attempt = 0; attempt < 3700; attempt += 1) {
        if (isOperationalDate(candidate, days, closedDates, openDates)) return openingForDate(candidate, opening, zone);
        candidate = shiftDateParts(candidate, 1);
    }
    throw new Error("Tidak ditemukan hari operasional approval berikutnya.");
}

function addOperationalMinutes(start, minutes, options) {
    let cursor = new Date(start);
    let remaining = Math.max(1, Number(minutes) || 1) * 60_000;
    for (let attempt = 0; attempt < 10000 && remaining > 0; attempt += 1) {
        let parts = getTimeZoneParts(cursor, options.zone);
        if (!isOperationalDate(parts, options.days, options.closedDates, options.openDates)) {
            cursor = findNextOperationalOpening(parts, options.days, options.closedDates, options.openDates, options.opening, options.zone, false);
            continue;
        }
        const openingAt = openingForDate(parts, options.opening, options.zone);
        const closingAt = closingForDate(parts, options.closing, options.zone);
        if (cursor < openingAt) cursor = openingAt;
        if (cursor >= closingAt) {
            cursor = findNextOperationalOpening(parts, options.days, options.closedDates, options.openDates, options.opening, options.zone, false);
            continue;
        }
        const available = closingAt.getTime() - cursor.getTime();
        const consumed = Math.min(available, remaining);
        cursor = new Date(cursor.getTime() + consumed);
        remaining -= consumed;
    }
    if (remaining > 0) throw new Error("Durasi approval melewati batas kalender operasional yang didukung.");
    return cursor;
}

function computeApprovalWindow({
    now = new Date(),
    visitStart,
    visitExpiry,
    timeoutMinutes,
    operationalStart = DEFAULT_OPERATIONAL_START,
    operationalEnd = DEFAULT_OPERATIONAL_END,
    operationalDays = DEFAULT_OPERATIONAL_DAYS,
    closedDates = [],
    openDates = [],
    timeZone = DEFAULT_TIME_ZONE
}) {
    const current = now instanceof Date ? new Date(now) : new Date(now);
    const visit = visitStart instanceof Date ? new Date(visitStart) : new Date(visitStart);
    if (Number.isNaN(current.getTime()) || Number.isNaN(visit.getTime())) {
        throw new Error("Tanggal kunjungan untuk approval tidak valid.");
    }

    const zone = normalizeApprovalTimeZone(timeZone);
    const opening = normalizeApprovalTime(operationalStart, DEFAULT_OPERATIONAL_START);
    const closing = normalizeApprovalTime(operationalEnd, DEFAULT_OPERATIONAL_END);
    if (closing <= opening) throw new Error("Jam operasional selesai harus lebih besar dari jam mulai.");
    const days = normalizeApprovalDays(operationalDays);
    const closed = normalizeDateKeys(closedDates);
    const open = normalizeDateKeys(openDates);
    const nowParts = getTimeZoneParts(current, zone);
    const visitParts = getTimeZoneParts(visit, zone);
    const futureVisit = dateKey(visitParts) > dateKey(nowParts);
    const visitOperational = isOperationalDate(visitParts, days, closed, open);
    let startsAt;

    if (futureVisit) {
        startsAt = visitOperational ? openingForDate(visitParts, opening, zone) : null;
    } else if (isOperationalDate(nowParts, days, closed, open)) {
        const openingAt = openingForDate(nowParts, opening, zone);
        const closingAt = closingForDate(nowParts, closing, zone);
        startsAt = current < openingAt
            ? openingAt
            : current < closingAt ? current : findNextOperationalOpening(nowParts, days, closed, open, opening, zone, false);
    } else {
        startsAt = findNextOperationalOpening(nowParts, days, closed, open, opening, zone, false);
    }

    let timeoutAt = startsAt ? addOperationalMinutes(startsAt, timeoutMinutes, {
        zone,
        opening,
        closing,
        days,
        closedDates: closed,
        openDates: open
    }) : null;
    const expiry = visitExpiry ? new Date(visitExpiry) : null;
    if (timeoutAt && expiry && !Number.isNaN(expiry.getTime()) && expiry < timeoutAt) timeoutAt = expiry;

    return {
        startsAt,
        timeoutAt,
        operationalStart: opening,
        operationalEnd: closing,
        operationalDays: days,
        closedDates: [...closed],
        openDates: [...open],
        timeoutMinutes: Math.max(1, Number(timeoutMinutes) || 1),
        timeZone: zone,
        delayed: futureVisit,
        invalid: !visitOperational || !startsAt || !timeoutAt || timeoutAt <= startsAt,
        invalidReason: !visitOperational ? "VISIT_NON_OPERATIONAL" : null
    };
}

module.exports = {
    DEFAULT_TIME_ZONE,
    DEFAULT_OPERATIONAL_START,
    DEFAULT_OPERATIONAL_END,
    DEFAULT_OPERATIONAL_DAYS,
    normalizeApprovalTime,
    normalizeApprovalTimeZone,
    normalizeApprovalDays,
    computeApprovalWindow
};
