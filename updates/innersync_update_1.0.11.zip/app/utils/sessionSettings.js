const pool = require("../database/db");

let schemaReady = false;
let cachedSettings = null;
let cacheExpiresAt = 0;

function normalizeSessionSettings(settings = {}) {
    const minutes = Number(settings.idle_logout_minutes);

    return {
        idle_logout_enabled: settings.idle_logout_enabled === true,
        idle_logout_minutes: Number.isFinite(minutes) ? Math.min(Math.max(Math.round(minutes), 1), 1440) : 30
    };
}

async function ensureSessionSettingsSchema() {
    if (schemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS maintenance_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1
        )
    `);

    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS idle_logout_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS idle_logout_minutes INTEGER NOT NULL DEFAULT 30");
    await pool.query("ALTER TABLE maintenance_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO maintenance_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    schemaReady = true;
}

async function getSessionSettings(options = {}) {
    const now = Date.now();
    if (!options.force && cachedSettings && now < cacheExpiresAt) return cachedSettings;

    await ensureSessionSettingsSchema();
    const result = await pool.query(`
        SELECT idle_logout_enabled, idle_logout_minutes
        FROM maintenance_settings
        WHERE setting_id = 1
    `);

    cachedSettings = normalizeSessionSettings(result.rows[0] || {});
    cacheExpiresAt = now + 30000;
    return cachedSettings;
}

async function saveSessionSettings(settings) {
    await ensureSessionSettingsSchema();
    const normalized = normalizeSessionSettings(settings);

    const result = await pool.query(
        `UPDATE maintenance_settings
         SET idle_logout_enabled = $1,
             idle_logout_minutes = $2,
             updated_at = NOW()
         WHERE setting_id = 1
         RETURNING idle_logout_enabled, idle_logout_minutes`,
        [normalized.idle_logout_enabled, normalized.idle_logout_minutes]
    );

    cachedSettings = normalizeSessionSettings(result.rows[0] || normalized);
    cacheExpiresAt = Date.now() + 30000;
    return cachedSettings;
}

module.exports = {
    ensureSessionSettingsSchema,
    getSessionSettings,
    saveSessionSettings
};
