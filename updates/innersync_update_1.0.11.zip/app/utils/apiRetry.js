const DEFAULT_POLICY = {
    maxAttempts: 4,
    maxWindowMs: 5000,
    firstAttemptTimeoutCapMs: 4500,
    retryDelaysMs: [100, 200, 300]
};

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, Math.max(Number(ms || 0), 0)));
}

function normalizePolicy(policy = {}) {
    return {
        ...DEFAULT_POLICY,
        ...policy,
        maxAttempts: Math.max(1, Number(policy.maxAttempts || DEFAULT_POLICY.maxAttempts)),
        maxWindowMs: Math.max(1000, Number(policy.maxWindowMs || DEFAULT_POLICY.maxWindowMs))
    };
}

function transientText(value) {
    return /timeout|timed out|network|fetch failed|socket|econn|etimedout|eai_again|und_err|login-error|callback returned false/i
        .test(String(value || ""));
}

function isRetryableError(error) {
    return transientText(error?.message || error);
}

function isRetryableResult(result = {}) {
    const status = Number(result.status || result.response_status || 0);
    const authType = String(result.auth_type || "").toUpperCase();
    const body = String(result.body || result.response_body || "");
    const providerError = String(result.provider_error || result.error_message || "");

    if (!status) return true;
    if (status === 408 || status === 429 || status >= 500) return true;
    if (status === 401 && (authType === "DYNAMIC_BEARER" || transientText(body) || transientText(providerError))) return true;
    return transientText(body) || transientText(providerError);
}

function getDelayMs(attemptNumber, policy = DEFAULT_POLICY) {
    const delays = Array.isArray(policy.retryDelaysMs) ? policy.retryDelaysMs : DEFAULT_POLICY.retryDelaysMs;
    return Number(delays[Math.max(attemptNumber - 1, 0)] || delays[delays.length - 1] || 0);
}

function getAttemptTimeoutMs(baseTimeoutMs, attemptNumber, startedAt, policyInput = {}) {
    const policy = normalizePolicy(policyInput);
    const base = Math.max(Number(baseTimeoutMs || policy.firstAttemptTimeoutCapMs), 500);
    const elapsed = Date.now() - startedAt;
    const remaining = Math.max(policy.maxWindowMs - elapsed, 500);

    if (attemptNumber <= 1) {
        return Math.max(500, Math.min(base, policy.firstAttemptTimeoutCapMs, remaining));
    }

    const attemptsLeft = Math.max(policy.maxAttempts - attemptNumber + 1, 1);
    const sharedRemaining = Math.max(Math.floor((remaining - 100) / attemptsLeft), 500);
    return Math.max(500, Math.min(base, sharedRemaining, remaining));
}

function canRetry(attemptNumber, startedAt, policyInput = {}) {
    const policy = normalizePolicy(policyInput);
    return attemptNumber < policy.maxAttempts && (Date.now() - startedAt) < policy.maxWindowMs;
}

module.exports = {
    DEFAULT_POLICY,
    sleep,
    normalizePolicy,
    isRetryableError,
    isRetryableResult,
    getDelayMs,
    getAttemptTimeoutMs,
    canRetry
};
