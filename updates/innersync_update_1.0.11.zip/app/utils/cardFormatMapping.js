async function ensureCardFormatSchema(pool) {
    await pool.query(`
        CREATE TABLE IF NOT EXISTS card_format_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            profile_name VARCHAR(120) NOT NULL DEFAULT 'Default Card Format',
            format_mode VARCHAR(20) NOT NULL DEFAULT 'GENERIC',
            input_base VARCHAR(20) NOT NULL DEFAULT 'TEXT',
            output_base VARCHAR(20) NOT NULL DEFAULT 'TEXT',
            wiegand_preset VARCHAR(20) NOT NULL DEFAULT 'W26',
            wiegand_total_bits INTEGER NOT NULL DEFAULT 26,
            wiegand_facility_start INTEGER NOT NULL DEFAULT 1,
            wiegand_facility_bits INTEGER NOT NULL DEFAULT 8,
            wiegand_card_start INTEGER NOT NULL DEFAULT 9,
            wiegand_card_bits INTEGER NOT NULL DEFAULT 16,
            wiegand_bit_order VARCHAR(20) NOT NULL DEFAULT 'NORMAL',
            wiegand_output VARCHAR(30) NOT NULL DEFAULT 'CARD_NUMBER',
            remove_non_alnum BOOLEAN NOT NULL DEFAULT TRUE,
            uppercase BOOLEAN NOT NULL DEFAULT TRUE,
            reverse_bytes BOOLEAN NOT NULL DEFAULT FALSE,
            slice_mode VARCHAR(20) NOT NULL DEFAULT 'NONE',
            slice_length INTEGER NOT NULL DEFAULT 0,
            pad_side VARCHAR(20) NOT NULL DEFAULT 'NONE',
            pad_length INTEGER NOT NULL DEFAULT 0,
            pad_char VARCHAR(4) NOT NULL DEFAULT '0',
            prefix TEXT DEFAULT '',
            suffix TEXT DEFAULT '',
            max_length INTEGER NOT NULL DEFAULT 0,
            max_length_keep VARCHAR(20) NOT NULL DEFAULT 'RIGHT',
            apply_to_api BOOLEAN NOT NULL DEFAULT TRUE,
            apply_to_qr BOOLEAN NOT NULL DEFAULT TRUE,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS profile_name VARCHAR(120) NOT NULL DEFAULT 'Default Card Format'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS format_mode VARCHAR(20) NOT NULL DEFAULT 'GENERIC'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS input_base VARCHAR(20) NOT NULL DEFAULT 'TEXT'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS output_base VARCHAR(20) NOT NULL DEFAULT 'TEXT'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_preset VARCHAR(20) NOT NULL DEFAULT 'W26'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_total_bits INTEGER NOT NULL DEFAULT 26");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_facility_start INTEGER NOT NULL DEFAULT 1");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_facility_bits INTEGER NOT NULL DEFAULT 8");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_card_start INTEGER NOT NULL DEFAULT 9");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_card_bits INTEGER NOT NULL DEFAULT 16");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_bit_order VARCHAR(20) NOT NULL DEFAULT 'NORMAL'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS wiegand_output VARCHAR(30) NOT NULL DEFAULT 'CARD_NUMBER'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS remove_non_alnum BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS uppercase BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS reverse_bytes BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS slice_mode VARCHAR(20) NOT NULL DEFAULT 'NONE'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS slice_length INTEGER NOT NULL DEFAULT 0");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS pad_side VARCHAR(20) NOT NULL DEFAULT 'NONE'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS pad_length INTEGER NOT NULL DEFAULT 0");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS pad_char VARCHAR(4) NOT NULL DEFAULT '0'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS prefix TEXT DEFAULT ''");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS suffix TEXT DEFAULT ''");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS max_length INTEGER NOT NULL DEFAULT 0");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS max_length_keep VARCHAR(20) NOT NULL DEFAULT 'RIGHT'");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS apply_to_api BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS apply_to_qr BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE card_format_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO card_format_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);
}

function normalizeCardFormatSettings(input = {}) {
    const upper = value => String(value || "").toUpperCase();
    const inputBase = upper(input.input_base || "TEXT");
    const outputBase = upper(input.output_base || "TEXT");
    const formatMode = upper(input.format_mode || "GENERIC");
    const wiegandPreset = upper(input.wiegand_preset || "W26");
    const wiegandBitOrder = upper(input.wiegand_bit_order || "NORMAL");
    const wiegandOutput = upper(input.wiegand_output || "CARD_NUMBER");
    const sliceMode = upper(input.slice_mode || "NONE");
    const padSide = upper(input.pad_side || "NONE");
    const maxLengthKeep = upper(input.max_length_keep || "RIGHT");

    return {
        enabled: input.enabled === true,
        profile_name: String(input.profile_name || "Default Card Format").trim() || "Default Card Format",
        format_mode: ["GENERIC", "WIEGAND"].includes(formatMode) ? formatMode : "GENERIC",
        input_base: ["TEXT", "DECIMAL", "HEX", "AUTO"].includes(inputBase) ? inputBase : "TEXT",
        output_base: ["TEXT", "DECIMAL", "HEX"].includes(outputBase) ? outputBase : "TEXT",
        wiegand_preset: ["W26", "W32", "W34", "CUSTOM"].includes(wiegandPreset) ? wiegandPreset : "W26",
        wiegand_total_bits: Math.max(Number.parseInt(input.wiegand_total_bits, 10) || 26, 1),
        wiegand_facility_start: Math.max(Number.parseInt(input.wiegand_facility_start, 10) || 0, 0),
        wiegand_facility_bits: Math.max(Number.parseInt(input.wiegand_facility_bits, 10) || 0, 0),
        wiegand_card_start: Math.max(Number.parseInt(input.wiegand_card_start, 10) || 0, 0),
        wiegand_card_bits: Math.max(Number.parseInt(input.wiegand_card_bits, 10) || 0, 0),
        wiegand_bit_order: ["NORMAL", "REVERSE"].includes(wiegandBitOrder) ? wiegandBitOrder : "NORMAL",
        wiegand_output: ["CARD_NUMBER", "FACILITY", "FACILITY_CARD", "FACILITY_DASH_CARD", "RAW_BITS"].includes(wiegandOutput) ? wiegandOutput : "CARD_NUMBER",
        remove_non_alnum: input.remove_non_alnum !== false,
        uppercase: input.uppercase !== false,
        reverse_bytes: input.reverse_bytes === true,
        slice_mode: ["NONE", "LEFT", "RIGHT"].includes(sliceMode) ? sliceMode : "NONE",
        slice_length: Math.max(Number.parseInt(input.slice_length, 10) || 0, 0),
        pad_side: ["NONE", "LEFT", "RIGHT"].includes(padSide) ? padSide : "NONE",
        pad_length: Math.max(Number.parseInt(input.pad_length, 10) || 0, 0),
        pad_char: String(input.pad_char || "0").slice(0, 1) || "0",
        prefix: String(input.prefix || ""),
        suffix: String(input.suffix || ""),
        max_length: Math.max(Number.parseInt(input.max_length, 10) || 0, 0),
        max_length_keep: ["LEFT", "RIGHT"].includes(maxLengthKeep) ? maxLengthKeep : "RIGHT",
        apply_to_api: input.apply_to_api !== false,
        apply_to_qr: input.apply_to_qr !== false
    };
}

async function getCardFormatSettings(pool) {
    await ensureCardFormatSchema(pool);
    const result = await pool.query("SELECT * FROM card_format_settings WHERE setting_id = 1");
    return normalizeCardFormatSettings(result.rows[0] || {});
}

function convertBase(value, inputBase, outputBase) {
    const source = String(value || "").trim();
    if (!source || outputBase === "TEXT") return source;

    let effectiveInput = inputBase;
    if (effectiveInput === "AUTO") {
        effectiveInput = /[A-F]/i.test(source) ? "HEX" : "DECIMAL";
    }

    try {
        let numberValue;
        if (effectiveInput === "HEX") {
            numberValue = BigInt(`0x${source || "0"}`);
        } else if (effectiveInput === "DECIMAL") {
            numberValue = BigInt(source || "0");
        } else {
            return source;
        }

        if (outputBase === "HEX") return numberValue.toString(16).toUpperCase();
        if (outputBase === "DECIMAL") return numberValue.toString(10);
        return source;
    } catch {
        return source;
    }
}

function reverseHexBytes(value) {
    const text = String(value || "").replace(/\s+/g, "");
    if (!text) return text;
    const evenText = text.length % 2 === 0 ? text : `0${text}`;
    return evenText.match(/.{1,2}/g).reverse().join("");
}

function numberToBitString(value, inputBase, totalBits) {
    const source = String(value || "").trim();
    if (!source) return "";
    let effectiveInput = inputBase;
    if (effectiveInput === "AUTO" || effectiveInput === "TEXT") {
        effectiveInput = /[A-F]/i.test(source) ? "HEX" : "DECIMAL";
    }

    try {
        const numberValue = effectiveInput === "HEX"
            ? BigInt(`0x${source || "0"}`)
            : BigInt(source || "0");
        const bits = numberValue.toString(2);
        return bits.length < totalBits ? bits.padStart(totalBits, "0") : bits.slice(-totalBits);
    } catch {
        return /^[01]+$/.test(source) ? source.padStart(totalBits, "0").slice(-totalBits) : "";
    }
}

function bitsToDecimal(bits) {
    if (!bits) return "0";
    return BigInt(`0b${bits}`).toString(10);
}

function applyWiegandFormat(value, config) {
    let bits = numberToBitString(value, config.input_base, config.wiegand_total_bits);
    if (!bits) return String(value || "");
    if (config.wiegand_bit_order === "REVERSE") bits = bits.split("").reverse().join("");

    const facilityBits = config.wiegand_facility_bits > 0
        ? bits.slice(config.wiegand_facility_start, config.wiegand_facility_start + config.wiegand_facility_bits)
        : "";
    const cardBits = config.wiegand_card_bits > 0
        ? bits.slice(config.wiegand_card_start, config.wiegand_card_start + config.wiegand_card_bits)
        : "";
    const facility = bitsToDecimal(facilityBits);
    const card = bitsToDecimal(cardBits);

    if (config.wiegand_output === "RAW_BITS") return bits;
    if (config.wiegand_output === "FACILITY") return facility;
    if (config.wiegand_output === "FACILITY_CARD") return `${facility}${card}`;
    if (config.wiegand_output === "FACILITY_DASH_CARD") return `${facility}-${card}`;
    return card;
}

function formatCardNumber(value, settings = {}) {
    const config = normalizeCardFormatSettings(settings);
    const raw = String(value ?? "").trim();
    if (!raw || !config.enabled) {
        return { raw, formatted: raw, changed: false };
    }

    let output = raw;
    if (config.remove_non_alnum) output = output.replace(/[^0-9a-z]/gi, "");
    if (config.uppercase) output = output.toUpperCase();
    if (config.format_mode === "WIEGAND") {
        output = applyWiegandFormat(output, config);
    } else {
        output = convertBase(output, config.input_base, config.output_base);
        if (config.uppercase) output = output.toUpperCase();
        if (config.reverse_bytes) output = reverseHexBytes(output);
    }

    if (config.slice_mode !== "NONE" && config.slice_length > 0 && output.length > config.slice_length) {
        output = config.slice_mode === "LEFT"
            ? output.slice(0, config.slice_length)
            : output.slice(-config.slice_length);
    }

    if (config.pad_side !== "NONE" && config.pad_length > 0 && output.length < config.pad_length) {
        output = config.pad_side === "LEFT"
            ? output.padStart(config.pad_length, config.pad_char)
            : output.padEnd(config.pad_length, config.pad_char);
    }

    output = `${config.prefix}${output}${config.suffix}`;

    if (config.max_length > 0 && output.length > config.max_length) {
        output = config.max_length_keep === "LEFT"
            ? output.slice(0, config.max_length)
            : output.slice(-config.max_length);
    }

    return { raw, formatted: output, changed: raw !== output };
}

function normalizeCompareValue(value) {
    return String(value ?? "").trim().replace(/\s+/g, "").toUpperCase();
}

function buildAnalyzerCandidates(samples = []) {
    const targetLengths = [...new Set(samples
        .map(sample => normalizeCompareValue(sample.target).length)
        .filter(length => length > 0))];
    const baseCandidate = {
        enabled: true,
        profile_name: "Analyzer Candidate",
        remove_non_alnum: true,
        uppercase: true,
        reverse_bytes: false,
        slice_mode: "NONE",
        slice_length: 0,
        pad_side: "NONE",
        pad_length: 0,
        pad_char: "0",
        prefix: "",
        suffix: "",
        max_length: 0,
        max_length_keep: "RIGHT",
        apply_to_api: false,
        apply_to_qr: false
    };

    const candidates = [];
    const addCandidate = (name, category, settings) => {
        candidates.push({
            name,
            category,
            settings: normalizeCardFormatSettings({ ...baseCandidate, ...settings })
        });
    };

    ["TEXT", "DECIMAL", "HEX", "AUTO"].forEach(inputBase => {
        ["TEXT", "DECIMAL", "HEX"].forEach(outputBase => {
            addCandidate(`Generic ${inputBase} to ${outputBase}`, "GENERIC", {
                format_mode: "GENERIC",
                input_base: inputBase,
                output_base: outputBase
            });
            addCandidate(`Generic ${inputBase} to ${outputBase} reverse bytes`, "GENERIC", {
                format_mode: "GENERIC",
                input_base: inputBase,
                output_base: outputBase,
                reverse_bytes: true
            });
            targetLengths.forEach(length => {
                addCandidate(`Generic ${inputBase} to ${outputBase} right ${length}`, "GENERIC", {
                    format_mode: "GENERIC",
                    input_base: inputBase,
                    output_base: outputBase,
                    slice_mode: "RIGHT",
                    slice_length: length
                });
                addCandidate(`Generic ${inputBase} to ${outputBase} left ${length}`, "GENERIC", {
                    format_mode: "GENERIC",
                    input_base: inputBase,
                    output_base: outputBase,
                    slice_mode: "LEFT",
                    slice_length: length
                });
                addCandidate(`Generic ${inputBase} to ${outputBase} pad left ${length}`, "GENERIC", {
                    format_mode: "GENERIC",
                    input_base: inputBase,
                    output_base: outputBase,
                    pad_side: "LEFT",
                    pad_length: length,
                    pad_char: "0"
                });
            });
        });
    });

    [
        { preset: "W26", total: 26, facilityStart: 1, facilityBits: 8, cardStart: 9, cardBits: 16 },
        { preset: "W32", total: 32, facilityStart: 0, facilityBits: 0, cardStart: 0, cardBits: 32 },
        { preset: "W34", total: 34, facilityStart: 1, facilityBits: 16, cardStart: 17, cardBits: 16 }
    ].forEach(preset => {
        ["NORMAL", "REVERSE"].forEach(bitOrder => {
            ["CARD_NUMBER", "FACILITY_CARD", "FACILITY_DASH_CARD", "FACILITY"].forEach(output => {
                addCandidate(`${preset.preset} ${bitOrder} ${output}`, "WIEGAND", {
                    format_mode: "WIEGAND",
                    input_base: "AUTO",
                    output_base: "TEXT",
                    wiegand_preset: preset.preset,
                    wiegand_total_bits: preset.total,
                    wiegand_facility_start: preset.facilityStart,
                    wiegand_facility_bits: preset.facilityBits,
                    wiegand_card_start: preset.cardStart,
                    wiegand_card_bits: preset.cardBits,
                    wiegand_bit_order: bitOrder,
                    wiegand_output: output
                });
            });
        });
    });

    [26, 32, 34, 35, 37, 40, 48, 56, 64].forEach(totalBits => {
        [0, 4, 8, 10, 12, 16, 20, 24].forEach(facilityBits => {
            [true, false].forEach(hasParity => {
                const facilityStart = hasParity ? 1 : 0;
                const cardStart = facilityStart + facilityBits;
                const cardBits = totalBits - cardStart - (hasParity ? 1 : 0);
                if (cardBits <= 0 || cardStart + cardBits > totalBits) return;
                ["NORMAL", "REVERSE"].forEach(bitOrder => {
                    ["CARD_NUMBER", "FACILITY_CARD", "FACILITY_DASH_CARD"].forEach(output => {
                        addCandidate(`Custom ${totalBits} bit F${facilityBits} C${cardBits} ${bitOrder} ${output}`, "WIEGAND", {
                            format_mode: "WIEGAND",
                            input_base: "AUTO",
                            output_base: "TEXT",
                            wiegand_preset: "CUSTOM",
                            wiegand_total_bits: totalBits,
                            wiegand_facility_start: facilityStart,
                            wiegand_facility_bits: facilityBits,
                            wiegand_card_start: cardStart,
                            wiegand_card_bits: cardBits,
                            wiegand_bit_order: bitOrder,
                            wiegand_output: output
                        });
                    });
                });
            });
        });
    });

    return candidates;
}

function analyzeCardFormats(rawSamples = []) {
    const samples = rawSamples
        .map(sample => ({
            source: String(sample?.source ?? sample?.source_card ?? "").trim(),
            target: String(sample?.target ?? sample?.target_card ?? "").trim()
        }))
        .filter(sample => sample.source && sample.target)
        .slice(0, 10);

    if (samples.length === 0) {
        return { samples, candidates: [], message: "Isi minimal 1 pasangan Source dan Target." };
    }

    const candidates = buildAnalyzerCandidates(samples)
        .map(candidate => {
            const results = samples.map(sample => {
                const preview = formatCardNumber(sample.source, candidate.settings);
                const output = normalizeCompareValue(preview.formatted);
                const target = normalizeCompareValue(sample.target);
                return {
                    source: sample.source,
                    target: sample.target,
                    output: preview.formatted,
                    matched: output === target
                };
            });
            const matchCount = results.filter(result => result.matched).length;
            const confidence = Math.round((matchCount / samples.length) * 100);
            return {
                ...candidate,
                match_count: matchCount,
                sample_count: samples.length,
                confidence,
                results
            };
        })
        .filter(candidate => candidate.match_count > 0)
        .sort((a, b) => {
            if (b.match_count !== a.match_count) return b.match_count - a.match_count;
            if (b.confidence !== a.confidence) return b.confidence - a.confidence;
            if (a.category !== b.category) return a.category === "WIEGAND" ? -1 : 1;
            return a.name.localeCompare(b.name);
        })
        .slice(0, 20);

    return {
        samples,
        candidates,
        message: candidates.length
            ? `${candidates.length} kandidat ditemukan. Gunakan 3-5 sample agar hasil lebih akurat.`
            : "Belum ada kandidat yang cocok. Coba tambah sample atau pastikan source-target dari kartu yang sama."
    };
}

module.exports = {
    ensureCardFormatSchema,
    getCardFormatSettings,
    normalizeCardFormatSettings,
    formatCardNumber,
    analyzeCardFormats
};
