const pool = require("../database/db");

const ROLE_MODULES = [
    "dashboard",
    "visitor_registration",
    "operator_dashboard",
    "visitor_logs",
    "visitor_watchlist",
    "invitation_booking",
    "activity_logs",
    "notifications",
    "host",
    "permission_group",
    "floor",
    "device",
    "api_configuration",
    "monitoring_api_activity",
    "gateway_api",
    "middleware_sync",
    "settings",
    "account_management",
    "monitoring_account",
    "software_activity_log",
    "database_capacity",
    "license_manager",
    "software_update"
];

const PAGE_MODULES = {
    "/dashboard.html": "dashboard",
    "/index.html": "visitor_registration",
    "/operator-dashboard.html": "operator_dashboard",
    "/visitor-logs.html": "visitor_logs",
    "/visitor-watchlist.html": "visitor_watchlist",
    "/invitation-booking.html": "invitation_booking",
    "/activity-log.html": "activity_logs",
    "/notifications.html": "notifications",
    "/host.html": "host",
    "/permission-group.html": "permission_group",
    "/floor-list.html": "floor",
    "/device.html": "device",
    "/api-settings.html": "api_configuration",
    "/monitoring-api-activity.html": "monitoring_api_activity",
    "/gateway-api.html": "gateway_api",
    "/middleware-sync.html": "middleware_sync",
    "/settings.html": "settings",
    "/users.html": "account_management",
    "/monitoring-account.html": "monitoring_account",
    "/software-activity-log.html": "software_activity_log",
    "/database-capacity.html": "database_capacity",
    "/software-update.html": "software_update"
};

const EXECUTE_PATH = /(?:\/test(?:\/|$)|\/retry(?:\/|$)|\/run(?:\/|$)|\/run-now(?:\/|$)|\/start(?:\/|$)|\/stop(?:\/|$)|\/auto-start(?:\/|$)|\/preview(?:\/|$)|\/analyze(?:\/|$)|\/check-now(?:\/|$)|\/backup-now(?:\/|$)|\/cleanup-now(?:\/|$)|\/restore(?:\/|$)|\/repair(?:\/|$)|\/regenerate(?:\/|$)|\/activate-access(?:\/|$)|\/revoke-access(?:\/|$)|\/bm-approval(?:\/|$)|\/send-email(?:\/|$)|\/cancel(?:\/|$)|\/mark-read(?:\/|$)|\/close(?:\/|$)|\/close-all(?:\/|$)|\/apply(?:\/|$)|\/rollback(?:\/|$)|\/download-online(?:\/|$)|\/update-now(?:\/|$)|\/upload(?:\/|$)|\/end-task(?:\/|$)|\/approve-user(?:\/|$)|\/reset-password(?:\/|$)|\/toggle-block(?:\/|$)|\/verify-reset-code(?:\/|$))/i;

const API_RULES = [
    { pattern: /^\/api\/session-settings(?:\/|$)/, module: "settings", viewAnyOf: ["dashboard"] },
    { pattern: /^\/api\/(?:operation-mode|maintenance-settings|database-health)(?:\/|$)/, module: "settings" },
    {
        pattern: /^\/api\/(?:self-registration-settings|self-registration-holidays|qr-settings|card-format-settings|whatsapp-settings|visitor-extension-settings|auto-checkout-settings)(?:\/|$)/,
        module: "settings",
        viewAnyOf: ["visitor_registration", "invitation_booking"]
    },
    { pattern: /^\/api\/(?:smtp-settings|cloudflare-quick-tunnel)(?:\/|$)/, module: "settings" },
    { pattern: /^\/api\/auto-checkout(?:\/|$)/, module: "settings" },
    { pattern: /^\/api\/maintenance(?:\/|$)/, module: "settings" },
    { pattern: /^\/api\/maintenance-jobs(?:\/|$)/, module: "software_activity_log" },
    { pattern: /^\/api\/database-capacity(?:\/|$)/, module: "database_capacity" },
    { pattern: /^\/api\/visitor-watchlist-settings(?:\/|$)/, module: "visitor_watchlist" },
    { pattern: /^\/api\/visitor-watchlist(?:\/|$)/, module: "visitor_watchlist" },
    { pattern: /^\/api\/host-notification-settings(?:\/|$)/, module: "host" },
    { pattern: /^\/api\/hosts(?:\/|$)/, module: "host" },
    { pattern: /^\/api\/permission-groups(?:\/|$)/, module: "permission_group", viewAnyOf: ["visitor_registration", "invitation_booking"] },
    { pattern: /^\/api\/floors(?:\/|$)/, module: "floor", viewAnyOf: ["visitor_registration", "invitation_booking"] },
    { pattern: /^\/api\/devices(?:\/|$)/, module: "device", viewAnyOf: ["visitor_registration", "invitation_booking"] },
    { pattern: /^\/api\/device-sync-logs(?:\/|$)/, module: "device" },
    { pattern: /^\/api\/third-party-settings(?:\/|$)/, module: "api_configuration" },
    { pattern: /^\/api\/monitoring-api-activity(?:\/|$)/, module: "monitoring_api_activity" },
    { pattern: /^\/api\/middleware-sync(?:\/|$)/, module: "middleware_sync" },
    { pattern: /^\/api\/gateway-(?:settings|logs)(?:\/|$)/, module: "gateway_api" },
    { pattern: /^\/api\/software-update(?:\/|$)/, module: "software_update" },
    { pattern: /^\/api\/operator-dashboard(?:\/|$)/, module: "operator_dashboard" },
    { pattern: /^\/api\/roles(?:\/|$)/, module: "account_management" },
    { pattern: /^\/api\/active-sessions(?:\/|$)/, module: "monitoring_account" },
    { pattern: /^\/activity-logs(?:\/|$)/, module: "activity_logs" },
    { pattern: /^\/(?:users|create-user|approve-user|reset-password|delete-user|edit-user|toggle-block|verify-reset-code)(?:\/|$)/, module: "account_management" },
    { pattern: /^\/api\/system-notifications(?:\/|$)/, module: "notifications" },
    { pattern: /^\/api\/delivery-monitoring(?:\/|$)/, module: "notifications" },
    { pattern: /^\/api\/visitor-(?:log-filter-options|logs|stats|analytics|history)(?:\/|$)/, module: "visitor_logs" },
    { pattern: /^\/api\/extension-requests(?:\/|$)/, module: "visitor_registration" },
    { pattern: /^\/api\/invitations(?:\/|$)/, module: "invitation_booking" },
    { pattern: /^\/visitors(?:\/|$)/, module: "visitor_registration" },
    { pattern: /^\/register-visitor(?:\/|$)/, module: "visitor_registration" },
    { pattern: /^\/(?:sync-acs|sync-lift|card-reader)(?:\/|$)/, module: "visitor_registration" },
    { pattern: /^\/export-excel(?:\/|$)/, module: "visitor_logs", action: "can_export" }
];

function normalizeRoleName(value) {
    return String(value || "").trim().toUpperCase();
}

function actionForRequest(req, explicitAction = "") {
    if (explicitAction) return explicitAction;
    if (req.method === "GET" || req.method === "HEAD") return "can_view";
    if (req.method === "DELETE") return "can_delete";
    if (EXECUTE_PATH.test(req.path)) return "can_execute";
    if (req.method === "PUT" || req.method === "PATCH") return "can_edit";
    return "can_add";
}

async function getRolePermissions(roleName) {
    const normalized = normalizeRoleName(roleName);
    if (!normalized) return {};
    if (normalized === "SUPERADMIN") {
        return ROLE_MODULES.reduce((permissions, moduleKey) => {
            permissions[moduleKey] = {
                can_view: true,
                can_add: true,
                can_edit: true,
                can_delete: true,
                can_export: true,
                can_execute: true
            };
            return permissions;
        }, {});
    }

    const result = await pool.query(
        `SELECT p.module_key, p.can_view, p.can_add, p.can_edit,
                p.can_delete, p.can_export, p.can_execute
         FROM account_role_permissions p
         JOIN account_roles r ON r.role_id = p.role_id
         WHERE r.role_name = $1`,
        [normalized]
    );

    return result.rows.reduce((permissions, row) => {
        permissions[row.module_key] = {
            can_view: row.can_view === true,
            can_add: row.can_add === true,
            can_edit: row.can_edit === true,
            can_delete: row.can_delete === true,
            can_export: row.can_export === true,
            can_execute: row.can_execute === true
        };
        return permissions;
    }, {});
}

async function hasRolePermission(roleName, moduleKey, action = "can_view") {
    if (normalizeRoleName(roleName) === "SUPERADMIN") return true;
    if (!ROLE_MODULES.includes(moduleKey)) return false;
    const permissions = await getRolePermissions(roleName);
    return permissions[moduleKey]?.[action] === true;
}

function resolveApiPermission(req) {
    const rule = API_RULES.find(item => item.pattern.test(req.path));
    if (!rule) return null;
    return {
        module: rule.module,
        action: actionForRequest(req, rule.action),
        viewAnyOf: rule.viewAnyOf || []
    };
}

function requireResolvedApiPermission(req, res, next) {
    const required = resolveApiPermission(req);
    if (!required) return next();
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Session expired" });
    }

    const permissionChecks = [hasRolePermission(req.session.role_name, required.module, required.action)];
    if (required.action === "can_view") {
        required.viewAnyOf.forEach(moduleKey => {
            permissionChecks.push(hasRolePermission(req.session.role_name, moduleKey, "can_view"));
        });
    }

    Promise.all(permissionChecks)
        .then(results => {
            const allowed = results.some(Boolean);
            if (!allowed) {
                return res.status(403).json({
                    success: false,
                    message: `Role tidak memiliki privilege ${required.action.replace("can_", "")} untuk modul ${required.module}.`,
                    module: required.module,
                    action: required.action
                });
            }
            next();
        })
        .catch(error => {
            console.error("Role authorization error:", error.message);
            res.status(500).json({ success: false, message: "Gagal memeriksa privilege role." });
        });
}

module.exports = {
    ROLE_MODULES,
    PAGE_MODULES,
    getRolePermissions,
    hasRolePermission,
    requireResolvedApiPermission,
    resolveApiPermission
};
