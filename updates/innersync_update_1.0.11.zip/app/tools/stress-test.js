const fs = require("fs");
const path = require("path");
const http = require("http");
const { performance } = require("perf_hooks");

const DEFAULT_BASE_URL = "http://localhost:8081";

function parseArgs(argv) {
    const args = {
        base: DEFAULT_BASE_URL,
        scenario: "dashboard",
        requests: 100,
        users: 10,
        concurrency: 10,
        timeout: 5000,
        username: "",
        password: "",
        gatewayKey: "",
        gatewayUsername: "",
        gatewayPassword: "",
        gatewayMode: "SYNC",
        mockServer: false,
        mockPort: 9099,
        mockApiCount: 2,
        mockDelay: 300,
        mockJitter: 200,
        mockFailRate: 0,
        mockTimeoutRate: 0,
        retry: 3,
        retryDelay: 300,
        apiMode: "parallel",
        operatorThinkMs: 0,
        allowRealWrites: false,
        realPrefix: "STRESS",
        realHost: "Stress Test Host",
        realGroup: "Stress Test",
        realCompany: "Innersync Stress Test",
        realEmailDomain: "stress.local",
        realCardStart: 990000000,
        realDurationHours: 24,
        realForceNewThirdPartyUser: true,
        output: "",
        warmup: 5
    };

    for (let index = 2; index < argv.length; index += 1) {
        const token = argv[index];
        if (!token.startsWith("--")) continue;
        const key = token.slice(2);
        const next = argv[index + 1];
        const readValue = () => {
            if (next && !next.startsWith("--")) {
                index += 1;
                return next;
            }
            return "true";
        };

        const value = readValue();
        const normalizedKey = {
            "mock-api-count": "mockApiCount",
            "mock-delay": "mockDelay",
            "mock-jitter": "mockJitter",
            "mock-fail-rate": "mockFailRate",
            "mock-timeout-rate": "mockTimeoutRate",
            "retry-delay": "retryDelay",
            "api-mode": "apiMode",
            "operator-think-ms": "operatorThinkMs",
            "allow-real-writes": "allowRealWrites",
            "real-prefix": "realPrefix",
            "real-host": "realHost",
            "real-group": "realGroup",
            "real-company": "realCompany",
            "real-email-domain": "realEmailDomain",
            "real-card-start": "realCardStart",
            "real-duration-hours": "realDurationHours",
            "real-force-new-third-party-user": "realForceNewThirdPartyUser"
        }[key] || key;

        if (["requests", "users", "concurrency", "timeout", "mockPort", "warmup", "mockApiCount", "mockDelay", "mockJitter", "retry", "retryDelay", "operatorThinkMs", "realCardStart", "realDurationHours"].includes(normalizedKey)) {
            args[normalizedKey] = Math.max(0, Number(value) || 0);
        } else if (["mockFailRate", "mockTimeoutRate"].includes(normalizedKey)) {
            args[normalizedKey] = Math.min(100, Math.max(0, Number(value) || 0));
        } else if (normalizedKey === "mockServer") {
            args.mockServer = !["false", "0", "no"].includes(String(value).toLowerCase());
        } else if (["allowRealWrites", "realForceNewThirdPartyUser"].includes(normalizedKey)) {
            args[normalizedKey] = ["true", "1", "yes", "on"].includes(String(value).toLowerCase());
        } else if (normalizedKey === "gateway-key") {
            args.gatewayKey = value;
        } else if (normalizedKey === "gateway-username") {
            args.gatewayUsername = value;
        } else if (normalizedKey === "gateway-password") {
            args.gatewayPassword = value;
        } else if (normalizedKey === "gateway-mode") {
            args.gatewayMode = String(value || "SYNC").toUpperCase();
        } else if (Object.prototype.hasOwnProperty.call(args, normalizedKey)) {
            args[normalizedKey] = value;
        }
    }

    args.base = String(args.base || DEFAULT_BASE_URL).replace(/\/+$/, "");
    args.scenario = String(args.scenario || "dashboard").toLowerCase();
    args.concurrency = Math.max(1, args.concurrency || args.users || 1);
    args.users = Math.max(1, args.users || args.concurrency || 1);
    args.requests = Math.max(1, args.requests || 1);
    args.timeout = Math.max(500, args.timeout || 5000);
    args.mockApiCount = Math.max(1, args.mockApiCount || 1);
    args.retry = Math.max(1, args.retry || 1);
    args.realDurationHours = Math.max(1, args.realDurationHours || 24);
    args.apiMode = String(args.apiMode || "parallel").toLowerCase() === "sequence" ? "sequence" : "parallel";
    return args;
}

function printHelp() {
    console.log(`
Innersync Stress Test Tool

Usage:
  node tools/stress-test.js --scenario dashboard --requests 200 --users 20 --concurrency 20
  node tools/stress-test.js --scenario gateway --gateway-key YOUR_KEY --requests 100 --users 10
  node tools/stress-test.js --scenario checkin-mock --requests 100 --users 5 --concurrency 10
  node tools/stress-test.js --scenario checkin-real --allow-real-writes true --username admin --password PASSWORD --requests 10
  node tools/stress-test.js --mockServer true --mockPort 9099

Options:
  --base                 Base URL Innersync. Default: ${DEFAULT_BASE_URL}
  --scenario             dashboard | gateway | mixed | checkin-mock | checkin-real | mock-server-only
  --requests             Total request simulasi. Default: 100
  --users                Virtual user/session. Default: 10
  --concurrency          Request paralel maksimal. Default: 10
  --timeout              Timeout per request ms. Default: 5000
  --username             Username Innersync untuk login session test
  --password             Password Innersync untuk login session test
  --gateway-key          API key Gateway untuk scenario gateway/mixed
  --gateway-username     Username Gateway jika diaktifkan
  --gateway-password     Password Gateway jika diaktifkan
  --gateway-mode         SYNC atau ASYNC. Default: SYNC
  --mockServer           true untuk start mock third party server lokal
  --mockPort             Port mock server. Default: 9099
  --mock-api-count       Jumlah API vendor simulasi per check-in. Default: 2
  --mock-delay           Delay dasar API vendor ms. Default: 300
  --mock-jitter          Random tambahan delay ms. Default: 200
  --mock-fail-rate       Persen response vendor 500. Default: 0
  --mock-timeout-rate    Persen vendor timeout. Default: 0
  --retry                Maksimal attempt per API. Default: 3
  --retry-delay          Jeda antar retry ms. Default: 300
  --api-mode             parallel atau sequence. Default: parallel
  --operator-think-ms    Simulasi jeda operator sebelum submit ms. Default: 0
  --allow-real-writes    Wajib true untuk scenario checkin-real
  --real-prefix          Prefix data test real. Default: STRESS
  --real-host            Host test real. Default: Stress Test Host
  --real-group           Grouping test real. Default: Stress Test
  --real-company         Company test real. Default: Innersync Stress Test
  --real-email-domain    Domain email dummy. Default: stress.local
  --real-card-start      Nomor awal kartu dummy. Default: 990000000
  --real-duration-hours  Durasi visitor test dari start sampai expiry. Default: 24
  --real-force-new-third-party-user  true agar test tidak reuse slot U lama. Default: true
  --output               Path file JSON report. Default: exports/stress-test/stress-test-*.json
  --warmup               Jumlah warmup request sebelum dihitung. Default: 5

Catatan:
  Mock server hanya endpoint dummy. Pakai URL http://127.0.0.1:9099/mock di API Setting/Destination
  jika ingin menguji flow integrasi tanpa menyentuh vendor asli.
  Scenario checkin-mock berjalan full mock, tidak membuat visitor di database Innersync.
  Scenario checkin-real membuat visitor sungguhan dan dapat memicu background API/email sesuai setting aktif.
`);
}

function nowFileStamp() {
    const d = new Date();
    const pad = value => String(value).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function startMockServer(port, behavior = {}) {
    const server = http.createServer((req, res) => {
        let body = "";
        req.on("data", chunk => {
            body += chunk;
            if (body.length > 1024 * 1024) req.destroy();
        });
        req.on("end", () => {
            const parsedUrl = new URL(req.url, `http://localhost:${port}`);
            const delayParam = parsedUrl.searchParams.get("delay");
            const statusParam = parsedUrl.searchParams.get("status");
            const delayMs = delayParam !== null
                ? Number(delayParam || 0)
                : Math.max(0, Number(behavior.delay || 0) + Math.round(Math.random() * Number(behavior.jitter || 0)));
            const timeoutRate = Number(behavior.timeoutRate || 0);
            const failRate = Number(behavior.failRate || 0);
            const roll = Math.random() * 100;
            if (timeoutRate > 0 && roll < timeoutRate) {
                return;
            }
            const status = statusParam !== null
                ? Number(statusParam || 200)
                : (failRate > 0 && roll < timeoutRate + failRate ? 500 : 200);
            const send = () => {
                res.writeHead(status, { "Content-Type": "application/json" });
                res.end(JSON.stringify({
                    success: status >= 200 && status < 300,
                    mock: true,
                    provider: parsedUrl.pathname.split("/").filter(Boolean).pop() || "mock",
                    method: req.method,
                    url: req.url,
                    received_at: new Date().toISOString(),
                    body_length: body.length
                }));
            };
            if (delayMs > 0) setTimeout(send, delayMs);
            else send();
        });
    });

    return new Promise((resolve, reject) => {
        server.once("error", reject);
        server.listen(port, "127.0.0.1", () => resolve(server));
    });
}

function getSetCookie(headers) {
    if (!headers?.getSetCookie) {
        const single = headers?.get?.("set-cookie");
        return single ? [single] : [];
    }
    return headers.getSetCookie();
}

class HttpClient {
    constructor(baseUrl, timeoutMs) {
        this.baseUrl = baseUrl;
        this.timeoutMs = timeoutMs;
        this.cookie = "";
    }

    updateCookie(headers) {
        const cookies = getSetCookie(headers)
            .map(cookie => cookie.split(";")[0])
            .filter(Boolean);
        if (!cookies.length) return;
        const jar = new Map();
        for (const part of this.cookie.split(";").map(value => value.trim()).filter(Boolean)) {
            const [name, ...rest] = part.split("=");
            jar.set(name, rest.join("="));
        }
        for (const part of cookies) {
            const [name, ...rest] = part.split("=");
            jar.set(name, rest.join("="));
        }
        this.cookie = [...jar.entries()].map(([key, value]) => `${key}=${value}`).join("; ");
    }

    async request(method, urlPath, options = {}) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), options.timeout || this.timeoutMs);
        const headers = {
            ...(options.headers || {})
        };
        if (this.cookie) headers.Cookie = this.cookie;

        let body = options.body;
        if (body && typeof body === "object" && !(body instanceof FormData)) {
            headers["Content-Type"] = headers["Content-Type"] || "application/json";
            body = JSON.stringify(body);
        }

        const startedAt = performance.now();
        try {
            const response = await fetch(`${this.baseUrl}${urlPath}`, {
                method,
                headers,
                body,
                signal: controller.signal
            });
            this.updateCookie(response.headers);
            const text = await response.text();
            let data = null;
            try {
                data = text ? JSON.parse(text) : null;
            } catch (_) {
                data = { raw: text.slice(0, 500) };
            }
            return {
                ok: response.ok,
                status: response.status,
                duration_ms: Math.round(performance.now() - startedAt),
                data
            };
        } catch (error) {
            return {
                ok: false,
                status: 0,
                duration_ms: Math.round(performance.now() - startedAt),
                error: error.name === "AbortError" ? `Timeout after ${options.timeout || this.timeoutMs} ms` : error.message
            };
        } finally {
            clearTimeout(timer);
        }
    }

    get(urlPath, options) {
        return this.request("GET", urlPath, options);
    }

    post(urlPath, body, options = {}) {
        return this.request("POST", urlPath, { ...options, body });
    }
}

async function loginClient(client, username, password) {
    if (!username || !password) return { skipped: true };
    const response = await client.post("/login", { username, password });
    return {
        skipped: false,
        success: response.ok && response.data?.success === true,
        response
    };
}

function createVisitorPayload(index) {
    const seq = String(index + 1).padStart(6, "0");
    const startDate = new Date(Date.now() + 60 * 1000).toISOString();
    const expiryDate = new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString();
    return {
        action: "CHECKIN",
        mode: "SYNC",
        request_id: `STRESS-${Date.now()}-${seq}`,
        source_system: "Innersync Stress Test",
        visitor: {
            first_name: "Stress",
            second_name: `Visitor ${seq}`,
            company_name: "Innersync Test",
            identity_number: `STRESS-ID-${seq}`,
            card_number: String(900000000 + index),
            host: "Stress Test Host",
            permission_group: "Stress Test",
            start_date: startDate,
            expiry_date: expiryDate,
            purpose_note: "Automated stress test"
        }
    };
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function createMockCheckinPayload(index, provider) {
    const base = createVisitorPayload(index);
    return {
        ...base,
        provider,
        simulated: true,
        visitor: {
            ...base.visitor,
            face_photo: "mock-face-photo-base64",
            id_card_photo: "mock-id-card-photo-base64"
        }
    };
}

async function postAbsoluteJson(url, body, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const startedAt = performance.now();
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
            signal: controller.signal
        });
        const text = await response.text();
        let data = null;
        try {
            data = text ? JSON.parse(text) : null;
        } catch (_) {
            data = { raw: text.slice(0, 500) };
        }
        return {
            ok: response.ok,
            status: response.status,
            duration_ms: Math.round(performance.now() - startedAt),
            data
        };
    } catch (error) {
        return {
            ok: false,
            status: 0,
            duration_ms: Math.round(performance.now() - startedAt),
            error: error.name === "AbortError" ? `Timeout after ${timeoutMs} ms` : error.message
        };
    } finally {
        clearTimeout(timer);
    }
}

function getMockProviderName(index) {
    const known = ["INNERANGE", "SCHINDLER", "DEVICE", "LIFT", "FACE_RECOGNITION", "THIRD_PARTY"];
    return known[index] || `THIRD_PARTY_${index + 1}`;
}

async function callMockApiWithRetry(args, visitorIndex, providerIndex) {
    const provider = getMockProviderName(providerIndex);
    const url = `http://127.0.0.1:${args.mockPort}/mock/${encodeURIComponent(provider.toLowerCase())}`;
    const attempts = [];

    for (let attempt = 1; attempt <= args.retry; attempt += 1) {
        const result = await postAbsoluteJson(url, createMockCheckinPayload(visitorIndex, provider), args.timeout);
        attempts.push({
            attempt,
            ok: result.ok,
            status: result.status,
            duration_ms: result.duration_ms,
            error: result.error || result.data?.message || null
        });
        if (result.ok) {
            return {
                provider,
                ok: true,
                status: result.status,
                attempts: attempt,
                duration_ms: attempts.reduce((sum, item) => sum + item.duration_ms, 0),
                attempt_details: attempts
            };
        }
        if (attempt < args.retry && args.retryDelay > 0) {
            await sleep(args.retryDelay);
        }
    }

    const lastAttempt = attempts[attempts.length - 1] || {};
    return {
        provider,
        ok: false,
        status: lastAttempt.status || 0,
        attempts: attempts.length,
        duration_ms: attempts.reduce((sum, item) => sum + item.duration_ms, 0),
        error: lastAttempt.error || `Mock API ${provider} gagal setelah ${attempts.length} attempt`,
        attempt_details: attempts
    };
}

async function runCheckinMockScenario(args, index) {
    const startedAt = performance.now();
    if (args.operatorThinkMs > 0) {
        await sleep(args.operatorThinkMs);
    }

    const apiIndexes = Array.from({ length: args.mockApiCount }, (_, itemIndex) => itemIndex);
    const apiResults = [];

    if (args.apiMode === "sequence") {
        for (const apiIndex of apiIndexes) {
            apiResults.push(await callMockApiWithRetry(args, index, apiIndex));
        }
    } else {
        apiResults.push(...await Promise.all(apiIndexes.map(apiIndex => callMockApiWithRetry(args, index, apiIndex))));
    }

    const ok = apiResults.every(item => item.ok);
    const attempts = apiResults.reduce((sum, item) => sum + item.attempts, 0);
    const failedApi = apiResults.find(item => !item.ok);
    return {
        ok,
        status: ok ? 200 : (failedApi?.status || 500),
        duration_ms: Math.round(performance.now() - startedAt),
        data: {
            scenario: "checkin-mock",
            transaction_id: `MOCK-CHECKIN-${Date.now()}-${String(index + 1).padStart(6, "0")}`,
            api_mode: args.apiMode,
            api_count: args.mockApiCount,
            total_attempts: attempts,
            visitor: createVisitorPayload(index).visitor,
            api_results: apiResults
        },
        error: failedApi?.error
    };
}

function createTinyPngBlob() {
    const base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=";
    const buffer = Buffer.from(base64, "base64");
    return new Blob([buffer], { type: "image/png" });
}

function appendRealCheckinFields(formData, args, index) {
    const seq = String(index + 1).padStart(6, "0");
    const prefix = String(args.realPrefix || "STRESS").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 24) || "STRESS";
    const startDate = new Date(Date.now() + 60 * 1000);
    const expiryDate = new Date(Date.now() + Number(args.realDurationHours || 24) * 60 * 60 * 1000);
    const fields = {
        first_name: `${prefix}${seq}`,
        second_name: "Visitor",
        company_name: args.realCompany,
        host: args.realHost,
        identity_type: "STRESS_TEST",
        email_address: `${prefix.toLowerCase()}.${seq}@${args.realEmailDomain}`,
        telephone_number: `0800${String(index + 1).padStart(8, "0")}`,
        start_date: startDate.toISOString(),
        expiry_date: expiryDate.toISOString(),
        card_number: String(Number(args.realCardStart || 990000000) + index),
        identity_number: `${prefix}-ID-${seq}-${Date.now()}`,
        permission_group: args.realGroup,
        purpose_note: "Automated real stress test",
        booking_code: "",
        skip_third_party_reuse: args.realForceNewThirdPartyUser ? "true" : "false",
        force_new_third_party_user: args.realForceNewThirdPartyUser ? "true" : "false"
    };
    for (const [key, value] of Object.entries(fields)) {
        formData.append(key, value == null ? "" : String(value));
    }
    formData.append("visitor_photo", createTinyPngBlob(), "stress-visitor.png");
    formData.append("identity_photo", createTinyPngBlob(), "stress-idcard.png");
    return fields;
}

async function runCheckinRealScenario(client, args, index) {
    if (!args.allowRealWrites) {
        return {
            ok: false,
            status: 0,
            duration_ms: 0,
            error: "Scenario checkin-real ditolak. Tambahkan --allow-real-writes true karena test ini membuat data visitor sungguhan."
        };
    }
    if (args.operatorThinkMs > 0) {
        await sleep(args.operatorThinkMs);
    }
    const formData = new FormData();
    const fields = appendRealCheckinFields(formData, args, index);
    const response = await client.post("/register-visitor", formData);
    return {
        ...response,
        data: {
            scenario: "checkin-real",
            request_fields: {
                identity_number: fields.identity_number,
                card_number: fields.card_number,
                host: fields.host,
                permission_group: fields.permission_group,
                force_new_third_party_user: fields.force_new_third_party_user
            },
            response: response.data
        },
        error: response.ok ? undefined : (response.error || response.data?.message || response.data?.error)
    };
}

async function runDashboardScenario(client, index) {
    const endpoints = [
        "/api/visitor-stats",
        "/api/database-capacity",
        "/api/system-notifications/unread-count",
        "/api/software-update/status",
        "/api/service-status",
        `/visitors/search?id=STRESS-ID-${String(index + 1).padStart(6, "0")}`
    ];
    const endpoint = endpoints[index % endpoints.length];
    return client.get(endpoint);
}

async function runGatewayScenario(client, args, index) {
    if (!args.gatewayKey) {
        return {
            ok: false,
            status: 0,
            duration_ms: 0,
            error: "gateway-key belum diisi"
        };
    }
    const body = createVisitorPayload(index);
    body.mode = args.gatewayMode;
    const headers = {
        "x-innersync-gateway-key": args.gatewayKey
    };
    if (args.gatewayUsername) headers["x-innersync-gateway-username"] = args.gatewayUsername;
    if (args.gatewayPassword) headers["x-innersync-gateway-password"] = args.gatewayPassword;
    return client.post("/api/gateway/execute", body, { headers });
}

async function runOneRequest(client, args, index) {
    if (args.scenario === "dashboard") return runDashboardScenario(client, index);
    if (args.scenario === "gateway") return runGatewayScenario(client, args, index);
    if (args.scenario === "checkin-mock") return runCheckinMockScenario(args, index);
    if (args.scenario === "checkin-real") return runCheckinRealScenario(client, args, index);
    if (args.scenario === "mixed") {
        return index % 3 === 0
            ? runGatewayScenario(client, args, index)
            : runDashboardScenario(client, index);
    }
    return {
        ok: false,
        status: 0,
        duration_ms: 0,
        error: `Scenario tidak dikenal: ${args.scenario}`
    };
}

function percentile(values, pct) {
    if (!values.length) return 0;
    const sorted = [...values].sort((a, b) => a - b);
    const index = Math.min(sorted.length - 1, Math.ceil((pct / 100) * sorted.length) - 1);
    return sorted[index];
}

function summarize(results, startedAt, finishedAt) {
    const durations = results.map(item => item.duration_ms).filter(value => Number.isFinite(value));
    const successCount = results.filter(item => item.ok).length;
    const failed = results.filter(item => !item.ok);
    const statusCounts = {};
    for (const result of results) {
        const key = String(result.status || "ERROR");
        statusCounts[key] = (statusCounts[key] || 0) + 1;
    }
    const totalSeconds = Math.max(0.001, (finishedAt - startedAt) / 1000);
    return {
        total_requests: results.length,
        success: successCount,
        failed: failed.length,
        success_rate_percent: Number(((successCount / Math.max(1, results.length)) * 100).toFixed(2)),
        total_duration_seconds: Number(totalSeconds.toFixed(2)),
        requests_per_second: Number((results.length / totalSeconds).toFixed(2)),
        avg_ms: durations.length ? Math.round(durations.reduce((sum, value) => sum + value, 0) / durations.length) : 0,
        min_ms: durations.length ? Math.min(...durations) : 0,
        max_ms: durations.length ? Math.max(...durations) : 0,
        p50_ms: percentile(durations, 50),
        p90_ms: percentile(durations, 90),
        p95_ms: percentile(durations, 95),
        p99_ms: percentile(durations, 99),
        status_counts: statusCounts,
        first_errors: failed.slice(0, 10).map(item => ({
            status: item.status,
            duration_ms: item.duration_ms,
            error: item.error || item.data?.message || item.data?.error || JSON.stringify(item.data || {}).slice(0, 180)
        }))
    };
}

async function runPool(clients, args, startIndex, count, onProgress) {
    const results = [];
    let nextIndex = 0;
    let completed = 0;
    const workerCount = Math.min(args.concurrency, count);

    async function worker(workerId) {
        while (true) {
            const localIndex = nextIndex;
            nextIndex += 1;
            if (localIndex >= count) return;
            const client = clients[(startIndex + localIndex + workerId) % clients.length];
            const result = await runOneRequest(client, args, startIndex + localIndex);
            results.push(result);
            completed += 1;
            if (onProgress && (completed === count || completed % Math.max(1, Math.ceil(count / 10)) === 0)) {
                onProgress(completed, count);
            }
        }
    }

    await Promise.all(Array.from({ length: workerCount }, (_, index) => worker(index)));
    return results;
}

function writeReport(args, summary, results) {
    const outputPath = args.output
        ? path.resolve(args.output)
        : path.resolve("exports", "stress-test", `stress-test-${nowFileStamp()}.json`);
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, JSON.stringify({
        generated_at: new Date().toISOString(),
        args: {
            ...args,
            password: args.password ? "***" : "",
            gatewayKey: args.gatewayKey ? "***" : "",
            gatewayPassword: args.gatewayPassword ? "***" : ""
        },
        summary,
        results
    }, null, 2));
    return outputPath;
}

async function main() {
    const args = parseArgs(process.argv);
    if (process.argv.includes("--help") || process.argv.includes("-h")) {
        printHelp();
        return;
    }

    let mockServer = null;
    if (args.mockServer || args.scenario === "mock-server-only" || args.scenario === "checkin-mock") {
        mockServer = await startMockServer(args.mockPort, {
            delay: args.mockDelay,
            jitter: args.mockJitter,
            failRate: args.mockFailRate,
            timeoutRate: args.mockTimeoutRate
        });
        console.log(`Mock third party server running: http://127.0.0.1:${args.mockPort}/mock`);
        if (args.scenario === "mock-server-only") {
            console.log("Tekan Ctrl+C untuk stop mock server.");
            return;
        }
    }

    const clients = Array.from({ length: args.users }, () => new HttpClient(args.base, args.timeout));

    if (args.scenario === "checkin-mock") {
        console.log("Login dilewati. Scenario checkin-mock berjalan full mock dan tidak membuat data DB.");
    } else if (args.username && args.password) {
        console.log(`Login ${args.users} virtual session...`);
        const loginResults = await Promise.all(clients.map(client => loginClient(client, args.username, args.password)));
        const loginSuccess = loginResults.filter(item => item.success || item.skipped).length;
        console.log(`Login success: ${loginSuccess}/${args.users}`);
        const firstFailed = loginResults.find(item => item.skipped === false && !item.success);
        if (firstFailed) {
            console.log(`Warning login gagal: HTTP ${firstFailed.response.status} ${firstFailed.response.data?.message || firstFailed.response.error || ""}`);
        }
    } else {
        console.log("Login dilewati. Endpoint yang butuh session mungkin gagal 401.");
    }

    const effectiveWarmup = args.scenario === "checkin-real" ? 0 : args.warmup;
    if (args.scenario === "checkin-real" && args.warmup > 0) {
        console.log("Warmup dilewati untuk scenario checkin-real supaya tidak membuat data visitor tambahan.");
    }

    if (effectiveWarmup > 0) {
        console.log(`Warmup ${effectiveWarmup} request...`);
        await runPool(clients, { ...args, concurrency: Math.min(args.concurrency, effectiveWarmup) }, 0, effectiveWarmup);
    }

    console.log(`Running scenario=${args.scenario}, requests=${args.requests}, users=${args.users}, concurrency=${args.concurrency}`);
    const startedAt = performance.now();
    const results = await runPool(clients, args, effectiveWarmup, args.requests, (done, total) => {
        process.stdout.write(`\rProgress ${done}/${total}`);
    });
    const finishedAt = performance.now();
    process.stdout.write("\n");

    const summary = summarize(results, startedAt, finishedAt);
    const reportPath = writeReport(args, summary, results);

    console.log("\nSummary");
    console.log("-------");
    console.log(`Success          : ${summary.success}/${summary.total_requests} (${summary.success_rate_percent}%)`);
    console.log(`Failed           : ${summary.failed}`);
    console.log(`Requests/second  : ${summary.requests_per_second}`);
    console.log(`Avg / P95 / Max  : ${summary.avg_ms} ms / ${summary.p95_ms} ms / ${summary.max_ms} ms`);
    console.log(`Status counts    : ${JSON.stringify(summary.status_counts)}`);
    if (summary.first_errors.length) {
        console.log("First errors     :");
        for (const error of summary.first_errors.slice(0, 5)) {
            console.log(`  - HTTP ${error.status}: ${error.error}`);
        }
    }
    console.log(`Report           : ${reportPath}`);

    if (mockServer) {
        mockServer.close();
    }
}

main().catch(error => {
    console.error(error.message || error);
    process.exitCode = 1;
});
