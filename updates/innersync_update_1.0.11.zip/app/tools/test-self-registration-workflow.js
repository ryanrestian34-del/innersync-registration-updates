const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { Pool } = require("pg");
const sourcePool = require("../database/db");
const { createSelfRegistrationWorkflow } = require("../services/selfRegistrationWorkflow");

async function main() {
    const schema = `test_self_access_${crypto.randomBytes(8).toString("hex")}`;
    const db = new Pool({ ...sourcePool.options, options: `-c search_path=${schema},public` });
    const calls = [];
    const blacklisted = new Set();
    let failStage = null;
    let confirmStage = null;
    let failEmail = false;
    let whatsappEnabled = false;
    let emptyPlan = false;
    let emails = 0;
    let whatsapps = 0;
    let blacklistDuringSend = false;
    const stage = id => ({ kind: "MOCK", id, state: "PENDING" });
    const workflow = createSelfRegistrationWorkflow(db, {
        isBlacklisted: async id => blacklisted.has(id),
        notify: async () => {},
        qrValue: async code => code,
        release: async () => {},
        plan: async () => ({ digits: 10, add: emptyPlan ? [] : [stage(1),stage(2)], remove: emptyPlan ? [] : [stage(1),stage(2)] }),
        send: async (target, visitor, revoke) => {
            calls.push({ id: target.id, visitor: visitor.visitor_id, revoke, code: visitor.card_number });
            if (blacklistDuringSend && target.id === 2 && !revoke) blacklisted.add(visitor.identity_number);
            return { success: target.id !== failStage, error: "MOCK failure" };
        },
        confirm: async target => target.id === confirmStage,
        email: async (_invitation, qr) => {
            assert(/^\d+$/.test(qr));
            emails++;
            if (failEmail) throw new Error("MOCK SMTP unavailable");
        },
        whatsapp: async (_invitation, qr) => {
            assert(/^\d+$/.test(qr));
            if (!whatsappEnabled) return { skipped: true };
            whatsapps++;
            return { success: true };
        }
    });
    async function invitation(overrides = {}) {
        const name = crypto.randomBytes(8).toString("hex");
        const data = { status: "PENDING", mode: "AUTOMATIC", timing: "AFTER_APPROVAL", approval: "BM_AND_HOST", bm: "APPROVED", host: "APPROVED", identity: name, ...overrides };
        const row = (await db.query(`INSERT INTO visitor_invitations
            (booking_code,first_name,identity_number,host,email_address,permission_group,status,access_mode,activation_timing,
             approval_mode,bm_approval_status,host_approval_status,start_date,expiry_date,approval_timeout_at,created_by)
            VALUES ($1,'Test',$2,'Test Host','test@example.invalid','Visitor',$3,$4,$5,$6,$7,$8,NOW(),NOW()+INTERVAL '1 day',NOW()+INTERVAL '1 hour','SELF_REGISTRATION') RETURNING *`,
        [`INV-TEST-${name}`,data.identity,data.status,data.mode,data.timing,data.approval,data.bm,data.host])).rows[0];
        return row;
    }
    const state = async id => (await db.query(`SELECT i.status,j.* FROM visitor_invitations i
        LEFT JOIN self_registration_access_jobs j ON j.invitation_id=i.invitation_id WHERE i.invitation_id=$1`, [id])).rows[0];
    async function waitForState(id, predicate) {
        for (let attempt = 0; attempt < 100; attempt += 1) {
            const current = await state(id);
            if (predicate(current)) return current;
            await new Promise(resolve => setTimeout(resolve, 10));
        }
        throw new Error(`Timed out waiting for invitation ${id}`);
    }
    try {
        await sourcePool.query(`CREATE SCHEMA ${schema}`);
        for (const [table, key] of [["visitor_invitations","invitation_id"],["visitor_registration","visitor_id"],["visitor_approval_tokens","token_id"]]) {
            await db.query(`CREATE TABLE ${table} (LIKE public.${table} INCLUDING DEFAULTS)`);
            await db.query(`CREATE SEQUENCE ${table}_test_seq`);
            await db.query(`ALTER TABLE ${table} ALTER COLUMN ${key} SET DEFAULT nextval('${schema}.${table}_test_seq')`);
            await db.query(`ALTER TABLE ${table} ADD PRIMARY KEY (${key})`);
        }
        await db.query("CREATE TABLE self_registration_settings (LIKE public.self_registration_settings INCLUDING DEFAULTS)");
        await workflow.ensureSchema();
        const operator = await invitation({ mode: "OPERATOR" });
        const waiting = await invitation({ status: "WAITING_HOST_APPROVAL", host: "WAITING" });
        const incomplete = await invitation({ host: "WAITING" });
        await workflow.queueApproved();
        for (const i of [operator,waiting,incomplete]) assert.equal((await state(i.invitation_id)).invitation_id, null);
        await db.query("UPDATE visitor_invitations SET approval_timeout_at=NOW()-INTERVAL '1 second' WHERE invitation_id=$1", [waiting.invitation_id]);
        await db.query("INSERT INTO visitor_approval_tokens (invitation_id,approval_step,token,status,expires_at) VALUES ($1,'HOST','TEST-TOKEN','ACTIVE',NOW()+INTERVAL '1 hour')", [waiting.invitation_id]);
        await workflow.expireApprovals();
        assert.equal((await state(waiting.invitation_id)).status,"APPROVAL_TIMEOUT");
        assert.equal((await db.query("SELECT status FROM visitor_approval_tokens WHERE token='TEST-TOKEN'")).rows[0].status,"EXPIRED");
        console.log("PASS approval gates, operator default, authoritative deadline and token expiration");

        const ok = await invitation();
        await workflow.queueApproved();
        await Promise.all([workflow.processJob(ok.invitation_id),workflow.processJob(ok.invitation_id)]);
        const ready = await state(ok.invitation_id);
        assert.equal(ready.status,"CHECKED_IN");
        assert(/^\d{10}$/.test(ready.access_code));
        const person = (await db.query("SELECT * FROM visitor_registration WHERE visitor_id=$1",[ready.visitor_id])).rows[0];
        assert(person.check_in_time);
        assert.equal(person.status,"CHECKED_IN");
        const sent = calls.length;
        await workflow.processJob(ok.invitation_id);
        assert.equal(calls.length,sent);
        assert.equal(emails,1);
        assert.equal((await state(ok.invitation_id)).access_code,ready.access_code);
        console.log("PASS AFTER_APPROVAL creates one visitor/code, activates targets, checks in once, and sends no duplicate API or email");

        whatsappEnabled = true;
        const autoWhatsapp = await invitation();
        const beforeWhatsapps = whatsapps;
        await workflow.queueApproved();
        await workflow.processJob(autoWhatsapp.invitation_id);
        assert.equal((await state(autoWhatsapp.invitation_id)).whatsapp_status, "SENT");
        assert.equal(whatsapps, beforeWhatsapps + 1);
        await workflow.processJob(autoWhatsapp.invitation_id);
        assert.equal(whatsapps, beforeWhatsapps + 1);
        whatsappEnabled = false;
        console.log("PASS automatic WhatsApp QR sends once and does not duplicate");

        let statusHandler;
        const source = fs.readFileSync(path.join(__dirname, "../routes/visitorRoutes.js"), "utf8");
        const context = vm.createContext({ pool: db, selfRegistrationWorkflow: workflow, normalizeBookingCode: value => value, router: { get: (_path, handler) => { statusHandler = handler; } } });
        vm.runInContext(source.slice(source.indexOf('router.get("/api/public/self-registration/status/:code",'), source.indexOf('router.get("/api/hosts",')), context);
        const token = crypto.randomBytes(32).toString("hex");
        await db.query("UPDATE visitor_invitations SET public_status_token=$2 WHERE invitation_id=$1", [ok.invitation_id, token]);
        async function publicStatus(secret) {
            let status = 200;
            let body;
            await statusHandler({ params: { code: ok.booking_code }, query: { token: secret } }, { status(value) { status = value; return this; }, json(value) { body = value; } });
            return { status, body };
        }
        assert.equal((await publicStatus("")).status, 404);
        assert.equal((await publicStatus("wrong-token")).status, 404);
        assert.equal((await publicStatus(token)).body.data.access_code, ready.qr_value);
        console.log("PASS automatic access QR requires the registering browser's secret, not booking code alone");

        const rejected = await invitation({
            status: "REJECTED",
            bm: "REJECTED",
            host: "PENDING_BM"
        });
        const rejectedToken = crypto.randomBytes(32).toString("hex");
        await db.query(
            "UPDATE visitor_invitations SET public_status_token=$2, bm_reject_reason=$3 WHERE invitation_id=$1",
            [rejected.invitation_id, rejectedToken, "Data identitas belum sesuai"]
        );
        let rejectedStatus = 200;
        let rejectedBody;
        await statusHandler(
            { params: { code: rejected.booking_code }, query: { token: rejectedToken } },
            { status(value) { rejectedStatus = value; return this; }, json(value) { rejectedBody = value; } }
        );
        assert.equal(rejectedStatus, 200);
        assert.equal(rejectedBody.data.status, "REJECTED");
        assert.equal(rejectedBody.data.bm_reject_reason, "Data identitas belum sesuai");
        console.log("PASS public self-registration status includes rejection reason");

        const partial = await invitation();
        failStage = 2;
        await workflow.queueApproved();
        await workflow.processJob(partial.invitation_id);
        const failed = await state(partial.invitation_id);
        assert.equal(failed.status,"CHECKED_IN");
        assert.equal(failed.error,"MOCK failure");
        assert.equal(failed.stages[0].state,"DONE");
        assert.equal(failed.stages[1].state,"FAILED");
        failStage = null;
        await workflow.retry(partial.invitation_id);
        await workflow.processJob(partial.invitation_id);
        const emailFailure = await state(partial.invitation_id);
        assert.equal(emailFailure.status,"CHECKED_IN");
        assert.equal(emailFailure.error,null);
        assert.equal(emailFailure.access_code,failed.access_code);
        assert.equal(calls.filter(c=>c.visitor===failed.visitor_id&&c.id===1&&!c.revoke).length,1);
        await db.query("UPDATE self_registration_access_jobs SET email_status='FAILED' WHERE invitation_id=$1", [partial.invitation_id]);
        const beforeEmailRetry = calls.length;
        await workflow.retry(partial.invitation_id,true);
        await workflow.processJob(partial.invitation_id);
        assert.equal((await state(partial.invitation_id)).email_status,"SENT");
        assert.equal(calls.length,beforeEmailRetry);
        console.log("PASS failed-target-only retry and email-only resend preserve visitor/card");

        const reconciled = await invitation();
        failStage = 1;
        confirmStage = 1;
        const beforeReconciledCalls = calls.length;
        await workflow.queueApproved();
        await workflow.processJob(reconciled.invitation_id);
        const reconciledState = await state(reconciled.invitation_id);
        assert.equal(reconciledState.status, "CHECKED_IN");
        assert.deepEqual(reconciledState.stages.map(item => item.state), ["DONE", "DONE"]);
        assert.equal(calls.length, beforeReconciledCalls + 2);
        failStage = null;
        confirmStage = null;
        console.log("PASS timeout-after-write is reconciled and the next target continues without resending the applied stage");

        const arrival = await invitation({ timing: "ON_OPERATOR_CHECKIN" });
        const beforeArrivalCalls = calls.length;
        const beforeArrivalEmails = emails;
        await workflow.queueApproved();
        await workflow.processJob(arrival.invitation_id);
        const waitingArrival = await state(arrival.invitation_id);
        assert.equal(waitingArrival.status, "WAITING_ARRIVAL");
        assert.equal(waitingArrival.phase, "WAITING_ARRIVAL");
        assert.equal((await db.query("SELECT check_in_time,status FROM visitor_registration WHERE visitor_id=$1", [waitingArrival.visitor_id])).rows[0].check_in_time, null);
        assert.equal(calls.length, beforeArrivalCalls);
        assert.equal(emails, beforeArrivalEmails);
        await workflow.processJob(arrival.invitation_id);
        assert.equal(calls.length, beforeArrivalCalls);
        assert.equal(emails, beforeArrivalEmails);
        await assert.rejects(workflow.retry(arrival.invitation_id, true), /QR belum tersedia/);
        assert.equal((await workflow.activate(arrival.invitation_id)).status, "CHECKED_IN");
        await waitForState(arrival.invitation_id, row => row.email_status === "SENT" && row.stages.every(stageItem => stageItem.state === "DONE"));
        assert.equal(emails, beforeArrivalEmails + 1);
        const arrived = await state(arrival.invitation_id);
        assert.equal(arrived.access_code, waitingArrival.access_code);
        assert.equal(calls.filter(call => call.visitor === waitingArrival.visitor_id && !call.revoke).length, 2);
        assert((await db.query("SELECT check_in_time FROM visitor_registration WHERE visitor_id=$1", [waitingArrival.visitor_id])).rows[0].check_in_time);
        console.log("PASS location QR mode prepares inactive access, waits without API calls, then activates and checks in from visitor scan");

        const noShow = await invitation({ timing: "ON_OPERATOR_CHECKIN" });
        await workflow.queueApproved();
        await workflow.processJob(noShow.invitation_id);
        const noShowWaiting = await state(noShow.invitation_id);
        const beforeNoShowRevoke = calls.length;
        await workflow.revoke(noShow.invitation_id);
        await workflow.processJob(noShow.invitation_id);
        assert.equal((await state(noShow.invitation_id)).status, "ACCESS_EXPIRED");
        assert.equal(calls.length, beforeNoShowRevoke);
        assert.equal((await db.query("SELECT check_in_time,check_out_time FROM visitor_registration WHERE visitor_id=$1", [noShowWaiting.visitor_id])).rows[0].check_out_time, null);
        console.log("PASS no-show/cancel before location QR check-in expires without sending add or remove API calls");

        const repeatNoShow = await invitation({ timing: "ON_OPERATOR_CHECKIN", identity: noShow.identity_number });
        const beforeRepeatNoShowEmails = emails;
        await workflow.queueApproved();
        await workflow.processJob(repeatNoShow.invitation_id);
        assert.equal((await state(repeatNoShow.invitation_id)).status, "WAITING_ARRIVAL");
        assert.equal(calls.length, beforeNoShowRevoke);
        assert.equal(emails, beforeRepeatNoShowEmails);
        const duplicateArrival = await invitation({ timing: "ON_OPERATOR_CHECKIN", identity: noShow.identity_number });
        await workflow.queueApproved();
        await workflow.processJob(duplicateArrival.invitation_id);
        assert.equal((await state(duplicateArrival.invitation_id)).status, "ACCESS_FAILED");
        assert.equal((await state(duplicateArrival.invitation_id)).visitor_id, null);
        console.log("PASS completed no-show permits same-ID registration; an actual waiting arrival still blocks duplicates");

        const failedArrival = await invitation({ timing: "ON_OPERATOR_CHECKIN" });
        await workflow.queueApproved();
        await workflow.processJob(failedArrival.invitation_id);
        failStage = 2;
        assert.equal((await workflow.activate(failedArrival.invitation_id)).status, "CHECKED_IN");
        const failedArrivalJob = await waitForState(failedArrival.invitation_id, row => !!row.error);
        assert.equal(failedArrivalJob.status, "CHECKED_IN");
        assert.equal(failedArrivalJob.error, "MOCK failure");
        await workflow.revoke(failedArrival.invitation_id);
        await workflow.processJob(failedArrival.invitation_id);
        assert.equal((await state(failedArrival.invitation_id)).status, "ACCESS_EXPIRED");
        assert.equal((await state(failedArrival.invitation_id)).error, "MOCK failure");
        const failedRevokedVisitor = (await db.query("SELECT check_in_time,check_out_time FROM visitor_registration WHERE visitor_id=$1", [failedArrivalJob.visitor_id])).rows[0];
        assert(failedRevokedVisitor.check_in_time);
        assert(failedRevokedVisitor.check_out_time);
        const retryArrival = await invitation({ timing: "ON_OPERATOR_CHECKIN", identity: failedArrival.identity_number });
        await workflow.queueApproved();
        await workflow.processJob(retryArrival.invitation_id);
        assert.equal((await state(retryArrival.invitation_id)).status, "WAITING_ARRIVAL");
        failStage = null;
        await workflow.retry(failedArrival.invitation_id);
        await workflow.processJob(failedArrival.invitation_id);
        assert.equal((await state(failedArrival.invitation_id)).status, "ACCESS_EXPIRED");
        assert.equal((await state(failedArrival.invitation_id)).error, null);
        const beforeRecoveryCalls = calls.length;
        const beforeRecoveryEmails = emails;
        await workflow.processJob(retryArrival.invitation_id);
        assert.equal((await state(retryArrival.invitation_id)).status, "WAITING_ARRIVAL");
        assert.equal(calls.length, beforeRecoveryCalls);
        assert.equal(emails, beforeRecoveryEmails);
        assert.equal((await workflow.activate(retryArrival.invitation_id)).status, "CHECKED_IN");
        await waitForState(retryArrival.invitation_id, row => row.email_status === "SENT" && row.stages.every(stageItem => stageItem.state === "DONE"));
        console.log("PASS failed revocation checks out locally, allows recovery, and keeps external revoke retryable");

        const blacklist = await invitation();
        blacklisted.add(blacklist.identity_number);
        await workflow.queueApproved();
        await workflow.processJob(blacklist.invitation_id);
        assert.equal((await state(blacklist.invitation_id)).visitor_id,null);
        assert.equal((await state(blacklist.invitation_id)).status,"ACCESS_EXPIRED");
        await db.query("UPDATE visitor_invitations SET expiry_date=NOW()-INTERVAL '1 second' WHERE invitation_id=$1",[ok.invitation_id]);
        await workflow.processJob(ok.invitation_id);
        assert.equal((await state(ok.invitation_id)).status,"ACCESS_EXPIRED");
        assert.equal(calls.filter(c=>c.visitor===ready.visitor_id&&c.revoke).length,2);
        await workflow.revoke(partial.invitation_id);
        await workflow.processJob(partial.invitation_id);
        assert.equal((await state(partial.invitation_id)).status,"ACCESS_EXPIRED");
        console.log("PASS blacklist, expiry and manual revocation remove access");

        const lateBlacklist = await invitation();
        blacklistDuringSend = true;
        const beforeLateEmail = emails;
        await workflow.queueApproved();
        await workflow.processJob(lateBlacklist.invitation_id);
        assert.equal((await state(lateBlacklist.invitation_id)).status, "ACCESS_EXPIRED");
        assert.equal(emails, beforeLateEmail + 1);
        blacklistDuringSend = false;

        const interrupted = await invitation();
        failStage = 2;
        await workflow.queueApproved();
        await workflow.processJob(interrupted.invitation_id);
        failStage = null;
        const interruptedJob = await state(interrupted.invitation_id);
        interruptedJob.stages[1].state = "SENDING";
        await db.query("UPDATE self_registration_access_jobs SET stages=$2 WHERE invitation_id=$1", [interrupted.invitation_id, JSON.stringify(interruptedJob.stages)]);
        await db.query("UPDATE visitor_invitations SET status='ACCESS_PENDING' WHERE invitation_id=$1", [interrupted.invitation_id]);
        const beforeInterrupted = calls.length;
        await workflow.processJob(interrupted.invitation_id);
        assert.equal(calls.length, beforeInterrupted);
        assert.equal((await state(interrupted.invitation_id)).status, "CHECKED_IN");
        assert.match((await state(interrupted.invitation_id)).error, /terputus/);
        await workflow.retry(interrupted.invitation_id);
        await workflow.processJob(interrupted.invitation_id);
        await workflow.revoke(interrupted.invitation_id);
        failStage = 2;
        await workflow.processJob(interrupted.invitation_id);
        assert.equal((await state(interrupted.invitation_id)).phase, "REVOKE");
        assert.equal((await state(interrupted.invitation_id)).status, "ACCESS_EXPIRED");
        assert.match((await state(interrupted.invitation_id)).error, /MOCK failure/);
        failStage = null;
        await workflow.retry(interrupted.invitation_id);
        await workflow.processJob(interrupted.invitation_id);
        assert.equal((await state(interrupted.invitation_id)).status, "ACCESS_EXPIRED");
        assert.equal(calls.filter(c => c.visitor === interruptedJob.visitor_id && c.id === 1 && c.revoke).length, 1);
        console.log("PASS blacklist during provisioning revokes before email; interrupted sends need manual review; revoke retry skips completed targets");

        emptyPlan = true;
        const noTargets = await invitation();
        await workflow.queueApproved();
        await workflow.processJob(noTargets.invitation_id);
        assert.equal((await state(noTargets.invitation_id)).status,"CHECKED_IN");
        assert.match((await state(noTargets.invitation_id)).access_code,/^\d+$/);
        assert.deepEqual((await state(noTargets.invitation_id)).stages,[]);
        console.log("PASS QR remains available with no third-party API or device targets; all external calls mocked");
    } finally {
        await db.end();
        if (!/^test_self_access_[a-f0-9]{16}$/.test(schema)) throw new Error("Unexpected test schema");
        await sourcePool.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`);
        await sourcePool.end();
    }
}

main().catch(error => { console.error(error); process.exitCode=1; });
