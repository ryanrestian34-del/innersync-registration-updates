from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable,
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "installer" / "windows" / "Innersync-PC-Requirement.pdf"
LOGO = ROOT / "public" / "Logo.png"

NAVY = colors.HexColor("#0B1F3A")
BLUE = colors.HexColor("#1659C7")
BLUE_DARK = colors.HexColor("#0D47A1")
TEAL = colors.HexColor("#0F8B8D")
TEXT = colors.HexColor("#172033")
MUTED = colors.HexColor("#526987")
LINE = colors.HexColor("#C9D9EF")
PALE = colors.HexColor("#F4F8FD")
PALE_BLUE = colors.HexColor("#EAF2FF")
PALE_TEAL = colors.HexColor("#E8F7F4")
WHITE = colors.white


styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="DocTitle", parent=styles["Title"], fontName="Helvetica-Bold",
    fontSize=25, leading=29, textColor=NAVY, spaceAfter=8, alignment=TA_LEFT,
))
styles.add(ParagraphStyle(
    name="DocIntro", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=10, leading=14, textColor=MUTED, spaceAfter=6,
))
styles.add(ParagraphStyle(
    name="Section", parent=styles["Heading1"], fontName="Helvetica-Bold",
    fontSize=15, leading=18, textColor=BLUE, spaceBefore=9, spaceAfter=7,
))
styles.add(ParagraphStyle(
    name="Subsection", parent=styles["Heading2"], fontName="Helvetica-Bold",
    fontSize=10.5, leading=13, textColor=NAVY, spaceBefore=6, spaceAfter=4,
))
styles.add(ParagraphStyle(
    name="BodySmall", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=8.6, leading=12, textColor=TEXT, spaceAfter=4,
))
styles.add(ParagraphStyle(
    name="BulletSmall", parent=styles["BodySmall"], leftIndent=10,
    firstLineIndent=-8, bulletIndent=0, spaceAfter=4,
))
styles.add(ParagraphStyle(
    name="TableHead", parent=styles["BodyText"], fontName="Helvetica-Bold",
    fontSize=7.5, leading=9, textColor=WHITE, alignment=TA_CENTER,
))
styles.add(ParagraphStyle(
    name="TableCell", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=7.4, leading=9.4, textColor=TEXT,
))
styles.add(ParagraphStyle(
    name="TableCellBold", parent=styles["TableCell"], fontName="Helvetica-Bold",
))
styles.add(ParagraphStyle(
    name="CalloutTitle", parent=styles["BodyText"], fontName="Helvetica-Bold",
    fontSize=9.3, leading=12, textColor=BLUE_DARK, spaceAfter=3,
))
styles.add(ParagraphStyle(
    name="CalloutBody", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=8.3, leading=11.5, textColor=TEXT,
))
styles.add(ParagraphStyle(
    name="MonoCode", parent=styles["Code"], fontName="Courier",
    fontSize=7.8, leading=10.5, textColor=NAVY,
))


def p(text, style="BodySmall"):
    return Paragraph(text, styles[style])


def bullet(text):
    return Paragraph(f"- {text}", styles["BulletSmall"])


def section(number, title):
    return Paragraph(f"{number}. {title}", styles["Section"])


def table(headers, rows, widths, header_color=BLUE):
    data = [[p(value, "TableHead") for value in headers]]
    for row in rows:
        data.append([
            value if hasattr(value, "wrap") else p(str(value), "TableCell")
            for value in row
        ])
    result = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    result.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.45, LINE),
        ("BACKGROUND", (0, 1), (-1, -1), colors.white),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return result


def callout(title, body, color=PALE_BLUE, border=BLUE):
    box = Table([[p(title, "CalloutTitle")], [p(body, "CalloutBody")]], colWidths=[170 * mm])
    box.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), color),
        ("BOX", (0, 0), (-1, -1), 0.8, border),
        ("LINEBEFORE", (0, 0), (0, -1), 4, border),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return box


def header_footer(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, height - 13 * mm, "Innersync Registration Portal - Server & VPS Requirement")
    canvas.setStrokeColor(LINE)
    canvas.setLineWidth(0.5)
    canvas.line(18 * mm, height - 16 * mm, width - 18 * mm, height - 16 * mm)
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(width - 18 * mm, 12 * mm, f"Page {doc.page}")
    canvas.restoreState()


def build():
    doc = SimpleDocTemplate(
        str(OUTPUT), pagesize=A4,
        rightMargin=18 * mm, leftMargin=18 * mm,
        topMargin=22 * mm, bottomMargin=18 * mm,
        title="Innersync Server and VPS Requirement",
        author="Innersync",
    )
    story = []

    title_table = Table([
        [p("Server & VPS Requirement -<br/>Innersync Registration Portal", "DocTitle"),
         Image(str(LOGO), width=34 * mm, height=24 * mm)],
    ], colWidths=[132 * mm, 38 * mm])
    title_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story += [Spacer(1, 7 * mm), title_table,
              p("Dokumen kebutuhan server untuk instalasi dan operasional Innersync Registration Portal. Mencakup deployment Windows, Linux, VPS, database, network, security, dan integrasi perangkat lokal.", "DocIntro"),
              p("Tanggal pembaruan: 04/10/2026", "DocIntro"), Spacer(1, 3 * mm)]

    story += [section(1, "Ringkasan Kebutuhan Umum")]
    story.append(table(
        ["Komponen", "Minimum", "Direkomendasikan"],
        [
            ["Processor", "2 core CPU setara Intel Core i3", "4 core CPU atau lebih untuk 10-50 operator dan integrasi aktif"],
            ["Memory", "8 GB RAM", "16 GB RAM atau lebih"],
            ["Storage", "SSD 50 GB untuk aplikasi dan database awal", "SSD 100-250 GB; sesuaikan dengan foto, log, backup, dan retensi"],
            ["Network", "LAN aktif", "IP statis, LAN gigabit, dan outbound internet untuk API/cloud"],
            ["Browser", "Chrome, Edge, atau Firefox modern", "Chrome atau Edge terbaru"],
        ], [34 * mm, 58 * mm, 78 * mm]
    ))

    story += [section(2, "Requirement Windows")]
    for text in [
        "OS: Windows 10/11 64-bit atau Windows Server 2019 ke atas. Windows Server 2022/2025 direkomendasikan untuk produksi.",
        "Service: InnersyncRegistrationPortal berjalan sebagai Windows Service. PostgreSQL dapat dibundel atau memakai database existing/customer.",
        "Runtime: Node.js portable dapat dibundel pada installer all-in-one sehingga tidak perlu instalasi manual.",
        "Permission: installer dijalankan sebagai Administrator untuk membuat service, folder data, firewall rule, dan database.",
        "Default web port: 8081 dan dapat diubah melalui konfigurasi network aplikasi.",
    ]:
        story.append(bullet(text))

    story += [section(3, "Requirement Linux")]
    story.append(table(
        ["Komponen", "Kebutuhan Linux"],
        [
            ["OS", "Ubuntu Server 22.04/24.04 LTS atau Debian 12. Distro lain harus mendukung systemd, Node.js, dan PostgreSQL."],
            ["Architecture", "x64/amd64 direkomendasikan. ARM memerlukan build/runtime khusus."],
            ["Runtime", "Node.js minimal 20; installer Linux saat ini menggunakan Node.js 22."],
            ["Privilege", "Akses sudo/root diperlukan saat instalasi untuk folder /opt/innersync, systemd, dan database."],
            ["Service", "Aplikasi berjalan sebagai service systemd bernama innersync dan start otomatis saat boot."],
        ], [38 * mm, 132 * mm]
    ))

    story += [PageBreak(), section(4, "Flow Install Linux")]
    for text in [
        "Copy paket Linux ke server, contoh deploy/linux/innersync-linux-v1.0.1.tar.gz.",
        "Extract paket, masuk ke folder hasil extract, lalu jalankan install.sh dengan sudo.",
        "Installer menyiapkan dependency, environment, database connection, systemd, dan menjalankan aplikasi.",
        "License aktif tidak ikut dipindahkan. Aktivasi mengikuti Machine ID server baru.",
    ]:
        story.append(bullet(text))
    story.append(callout(
        "Perintah instalasi dan service",
        "<font name='Courier'>tar -xzf innersync-linux-v1.0.1.tar.gz<br/>cd innersync-linux-v1.0.1<br/>sudo bash install.sh<br/><br/>sudo systemctl status innersync<br/>sudo systemctl restart innersync</font>",
    ))

    story += [section(5, "Deployment VPS")]
    story.append(table(
        ["Skala VPS", "CPU / RAM", "SSD", "Penggunaan"],
        [
            ["Minimum / demo", "2 vCPU / 8 GB", "80-100 GB", "1-5 operator, volume visitor rendah, integrasi terbatas"],
            ["Produksi", "4 vCPU / 16 GB", "160-250 GB", "10-50 operator, foto, email/WhatsApp, API dan monitoring aktif"],
            ["Besar", "8 vCPU / 32 GB", "500 GB+", "50+ operator, multi integrasi, log besar, dan retensi panjang"],
        ], [31 * mm, 37 * mm, 31 * mm, 71 * mm], header_color=TEAL
    ))
    story += [Spacer(1, 3 * mm), callout(
        "Rekomendasi VPS produksi",
        "Ubuntu Server 24.04 LTS, 4 vCPU, RAM 16 GB, SSD 160-250 GB, IP publik statis, domain HTTPS permanen, backup harian, serta data center Indonesia atau Singapura.",
        PALE_TEAL, TEAL,
    )]
    story.append(Paragraph("Skenario deployment", styles["Subsection"]))
    story.append(table(
        ["Kondisi", "Kebutuhan server lokal"],
        [
            ["Registrasi, QR, dashboard, email, WhatsApp, dan API cloud", "Tidak wajib. Innersync dan PostgreSQL dapat sepenuhnya berjalan di VPS."],
            ["InnerRange/Schindler berada di LAN gedung", "Wajib ada jalur lokal melalui VPN atau gateway yang selalu menyala. Tidak perlu menjalankan database Innersync kedua."],
            ["Perangkat memiliki API HTTPS publik yang aman", "VPS dapat terhubung langsung sesuai firewall dan kebijakan security customer."],
            ["Tanpa VPS", "Innersync tetap lokal dan dipublikasikan dengan domain serta Cloudflare Tunnel permanen."],
        ], [62 * mm, 108 * mm]
    ))
    story.append(Paragraph("Topologi hybrid yang direkomendasikan", styles["Subsection"]))
    story.append(callout(
        "VPS + akses perangkat lokal",
        "Visitor / Operator -> Internet HTTPS -> Innersync VPS -> VPN terenkripsi -> PC atau router gateway lokal -> InnerRange / Schindler / perangkat akses",
    ))
    for text in [
        "Gateway lokal dapat berupa PC aplikasi existing, mini PC 2 core dengan RAM 4-8 GB, atau router yang mendukung WireGuard.",
        "Software VPN dapat memakai WireGuard, OpenVPN, Tailscale, atau ZeroTier. Biaya utama biasanya berasal dari VPS, domain, dan pengelolaan.",
        "Quick Tunnel tidak diperlukan jika VPS memakai domain dan HTTPS permanen.",
        "Rebuild atau migrasi VPS dapat mengubah Machine ID sehingga license mungkin perlu diaktifkan ulang.",
    ]:
        story.append(bullet(text))

    story += [PageBreak(), section(6, "PostgreSQL Database")]
    story.append(table(
        ["Mode Database", "Keterangan"],
        [
            ["Create New Database", "Instalasi baru. Semua tabel dimulai kosong dan admin pertama dibuat saat setup."],
            ["Restore Backup", "Recovery atau pindah server. Data kembali, tetapi license divalidasi ulang berdasarkan Machine ID."],
            ["Existing PostgreSQL", "Bisa memakai database customer selama kompatibel, stabil, dan user memiliki hak create/alter table."],
        ], [45 * mm, 125 * mm]
    ))
    for text in [
        "PostgreSQL 14 ke atas direkomendasikan; installer Windows saat ini menyediakan PostgreSQL 16.",
        "Kapasitas database dan retensi log harus disesuaikan dengan volume visitor, foto, API log, dan middleware polling.",
        "Backup full database harus mencakup seluruh tabel, setting, log, dan konfigurasi.",
        "Aktifkan autocleanup untuk Activity Logs, API Logs, Middleware Sync Logs, dan Visitor Logs lama.",
    ]:
        story.append(bullet(text))

    story += [section(7, "Port dan Network")]
    story.append(table(
        ["Port", "Kegunaan", "Catatan"],
        [
            ["8081/tcp", "Web aplikasi Innersync", "Port internal/default; pada VPS sebaiknya hanya melalui reverse proxy."],
            ["5432/tcp", "PostgreSQL", "Jangan dibuka ke internet. Buka hanya untuk host database tepercaya."],
            ["80/443", "HTTPS, reverse proxy, atau tunnel", "Akses publik untuk domain, Cloudflare, dan sertifikat TLS."],
            ["VPN", "Akses jaringan lokal", "WireGuard umumnya memakai UDP 51820, tetapi dapat disesuaikan."],
            ["Third-party API", "InnerRange, Schindler, LifeSmart, dan lainnya", "Server harus dapat menjangkau IP/URL tujuan dengan latency stabil."],
        ], [27 * mm, 57 * mm, 86 * mm]
    ))

    story += [section(8, "Security dan Permission")]
    for text in [
        "Gunakan account OS khusus untuk service dan batasi akses folder config, backup, license, dan credential.",
        "Gunakan HTTPS, firewall, API key, password kuat, dan pembatasan alamat IP bila memungkinkan.",
        "Buka ke internet hanya port 80/443; port aplikasi dan database tetap private.",
        "Sinkronkan waktu menggunakan NTP dan timezone Asia/Jakarta agar expiry serta transaksi integrasi akurat.",
        "Foto identitas dan data visitor harus mengikuti kebijakan privasi dan retensi customer.",
    ]:
        story.append(bullet(text))

    story += [section(9, "Mode Operasi Software")]
    story.append(table(
        ["Mode", "Fungsi", "Catatan"],
        [
            ["Visitor Registration", "Registrasi, approval, check-in/out, QR, email/WhatsApp, dan trigger API.", "Operasional visitor harian."],
            ["Middleware Sync", "Sinkron source ke destination API berdasarkan project dan konfigurasi.", "Integrasi antar sistem."],
            ["Gateway API", "Menerima request vendor lalu meneruskannya ke API/device tujuan.", "Integrasi vendor eksternal."],
        ], [39 * mm, 78 * mm, 53 * mm]
    ))

    story += [PageBreak(), section(10, "Rekomendasi Kapasitas Berdasarkan Penggunaan")]
    story.append(table(
        ["Skala", "Operator", "Estimasi Aktivitas", "Rekomendasi"],
        [
            ["Kecil", "1-5", "Ratusan sampai ribuan log/bulan", "8 GB RAM, SSD 50-100 GB, cleanup bulanan"],
            ["Menengah", "10-50", "Puluhan ribu log/bulan, API dan middleware aktif", "16 GB RAM, SSD 100-250 GB, backup harian/mingguan"],
            ["Besar", "50+", "Ratusan ribu log/bulan dan multi integrasi", "Dedicated server/VPS, RAM 32 GB, storage 500 GB+, monitoring dan retention wajib"],
        ], [25 * mm, 27 * mm, 59 * mm, 59 * mm]
    ))

    story += [section(11, "Backup, Restore, dan Maintenance")]
    for text in [
        "Buat backup database harian dan simpan salinan di lokasi terpisah dari disk utama.",
        "Sertakan folder uploads, exports, config, dan data penting lain dalam kebijakan backup.",
        "Sebelum cleanup log, sistem dapat mengekspor CSV agar audit lama tetap tersedia.",
        "Uji restore secara berkala; setelah restore selesai, restart service direkomendasikan.",
    ]:
        story.append(bullet(text))

    story += [section(12, "Update Software")]
    for text in [
        "Online update menggunakan latest.json dan package ZIP jika server memiliki akses internet.",
        "Offline update menggunakan file ZIP yang diunggah melalui menu Software Update.",
        "Update tidak menghapus database; migration dijalankan jika terdapat perubahan schema.",
        "Rollback tersedia untuk kembali ke versi sebelumnya jika update bermasalah.",
    ]:
        story.append(bullet(text))

    story += [section(13, "Checklist Sebelum Install")]
    checklist = [
        "Tentukan deployment: server lokal, VPS penuh, atau VPS + gateway lokal.",
        "Pilih OS 64-bit dan pastikan CPU, RAM, serta SSD sesuai volume penggunaan.",
        "Siapkan domain, HTTPS, IP statis, firewall, dan VPN bila perangkat berada di LAN gedung.",
        "Pastikan port web tidak bentrok dan PostgreSQL tidak terbuka ke internet.",
        "Siapkan credential PostgreSQL, SMTP, WhatsApp, dan API third party.",
        "Pastikan storage mencukupi untuk database, foto, backup, export, dan log.",
        "Aktifkan NTP, backup otomatis, monitoring kapasitas, dan kebijakan retensi.",
    ]
    for text in checklist:
        story.append(bullet(text))
    story += [Spacer(1, 4 * mm), callout(
        "Catatan sizing",
        "Requirement final perlu disesuaikan dengan jumlah visitor harian, operator bersamaan, ukuran foto, durasi retensi log, frekuensi middleware polling, jumlah integrasi aktif, dan target ketersediaan layanan.",
        PALE_TEAL, TEAL,
    )]

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    print(OUTPUT)


if __name__ == "__main__":
    build()
