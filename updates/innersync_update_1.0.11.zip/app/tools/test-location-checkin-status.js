const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const path = require("node:path");

async function main() {
    const source = fs.readFileSync(path.join(__dirname, "../routes/visitorRoutes.js"), "utf8");
    let handler;
    let status = "ACCESS_FAILED";
    let activations = 0;
    const context = {
        router: { post: (_, fn) => { handler = fn; } },
        normalizeBookingCode: value => value,
        getSelfRegistrationSettings: async () => ({ access_mode: "AUTOMATIC", activation_timing: "ON_OPERATOR_CHECKIN" }),
        secureTextEqual: (a, b) => a === b,
        getLocationCheckinQrValue: () => "location-token",
        pool: { query: async () => ({ rows: [{ status, access_mode: "AUTOMATIC", activation_timing: "ON_OPERATOR_CHECKIN", access_code: "12345" }] }) },
        selfRegistrationWorkflow: { activate: async () => { activations++; } }
    };
    vm.runInNewContext(source.slice(source.indexOf('router.post("/api/public/self-registration/check-in",'), source.indexOf('router.post("/api/invitations/:id/send-email",')), context);
    for (status of ["ACCESS_FAILED", "ACCESS_PENDING"]) {
        let body;
        let http;
        await handler({ body: { booking_code: "test", public_status_token: "secret", location_qr: "location-token" } }, {
            status(value) { http = value; return this; },
            json(value) { body = value; return this; }
        });
        assert.equal(body.activation_status, status);
        assert.equal(body.data.access_code, null);
        assert.equal(http, status === "ACCESS_PENDING" ? 202 : 409);
        assert.equal(body.success, false);
    }
    assert.equal(activations, 0);
    console.log("PASS failed/pending scan reports accurate status, hides access code, and never repeats activation");
}
main().catch(error => { console.error(error); process.exitCode = 1; });
