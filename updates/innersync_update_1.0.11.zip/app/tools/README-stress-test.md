# Innersync Stress Test Tool

Tool ini dipakai untuk simulasi banyak user/request tanpa harus membuka banyak browser.

## Mode Aman Awal

Uji endpoint ringan dashboard dan status internal:

```bash
npm run stress:test -- --scenario dashboard --base http://localhost:8081 --requests 200 --users 20 --concurrency 20 --username admin --password PASSWORD_ADMIN
```

Hasil report akan dibuat otomatis di:

```text
exports/stress-test/
```

## Simulasi Gateway API

Pakai ini jika Gateway API sudah aktif dan ingin simulasi software lain mengirim data ke Innersync:

```bash
npm run stress:test -- --scenario gateway --base http://localhost:8081 --requests 100 --users 10 --concurrency 10 --gateway-key API_KEY_GATEWAY
```

Jika Gateway API memakai username/password:

```bash
npm run stress:test -- --scenario gateway --base http://localhost:8081 --requests 100 --users 10 --concurrency 10 --gateway-key API_KEY_GATEWAY --gateway-username USER_GATEWAY --gateway-password PASSWORD_GATEWAY
```

## Mixed Test

Campuran dashboard request dan Gateway API:

```bash
npm run stress:test -- --scenario mixed --base http://localhost:8081 --requests 300 --users 30 --concurrency 30 --username admin --password PASSWORD_ADMIN --gateway-key API_KEY_GATEWAY
```

## Mock Check-In Transaction

Mode ini untuk membuktikan skenario 1 operator atau banyak operator melakukan check-in banyak visitor, plus transaksi API ke beberapa sistem, tanpa membuat data visitor di database dan tanpa menyentuh API vendor asli.

Contoh 1 operator check-in 100 visitor, 2 API vendor berjalan paralel:

```bash
npm run stress:test -- --scenario checkin-mock --requests 100 --users 1 --concurrency 1 --mock-api-count 2 --mock-delay 500 --mock-jitter 300 --retry 3 --retry-delay 300
```

Contoh 10 operator, 300 transaksi, 3 API vendor, ada simulasi gagal 5%:

```bash
npm run stress:test -- --scenario checkin-mock --requests 300 --users 10 --concurrency 20 --mock-api-count 3 --mock-delay 500 --mock-jitter 500 --mock-fail-rate 5 --retry 3 --retry-delay 300
```

Contoh API vendor dijalankan berurutan, bukan paralel:

```bash
npm run stress:test -- --scenario checkin-mock --requests 100 --users 5 --concurrency 5 --api-mode sequence --mock-api-count 3 --mock-delay 500
```

Parameter penting:

- `--mock-api-count`: jumlah API third party yang ditembak dalam 1 check-in.
- `--mock-delay`: delay dasar API vendor dalam ms.
- `--mock-jitter`: delay random tambahan.
- `--mock-fail-rate`: persentase response 500.
- `--mock-timeout-rate`: persentase timeout.
- `--retry`: maksimal attempt per API. Default 3.
- `--retry-delay`: jeda antar retry dalam ms.
- `--api-mode`: `parallel` untuk API yang tidak saling menunggu, `sequence` jika harus berurutan.

Target awal untuk flow check-in:

- P95 di bawah 3000 ms.
- Failed 0% untuk kondisi normal.
- Jika ada fail-rate simulasi, pastikan mayoritas pulih setelah retry.

## Mock Third Party Server

Jika ingin test integrasi API tanpa menyentuh InnerRange/Schindler/vendor asli, nyalakan mock server:

```bash
npm run stress:test -- --scenario mock-server-only --mockServer true --mockPort 9099
```

Lalu di API Configuration/Destination Innersync arahkan URL testing ke:

```text
http://127.0.0.1:9099/mock
```

Untuk simulasi vendor lambat:

```text
http://127.0.0.1:9099/mock?delay=2000
```

Untuk simulasi vendor error:

```text
http://127.0.0.1:9099/mock?status=500
```

## Real Check-In Test

Mode ini menjalankan endpoint check-in asli Innersync (`/register-visitor`). Artinya sistem akan membuat visitor sungguhan di database, membuat QR, mencatat log, dan dapat memicu background API/email/WhatsApp/device sesuai setting yang sedang aktif.

Untuk mode `checkin-real`, warmup otomatis dilewati supaya jumlah visitor yang dibuat sesuai nilai `--requests`.

Gunakan bertahap:

1. Backup database dulu.
2. Pakai prefix khusus seperti `REALTEST` agar data test mudah dicari/dibersihkan.
3. Mulai dari request kecil.
4. Jika belum ingin menyentuh vendor asli, nonaktifkan API/email/WhatsApp/device atau arahkan endpoint API ke mock server.

Contoh test real kecil:

```bash
npm run stress:test -- --scenario checkin-real --base http://localhost:8081 --username admin --password PASSWORD_ADMIN --allow-real-writes true --requests 10 --users 1 --concurrency 1 --real-prefix REALTEST --real-host "Stress Test Host" --real-group "Stress Test"
```

Contoh simulasi beberapa operator check-in visitor real:

```bash
npm run stress:test -- --scenario checkin-real --base http://localhost:8081 --username admin --password PASSWORD_ADMIN --allow-real-writes true --requests 100 --users 5 --concurrency 5 --real-prefix REALTEST --real-card-start 990000000
```

Parameter tambahan:

- `--allow-real-writes true`: wajib, sebagai pengaman supaya tidak sengaja membuat data real.
- `--real-prefix`: prefix nama, identity number, dan email visitor test.
- `--real-host`: host yang dipakai pada data test.
- `--real-group`: permission group yang dipakai pada data test.
- `--real-company`: company visitor test.
- `--real-email-domain`: domain email dummy.
- `--real-card-start`: nomor awal card number test.
- `--real-duration-hours`: durasi visitor test dari start sampai expiry. Default `24` jam.
- `--real-force-new-third-party-user`: default `true`, test tidak memakai ulang slot `U` lama di InnerRange supaya jumlah user baru sesuai jumlah request. Isi `false` hanya jika ingin menguji mekanisme reuse slot lama.

Target pembuktian operasional:

- Check-in real P95 di bawah 3000 ms.
- Failed 0% pada DB lokal.
- Jika API vendor aktif, failed harus pulih dari retry otomatis atau masuk daftar failed untuk ditindaklanjuti.

## Cara Membaca Hasil

- `Success`: request berhasil.
- `Failed`: request gagal, timeout, 401, 500, atau response tidak OK.
- `Requests/second`: kemampuan proses request per detik.
- `Avg / P95 / Max`: waktu rata-rata, 95% request selesai di bawah angka P95, dan request paling lambat.
- `Status counts`: jumlah status HTTP, misalnya 200, 207, 401, 500.

Target awal yang sehat untuk operasional visitor:

- Average di bawah 1000 ms untuk endpoint ringan.
- P95 di bawah 3000 ms untuk flow yang menyentuh API vendor.
- Failed rendah dan penyebabnya jelas.

## Catatan Penting

- `dashboard` aman untuk uji awal karena tidak membuat visitor baru.
- `gateway` bisa memicu API third party sesuai setting aktif. Pakai mock server dulu jika belum siap menyentuh vendor asli.
- `checkin-real` membuat visitor sungguhan dan dapat memicu proses background. Jalankan kecil dulu.
- Jangan jalankan test besar di database produksi tanpa backup.
