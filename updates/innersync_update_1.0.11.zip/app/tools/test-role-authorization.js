const assert = require("assert");
const {
    ROLE_MODULES,
    PAGE_MODULES,
    resolveApiPermission
} = require("../middleware/roleAuthorization");

const requiredModules = [
    "operator_dashboard",
    "invitation_booking",
    "notifications",
    "floor",
    "monitoring_api_activity",
    "license_manager",
    "software_update"
];

requiredModules.forEach(moduleKey => {
    assert(ROLE_MODULES.includes(moduleKey), `Missing role module: ${moduleKey}`);
});

assert.strictEqual(PAGE_MODULES["/settings.html"], "settings");
assert.strictEqual(PAGE_MODULES["/invitation-booking.html"], "invitation_booking");
assert.strictEqual(PAGE_MODULES["/monitoring-api-activity.html"], "monitoring_api_activity");

const cases = [
    ["GET", "/api/whatsapp-settings", "settings", "can_view"],
    ["PUT", "/api/whatsapp-settings", "settings", "can_edit"],
    ["POST", "/api/smtp-settings/test", "settings", "can_execute"],
    ["DELETE", "/api/self-registration-holidays/4", "settings", "can_delete"],
    ["GET", "/api/invitations", "invitation_booking", "can_view"],
    ["POST", "/api/invitations", "invitation_booking", "can_add"],
    ["POST", "/api/invitations/9/bm-approval", "invitation_booking", "can_execute"],
    ["DELETE", "/api/hosts/2", "host", "can_delete"],
    ["GET", "/api/operator-dashboard", "operator_dashboard", "can_view"],
    ["GET", "/api/roles", "account_management", "can_view"],
    ["GET", "/activity-logs", "activity_logs", "can_view"],
    ["GET", "/api/maintenance-jobs", "software_activity_log", "can_view"],
    ["POST", "/api/auto-checkout/run-now", "settings", "can_execute"],
    ["POST", "/api/database-health/repair", "settings", "can_execute"],
    ["POST", "/api/software-update/apply/12", "software_update", "can_execute"]
];

cases.forEach(([method, path, expectedModule, expectedAction]) => {
    const permission = resolveApiPermission({ method, path });
    assert(permission, `No permission mapping for ${method} ${path}`);
    assert.strictEqual(permission.module, expectedModule, `${method} ${path} module`);
    assert.strictEqual(permission.action, expectedAction, `${method} ${path} action`);
});

console.log(`Role authorization tests passed: ${cases.length} API rules, ${ROLE_MODULES.length} modules.`);
