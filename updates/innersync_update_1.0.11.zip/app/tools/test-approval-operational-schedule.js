const assert = require("node:assert/strict");
const { computeApprovalWindow } = require("../utils/approvalSchedule");

function iso(value) {
    return value.toISOString();
}

const fridayAfternoon = new Date("2026-09-11T09:30:00.000Z"); // 16:30 WIB, Jumat

const futureMonday = computeApprovalWindow({
    now: fridayAfternoon,
    visitStart: "2026-09-14T09:30:00.000Z",
    visitExpiry: "2026-09-14T12:00:00.000Z",
    timeoutMinutes: 60,
    operationalStart: "08:00",
    operationalEnd: "17:00",
    timeZone: "Asia/Jakarta"
});
assert.equal(iso(futureMonday.startsAt), "2026-09-14T01:00:00.000Z");
assert.equal(iso(futureMonday.timeoutAt), "2026-09-14T02:00:00.000Z");
assert.equal(futureMonday.delayed, true);

const todayAcrossWeekend = computeApprovalWindow({
    now: fridayAfternoon,
    visitStart: "2026-09-11T10:00:00.000Z",
    visitExpiry: "2026-09-14T03:00:00.000Z",
    timeoutMinutes: 60,
    operationalStart: "08:00",
    operationalEnd: "17:00",
    timeZone: "Asia/Jakarta"
});
assert.equal(iso(todayAcrossWeekend.startsAt), iso(fridayAfternoon));
assert.equal(iso(todayAcrossWeekend.timeoutAt), "2026-09-14T01:30:00.000Z");
assert.equal(todayAcrossWeekend.delayed, false);

const capped = computeApprovalWindow({
    now: fridayAfternoon,
    visitStart: "2026-09-14T09:30:00.000Z",
    visitExpiry: "2026-09-14T01:20:00.000Z",
    timeoutMinutes: 60,
    operationalStart: "08:00",
    operationalEnd: "17:00",
    timeZone: "Asia/Jakarta"
});
assert.equal(iso(capped.startsAt), "2026-09-14T01:00:00.000Z");
assert.equal(iso(capped.timeoutAt), "2026-09-14T01:20:00.000Z");

const saturdayVisit = computeApprovalWindow({
    now: fridayAfternoon,
    visitStart: "2026-09-12T03:00:00.000Z",
    visitExpiry: "2026-09-12T06:00:00.000Z",
    timeoutMinutes: 60,
    operationalStart: "08:00",
    operationalEnd: "17:00",
    timeZone: "Asia/Jakarta"
});
assert.equal(saturdayVisit.invalid, true);
assert.equal(saturdayVisit.invalidReason, "VISIT_NON_OPERATIONAL");

const holidayVisit = computeApprovalWindow({
    now: fridayAfternoon,
    visitStart: "2026-09-14T03:00:00.000Z",
    visitExpiry: "2026-09-14T06:00:00.000Z",
    timeoutMinutes: 60,
    operationalStart: "08:00",
    operationalEnd: "17:00",
    closedDates: ["2026-09-14"],
    timeZone: "Asia/Jakarta"
});
assert.equal(holidayVisit.invalid, true);
assert.equal(holidayVisit.invalidReason, "VISIT_NON_OPERATIONAL");

const openOverrideVisit = computeApprovalWindow({
    now: fridayAfternoon,
    visitStart: "2026-09-12T03:00:00.000Z",
    visitExpiry: "2026-09-12T06:00:00.000Z",
    timeoutMinutes: 60,
    operationalStart: "08:00",
    operationalEnd: "17:00",
    openDates: ["2026-09-12"],
    timeZone: "Asia/Jakarta"
});
assert.equal(openOverrideVisit.invalid, false);
assert.equal(iso(openOverrideVisit.startsAt), "2026-09-12T01:00:00.000Z");
assert.equal(iso(openOverrideVisit.timeoutAt), "2026-09-12T02:00:00.000Z");

console.log("Approval operational schedule tests passed.");
