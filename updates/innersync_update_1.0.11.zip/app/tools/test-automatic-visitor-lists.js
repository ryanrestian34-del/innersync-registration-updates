const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const pool = require("../database/db");

async function main() {
    const client = await pool.connect();
    const handlers = new Map();
    const source = fs.readFileSync(path.join(__dirname, "../routes/visitorRoutes.js"), "utf8");
    const context = vm.createContext({ pool: client, getCurrentUsername: () => "TEST", selfRegistrationWorkflow: { expireApprovals: async () => {} }, router: { get: (url, handler) => handlers.set(url, handler) } });
    for (const [start, end] of [
        ['router.get("/visitors",', '// ALL VISITOR LOGS'],
        ['router.get("/visitors/:id",', 'router.get("/visitors/:id/operator-notes",'],
        ['router.get("/api/invitations",', 'router.post("/api/invitations",']
    ]) vm.runInContext(source.slice(source.indexOf(start), source.indexOf(end, source.indexOf(start))), context);
    async function request(url, query = {}, params = {}) {
        let status = 200;
        let body;
        await handlers.get(url)({ query, params }, { status(code) { status = code; return this; }, json(value) { body = value; } });
        assert.equal(status, 200, JSON.stringify(body));
        assert.equal(body.success, true);
        return body.data;
    }
    try {
        await client.query("BEGIN");
        for (const table of ["visitor_registration", "visitor_invitations", "self_registration_access_jobs", "visitor_operator_notes", "visitor_operator_note_reads"]) {
            await client.query(`CREATE TEMP TABLE ${table} (LIKE public.${table} INCLUDING DEFAULTS) ON COMMIT DROP`);
        }
        await client.query(`INSERT INTO visitor_registration (visitor_id,first_name,identity_number,status,check_in_time,check_out_time,expiry_date) VALUES
            (9001,'Manual','TEST-1','ACTIVE',NOW(),NULL,NOW()+INTERVAL '1 day'),
            (9002,'Ready','TEST-2','ACCESS_READY',NULL,NULL,NOW()+INTERVAL '1 day'),
            (9003,'Pending','TEST-3','ACCESS_PENDING',NULL,NULL,NOW()+INTERVAL '1 day'),
            (9004,'Failed','TEST-4','ACCESS_PENDING',NULL,NULL,NOW()+INTERVAL '1 day'),
            (9005,'Expired','TEST-5','ACCESS_EXPIRED',NULL,NOW(),NOW()-INTERVAL '1 day'),
            (9006,'Closed Manual','TEST-6','DONE',NOW(),NOW(),NOW()),
            (9007,'Revoke failed','TEST-7','ACCESS_READY',NOW(),NOW(),NOW()+INTERVAL '1 day'),
            (9010,'Waiting arrival','TEST-10','WAITING_ARRIVAL',NULL,NULL,NOW()+INTERVAL '1 day'),
            (9011,'Direct checkin','TEST-11','CHECKED_IN',NOW(),NULL,NOW()+INTERVAL '1 day')`);
        for (const [id, status, mode] of [[9001,"PENDING","OPERATOR"],[9002,"ACCESS_READY","AUTOMATIC"],[9003,"ACCESS_PENDING","AUTOMATIC"],[9004,"ACCESS_FAILED","AUTOMATIC"],[9005,"ACCESS_EXPIRED","AUTOMATIC"],[9006,"WAITING_HOST_APPROVAL","AUTOMATIC"],[9007,"ACCESS_FAILED","AUTOMATIC"],[9008,"ACCESS_FAILED","AUTOMATIC"],[9009,"CHECKED_IN","OPERATOR"],[9010,"WAITING_ARRIVAL","AUTOMATIC"],[9011,"CHECKED_IN","AUTOMATIC"]]) {
            await client.query("INSERT INTO visitor_invitations (invitation_id,booking_code,first_name,status,access_mode,expiry_date) VALUES ($1,$2,'Test',$3,$4,NOW()+INTERVAL '1 day')", [id, `INV-TEST-${id}`, status, mode]);
        }
        for (const id of [9002,9003,9004,9005,9007,9010,9011]) await client.query("INSERT INTO self_registration_access_jobs (invitation_id,visitor_id,qr_value,phase) VALUES ($1,$1,$2,$3)", [id, `${id}12345`, id === 9007 ? "REVOKE" : id === 9010 ? "WAITING_ARRIVAL" : "PROVISION"]);
        await client.query("INSERT INTO self_registration_access_jobs (invitation_id,error) VALUES (9008,'Target not configured')");

        const visitors = await request("/visitors");
        assert.deepEqual(visitors.map(v => v.visitor_id).sort(), [9001,9002,9003,9004,9007,9010,9011]);
        assert.equal(new Set(visitors.map(v=>v.visitor_id)).size, visitors.length);
        const ready = visitors.find(v=>v.visitor_id===9002);
        assert.equal(ready.check_in_time, null);
        assert.equal(ready.access_status, "ACCESS_READY");
        assert.equal(ready.access_qr_value, "900212345");
        assert.equal(visitors.find(v=>v.visitor_id===9010).access_qr_value, "901012345");
        assert.equal(visitors.find(v=>v.visitor_id===9011).access_status, "CHECKED_IN");
        for (const id of [9003,9004,9007]) assert.equal(visitors.find(v=>v.visitor_id===id).access_qr_value, null);
        const detail = await request("/visitors/:id", {}, { id: 9002 });
        assert.equal(detail.access_invitation_id, 9002);
        assert.equal(detail.access_qr_value, ready.access_qr_value);
        assert.deepEqual((await request("/api/invitations")).map(i=>i.invitation_id).sort(), [9001,9006,9008]);
        assert.equal((await request("/api/invitations", { include_checked_in: "true" })).length, 11);
        console.log("PASS waiting-arrival/direct-checkin/failed automatic visitors appear once; QR visibility follows activation state");
        console.log("PASS completed transfers disappear from Invitation List without deletion; awaiting approval, manual booking and pre-creation failures remain visible");
        console.log("PASS detail metadata, failed revocation visibility and history opt-in; database changes rolled back; no external API calls");
    } finally { await client.query("ROLLBACK"); client.release(); await pool.end(); }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
