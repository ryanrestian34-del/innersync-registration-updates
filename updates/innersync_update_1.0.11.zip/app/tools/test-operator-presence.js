const assert = require("assert");
const {
    getOnlineOperatorCount,
    removeOperatorPresence,
    touchOperatorPresence
} = require("../services/operatorPresence");

function request(sessionId, userId, roleName) {
    return {
        sessionID: sessionId,
        session: {
            user_id: userId,
            role_name: roleName,
            user: { user_id: userId, role_name: roleName }
        }
    };
}

assert.strictEqual(getOnlineOperatorCount(), 0, "Presence harus kosong saat proses dimulai");

touchOperatorPresence(request("operator-a-tab-1", 101, "OPERATOR"));
assert.strictEqual(getOnlineOperatorCount(), 1, "Operator pertama harus langsung online");

touchOperatorPresence(request("operator-a-tab-2", 101, "OPERATOR"));
assert.strictEqual(getOnlineOperatorCount(), 1, "Akun yang sama tidak boleh dihitung dua kali");

touchOperatorPresence(request("operator-b", 102, "OPERATOR"));
assert.strictEqual(getOnlineOperatorCount(), 2, "Operator kedua harus menambah jumlah online");

touchOperatorPresence(request("administrator", 103, "ADMIN"));
assert.strictEqual(getOnlineOperatorCount(), 2, "Role selain OPERATOR tidak boleh dihitung");

touchOperatorPresence(request("operator-no-access", 105, "OPERATOR"), { canOperate: false });
assert.strictEqual(getOnlineOperatorCount(), 2, "Operator tanpa privilege operasional tidak boleh dihitung");

removeOperatorPresence("operator-a-tab-1");
assert.strictEqual(getOnlineOperatorCount(), 2, "Akun tetap online jika masih memiliki sesi lain");

removeOperatorPresence("operator-a-tab-2");
assert.strictEqual(getOnlineOperatorCount(), 1, "Akun offline setelah seluruh sesinya berakhir");

removeOperatorPresence("operator-b");
removeOperatorPresence("administrator");
removeOperatorPresence("operator-no-access");
assert.strictEqual(getOnlineOperatorCount(), 0, "Semua operator harus offline setelah logout");

touchOperatorPresence(request("operator-timeout", 104, "OPERATOR"));
assert.strictEqual(
    getOnlineOperatorCount(Date.now() + 91 * 1000),
    0,
    "Operator harus offline setelah heartbeat berhenti selama lebih dari 90 detik"
);

console.log("Operator presence tests passed.");
