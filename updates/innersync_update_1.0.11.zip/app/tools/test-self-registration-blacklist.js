const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const pool = require("../database/db");

async function main() {
    const source = fs.readFileSync(path.join(__dirname, "../routes/visitorRoutes.js"), "utf8");
    const client = await pool.connect();
    let handler;
    let mode = "BM_AND_HOST";
    let calls;
    let currentInvitation;
    let notifySecurity = true;
    const context = vm.createContext({
        console,
        path,
        fs: { unlink: async target => calls.removed.push(target) },
        router: { post: (_url, _upload, callback) => { handler = callback; } },
        upload: { fields: () => null },
        pool: {
            query: async (sql, values) => {
                if (sql.includes("FROM visitor_watchlist_settings")) return { rows: [{ notify_security: notifySecurity, blacklist_mode: "WARNING_ONLY" }] };
                if (sql.includes("FROM visitor_watchlist")) return client.query(sql, values);
                if (sql.includes("INSERT INTO visitor_invitations")) {
                    calls.inserts += 1;
                    return { rows: [{ booking_code: values[0], status: values[1], approval_mode: values[2] }] };
                }
                if (sql.includes("FROM visitor_invitations")) {
                    calls.lookups += 1;
                    return { rows: [] };
                }
                throw new Error(`Unexpected SQL: ${sql}`);
            }
        },
        safeUploadFilename: value => value || null,
        isPastDateValue: () => false,
        saveActivityLog: async () => { calls.logs += 1; },
        createSystemNotification: async (_req, value) => calls.notifications.push(value),
        getSelfRegistrationSettings: async () => ({ approval_mode: mode, bm_timeout_minutes: 60, host_timeout_minutes: 60 }),
        selfRegistrationWorkflow: { expireApprovals: async () => {} },
        generateBookingCode: async () => { calls.generated += 1; return "INV-REGRESSION"; },
        addMinutes: (date, minutes) => new Date(date.getTime() + minutes * 60000),
        startHostApproval: async () => { calls.hostEmails += 1; return {}; },
        getVisitorDisplayName: () => "Regression Visitor",
        getInvitationByBookingCode: async () => currentInvitation
    });
    vm.runInContext(source.slice(source.indexOf("function normalizeWatchlistType("), source.indexOf("function summarizeWatchlistDecision(")), context);
    vm.runInContext(source.slice(source.indexOf("function normalizeSelfRegistrationApprovalMode("), source.indexOf("function clampInteger(")), context);
    vm.runInContext(source.slice(source.indexOf("function getInitialSelfRegistrationApprovalState("), source.indexOf("function addMinutes(")), context);
    vm.runInContext(source.slice(source.indexOf("async function validatePendingInvitationByCode("), source.indexOf("async function getWhatsappSettings(")), context);
    vm.runInContext(source.slice(source.indexOf('router.post("/api/public/self-registration",'), source.indexOf('router.put("/api/invitations/:id",')), context);

    async function submit(identityNumber, files = {}) {
        calls = { generated: 0, inserts: 0, hostEmails: 0, lookups: 0, logs: 0, notifications: [], removed: [] };
        let status = 200;
        let result;
        const req = { files, body: { first_name: "Same Name", identity_number: identityNumber, host: "Test Host", email_address: "test@example.invalid", existing_visitor_photo: "existing-face.jpg", existing_identity_photo: "existing-id.jpg" } };
        const res = { status(value) { status = value; return this; }, json(value) { result = value; return this; } };
        await handler(req, res);
        return { status, result };
    }

    try {
        await client.query("BEGIN");
        await client.query("CREATE TEMP TABLE visitor_watchlist (LIKE public.visitor_watchlist INCLUDING DEFAULTS) ON COMMIT DROP");
        await client.query(`INSERT INTO visitor_watchlist (watchlist_id, list_type, visitor_name, identity_number, is_active, start_date, expiry_date) VALUES
            (1, 'BLACKLIST', 'Same Name', 'BLOCKED', TRUE, NULL, NULL),
            (2, 'WHITELIST', 'Same Name', 'BLOCKED', TRUE, NULL, NULL),
            (3, 'BLACKLIST', 'Same Name', 'EXPIRED', TRUE, NULL, NOW() - INTERVAL '1 day'),
            (4, 'BLACKLIST', 'Same Name', 'FUTURE', TRUE, NOW() + INTERVAL '1 day', NULL),
            (5, 'BLACKLIST', 'Same Name', 'INACTIVE', FALSE, NULL, NULL),
            (6, 'WHITELIST', 'Same Name', 'WHITELIST', TRUE, NULL, NULL)`);
        const blocked = await submit("  BLOCKED  ", { visitor_photo: [{ path: path.join("uploads", "new-face-test.jpg") }], identity_photo: [{ path: path.join("..", "outside-test.jpg") }] });
        assert.equal(blocked.status, 403);
        assert.equal(blocked.result.message, "Registrasi tidak dapat dilanjutkan. Silakan hubungi receptionist.");
        assert(!("data" in blocked.result));
        assert.equal(calls.generated + calls.inserts + calls.hostEmails + calls.lookups, 0);
        assert.equal(calls.logs, 1);
        assert.equal(calls.notifications[0].status, "BLOCKED");
        assert.deepEqual(calls.removed, [path.resolve("uploads", "new-face-test.jpg")]);
        console.log("PASS exact blacklist blocks before reuse/create/email; no public reason leak; only new in-root uploads removed");

        notifySecurity = false;
        assert.equal((await submit("BLOCKED")).status, 403);
        assert.equal(calls.notifications.length, 0);
        for (const identity of ["EXPIRED", "FUTURE", "INACTIVE", "WHITELIST", "NEW-PERSON"]) {
            const response = await submit(identity);
            assert.equal(response.status, 200, JSON.stringify(response.result));
            assert.equal(response.result.data.status, "WAITING_BM_APPROVAL");
        }
        for (const [approvalMode, status] of Object.entries({ NO_APPROVAL: "PENDING", BM_ONLY: "WAITING_BM_APPROVAL", HOST_ONLY: "WAITING_HOST_APPROVAL", BM_AND_HOST: "WAITING_BM_APPROVAL" })) {
            mode = approvalMode;
            assert.equal((await submit("WHITELIST")).result.data.status, status);
        }
        console.log("PASS inactive/expired/future/name-only matches do not block; whitelist follows all four approval modes");

        currentInvitation = { created_by: "SELF_REGISTRATION", identity_number: "WHITELIST", status: "PENDING" };
        assert((await context.validatePendingInvitationByCode("INV-TEST")).ok);
        await client.query("UPDATE visitor_watchlist SET list_type = 'BLACKLIST' WHERE watchlist_id = 6");
        assert.equal((await context.validatePendingInvitationByCode("INV-TEST")).status, 403);
        currentInvitation.created_by = "OPERATOR";
        assert((await context.validatePendingInvitationByCode("INV-TEST")).ok);
        console.log("PASS new blacklist blocks existing self-registration booking at check-in; manual operator flow unchanged");
    } finally {
        await client.query("ROLLBACK");
        client.release();
        await pool.end();
    }
}

main().catch(error => { console.error(error); process.exitCode = 1; pool.end().catch(() => {}); });
