const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const path = require("node:path");
const os = require("node:os");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const QRCode = require("qrcode");

async function main() {
    const browser = await chromium.launch({ channel: "msedge", headless: true });
    const publicRoot = path.resolve(__dirname, "../public");
    const output = path.join(os.tmpdir(), "innersync-countdown-qa");
    await fs.mkdir(output, { recursive: true });
    const qr = await QRCode.toBuffer("INNERSYNC-CHECKIN:TEST");
    const jsQrSource = await fs.readFile(path.resolve(__dirname, "../node_modules/jsqr/dist/jsQR.js"), "utf8");
    const errors = [];
    const checkinPosts = [];
    let serverNow = Date.now();
    let data = {
        invitation_id: 123, booking_code: "INV-TEST-COUNTDOWN", first_name: "Visitor Test", host: "Host Test",
        status: "WAITING_BM_APPROVAL", approval_mode: "BM_AND_HOST", access_mode: "AUTOMATIC",
        bm_approval_status: "WAITING", host_approval_status: "WAITING", token_status: "ACTIVE",
        approval_timeout_at: new Date(serverNow + 60 * 60000).toISOString(),
        start_date: new Date(serverNow).toISOString(), expiry_date: new Date(serverNow + 86400000).toISOString()
    };
    async function openPage(file, mobile = false, saved = false) {
        const context = await browser.newContext({ viewport: mobile ? { width: 390, height: 844 } : { width: 1440, height: 1000 } });
        const page = await context.newPage();
        page.on("pageerror", error => errors.push(`${file}: ${error.message}`));
        await page.clock.install({ time: serverNow });
        if (saved) await page.addInitScript(() => localStorage.setItem("innersync_self_registration_last_booking", JSON.stringify({ booking_code: "INV-TEST-COUNTDOWN", public_status_token: "PUBLIC-TEST-TOKEN" })));
        await page.route("**/*", async route => {
            const url = new URL(route.request().url());
            if (url.hostname !== "innersync.test") return route.fulfill({ body: "", contentType: "text/css" });
            const json = value => route.fulfill({ json: { success: true, server_time: new Date(serverNow).toISOString(), ...value } });
            if (url.pathname === "/vendor/jsqr/jsQR.js") return route.fulfill({ contentType: "text/javascript", body: jsQrSource });
            if (url.pathname === "/current-user") return json({ role_name: "SUPERADMIN" });
            if (url.pathname === "/api/self-registration-settings") return json({ data: {
                approval_mode: "BM_AND_HOST", access_mode: "AUTOMATIC", activation_timing: "ON_OPERATOR_CHECKIN",
                checkin_qr_token: "LOCATION-TOKEN", checkin_qr_title: "Lobby Visitor Check-in"
            } });
            if (url.pathname === "/api/public/self-registration" && route.request().method() === "POST") {
                data = { ...data, booking_code: "INV-NEW-APPROVAL", status: "WAITING_BM_APPROVAL", access_mode: "AUTOMATIC",
                    approval_mode: "BM_AND_HOST", bm_approval_status: "WAITING", host_approval_status: "PENDING_BM",
                    checked_in_time: null, access_code: null, public_status_token: "NEW-BROWSER-TOKEN",
                    approval_timeout_at: new Date(serverNow + 3600000).toISOString() };
                return json({ data });
            }
            if (url.pathname === "/api/public/self-registration/check-in" && route.request().method() === "POST") {
                checkinPosts.push(route.request().postDataJSON());
                data = { ...data, status: "CHECKED_IN", access_code: "1234567890", access_email_status: "SENT" };
                return json({ data, message: "Check-in berhasil. QR akses sekarang sudah aktif." });
            }
            if (url.pathname.includes("/status/") || url.pathname.includes("/public/approval/")) return json({ data });
            if (url.pathname === "/api/invitations") return json({ data: [data] });
            if (url.pathname.includes("/qr")) return url.pathname.endsWith("/qr") ? route.fulfill({ body: qr, contentType: "image/png" }) : json({ data: {} });
            if (url.pathname.includes("/options")) return json({ data: { hosts: [], permission_groups: [] } });
            if (url.pathname.startsWith("/api/")) return json({ data: [] });
            const filename = path.resolve(publicRoot, "." + url.pathname);
            if (!filename.startsWith(publicRoot + path.sep)) return route.abort();
            try {
                const contentType = filename.endsWith(".html") ? "text/html" : filename.endsWith(".js") ? "text/javascript" : "image/png";
                await route.fulfill({ body: await fs.readFile(filename), contentType });
            } catch { await route.fulfill({ status: 404, body: "" }); }
        });
        await page.goto(`http://innersync.test/${file}`, { waitUntil: "load" });
        return page;
    }
    async function countdownVisible(page, selector = "#approvalCountdown") {
        const element = page.locator(selector);
        await element.waitFor({ state: "visible" });
        assert.match(await element.textContent(), /Sisa waktu \d\d:\d\d/);
        const box = await element.boundingBox();
        const width = page.viewportSize().width;
        assert(box.x >= 0 && box.x + box.width <= width + 1, "Countdown fits viewport");
        return element;
    }
    try {
        for (const mobile of [false, true]) {
            const page = await openPage("self-registration.html", mobile, true);
            const counter = await countdownVisible(page);
            assert.equal(await page.locator("#bookingQrBox").isVisible(), false);
            const before = await counter.textContent();
            serverNow += 2000;
            await page.clock.fastForward(2000);
            assert.notEqual(await counter.textContent(), before);
            await page.reload();
            await countdownVisible(page);
            assert.notEqual(await counter.textContent(), "Sisa waktu 01:00:00", "Reload cannot restart deadline");
            await page.screenshot({ path: path.join(output, `visitor-${mobile ? "mobile" : "desktop"}.png`), fullPage: true });
            await page.close();
        }
        console.log("PASS visitor desktop/mobile countdown, refresh persistence, QR hidden during approval");

        data = { ...data, status: "WAITING_HOST_APPROVAL", bm_approval_status: "APPROVED", approval_timeout_at: new Date(serverNow + 120000).toISOString() };
        const host = await openPage("approval.html?token=test", true);
        const hostCounter = await countdownVisible(host);
        assert.equal(await hostCounter.getAttribute("data-urgent"), "true");
        assert.equal(await host.locator("#responseBox").isVisible(), true);
        await host.screenshot({ path: path.join(output, "host-mobile.png"), fullPage: true });
        serverNow += 120000;
        await host.clock.fastForward(120000);
        assert.equal(await host.locator("#responseBox").isVisible(), false);
        assert.match(await host.locator("#statusBox").textContent(), /timeout/i);
        await host.close();
        console.log("PASS host countdown and approval buttons unavailable at timeout");

        data = { ...data, status: "WAITING_BM_APPROVAL", bm_approval_status: "WAITING", approval_timeout_at: new Date(serverNow + 60000).toISOString() };
        const list = await openPage("invitation-booking.html");
        await countdownVisible(list, "#countdown-123");
        await list.locator("#invitationTable").scrollIntoViewIfNeeded();
        await list.screenshot({ path: path.join(output, "invitation-desktop.png") });
        await list.close();
        console.log("PASS invitation list countdown");

        const visitor = await openPage("self-registration.html", true, true);
        await countdownVisible(visitor);
        data = { ...data, status: "APPROVAL_TIMEOUT" };
        serverNow += 60000;
        await visitor.clock.fastForward(60000);
        await visitor.waitForFunction(() => document.getElementById("successTitle").textContent === "Approval Timeout");
        assert.equal(await visitor.evaluate(() => localStorage.getItem("innersync_self_registration_last_booking")), null);
        assert.equal(await visitor.locator("#bookingQrBox").isVisible(), false);
        data = { ...data, status: "ACCESS_PENDING", bm_approval_status: "APPROVED", host_approval_status: "APPROVED" };
        await visitor.evaluate(item => showBookingSuccess(item.booking_code, item.status, "", item), data);
        assert.equal(await visitor.locator("#bookingQrBox").isVisible(), false);
        data = { ...data, status: "ACCESS_READY", access_code: "1234567890", access_email_status: "SENT" };
        await visitor.evaluate(item => showBookingSuccess(item.booking_code, item.status, "", item), data);
        assert.equal(await visitor.locator("#bookingCodeText").textContent(), "1234567890");
        assert.equal(await visitor.locator("#bookingQrBox").isVisible(), true);
        await visitor.locator("#bookingQr").evaluate(image => image.decode());
        const imageBox = await visitor.locator("#bookingQr").boundingBox();
        const qrBox = await visitor.locator("#bookingQrBox").boundingBox();
        assert(Math.abs(imageBox.x + imageBox.width / 2 - qrBox.x - qrBox.width / 2) < 2, "QR centered");
        await visitor.screenshot({ path: path.join(output, "access-ready-mobile.png"), fullPage: true });
        assert.equal(await visitor.locator("#approvalCountdown").isVisible(), false);
        data = { ...data, status: "ACCESS_FAILED", activation_timing: "ON_OPERATOR_CHECKIN", access_code: null };
        await visitor.evaluate(item => showBookingSuccess(item.booking_code, item.status, "", item), data);
        assert.equal(await visitor.locator("#locationCheckinButton").isVisible(), false);
        data = { ...data, status: "WAITING_ARRIVAL" };
        await visitor.evaluate(item => showBookingSuccess(item.booking_code, item.status, "", item), data);
        assert.equal(await visitor.locator("#successTitle").textContent(), "Siap Check-in di Lokasi");
        assert.match(await visitor.locator("#successSubtitle").textContent(), /QR yang tersedia di meja atau area kedatangan/);
        assert.equal(await visitor.locator("#bookingQrBox").isVisible(), false);
        assert.equal(await visitor.locator("#locationCheckinButton").isVisible(), true);
        await visitor.screenshot({ path: path.join(output, "recovered-arrival-mobile.png"), fullPage: true });
        const decodedLocationQr = await visitor.evaluate(async () => {
            const image = new Image();
            image.src = "/api/public/self-registration/qr?value=INNERSYNC-CHECKIN%3ATEST";
            await image.decode();
            const canvas = document.createElement("canvas");
            canvas.width = image.naturalWidth;
            canvas.height = image.naturalHeight;
            const context = canvas.getContext("2d", { willReadFrequently: true });
            context.drawImage(image, 0, 0);
            const pixels = context.getImageData(0, 0, canvas.width, canvas.height);
            return window.jsQR(pixels.data, pixels.width, pixels.height)?.data || "";
        });
        assert.equal(decodedLocationQr, "INNERSYNC-CHECKIN:TEST");
        await visitor.evaluate(() => document.getElementById("locationScannerModal").classList.add("show"));
        const scannerBox = await visitor.locator("#locationScannerModal .camera-card").boundingBox();
        assert(scannerBox.x >= 0 && scannerBox.x + scannerBox.width <= 390, "Scanner fits mobile viewport");
        await visitor.screenshot({ path: path.join(output, "location-scanner-mobile.png"), fullPage: true });
        await visitor.evaluate(() => document.getElementById("locationScannerModal").classList.remove("show"));
        await visitor.evaluate(() => submitLocationCheckin("INNERSYNC-CHECKIN:TEST"));
        await visitor.waitForFunction(() => document.getElementById("successTitle").textContent === "Check-in Berhasil");
        assert.equal(checkinPosts.at(-1).booking_code, "INV-TEST-COUNTDOWN");
        assert.equal(checkinPosts.at(-1).public_status_token, "PUBLIC-TEST-TOKEN");
        assert.equal(await visitor.locator("#bookingQrBox").isVisible(), true);
        data = { ...data, status: "CHECKED_IN", activation_timing: "AFTER_APPROVAL" };
        await visitor.evaluate(item => showBookingSuccess(item.booking_code, item.status, "", item), data);
        assert.equal(await visitor.locator("#successTitle").textContent(), "Check-in Berhasil");
        assert.equal(await visitor.evaluate(item => isAutomaticApprovalCheckin(item, item.status), data), true);
        assert.equal(await visitor.evaluate(item => isAutomaticApprovalCheckin(item, item.status), { ...data, activation_timing: "ON_OPERATOR_CHECKIN" }), true);
        await visitor.close();

        for (const oldStatus of ["CHECKED_IN", "CHECKED_OUT"]) {
            data = { ...data, booking_code: "INV-TEST-COUNTDOWN", status: oldStatus, access_mode: "OPERATOR" };
            const repeatVisitor = await openPage("self-registration.html", true, true);
            await repeatVisitor.waitForFunction(() => document.getElementById("entryPanel").classList.contains("hide") === false);
            assert.doesNotMatch(await repeatVisitor.locator("#checkinToast").textContent(), /Check-in berhasil/);
            assert.equal(await repeatVisitor.evaluate(() => localStorage.getItem("innersync_self_registration_last_booking")), null);
            await repeatVisitor.evaluate(() => {
                selectVisitorMode("new");
                document.getElementById("first_name").value = "Repeat Visitor";
                document.getElementById("identity_number").value = "REPEAT-ID";
                document.getElementById("email_address").value = "repeat@example.invalid";
                document.getElementById("host").innerHTML = '<option value="Test Host" selected>Test Host</option>';
                returningVisitorPhoto = "test-face.jpg";
                returningIdentityPhoto = "test-id.jpg";
            });
            await repeatVisitor.locator("#submitBtn").click();
            await countdownVisible(repeatVisitor);
            assert.equal(await repeatVisitor.locator("#successTitle").textContent(), "Menunggu Approval");
            assert.equal(await repeatVisitor.locator("#locationCheckinButton").isVisible(), false);
            assert.equal(await repeatVisitor.locator("#bookingQrBox").isVisible(), false);
            assert.equal(await repeatVisitor.locator("#checkinToast").isVisible(), false);
            const savedNew = await repeatVisitor.evaluate(() => JSON.parse(localStorage.getItem("innersync_self_registration_last_booking")));
            assert.equal(savedNew.booking_code, "INV-NEW-APPROVAL");
            assert.equal(savedNew.status, "WAITING_BM_APPROVAL");
            await repeatVisitor.screenshot({ path: path.join(output, `repeat-visitor-${oldStatus.toLowerCase()}.png`), fullPage: true });
            await repeatVisitor.close();
        }
        console.log("PASS old checked-in/checked-out browser bookings do not announce new check-in; fresh submissions show BM countdown without QR or check-in button");

        const settings = await openPage("settings.html");
        await settings.locator("#selfRegistrationListBtn").click();
        assert.equal(await settings.locator("#sr_activation_timing").inputValue(), "ON_OPERATOR_CHECKIN");
        assert.match(await settings.locator("#sr_activation_timing option:checked").textContent(), /visitor scan QR Check-in Lokasi/);
        assert.equal(await settings.locator("#srCheckinQrTitleText").textContent(), "Lobby Visitor Check-in");
        assert.match(await settings.locator("#srCheckinQrImage").getAttribute("src"), /INNERSYNC-CHECKIN%3ALOCATION-TOKEN/);
        assert.equal(await settings.locator("#srLocationCheckinPanel").isVisible(), true);
        await settings.screenshot({ path: path.join(output, "settings-location-checkin.png"), fullPage: true });
        await settings.close();
        assert.deepEqual(errors, []);
        console.log("PASS timeout clears saved booking; arrival mode requires location QR scan; settings preview printable location QR; no page errors");
        console.log(`Screenshots: ${output}`);
    } finally { await browser.close(); }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
