const assert = require("node:assert/strict");
const pool = require("../database/db");

async function main() {
    const result = await pool.query(`
        WITH visitor_base AS (
            SELECT source.*,
                   COALESCE(UPPER(NULLIF(BTRIM(source.identity_number), '')), CONCAT('__VISITOR__:', source.visitor_id)) AS identity_key,
                   COUNT(*) FILTER (WHERE source.check_out_time IS NOT NULL) OVER (
                       PARTITION BY COALESCE(UPPER(NULLIF(BTRIM(source.identity_number), '')), CONCAT('__VISITOR__:', source.visitor_id))
                   )::int AS visit_count
            FROM visitor_registration source
        ),
        filtered_visits AS (
            SELECT v.* FROM visitor_base v WHERE v.check_out_time IS NOT NULL
        ),
        ranked_visits AS (
            SELECT filtered_visits.*,
                   ROW_NUMBER() OVER (
                       PARTITION BY identity_key
                       ORDER BY check_in_time DESC NULLS LAST, visitor_id DESC
                   ) AS identity_rank
            FROM filtered_visits
        )
        SELECT visitor_id, identity_number, identity_key, visit_count, check_in_time
        FROM ranked_visits
        WHERE identity_rank=1
        ORDER BY check_in_time DESC NULLS LAST, visitor_id DESC
    `);

    const uniqueKeys = new Set(result.rows.map(row => row.identity_key));
    assert.equal(result.rows.length, uniqueKeys.size, "Main log must contain one row per identity");

    for (const row of result.rows.filter(item => item.identity_number).slice(0, 25)) {
        const history = await pool.query(
            `SELECT COUNT(*)::int AS total,
                    MAX(check_in_time) FILTER (WHERE check_out_time IS NOT NULL) AS latest_completed
             FROM visitor_registration
             WHERE UPPER(BTRIM(identity_number))=UPPER(BTRIM($1))
               AND check_out_time IS NOT NULL`,
            [row.identity_number]
        );
        assert.equal(row.visit_count, history.rows[0].total);
        assert.equal(new Date(row.check_in_time).getTime(), new Date(history.rows[0].latest_completed).getTime());
    }

    console.log(JSON.stringify({
        grouped_rows: result.rows.length,
        repeat_visitors: result.rows.filter(row => row.visit_count > 1).length,
        largest_history: Math.max(0, ...result.rows.map(row => row.visit_count))
    }));
    console.log("PASS visitor logs contain one latest row per ID Number and preserve total visit history");
}

main().catch(error => {
    console.error(error);
    process.exitCode = 1;
}).finally(() => pool.end());
