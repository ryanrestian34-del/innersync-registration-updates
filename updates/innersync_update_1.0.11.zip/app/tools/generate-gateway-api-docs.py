from pathlib import Path
import textwrap

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.utils import simpleSplit
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Flowable,
    Image,
    KeepTogether,
    ListFlowable,
    ListItem,
    PageBreak,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "public" / "docs"
OUTPUT_PDF = OUTPUT_DIR / "innersync-gateway-api-documentation.pdf"
LOGO = ROOT / "public" / "logo.png"


class StatusBox(Flowable):
    def __init__(self, title, body, fill=colors.HexColor("#eef6ff"), stroke=colors.HexColor("#bdd7ff")):
        super().__init__()
        self.title = title
        self.body = body
        self.fill = fill
        self.stroke = stroke
        self.width = 170 * mm
        self.height = 25 * mm

    def draw(self):
        self.canv.setFillColor(self.fill)
        self.canv.setStrokeColor(self.stroke)
        self.canv.roundRect(0, 0, self.width, self.height, 6, stroke=1, fill=1)
        self.canv.setFillColor(colors.HexColor("#0f172a"))
        self.canv.setFont("Helvetica-Bold", 10)
        self.canv.drawString(5 * mm, 16 * mm, self.title)
        self.canv.setFont("Helvetica", 8.4)
        self.canv.drawString(5 * mm, 8 * mm, self.body)


def styles():
    base = getSampleStyleSheet()
    base.add(ParagraphStyle(
        name="DocTitle",
        parent=base["Title"],
        fontName="Helvetica-Bold",
        fontSize=23,
        leading=28,
        textColor=colors.HexColor("#0b192c"),
        alignment=TA_CENTER,
        spaceAfter=8,
    ))
    base.add(ParagraphStyle(
        name="Section",
        parent=base["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=15,
        leading=19,
        textColor=colors.HexColor("#0d47b5"),
        spaceBefore=12,
        spaceAfter=8,
    ))
    base.add(ParagraphStyle(
        name="SubSection",
        parent=base["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=11.5,
        leading=15,
        textColor=colors.HexColor("#0f172a"),
        spaceBefore=8,
        spaceAfter=5,
    ))
    base.add(ParagraphStyle(
        name="Body",
        parent=base["BodyText"],
        fontName="Helvetica",
        fontSize=9.2,
        leading=13,
        textColor=colors.HexColor("#172033"),
        spaceAfter=6,
    ))
    base.add(ParagraphStyle(
        name="Small",
        parent=base["BodyText"],
        fontName="Helvetica",
        fontSize=8,
        leading=10,
        textColor=colors.HexColor("#475569"),
    ))
    base.add(ParagraphStyle(
        name="DocCode",
        parent=base["Code"],
        fontName="Courier",
        fontSize=7.4,
        leading=9.1,
        leftIndent=0,
        textColor=colors.HexColor("#0f172a"),
    ))
    base.add(ParagraphStyle(
        name="TableHeader",
        parent=base["BodyText"],
        fontName="Helvetica-Bold",
        fontSize=7.8,
        leading=9.5,
        textColor=colors.white,
    ))
    base.add(ParagraphStyle(
        name="TableCell",
        parent=base["BodyText"],
        fontName="Helvetica",
        fontSize=7.7,
        leading=9.4,
        textColor=colors.HexColor("#0f172a"),
        wordWrap="CJK",
    ))
    base.add(ParagraphStyle(
        name="TableLink",
        parent=base["TableCell"],
        textColor=colors.HexColor("#0d47b5"),
        wordWrap="CJK",
    ))
    return base


def p(text, style_name="Body"):
    return Paragraph(text, STYLE[style_name])


def bullet(items):
    return ListFlowable(
        [ListItem(p(item), bulletColor=colors.HexColor("#0d47b5")) for item in items],
        bulletType="bullet",
        leftIndent=14,
        bulletFontSize=7,
    )


def wrap_code_lines(text, max_chars=92):
    wrapped = []
    for raw_line in text.strip().splitlines():
        if len(raw_line) <= max_chars:
            wrapped.append(raw_line)
            continue
        indent = raw_line[:len(raw_line) - len(raw_line.lstrip())]
        available = max(max_chars - len(indent), 32)
        chunks = textwrap.wrap(
            raw_line.strip(),
            width=available,
            break_long_words=True,
            break_on_hyphens=False,
            replace_whitespace=False,
            drop_whitespace=False,
        )
        wrapped.extend([(indent if index == 0 else indent + "  ") + chunk for index, chunk in enumerate(chunks)])
    return "\n".join(wrapped)


def code_block(text):
    block = Preformatted(wrap_code_lines(text), STYLE["DocCode"])
    table = Table([[block]], colWidths=[170 * mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("BOX", (0, 0), (-1, -1), 0.7, colors.HexColor("#dbe3ee")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    return table


def data_table(rows, widths=None):
    widths = widths or [40 * mm, 45 * mm, 85 * mm]
    formatted_rows = []
    for row_index, row in enumerate(rows):
        style_name = "TableHeader" if row_index == 0 else "TableCell"
        formatted_rows.append([Paragraph(str(cell if cell is not None else ""), STYLE[style_name]) for cell in row])
    table = Table(formatted_rows, colWidths=widths, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1677ff")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("LEADING", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dbe3ee")),
        ("BACKGROUND", (0, 1), (-1, -1), colors.white),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return table


def link_cell(url, label=None):
    label = label or url
    return Paragraph(f'<link href="{url}"><font color="#0d47b5"><u>{label}</u></font></link>', STYLE["TableLink"])


def data_table_flowable(rows, widths=None):
    widths = widths or [40 * mm, 45 * mm, 85 * mm]
    formatted_rows = []
    for row_index, row in enumerate(rows):
        style_name = "TableHeader" if row_index == 0 else "TableCell"
        formatted = []
        for cell in row:
            if hasattr(cell, "wrap"):
                formatted.append(cell)
            else:
                formatted.append(Paragraph(str(cell if cell is not None else ""), STYLE[style_name]))
        formatted_rows.append(formatted)
    table = Table(formatted_rows, colWidths=widths, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1677ff")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("LEADING", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dbe3ee")),
        ("BACKGROUND", (0, 1), (-1, -1), colors.white),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return table


def header_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#64748b"))
    canvas.drawString(18 * mm, 12 * mm, "Innersync Gateway API Documentation")
    canvas.drawRightString(192 * mm, 12 * mm, f"Page {doc.page}")
    canvas.restoreState()


def build_story():
    story = []
    if LOGO.exists():
        img = Image(str(LOGO), width=32 * mm, height=18 * mm)
        img.hAlign = "CENTER"
        story.append(img)
        story.append(Spacer(1, 5))

    story.append(p("Innersync Gateway API Documentation", "DocTitle"))
    story.append(p("Panduan integrasi untuk vendor external VMS, lift, access control, atau aplikasi third party yang ingin mengirim data ke Innersync.", "Small"))
    story.append(Spacer(1, 8))
    story.append(StatusBox("Document Version 1.0", "Compatible with Innersync Registration Portal Gateway API."))
    story.append(Spacer(1, 14))

    story.append(p("1. Overview", "Section"))
    story.append(p("Gateway API berfungsi sebagai pintu masuk integrasi dari software vendor lain. Vendor mengirim request ke Innersync, lalu Innersync dapat meneruskan data ke API Configuration/Destination yang sudah disetting, misalnya InnerRange, Schindler, atau system lain.", "Body"))
    story.append(bullet([
        "Gateway hanya menerima request jika Gateway API aktif dan API key valid.",
        "Saat Operation Mode = Middleware Sync, Gateway execute otomatis diblokir untuk mencegah double command.",
        "Field mapping dan action mapping dapat disesuaikan dari halaman Gateway API.",
        "Semua request gateway tercatat di Gateway Logs."
    ]))

    story.append(p("2. Base URL dan Authentication", "Section"))
    story.append(p("Base URL mengikuti IP/host dan port web Innersync customer. Contoh local default:", "Body"))
    story.append(code_block("http://localhost:8081"))
    story.append(p("Header wajib:", "SubSection"))
    story.append(data_table([
        ["Header", "Value", "Keterangan"],
        ["Content-Type", "application/json", "Body request dikirim dalam format JSON."],
        ["x-innersync-gateway-key", "API_KEY", "API key dari halaman Gateway API Innersync."],
        ["Authorization", "Basic base64(username:password)", "Wajib jika Gateway Username dan Password diset. Bisa diganti dengan header username/password di bawah."],
        ["x-innersync-gateway-username", "USERNAME", "Alternatif Basic Auth jika vendor tidak memakai Authorization Basic."],
        ["x-innersync-gateway-password", "PASSWORD", "Alternatif Basic Auth jika vendor tidak memakai Authorization Basic."],
    ]))
    story.append(p("API key tetap wajib. Username/password menjadi lapisan tambahan jika dikonfigurasi di halaman Gateway API.", "Body"))
    story.append(p("Alternatif authentication untuk API key: API key juga dapat dikirim sebagai Bearer token pada header Authorization jika username/password tidak dipakai.", "Body"))
    story.append(code_block("Authorization: Bearer API_KEY"))

    story.append(p("3. Endpoint", "Section"))
    story.append(data_table([
        ["Method", "Endpoint", "Fungsi"],
        ["POST", "/api/gateway/execute", "Endpoint utama untuk mengirim data check-in, edit, checkout, delete, atau action lain."],
        ["GET", "/api/gateway/status/{request_id}", "Melihat status request tertentu. Endpoint ini juga memakai Gateway API key."],
    ], [24 * mm, 63 * mm, 83 * mm]))

    story.append(PageBreak())
    story.append(p("4. Request Body", "Section"))
    story.append(p("Struktur umum request:", "Body"))
    story.append(data_table([
        ["Field", "Type", "Keterangan"],
        ["action", "string", "CHECKIN, EDIT, DELETE, CHECKOUT, ADD, UPDATE, CANCEL. Action akan dimapping ke trigger API."],
        ["mode", "string", "SYNC atau ASYNC. SYNC menunggu hasil destination. ASYNC langsung accepted dan proses background."],
        ["request_id", "string", "ID unik dari vendor. Disarankan selalu dikirim agar status mudah dilacak."],
        ["source_system", "string", "Nama aplikasi/vendor pengirim data."],
        ["visitor", "object", "Data visitor/user yang akan diproses Innersync."],
    ]))
    story.append(p("Field visitor yang umum dipakai:", "SubSection"))
    story.append(data_table([
        ["Field", "Contoh", "Keterangan"],
        ["first_name", "Ryan", "Nama depan visitor/user."],
        ["second_name", "Restian", "Nama belakang visitor/user."],
        ["company_name", "PT EPCON", "Nama perusahaan visitor."],
        ["card_number", "123456", "Nomor kartu atau badge."],
        ["host", "PT EPCON MULTI GUNA", "Tujuan bertamu/host."],
        ["permission_group", "LANTAI 5", "Grouping Innersync atau permission destination."],
        ["start_date", "2026-07-22T09:00:00+07:00", "Tanggal mulai aktif."],
        ["expiry_date", "2026-07-22T18:00:00+07:00", "Tanggal akhir aktif."],
        ["purpose_note", "Meeting", "Keperluan."],
    ]))

    story.append(p("5. Contoh Request CHECKIN", "Section"))
    story.append(code_block(r'''
POST /api/gateway/execute
Content-Type: application/json
x-innersync-gateway-key: YOUR_GATEWAY_API_KEY
Authorization: Basic base64(GATEWAY_USERNAME:GATEWAY_PASSWORD)

{
  "action": "CHECKIN",
  "mode": "SYNC",
  "request_id": "VMS-001",
  "source_system": "External VMS",
  "visitor": {
    "first_name": "Ryan",
    "second_name": "Restian",
    "company_name": "PT EPCON",
    "card_number": "123456",
    "host": "PT EPCON MULTI GUNA",
    "permission_group": "LANTAI 5",
    "start_date": "2026-07-22T09:00:00+07:00",
    "expiry_date": "2026-07-22T18:00:00+07:00",
    "purpose_note": "Meeting"
  }
}
'''))

    story.append(PageBreak())
    story.append(p("6. Contoh Response", "Section"))
    story.append(p("Success penuh:", "SubSection"))
    story.append(code_block(r'''
{
  "success": true,
  "request_id": "VMS-001",
  "log_id": 10,
  "visitor_id": 120,
  "action": "CHECKIN",
  "trigger_event": "CHECKIN",
  "mode": "SYNC",
  "results": [
    {
      "config_id": 1,
      "config_name": "API CHECK IN",
      "provider_type": "INNERRANGE",
      "success": true,
      "status": 200,
      "duration_ms": 350
    }
  ]
}
'''))
    story.append(p("Partial/failed destination. HTTP status 207 berarti request Gateway diterima, tetapi salah satu destination gagal:", "SubSection"))
    story.append(code_block(r'''
{
  "success": false,
  "request_id": "VMS-001",
  "log_id": 11,
  "action": "CHECKIN",
  "trigger_event": "CHECKIN",
  "mode": "SYNC",
  "results": [
    {
      "config_name": "API CHECK IN",
      "provider_type": "INNERRANGE",
      "success": false,
      "status": 500,
      "error": "Destination returned error"
    }
  ]
}
'''))
    story.append(p("ASYNC accepted:", "SubSection"))
    story.append(code_block(r'''
{
  "success": true,
  "accepted": true,
  "mode": "ASYNC",
  "request_id": "VMS-001",
  "log_id": 12,
  "status_url": "/api/gateway/status/VMS-001"
}
'''))

    story.append(PageBreak())
    story.append(p("7. HTTP Status Code", "Section"))
    story.append(data_table([
        ["Code", "Meaning", "Keterangan"],
        ["200", "OK", "Request diproses dan semua destination sukses, atau ASYNC accepted."],
        ["207", "Multi-Status", "Gateway menerima request, tetapi satu atau lebih destination gagal. Cek results dan Gateway Logs."],
        ["400", "Bad Request", "Action tidak diizinkan atau JSON/body tidak valid."],
        ["401", "Unauthorized", "Gateway API key salah, username/password salah, atau credential tidak dikirim."],
        ["403", "Forbidden", "Gateway API belum aktif."],
        ["409", "Conflict", "Gateway execute diblokir karena Operation Mode = Middleware Sync."],
        ["500", "Server Error", "Error internal Innersync saat memproses request."],
    ]))

    story.append(PageBreak())
    story.append(p("8. Gateway Behavior", "Section"))
    story.append(data_table([
        ["Mode", "Efek", "Kapan dipakai"],
        ["FORWARD_ONLY", "Tidak membuat visitor di database Innersync. Request hanya diteruskan ke destination API.", "Jika Innersync hanya menjadi gateway/middleware."],
        ["CREATE_VISITOR_AND_FORWARD", "Setiap request CHECKIN/ADD/CREATE membuat visitor baru lalu diteruskan.", "Jika external system ingin Innersync menyimpan record visitor."],
        ["UPSERT_VISITOR_AND_FORWARD", "Update record existing berdasarkan card_number/identity_number, jika tidak ada maka create.", "Jika vendor sering mengirim update data visitor."],
    ]))

    story.append(p("9. Operation Mode Safety", "Section"))
    story.append(p("Untuk menghindari bentrok dan double command ke destination yang sama, Gateway API tidak melakukan execute saat Innersync berada pada Operation Mode Middleware Sync.", "Body"))
    story.append(data_table([
        ["Operation Mode", "Gateway Execute", "Keterangan"],
        ["Visitor Registration", "Allowed", "Gateway dapat menerima dan memproses request vendor."],
        ["Middleware Sync", "Blocked", "Gateway mengembalikan HTTP 409 agar proses sync database menjadi satu-satunya sumber command."],
    ]))

    story.append(p("10. Postman Setup", "Section"))
    story.append(p("File Postman dapat didownload dari server Innersync customer:", "Body"))
    story.append(data_table_flowable([
        ["File", "Download URL", "Keterangan"],
        ["Collection", link_cell("/docs/innersync-gateway-api.postman_collection.json"), "Import ke Postman untuk endpoint execute dan status."],
        ["Environment", link_cell("/docs/innersync-gateway-api.postman_environment.json"), "Isi base_url, gateway_api_key, gateway_username, dan gateway_password."],
    ], [34 * mm, 76 * mm, 60 * mm]))
    story.append(bullet([
        "Method: POST",
        "URL: http://SERVER_IP:PORT/api/gateway/execute",
        "Authorization Type: Basic Auth jika username/password diset",
        "Username: gateway_username dari halaman Gateway API",
        "Password: gateway_password dari halaman Gateway API",
        "Key: x-innersync-gateway-key",
        "Value: API key dari halaman Gateway API",
        "Add to: Header",
        "Body: raw JSON"
    ]))

    story.append(p("11. Security Notes", "Section"))
    story.append(bullet([
        "Jangan share API key di screenshot atau dokumen publik.",
        "Jangan share Gateway username/password di screenshot atau dokumen publik.",
        "Gunakan jaringan private, VPN, firewall allowlist, atau HTTPS reverse proxy untuk deployment production.",
        "Rotate API key dan ganti password jika credential pernah terlihat pihak lain.",
        "Gunakan request_id unik untuk audit dan troubleshooting."
    ]))

    story.append(p("12. Troubleshooting", "Section"))
    story.append(data_table([
        ["Gejala", "Kemungkinan Penyebab", "Solusi"],
        ["401 Unauthorized", "Header API key salah, username/password salah, atau credential kosong.", "Pastikan x-innersync-gateway-key benar dan Basic Auth/header username-password sesuai setting."],
        ["403 Gateway belum aktif", "Toggle Gateway API off.", "Aktifkan Gateway API dari halaman Gateway API."],
        ["409 Conflict", "Operation Mode Middleware Sync aktif.", "Pindahkan ke Visitor Registration jika ingin Gateway execute."],
        ["207 Multi-Status", "Destination API gagal.", "Cek Gateway Logs dan API Log Activity untuk detail response."],
        ["500 Server Error", "Mapping/body/schema tidak sesuai.", "Cek error message dan validasi payload JSON."],
    ]))

    story.append(Spacer(1, 14))
    story.append(StatusBox("Support", "For implementation support, provide request_id, timestamp, response body, and Gateway Logs detail."))
    return story


if __name__ == "__main__":
    STYLE = styles()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(OUTPUT_PDF),
        pagesize=A4,
        rightMargin=20 * mm,
        leftMargin=20 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
        title="Innersync Gateway API Documentation",
        author="Innersync",
    )
    doc.build(build_story(), onFirstPage=header_footer, onLaterPages=header_footer)
    print(OUTPUT_PDF)
