const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const path = require("node:path");
const os = require("node:os");
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const QRCode = require("qrcode");

async function main() {
    const browser = await chromium.launch({ channel: "msedge", headless: true });
    const root = path.resolve(__dirname, "../public");
    const output = path.join(os.tmpdir(), "innersync-visitor-transfer-qa");
    await fs.mkdir(output, { recursive: true });
    const qrData = await QRCode.toDataURL("1234567890");
    const base = { host: "Test Host", permission_group: "Visitor", card_number: "9999999999", first_name: "Visitor Test", email_address: "test@example.invalid", check_in_time: null, check_out_time: null, start_date: new Date().toISOString(), expiry_date: new Date(Date.now()+86400000).toISOString() };
    const rows = [
        { ...base, visitor_id: 901, access_invitation_id: 801, access_status: "ACCESS_READY", access_qr_value: "1234567890", access_email_status: "SENT", access_phase: "PROVISION" },
        { ...base, visitor_id: 902, first_name: "Visitor Pending", access_invitation_id: 802, access_status: "ACCESS_PENDING", access_phase: "PROVISION" },
        { ...base, visitor_id: 903, first_name: "Visitor Failed", access_invitation_id: 803, access_status: "ACCESS_FAILED", access_error: "Mock timeout", access_phase: "PROVISION" },
        { ...base, visitor_id: 904, first_name: "Visitor Manual", check_in_time: new Date().toISOString() },
        { ...base, visitor_id: 905, first_name: "Visitor Arrival", access_invitation_id: 805, access_status: "WAITING_ARRIVAL", access_qr_value: "5555555555", access_email_status: "SENT", access_phase: "WAITING_ARRIVAL" },
        { ...base, visitor_id: 906, first_name: "Visitor Direct", access_invitation_id: 806, access_status: "CHECKED_IN", access_qr_value: "6666666666", access_email_status: "SENT", access_phase: "PROVISION", access_error: "Mock API timeout", check_in_time: new Date().toISOString() }
    ];
    const invitationRows = [
        { invitation_id: 1001, booking_code: "INV-BM-001", first_name: "Waiting", second_name: "BM", host: "Host One", status: "WAITING_BM_APPROVAL", start_date: new Date().toISOString(), expiry_date: new Date(Date.now()+86400000).toISOString() },
        { invitation_id: 1002, booking_code: "INV-HOST-001", first_name: "Waiting", second_name: "Host", host: "Host Two", status: "WAITING_HOST_APPROVAL", start_date: new Date().toISOString(), expiry_date: new Date(Date.now()+86400000).toISOString() },
        { invitation_id: 1003, booking_code: "INV-DONE-001", first_name: "No", second_name: "Approval", host: "Host Three", status: "PENDING", start_date: new Date().toISOString(), expiry_date: new Date(Date.now()+86400000).toISOString() }
    ];
    try {
        for (const width of [1920, 1366, 390]) {
            const page = await browser.newPage({ viewport: { width, height: 900 } });
            await page.addInitScript(() => localStorage.removeItem("innersync.visitorRegistration.columnWidths.v1"));
            const errors = [];
            const posts = [];
            page.on("pageerror", error => errors.push(error.message));
            page.on("dialog", dialog => dialog.accept().catch(() => {}));
            await page.route("**/*", async route => {
                const url = new URL(route.request().url());
                if (url.pathname.endsWith("qrcode.min.js")) return route.fulfill({ contentType: "text/javascript", body: `window.QRCode=class{static CorrectLevel={H:2};constructor(element,options){window.testQrValue=options.text;const image=document.createElement('img');image.src=${JSON.stringify(qrData)};image.width=options.width;image.height=options.height;element.appendChild(image)}};` });
                if (url.hostname !== "innersync.test") return route.fulfill({ contentType: "text/css", body: "" });
                const json = data => route.fulfill({ json: { success: true, data } });
                if (route.request().method() === "POST") { posts.push({ path: url.pathname, body: route.request().postDataJSON() }); return route.fulfill({ json: { success: true, message: "Queued" } }); }
                if (url.pathname === "/visitors") return json(rows);
                if (/^\/visitors\/\d+$/.test(url.pathname)) return json(rows.find(row=>row.visitor_id===Number(url.pathname.split("/").pop())));
                if (url.pathname === "/api/visitor-stats") return json({ active_visitors: 1, check_in_today: 1 });
                if (url.pathname === "/api/invitations") return json(invitationRows);
                if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/card-reader/")) return json([]);
                const filename = path.resolve(root, "."+url.pathname);
                if (!filename.startsWith(root+path.sep)) return route.abort();
                try { await route.fulfill({ body: await fs.readFile(filename), contentType: filename.endsWith(".html") ? "text/html" : "image/png" }); }
                catch { await route.fulfill({ status: 404, body: "" }); }
            });
            await page.goto("http://innersync.test/index.html");
            await page.waitForFunction(() => document.querySelectorAll("#visitorTable tr").length === 6);
            assert.equal(await page.locator("#visitorDataTable .visitor-column-resizer").count(), 8, "Every separator between visitor columns must have a resize handle");
            if (width === 1920) {
                const nameHeader = page.locator('#visitorDataTable th[data-column-key="name"]');
                const hostHeader = page.locator('#visitorDataTable th[data-column-key="host"]');
                const resizeHandle = nameHeader.locator(".visitor-column-resizer");
                const beforeWidth = (await nameHeader.boundingBox()).width;
                const hostBeforeWidth = (await hostHeader.boundingBox()).width;
                const handleBox = await resizeHandle.boundingBox();
                await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2);
                await page.mouse.down();
                await page.mouse.move(handleBox.x + handleBox.width / 2 + 40, handleBox.y + handleBox.height / 2, { steps: 4 });
                await page.mouse.up();
                const afterWidth = (await nameHeader.boundingBox()).width;
                const hostAfterWidth = (await hostHeader.boundingBox()).width;
                assert(afterWidth >= beforeWidth + 35, "Dragging a separator must resize its column");
                assert(hostAfterWidth <= hostBeforeWidth - 35, "The adjacent column must compensate so the table remains fluid");
                const storedLayout = await page.evaluate(() => JSON.parse(localStorage.getItem("innersync.visitorRegistration.columnWidths.v1") || "{}"));
                assert.equal(storedLayout.version, 2);
                const tableBeforeZoom = await page.locator("#visitorDataTable").boundingBox();
                const ratioBeforeZoom = afterWidth / tableBeforeZoom.width;
                assert(Math.abs(storedLayout.ratios.name - ratioBeforeZoom) <= 0.002, "Resized ratio must be persisted");
                await page.setViewportSize({ width: 1600, height: 900 });
                const tableAfterZoom = await page.locator("#visitorDataTable").boundingBox();
                const nameAfterZoom = await nameHeader.boundingBox();
                assert(Math.abs((nameAfterZoom.width / tableAfterZoom.width) - ratioBeforeZoom) <= 0.002, "Column proportions must follow viewport or browser zoom changes");
                const tableContainerAfterZoom = await page.locator(".table-container").boundingBox();
                assert(Math.abs((tableAfterZoom.x + tableAfterZoom.width) - (tableContainerAfterZoom.x + tableContainerAfterZoom.width - 25)) <= 2, "Table must continue filling the panel after zoom changes");
                await page.setViewportSize({ width, height: 900 });
                for (const label of await page.locator("#visitorDataTable .sort-header-label").all()) {
                    const labelBox = await label.boundingBox();
                    const headerBox = await label.locator("xpath=ancestor::th").boundingBox();
                    const labelCenter = labelBox.x + labelBox.width / 2;
                    const headerCenter = headerBox.x + headerBox.width / 2;
                    assert(Math.abs(labelCenter - headerCenter) <= 1, "Header labels must remain centered after resizing");
                }
            }
            assert.equal(await page.locator("#visitorPrevPageTop,#visitorNextPageTop,#visitorPageLabelTop").count(), 0, "Top pagination must be removed");
            assert.equal(await page.locator(".visitor-table-toolbar").count(), 0, "Top rows control must be removed");
            assert.equal(await page.locator(".visitor-table-footer #visitorPageSize").count(), 1, "Rows control must be placed beside the bottom pagination");
            await page.getByRole("button", { name: "Invitation List" }).click();
            await page.locator("#invitationListModal").waitFor({ state: "visible" });
            await page.waitForFunction(() => document.querySelector("#pendingInvitationTable")?.textContent.includes("INV-HOST-001"));
            assert.equal(await page.locator("#pendingInvitationTable tr").count(), 2, "Popup must only show invitations waiting for approval");
            assert.equal(await page.locator("#pendingInvitationTable").getByText("INV-DONE-001").count(), 0);
            assert.equal(await page.locator("#pendingInvitationTable .invitation-approval-action.approve").count(), 1);
            const invitationModalBox = await page.locator(".invitation-list-modal").boundingBox();
            assert(invitationModalBox.x >= 0 && invitationModalBox.x + invitationModalBox.width <= width, "Invitation popup must fit in the viewport");
            if (width > 720) {
                assert(await page.locator(".invitation-popup-table-wrap").evaluate(node => node.scrollWidth <= node.clientWidth + 1), "Desktop invitation table must show all columns without horizontal scrolling");
            }
            await page.screenshot({ path: path.join(output, `invitations-${width}.png`) });
            await page.getByRole("button", { name: "Tutup invitation list" }).click();
            await page.locator("#invitationListModal").waitFor({ state: "hidden" });
            const settingsButton = page.locator("#visitorSettingsButton");
            assert.equal((await settingsButton.textContent()).trim(), "", "Settings trigger must remain icon-only");
            const settingsButtonBox = await settingsButton.boundingBox();
            assert.equal(Math.round(settingsButtonBox.width), 42);
            assert.equal(Math.round(settingsButtonBox.height), 42);
            const primaryToolbarBox = await page.locator(".visitor-primary-toolbar").boundingBox();
            assert(Math.abs((settingsButtonBox.x + settingsButtonBox.width) - (primaryToolbarBox.x + primaryToolbarBox.width)) < 1, "Settings icon must align to the toolbar's right edge");
            assert.equal(await page.getByRole("button", { name: "Auto Check-Out", exact: true }).count(), 0, "Old toolbar button must be removed");
            await settingsButton.click();
            await page.locator("#visitorSettingsModal").waitFor({ state: "visible" });
            assert.equal(await page.locator("#visitorSettingsTitle").textContent(), "Pengaturan Visitor Registration");
            assert.equal(await page.locator("#autoCheckoutSettingsTitle").textContent().then(value => value.trim()), "Auto Check-Out");
            const autoCheckoutColumns = await page.locator(".auto-checkout-panel").evaluate(node => getComputedStyle(node).gridTemplateColumns.split(" ").length);
            assert.equal(autoCheckoutColumns, width <= 720 ? 1 : 2);
            const settingsModalBox = await page.locator(".visitor-settings-modal").boundingBox();
            assert(settingsModalBox.x >= 0 && settingsModalBox.x + settingsModalBox.width <= width, "Settings popup must fit in the viewport");
            await page.screenshot({ path: path.join(output, `settings-${width}.png`) });
            await page.getByRole("button", { name: "Tutup pengaturan" }).click();
            await page.locator("#visitorSettingsModal").waitFor({ state: "hidden" });
            const ready = page.locator("#visitorTable tr").filter({ hasText: "Akses Siap" });
            const pending = page.locator("#visitorTable tr").filter({ hasText: "Menyiapkan Akses" });
            const failed = page.locator("#visitorTable tr").filter({ hasText: "Akses Gagal" });
            assert.equal(await ready.locator("td").count(), 9);
            assert.equal((await ready.locator("td").nth(5).textContent()).trim(), "-");
            assert.equal(await ready.getByText("Check-Out", { exact: true }).count(), 0);
            const manual = page.locator("#visitorTable tr").filter({ hasText: "Visitor Manual" });
            assert.equal(await manual.getByTitle("Check-Out").count(), 1);
            assert.equal(await manual.getByTitle("Kirim QR via Email").count(), 1);
            assert.equal(await manual.getByText("Check-Out", { exact: true }).count(), 0);
            assert.equal(await pending.getByTitle("Lihat QR Akses").count(), 0);
            assert.equal(await failed.getByTitle("Retry Sinkronisasi").count(), 1);
            const arrival = page.locator("#visitorTable tr").filter({ hasText: "Visitor Arrival" });
            const direct = page.locator("#visitorTable tr").filter({ hasText: "Visitor Direct" });
            assert.equal(await arrival.getByTitle("Check-in dan Aktifkan Akses").count(), 0);
            assert.equal(await arrival.getByTitle("Lihat QR Akses").count(), 0);
            assert.equal(await arrival.locator(".access-action.email").count(), 0);
            assert.equal(await direct.getByTitle("Check-Out dan Cabut Akses").count(), 1);
            assert.equal(await direct.getByTitle("Lihat QR Akses").count(), 1);
            assert.equal(await direct.getByTitle("Retry Sinkronisasi").count(), 1);
            for (const button of await page.locator("#visitorTable .access-action").all()) {
                const box = await button.boundingBox();
                assert.equal(Math.round(box.width), 34);
                assert.equal(Math.round(box.height), 34);
            }
            for (const element of await page.locator(".visitor-state").all()) assert(await element.evaluate(node => node.scrollWidth <= node.clientWidth + 1));
            await ready.locator(".visitor-state").scrollIntoViewIfNeeded();
            await page.screenshot({ path: path.join(output, `visitors-${width}.png`) });
            await ready.locator(".visitor-state").click();
            await page.locator("#visitorDetailModal").waitFor({ state: "visible" });
            assert.equal(await page.locator("#detail_visit_status").inputValue(), "Akses Siap");
            assert.equal(await page.locator("#visitorDetailContent .detail-edit,#visitorDetailContent .detail-save").count(), 0);
            await page.evaluate(() => toggleVisitorDetail(false));
            await ready.getByTitle("Lihat QR Akses").click();
            await page.locator("#qrShareModal").waitFor({ state: "visible" });
            assert.equal(await page.evaluate(() => window.testQrValue), "1234567890", "Use stored QR, not raw card or current mapping");
            await page.locator(".qr-email").click();
            await page.waitForFunction(() => document.getElementById("visitorTable").children.length === 6);
            assert(posts.some(post=>post.path==="/api/invitations/801/retry-access" && post.body.email_only===true));
            await page.evaluate(() => toggleQrModal(false));
            const manualEmailRequest = page.waitForRequest(request => new URL(request.url()).pathname === "/api/send-qr-email");
            await manual.getByTitle("Kirim QR via Email").click();
            const manualEmailPayload = (await manualEmailRequest).postDataJSON();
            assert.equal(manualEmailPayload.to_email, "test@example.invalid");
            await failed.getByTitle("Retry Sinkronisasi").click();
            assert(posts.some(post=>post.path==="/api/invitations/803/retry-access" && post.body.email_only===false));
            await direct.getByTitle("Check-Out dan Cabut Akses").click();
            assert(posts.some(post=>post.path==="/api/invitations/806/revoke-access"));
            assert.deepEqual(errors, []);
            await page.close();
        }
        console.log("PASS settings popup, desktop/mobile status layout, controlled QR, read-only approved details, self-service arrival, checkout, retry and email controls");
        console.log(`Screenshots: ${output}; all APIs and QR renderer mocked, no real mutations`);
    } finally { await browser.close(); }
}

main().catch(error=>{ console.error(error); process.exitCode=1; });
