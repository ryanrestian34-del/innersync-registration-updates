from __future__ import annotations

from datetime import date
from hashlib import sha1
from html import escape
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    XPreformatted,
)
from reportlab.platypus.tableofcontents import TableOfContents


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output" / "pdf" / "Innersync-Linux-Installation-Operation-Manual.pdf"
LOGO = ROOT / "public" / "logo.png"

NAVY = colors.HexColor("#0B1F3A")
BLUE = colors.HexColor("#1457C5")
CYAN = colors.HexColor("#0B8EAB")
GREEN = colors.HexColor("#087B57")
AMBER = colors.HexColor("#C87900")
RED = colors.HexColor("#C92A2A")
TEXT = colors.HexColor("#172033")
MUTED = colors.HexColor("#526987")
LINE = colors.HexColor("#C9D9EF")
PALE = colors.HexColor("#F5F8FC")
PALE_BLUE = colors.HexColor("#EAF2FF")
PALE_GREEN = colors.HexColor("#E9F8F2")
PALE_AMBER = colors.HexColor("#FFF6E5")
PALE_RED = colors.HexColor("#FFF0F0")
WHITE = colors.white


styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="CoverTitle", parent=styles["Title"], fontName="Helvetica-Bold",
    fontSize=26, leading=31, textColor=NAVY, spaceAfter=8, alignment=TA_LEFT,
))
styles.add(ParagraphStyle(
    name="CoverSub", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=11, leading=16, textColor=MUTED, spaceAfter=6,
))
styles.add(ParagraphStyle(
    name="H1", parent=styles["Heading1"], fontName="Helvetica-Bold",
    fontSize=15, leading=19, textColor=BLUE, spaceBefore=10, spaceAfter=7,
    keepWithNext=True,
))
styles.add(ParagraphStyle(
    name="H2", parent=styles["Heading2"], fontName="Helvetica-Bold",
    fontSize=11, leading=14, textColor=NAVY, spaceBefore=8, spaceAfter=5,
    keepWithNext=True,
))
styles.add(ParagraphStyle(
    name="H3", parent=styles["Heading3"], fontName="Helvetica-Bold",
    fontSize=9.2, leading=12, textColor=CYAN, spaceBefore=6, spaceAfter=3,
    keepWithNext=True,
))
styles.add(ParagraphStyle(
    name="BodyManual", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=8.8, leading=12.4, textColor=TEXT, spaceAfter=5,
))
styles.add(ParagraphStyle(
    name="Small", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=7.8, leading=10.5, textColor=MUTED, spaceAfter=3,
))
styles.add(ParagraphStyle(
    name="BulletManual", parent=styles["BodyManual"], leftIndent=12,
    firstLineIndent=-9, bulletIndent=0, spaceAfter=3,
))
styles.add(ParagraphStyle(
    name="StepNumber", parent=styles["BodyManual"], fontName="Helvetica-Bold",
    fontSize=9.2, leading=12.5, textColor=NAVY, leftIndent=18,
    firstLineIndent=-18, spaceAfter=4,
))
styles.add(ParagraphStyle(
    name="TableHead", parent=styles["BodyText"], fontName="Helvetica-Bold",
    fontSize=7.2, leading=9, textColor=WHITE, alignment=TA_CENTER,
))
styles.add(ParagraphStyle(
    name="TableCell", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=7.4, leading=9.5, textColor=TEXT,
))
styles.add(ParagraphStyle(
    name="TableCellBold", parent=styles["TableCell"], fontName="Helvetica-Bold",
))
styles.add(ParagraphStyle(
    name="CalloutTitle", parent=styles["BodyText"], fontName="Helvetica-Bold",
    fontSize=9.2, leading=12, textColor=NAVY, spaceAfter=3,
))
styles.add(ParagraphStyle(
    name="CalloutBody", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=8.2, leading=11.3, textColor=TEXT,
))
styles.add(ParagraphStyle(
    name="CodeManual", parent=styles["Code"], fontName="Courier",
    fontSize=7.1, leading=9.4, textColor=NAVY, leftIndent=0, rightIndent=0,
))
styles.add(ParagraphStyle(
    name="TocTitle", parent=styles["Heading1"], fontName="Helvetica-Bold",
    fontSize=17, leading=21, textColor=NAVY, spaceAfter=10,
))


def para(text: str, style: str = "BodyManual") -> Paragraph:
    return Paragraph(text, styles[style])


def heading(number: str, title: str, level: int = 1) -> Paragraph:
    style = "H1" if level == 1 else "H2"
    return Paragraph(f"{escape(number)}. {escape(title)}", styles[style])


def subheading(title: str) -> Paragraph:
    return Paragraph(escape(title), styles["H3"])


def bullet(text: str) -> Paragraph:
    return Paragraph(f"- {text}", styles["BulletManual"])


def step(number: int, text: str) -> Paragraph:
    return Paragraph(f"{number}. {text}", styles["StepNumber"])


def code_block(text: str) -> Table:
    block = XPreformatted(text.strip(), styles["CodeManual"])
    table = Table([[block]], colWidths=[170 * mm], hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F2F6FB")),
        ("BOX", (0, 0), (-1, -1), 0.7, LINE),
        ("LINEBEFORE", (0, 0), (0, -1), 3, BLUE),
        ("LEFTPADDING", (0, 0), (-1, -1), 9),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return table


def callout(title: str, body: str, kind: str = "info") -> KeepTogether:
    palettes = {
        "info": (PALE_BLUE, BLUE),
        "success": (PALE_GREEN, GREEN),
        "warning": (PALE_AMBER, AMBER),
        "danger": (PALE_RED, RED),
    }
    background, border = palettes[kind]
    box = Table(
        [[para(title, "CalloutTitle")], [para(body, "CalloutBody")]],
        colWidths=[170 * mm], hAlign="LEFT",
    )
    box.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), background),
        ("BOX", (0, 0), (-1, -1), 0.75, border),
        ("LINEBEFORE", (0, 0), (0, -1), 4, border),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return KeepTogether([box])


def data_table(headers, rows, widths, header_color=BLUE) -> Table:
    data = [[para(str(value), "TableHead") for value in headers]]
    for row in rows:
        cells = []
        for index, value in enumerate(row):
            if hasattr(value, "wrap"):
                cells.append(value)
            else:
                style = "TableCellBold" if index == 0 else "TableCell"
                cells.append(para(str(value), style))
        data.append(cells)
    result = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    result.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), header_color),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, LINE),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, PALE]),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return result


class ManualDocTemplate(BaseDocTemplate):
    def __init__(self, filename: str):
        super().__init__(
            filename,
            pagesize=A4,
            leftMargin=18 * mm,
            rightMargin=18 * mm,
            topMargin=22 * mm,
            bottomMargin=18 * mm,
            title="Innersync Linux Installation and Operation Manual",
            author="Innersync",
            subject="Panduan instalasi produksi Innersync pada Ubuntu Linux",
        )
        frame = Frame(
            self.leftMargin,
            self.bottomMargin,
            self.width,
            self.height,
            id="normal",
        )
        self.addPageTemplates(PageTemplate(id="manual", frames=[frame], onPage=self.draw_page))

    def draw_page(self, canvas, doc):
        if doc.page == 1:
            return
        width, height = A4
        canvas.saveState()
        canvas.setFillColor(MUTED)
        canvas.setFont("Helvetica-Bold", 7.6)
        canvas.drawString(18 * mm, height - 12 * mm, "INNERSYNC - LINUX INSTALLATION & OPERATION MANUAL")
        canvas.setFont("Helvetica", 7.5)
        canvas.drawRightString(width - 18 * mm, height - 12 * mm, "Ubuntu 22.04 / 24.04 LTS")
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(0.45)
        canvas.line(18 * mm, height - 15 * mm, width - 18 * mm, height - 15 * mm)
        canvas.line(18 * mm, 15 * mm, width - 18 * mm, 15 * mm)
        canvas.setFont("Helvetica", 7.5)
        canvas.drawString(18 * mm, 10.5 * mm, "Operational deployment guide")
        canvas.drawRightString(width - 18 * mm, 10.5 * mm, f"Page {doc.page}")
        canvas.restoreState()

    def afterFlowable(self, flowable):
        if not isinstance(flowable, Paragraph):
            return
        if flowable.style.name not in {"H1", "H2"}:
            return
        level = 0 if flowable.style.name == "H1" else 1
        text = flowable.getPlainText()
        key = f"section-{sha1(text.encode('utf-8')).hexdigest()[:14]}"
        self.canv.bookmarkPage(key)
        self.canv.addOutlineEntry(text, key, level=level, closed=False)
        self.notify("TOCEntry", (level, text, self.page, key))


def build_story():
    story = []

    # Cover
    story.append(Spacer(1, 14 * mm))
    if LOGO.exists():
        logo = Image(str(LOGO), width=43 * mm, height=30 * mm)
        logo.hAlign = "LEFT"
        story.append(logo)
        story.append(Spacer(1, 7 * mm))
    story.append(para("Linux Installation &<br/>Operation Manual", "CoverTitle"))
    story.append(para("Innersync Registration Portal", "CoverSub"))
    story.append(para(
        "Versi interaktif dengan tombol Copy: "
        "<a href='https://innersync.my.id/docs/linux-installation-manual.html' "
        "color='#1457C5'>https://innersync.my.id/docs/linux-installation-manual.html</a>",
        "CoverSub",
    ))
    story.append(Spacer(1, 8 * mm))
    story.append(callout(
        "Tujuan dokumen",
        "Panduan end-to-end untuk menyiapkan VPS Ubuntu, memasang Innersync, memulihkan atau membuat database, menerbitkan domain HTTPS, mengaktifkan license, melakukan update, dan menyerahkan sistem dalam kondisi siap operasi.",
        "info",
    ))
    story.append(Spacer(1, 8 * mm))
    story.append(data_table(
        ["Dokumen", "Nilai"],
        [
            ["Target OS", "Ubuntu Server 22.04 LTS atau 24.04 LTS, x86_64"],
            ["Service", "innersync (systemd), user/group: innersync"],
            ["Default lokasi", "/opt/innersync"],
            ["Default port", "127.0.0.1:8081 di belakang Nginx"],
            ["Database", "PostgreSQL lokal atau existing"],
            ["Revisi manual", f"1.0 - {date(2026, 10, 5).strftime('%d/%m/%Y')}"],
        ],
        [45 * mm, 125 * mm],
        header_color=NAVY,
    ))
    story.append(Spacer(1, 9 * mm))
    story.append(callout(
        "Aturan penting",
        "Jangan memasukkan password, API key, private key, atau license key ke tiket, screenshot, chat, maupun dokumen serah terima. Nilai rahasia hanya dimasukkan pada terminal atau halaman konfigurasi resmi.",
        "warning",
    ))
    story.append(PageBreak())

    # TOC
    story.append(para("Daftar Isi", "TocTitle"))
    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle(
            name="TOC1", fontName="Helvetica-Bold", fontSize=9.2, leading=14,
            leftIndent=0, firstLineIndent=0, textColor=NAVY, spaceBefore=4,
        ),
        ParagraphStyle(
            name="TOC2", fontName="Helvetica", fontSize=8.2, leading=12,
            leftIndent=12, firstLineIndent=0, textColor=MUTED,
        ),
    ]
    story.append(toc)
    story.append(PageBreak())

    # 1
    story.append(heading("1", "Hasil Akhir dan Batasan"))
    story.append(para(
        "Setelah seluruh checklist selesai, operator dapat membuka Innersync melalui domain HTTPS, login, melakukan registrasi visitor, mengirim notifikasi, dan menjalankan integrasi. Service otomatis hidup setelah reboot dan database tidak diekspos ke internet."
    ))
    story.append(data_table(
        ["Komponen", "Kondisi lulus"],
        [
            ["Aplikasi", "systemctl melaporkan active (running) dan curl lokal memberi HTTP 200/302."],
            ["Reverse proxy", "Nginx aktif; port aplikasi 8081 tidak dibuka ke internet."],
            ["Domain", "A/AAAA yang relevan mengarah benar dan HTTPS valid tanpa warning browser."],
            ["Database", "Schema siap, login berhasil, backup awal tersedia."],
            ["License", "Status valid untuk Machine ID server produksi."],
            ["Update", "Menu Software Update dapat membaca versi terbaru; ownership aplikasi benar."],
            ["Integrasi lokal", "Jika diperlukan, VPN/gateway menghubungkan VPS ke perangkat gedung."],
        ],
        [43 * mm, 127 * mm],
    ))
    story.append(callout(
        "Batasan",
        "Tidak ada prosedur yang dapat menjamin nol kendala pada semua provider. Manual ini mengurangi risiko dengan checkpoint di setiap tahap. Jangan melanjutkan bila hasil checkpoint berbeda; gunakan bagian Troubleshooting terlebih dahulu.",
        "info",
    ))

    # 2
    story.append(heading("2", "Arsitektur Produksi yang Direkomendasikan"))
    story.append(code_block("""
Internet user
    |
    v
Domain HTTPS :443 -> Nginx -> 127.0.0.1:8081 -> Innersync
                                                   |
                                                   +-> PostgreSQL localhost:5432
                                                   +-> Email / WhatsApp / API cloud
                                                   +-> VPN -> gateway lokal -> InnerRange
"""))
    story.append(data_table(
        ["Resource", "Minimum", "Produksi direkomendasikan"],
        [
            ["CPU", "2 vCPU", "4 vCPU"],
            ["RAM", "8 GB", "16 GB"],
            ["Storage", "80 GB SSD", "100-250 GB SSD/NVMe"],
            ["Network", "IP publik tetap", "IP publik tetap, outbound internet, data center dekat lokasi"],
            ["OS", "Ubuntu 22.04 LTS", "Ubuntu 24.04 LTS x86_64"],
        ],
        [46 * mm, 48 * mm, 76 * mm],
        header_color=CYAN,
    ))
    story.append(callout(
        "Perangkat di jaringan lokal",
        "VPS tidak otomatis dapat menjangkau InnerRange atau perangkat lain di LAN gedung. Gunakan WireGuard atau gateway lokal. Schindler/API lain yang sudah memiliki endpoint HTTPS publik dapat diakses langsung sesuai allowlist dan kebijakan customer.",
        "warning",
    ))

    # 3
    story.append(PageBreak())
    story.append(heading("3", "Worksheet Sebelum Instalasi"))
    story.append(para("Isi dan verifikasi data berikut sebelum membuka terminal. Nilai contoh harus diganti dengan data customer."))
    story.append(data_table(
        ["Item", "Contoh", "Catatan"],
        [
            ["IP publik VPS", "103.147.33.10", "Harus statis atau tidak sering berubah."],
            ["Port SSH publik", "20225", "Dapat dipetakan provider ke port internal 22."],
            ["User admin", "innersyncadmin", "Memiliki sudo; jangan gunakan root untuk operasi harian."],
            ["Domain utama", "innersync.example.id", "A record menuju IP publik VPS."],
            ["Subdomain", "www, portal, visit", "Opsional; tambahkan hanya yang digunakan."],
            ["Paket installer", "innersync-linux-vX.Y.Z.tar.gz", "Gunakan paket resmi yang diserahkan vendor."],
            ["Mode database", "Create / Restore / Existing", "Putuskan sebelum menjalankan installer."],
            ["Nama database", "Innersync_db", "Case-sensitive pada beberapa operasi."],
            ["User database", "innersync_app", "Password kuat dan unik."],
            ["Bind aplikasi", "127.0.0.1", "Wajib untuk deployment Nginx pada satu VPS."],
            ["Port aplikasi", "8081", "Hanya lokal; tidak dibuka di firewall publik."],
            ["Email license", "admin@example.id", "Untuk penerbitan license permanen."],
        ],
        [39 * mm, 54 * mm, 77 * mm],
    ))
    story.append(heading("3.1", "Pilih Mode Database", level=2))
    story.append(data_table(
        ["Mode", "Pilih bila", "Prasyarat"],
        [
            ["1 - Create New", "Instalasi customer baru tanpa data lama.", "Database dengan nama tersebut belum ada di PostgreSQL lokal."],
            ["2 - Restore From Backup", "Migrasi atau disaster recovery dari file .backup.", "File backup sudah di-upload dan checksum sudah diverifikasi."],
            ["3 - Use Existing", "Database sudah dibuat/direstore sebelumnya atau berada di server lain.", "Host dapat dijangkau dan user DB punya hak schema/migration."],
        ],
        [37 * mm, 61 * mm, 72 * mm],
    ))

    # 4
    story.append(heading("4", "Persiapan dan Pengamanan VPS"))
    story.append(heading("4.1", "Login Pertama dari Windows PowerShell", level=2))
    story.append(para("Gunakan perintah SSH yang diberikan provider. Parameter <b>-p</b> adalah port publik provider, bukan selalu port internal Linux."))
    story.append(code_block("""
ssh -p SSH_PUBLIC_PORT root@SERVER_IP
"""))
    story.append(para("Jika muncul fingerprint host, cocokkan dengan panel provider sebelum mengetik <b>yes</b>."))

    story.append(heading("4.2", "Buat User Administrator", level=2))
    story.append(code_block("""
adduser innersyncadmin
usermod -aG sudo innersyncadmin
su - innersyncadmin
sudo whoami
"""))
    story.append(para("Hasil terakhir harus <b>root</b>. Keluar kembali ke root dengan <b>exit</b> bila perlu untuk menyalin SSH key."))

    story.append(heading("4.3", "Gunakan SSH Key", level=2))
    story.append(para("Di PowerShell laptop administrator:"))
    story.append(code_block(r"""
New-Item -ItemType Directory -Force "$env:USERPROFILE\.ssh" | Out-Null
ssh-keygen -t ed25519 -C "innersync-vps" `
  -f "$env:USERPROFILE\.ssh\innersync_vps"

Get-Content "$env:USERPROFILE\.ssh\innersync_vps.pub" | `
  ssh -p SSH_PUBLIC_PORT root@SERVER_IP `
  "umask 077; mkdir -p /home/innersyncadmin/.ssh; `
  cat >> /home/innersyncadmin/.ssh/authorized_keys; `
  chown -R innersyncadmin:innersyncadmin /home/innersyncadmin/.ssh"
"""))
    story.append(para("Uji pada jendela PowerShell kedua. Jangan menutup sesi pertama sebelum tes berhasil:"))
    story.append(code_block(r"""
ssh -i "$env:USERPROFILE\.ssh\innersync_vps" `
  -p SSH_PUBLIC_PORT innersyncadmin@SERVER_IP
"""))
    story.append(callout(
        "Checkpoint SSH",
        "Lanjutkan hanya bila login sebagai innersyncadmin dengan key berhasil dan sudo whoami menghasilkan root.",
        "success",
    ))

    story.append(heading("4.4", "Hardening SSH Setelah Key Teruji", level=2))
    story.append(code_block(r"""
sudo tee /etc/ssh/sshd_config.d/00-innersync-hardening.conf >/dev/null <<'EOF'
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin prohibit-password
EOF

sudo sshd -t
sudo systemctl reload ssh
sudo sshd -T | grep -E \
  'passwordauthentication|kbdinteractiveauthentication|permitrootlogin'
"""))
    story.append(para("Hasil yang diterima: passwordauthentication no, kbdinteractiveauthentication no, dan permitrootlogin without-password/prohibit-password."))
    story.append(callout(
        "Mengapa nama file dimulai 00",
        "OpenSSH memakai nilai pertama yang ditemukan. Provider dapat memiliki file 00-vendor.conf yang mengaktifkan password. Nama 00-innersync-hardening.conf harus terbaca sebelum konfigurasi vendor. Selalu verifikasi dengan sshd -T.",
        "warning",
    ))

    story.append(heading("4.5", "Waktu, Update OS, dan Utilitas", level=2))
    story.append(code_block("""
sudo timedatectl set-timezone Asia/Jakarta
sudo apt update
sudo apt install -y chrony curl ca-certificates unzip dnsutils
sudo systemctl enable --now chrony
timedatectl
chronyc tracking
"""))
    story.append(para("Timezone harus Asia/Jakarta dan sinkronisasi waktu harus aktif. Jangan melakukan upgrade mayor OS saat instalasi produksi."))

    story.append(heading("4.6", "Firewall", level=2))
    story.append(para("Cari port SSH yang benar di sisi Linux. Pada VPS NAT, port publik dapat berbeda dari port yang didengar sshd."))
    story.append(code_block("""
sudo ss -lntp | grep sshd
sudo ufw allow SSH_INTERNAL_PORT/tcp comment 'SSH'
sudo ufw allow 80/tcp comment 'HTTP'
sudo ufw allow 443/tcp comment 'HTTPS'
sudo ufw enable
sudo ufw status verbose
"""))
    story.append(callout(
        "Jangan buka port ini ke internet",
        "Port 5432 PostgreSQL dan 8081 Innersync tetap private. Jika WireGuard dipakai, buka UDP 51820 hanya setelah provider mengizinkan port tersebut.",
        "danger",
    ))

    # 5
    story.append(heading("5", "Upload dan Verifikasi Paket"))
    story.append(heading("5.1", "Upload Installer dari Windows", level=2))
    story.append(code_block(r"""
scp -i "$env:USERPROFILE\.ssh\innersync_vps" `
  -P SSH_PUBLIC_PORT `
  "D:\Path\innersync-linux-vX.Y.Z.tar.gz" `
  innersyncadmin@SERVER_IP:/home/innersyncadmin/
"""))
    story.append(callout(
        "PowerShell",
        "Ketik scp mulai dari awal perintah. Jangan menempel alamat tujuan sebelum kata scp dan jangan menyatukan dua perintah pada satu baris.",
        "info",
    ))
    story.append(heading("5.2", "Upload Backup Database Bila Migrasi", level=2))
    story.append(code_block(r"""
scp -i "$env:USERPROFILE\.ssh\innersync_vps" `
  -P SSH_PUBLIC_PORT `
  "D:\Backup\innersync_full_backup.backup" `
  innersyncadmin@SERVER_IP:/home/innersyncadmin/
"""))
    story.append(heading("5.3", "Verifikasi File di VPS", level=2))
    story.append(code_block("""
ls -lh /home/innersyncadmin/innersync-linux-vX.Y.Z.tar.gz
sha256sum /home/innersyncadmin/innersync-linux-vX.Y.Z.tar.gz

# Jika memakai backup:
ls -lh /home/innersyncadmin/innersync_full_backup.backup
sha256sum /home/innersyncadmin/innersync_full_backup.backup
"""))
    story.append(para("Bandingkan SHA256 dengan nilai dari vendor. Bila berbeda, upload ulang dan jangan mengekstrak file tersebut."))

    # 6
    story.append(heading("6", "Instalasi Innersync"))
    story.append(heading("6.1", "Extract di Home Directory", level=2))
    story.append(code_block("""
cd /home/innersyncadmin
tar -xzf innersync-linux-vX.Y.Z.tar.gz
cd innersync-linux-vX.Y.Z
ls -la
"""))
    story.append(callout(
        "Lokasi extract",
        "Extract installer di /home/innersyncadmin, bukan langsung ke /opt/innersync. Folder /opt/innersync dikelola oleh install.sh agar ownership dan service konsisten.",
        "warning",
    ))

    story.append(heading("6.2", "Jalankan Installer", level=2))
    story.append(code_block("""
sudo bash install.sh
"""))
    story.append(data_table(
        ["Prompt", "Nilai produksi yang direkomendasikan", "Keterangan"],
        [
            ["Install folder", "/opt/innersync", "Tekan Enter kecuali ada desain storage khusus."],
            ["Mode database", "1, 2, atau 3", "Ikuti keputusan pada Worksheet."],
            ["DB host", "localhost", "Gunakan hostname/IP hanya untuk DB remote."],
            ["DB port", "5432", "Jangan dipublikasikan ke internet."],
            ["DB name", "Innersync_db", "Pastikan sesuai backup/existing DB."],
            ["DB user", "innersync_app", "Role aplikasi, bukan user Linux."],
            ["DB password", "Password kuat", "Input tidak tampil di layar."],
            ["Bind IP / Host", "127.0.0.1", "Aman untuk Nginx di server yang sama."],
            ["Web port", "8081", "Port internal aplikasi."],
            ["Path backup", "/home/innersyncadmin/...backup", "Hanya muncul pada mode Restore."],
        ],
        [38 * mm, 55 * mm, 77 * mm],
    ))
    story.append(para("Installer akan memasang dependency, Node.js, PostgreSQL, menyalin aplikasi, menjalankan npm, menginisialisasi schema, membuat user service <b>innersync</b>, dan mengaktifkan systemd."))
    story.append(callout(
        "Bila installer terlihat sedang bekerja",
        "Pesan npm deprecated atau npm audit bukan kegagalan instalasi. Tunggu sampai muncul 'Install selesai'. Hentikan hanya jika ada FAILED, error koneksi database, atau proses kembali ke prompt tanpa service aktif.",
        "info",
    ))

    story.append(heading("6.3", "Validasi Service dan Database", level=2))
    story.append(code_block(r"""
sudo systemctl status innersync --no-pager -l
sudo journalctl -u innersync -n 80 --no-pager
curl -sS -o /dev/null -w 'APP HTTP %{http_code}\n' \
  http://127.0.0.1:8081/

sudo systemctl is-enabled innersync
sudo systemctl is-active innersync
"""))
    story.append(para("HTTP 200 atau 302 diterima. is-enabled dan is-active harus menghasilkan enabled dan active."))

    story.append(heading("6.4", "Validasi Ownership", level=2))
    story.append(code_block(r"""
sudo systemctl show innersync --no-pager \
  -p User -p Group -p WorkingDirectory -p ExecStart

sudo find /opt/innersync -xdev \
  \( ! -user innersync -o ! -group innersync \) -print
"""))
    story.append(para("Service harus memakai User=innersync, Group=innersync, WorkingDirectory=/opt/innersync. Setelah instalasi bersih, perintah find seharusnya tidak menampilkan file aplikasi."))

    # 7
    story.append(PageBreak())
    story.append(heading("7", "Nginx Reverse Proxy"))
    story.append(heading("7.1", "Install Nginx", level=2))
    story.append(code_block("""
sudo apt update
sudo apt install -y nginx
sudo systemctl enable --now nginx
curl -sS -o /dev/null -w 'NGINX HTTP %{http_code}\n' http://127.0.0.1/
"""))

    story.append(heading("7.2", "Buat Virtual Host", level=2))
    story.append(para("Ganti DOMAIN_UTAMA dan subdomain sesuai Worksheet. Hapus nama yang tidak digunakan."))
    story.append(code_block(r"""
sudo tee /etc/nginx/sites-available/innersync >/dev/null <<'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name DOMAIN_UTAMA www.DOMAIN_UTAMA
                portal.DOMAIN_UTAMA visit.DOMAIN_UTAMA;

    client_max_body_size 300m;
    proxy_connect_timeout 30s;
    proxy_send_timeout 300s;
    proxy_read_timeout 300s;

    location / {
        proxy_pass http://127.0.0.1:8081;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

sudo ln -sfn /etc/nginx/sites-available/innersync \
  /etc/nginx/sites-enabled/innersync
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
"""))
    story.append(heading("7.3", "Uji Reverse Proxy Sebelum DNS", level=2))
    story.append(code_block("""
curl -I -H 'Host: DOMAIN_UTAMA' http://127.0.0.1/
"""))
    story.append(para("HTTP 200/302 menunjukkan Nginx berhasil meneruskan request ke Innersync."))

    # 8
    story.append(heading("8", "DNS dan HTTPS"))
    story.append(heading("8.1", "Buat Record DNS", level=2))
    story.append(data_table(
        ["Nama", "Tipe", "Nilai", "TTL"],
        [
            ["@", "A", "SERVER_IP", "300-3600"],
            ["www", "CNAME", "DOMAIN_UTAMA", "300-3600"],
            ["portal", "CNAME", "DOMAIN_UTAMA", "300-3600"],
            ["visit", "CNAME", "DOMAIN_UTAMA", "300-3600"],
        ],
        [35 * mm, 30 * mm, 75 * mm, 30 * mm],
    ))
    story.append(para("Bila provider VPS memakai NAT dan menu Domain & Website, daftarkan domain pada layanan port 80/443 provider. Jangan mem-forward port 8081 secara publik."))
    story.append(code_block("""
dig +short DOMAIN_UTAMA A
dig +short www.DOMAIN_UTAMA
dig +short portal.DOMAIN_UTAMA
dig +short visit.DOMAIN_UTAMA
"""))
    story.append(para("Semua nama yang akan dimasukkan ke sertifikat harus sudah resolve ke IP publik VPS."))

    story.append(heading("8.2", "Pasang Sertifikat Let's Encrypt", level=2))
    story.append(code_block(r"""
sudo apt install -y certbot python3-certbot-nginx

sudo certbot --nginx --redirect \
  -d DOMAIN_UTAMA \
  -d www.DOMAIN_UTAMA \
  -d portal.DOMAIN_UTAMA \
  -d visit.DOMAIN_UTAMA
"""))
    story.append(para("Masukkan email operasional, setujui Terms of Service, lalu pilih preferensi email EFF sesuai kebijakan customer."))
    story.append(heading("8.3", "Validasi HTTPS dan Renewal", level=2))
    story.append(code_block("""
curl -I https://DOMAIN_UTAMA/
sudo certbot certificates
sudo certbot renew --dry-run
sudo systemctl status certbot.timer --no-pager
"""))
    story.append(callout(
        "Checkpoint publik",
        "Browser harus membuka https://DOMAIN_UTAMA tanpa warning sertifikat. HTTP harus redirect ke HTTPS. Uji juga portal dan visit bila digunakan.",
        "success",
    ))

    # 9
    story.append(PageBreak())
    story.append(heading("9", "Aktivasi dan Setup Pertama"))
    story.append(heading("9.1", "License", level=2))
    story.append(step(1, "Buka <b>https://DOMAIN_UTAMA</b>. Jika diarahkan ke License Activation, salin Machine ID."))
    story.append(step(2, "Minta license produksi yang diterbitkan khusus untuk Machine ID server tersebut."))
    story.append(step(3, "Masukkan license key melalui halaman resmi, lalu pilih Activate License."))
    story.append(step(4, "Pastikan status berubah menjadi valid/permanent dan versi aplikasi tampil benar."))
    story.append(callout(
        "Machine ID",
        "License tidak dipindahkan dari PC lama. Migrasi, rebuild VPS, atau perubahan identitas mesin dapat memerlukan penerbitan ulang license.",
        "warning",
    ))

    story.append(heading("9.2", "Buat Administrator Pertama", level=2))
    story.append(para("Setelah license valid, buka <b>/setup-admin.html</b> jika sistem belum memiliki admin. Gunakan username operasional, nama lengkap, dan password minimal 8 karakter yang mengikuti kebijakan customer."))
    story.append(para("Jika database hasil restore sudah memiliki admin, halaman setup akan mengarahkan ke login. Jangan membuat akun tambahan dengan memodifikasi database langsung."))

    story.append(heading("9.3", "Konfigurasi Dasar Aplikasi", level=2))
    story.append(data_table(
        ["Menu", "Nilai utama yang diperiksa"],
        [
            ["Settings - QR Code", "Public/Base URL = https://DOMAIN_UTAMA; aktifkan auto email/WhatsApp sesuai kebutuhan."],
            ["SMTP", "Host, port, TLS, username, password, sender; lakukan satu kirim percobaan."],
            ["WhatsApp", "Mode API, provider, Base URL, API Key; Phone Number ID hanya untuk Meta."],
            ["Visitor Registration", "Expiry, reminder, extension, approval BM/Host, limit pengajuan."],
            ["API Integration", "Credential dan endpoint InnerRange/Schindler; jangan menaruh secret pada screenshot."],
            ["Retention/Cleanup", "Sesuaikan Activity Log, API Log, visitor, foto, dan backup dengan kebijakan customer."],
        ],
        [51 * mm, 119 * mm],
    ))

    story.append(heading("9.4", "VPSMurah CloudChat", level=2))
    story.append(para("Untuk provider VPSMurah CloudChat:"))
    for item in [
        "Mode Kirim WhatsApp: WhatsApp Business API.",
        "Provider API: VPSMurah CloudChat.",
        "Base URL: https://my.vpsmurah.co.id/api/svc/v1.",
        "API Key disimpan pada field API Key. Phone Number ID dan API Version tidak digunakan.",
        "Akun CloudChat harus LIVE/connected dan memiliki kredit yang cukup.",
        "Nomor tujuan menggunakan format internasional 62... tanpa tanda +.",
    ]:
        story.append(bullet(item))
    story.append(para("Buat satu visitor uji, lalu periksa Monitoring Pengiriman. Status Terkirim adalah checkpoint integrasi."))

    # 10
    story.append(heading("10", "Software Update di Linux"))
    story.append(callout(
        "Satu jalur resmi",
        "Untuk instalasi baru gunakan paket Linux terbaru yang sudah memuat updater. Bootstrap hanya untuk instalasi lama dan hanya dijalankan dengan instruksi vendor. Customer tidak perlu bootstrap pada setiap update.",
        "info",
    ))
    story.append(heading("10.1", "Pre-check", level=2))
    story.append(code_block(r"""
sudo systemctl is-active innersync
sudo -u innersync test -w /opt/innersync && echo 'APP WRITABLE'
sudo -u innersync test -w /opt/innersync/routes && echo 'ROUTES WRITABLE'

sudo find /opt/innersync -xdev \
  \( ! -user innersync -o ! -group innersync \) -print
"""))
    story.append(para("Jika find menampilkan file aplikasi, hentikan update dan koreksi ownership sebelum melanjutkan:"))
    story.append(code_block("""
sudo chown -R innersync:innersync /opt/innersync
"""))

    story.append(heading("10.2", "Online Update", level=2))
    for item in [
        "Login sebagai SUPERADMIN dan buka Software Update.",
        "Klik Refresh Status dan pastikan Latest Version terbaca.",
        "Klik Update Now. Jangan menutup browser atau menjalankan update kedua.",
        "Tunggu status 100% dan pesan update berhasil.",
        "Restart service dari terminal agar kode baru aktif penuh.",
    ]:
        story.append(bullet(item))
    story.append(code_block("""
sudo systemctl restart innersync
sudo systemctl status innersync --no-pager -l
sudo journalctl -u innersync -n 80 --no-pager
"""))
    story.append(para("Refresh halaman dan pastikan Installed Version sudah berubah."))

    story.append(heading("10.3", "Offline Update", level=2))
    story.append(para("Pilih Offline Package, upload ZIP resmi, tunggu validasi checksum, pilih Apply Update, lalu restart service. Jangan meng-unzip package update secara manual ke /opt/innersync."))

    story.append(heading("10.4", "Pencegahan EPERM", level=2))
    story.append(callout(
        "Akar masalah umum",
        "File yang diekstrak dengan sudo langsung ke /opt/innersync menjadi milik root. Service berjalan sebagai innersync sehingga updater tidak dapat menimpanya. Selalu gunakan installer/updater resmi dan lakukan ownership pre-check.",
        "danger",
    ))
    story.append(para("Jika update gagal dengan EPERM atau copyfile operation not permitted:"))
    story.append(code_block(r"""
sudo find /opt/innersync -type f -name 'softwareUpdateRoutes.js' \
  -printf '%u:%g %m %p\n'

sudo chown -R innersync:innersync /opt/innersync
sudo -u innersync node --check \
  /opt/innersync/routes/softwareUpdateRoutes.js
sudo systemctl restart innersync
"""))
    story.append(para("Jika file aktif hilang, jangan restart. Pulihkan dari folder terbaru di /opt/innersync/updates/app-backups sesuai arahan vendor, validasi dengan node --check, baru restart."))

    # 11
    story.append(PageBreak())
    story.append(heading("11", "Koneksi Perangkat Lokal dengan WireGuard (Opsional)"))
    story.append(para("Gunakan bagian ini bila Innersync di VPS perlu menjangkau service InnerRange pada PC lokal. Pastikan provider mengizinkan UDP 51820 dan penggunaan VPN pribadi."))
    story.append(heading("11.1", "Server VPS", level=2))
    story.append(code_block(r"""
sudo apt update
sudo apt install -y wireguard
sudo install -d -m 700 /etc/wireguard
sudo sh -c 'umask 077; wg genkey | \
  tee /etc/wireguard/server_private.key | \
  wg pubkey > /etc/wireguard/server_public.key'
sudo cat /etc/wireguard/server_public.key
"""))
    story.append(para("Buat /etc/wireguard/wg0.conf. Jangan membagikan private key:"))
    story.append(code_block("""
[Interface]
Address = 10.77.77.1/24
ListenPort = 51820
PrivateKey = SERVER_PRIVATE_KEY

[Peer]
PublicKey = WINDOWS_PUBLIC_KEY
AllowedIPs = 10.77.77.2/32
"""))
    story.append(code_block("""
sudo chmod 600 /etc/wireguard/wg0.conf
sudo ufw allow 51820/udp comment 'WireGuard Innersync'
sudo systemctl enable --now wg-quick@wg0
sudo systemctl status wg-quick@wg0 --no-pager
sudo wg show
"""))

    story.append(heading("11.2", "Client Windows", level=2))
    story.append(para("Import tunnel berikut pada aplikasi WireGuard Windows:"))
    story.append(code_block("""
[Interface]
PrivateKey = WINDOWS_PRIVATE_KEY
Address = 10.77.77.2/32

[Peer]
PublicKey = SERVER_PUBLIC_KEY
Endpoint = SERVER_IP:51820
AllowedIPs = 10.77.77.1/32
PersistentKeepalive = 25
"""))
    story.append(para("Aktifkan tunnel, lalu verifikasi pada VPS bahwa <b>latest handshake</b> muncul. Baris contoh dari dokumentasi bukan perintah terminal."))
    story.append(code_block("""
sudo wg show
ping -c 4 10.77.77.2
curl -v http://10.77.77.2:7777/
"""))
    story.append(para("Service InnerRange di Windows harus listen pada 0.0.0.0:7777 atau IP WireGuard, dan Windows Firewall harus mengizinkan sumber 10.77.77.1. Gunakan URL http://10.77.77.2:7777 pada konfigurasi Innersync."))

    # 12
    story.append(heading("12", "Backup, Restore, dan Maintenance"))
    story.append(heading("12.1", "Backup Database", level=2))
    story.append(code_block(r"""
sudo install -d -m 750 -o postgres -g postgres \
  /var/backups/innersync

sudo -u postgres pg_dump -Fc Innersync_db \
  -f /var/backups/innersync/innersync_db_$(date +%F_%H%M).backup

sudo ls -lh /var/backups/innersync
"""))
    story.append(para("Salin backup ke storage terpisah. Backup yang hanya berada pada disk VPS yang sama belum memenuhi disaster recovery."))

    story.append(heading("12.2", "Backup File Aplikasi", level=2))
    story.append(code_block(r"""
sudo tar -czf \
  /var/backups/innersync/innersync_files_$(date +%F_%H%M).tar.gz \
  /opt/innersync/config \
  /opt/innersync/uploads \
  /opt/innersync/exports
"""))
    story.append(para("Lindungi backup karena config dapat berisi credential. Jangan memasukkan private license generator key dalam backup customer."))

    story.append(heading("12.3", "Pemeriksaan Mingguan", level=2))
    story.append(code_block("""
df -h /
free -h
sudo systemctl --failed
sudo journalctl -u innersync --since '7 days ago' -p warning --no-pager
sudo nginx -t
sudo certbot certificates
sudo -u postgres psql -d Innersync_db -c 'select now();'
"""))

    # 13
    story.append(heading("13", "Troubleshooting"))
    story.append(data_table(
        ["Gejala", "Diagnosis", "Tindakan"],
        [
            ["SSH connection reset", "Port provider belum terbuka, NAT/firewall, atau sshd reload bermasalah.", "Cek console provider, port mapping, ufw, dan sshd -t. Jangan menutup sesi aktif sebelum tes kedua berhasil."],
            ["Permission denied (publickey)", "Key salah, user salah, atau authorized_keys permission tidak 600/700.", "Uji path key, ownership home/.ssh, dan port SSH publik."],
            ["Service failed", "Database/config/syntax/dependency.", "systemctl status dan journalctl -u innersync -n 100."],
            ["HTTP 502", "Nginx hidup tetapi Innersync tidak listen di 127.0.0.1:8081.", "Cek service, ss -lntp, env HOST/PORT, lalu nginx -t."],
            ["Certbot gagal", "DNS belum resolve atau port 80 tidak dapat diakses.", "Periksa dig, record provider, NAT Domain & Website, UFW 80, dan Nginx."],
            ["Logo/image rusak", "File tidak ada, permission salah, atau case nama file berbeda.", "Cek public/logo.png, request browser, ownership, dan Linux case sensitivity."],
            ["Update EPERM", "File aplikasi dimiliki root.", "Pulihkan file jika hilang, chown ke innersync, node --check, restart, lalu retry."],
            ["NO INTERNET saat update", "Bisa merupakan label umum setelah kegagalan apply, bukan hanya jaringan.", "Baca pesan detail. Jika latest version terbaca, fokus pada error permission/checksum/apply."],
            ["WhatsApp gagal", "API key, account disconnect, kredit, format nomor, atau endpoint.", "Buka View pada Monitoring Pengiriman; perbaiki penyebab lalu Retry satu kali."],
            ["Expiry tidak akurat", "Timezone/NTP salah.", "timedatectl, chronyc tracking, dan pastikan Asia/Jakarta."],
        ],
        [38 * mm, 59 * mm, 73 * mm],
        header_color=AMBER,
    ))

    story.append(heading("13.1", "Perintah Diagnosis Aman", level=2))
    story.append(code_block("""
sudo systemctl status innersync --no-pager -l
sudo journalctl -u innersync -n 120 --no-pager
sudo ss -lntup
curl -I http://127.0.0.1:8081/
curl -I http://127.0.0.1/
sudo nginx -t
sudo ufw status verbose
sudo -u innersync test -r /opt/innersync/server.js && echo OK
"""))
    story.append(callout(
        "Sebelum mengirim log",
        "Hapus password, API key, Authorization header, private key, license key, cookie, dan data pribadi visitor. Kirim hanya bagian error yang relevan beserta timestamp.",
        "danger",
    ))

    # 14
    story.append(heading("14", "Checklist Acceptance dan Serah Terima"))
    checklist_rows = [
        ["[ ]", "OS dan waktu", "Ubuntu LTS x86_64; Asia/Jakarta; NTP sinkron."],
        ["[ ]", "SSH", "User sudo dan SSH key diuji; hardening efektif."],
        ["[ ]", "Firewall", "Hanya SSH, 80, 443, dan VPN yang diperlukan."],
        ["[ ]", "Service", "innersync enabled + active setelah reboot test."],
        ["[ ]", "Ownership", "/opt/innersync dimiliki user/group innersync."],
        ["[ ]", "Database", "Login/transaction berhasil; backup awal dan checksum tersedia."],
        ["[ ]", "HTTPS", "Domain dan subdomain aktif tanpa warning; renewal dry-run sukses."],
        ["[ ]", "License", "License produksi valid pada Machine ID VPS."],
        ["[ ]", "Admin", "Admin customer dapat login; password default tidak ada."],
        ["[ ]", "Email", "Test email berhasil dan tercatat di monitoring."],
        ["[ ]", "WhatsApp", "Test CloudChat/Meta berhasil dan status Terkirim."],
        ["[ ]", "Visitor", "Registrasi, approval, check-in, extension, checkout diuji."],
        ["[ ]", "Integrasi", "InnerRange/Schindler diuji dengan data non-produksi."],
        ["[ ]", "Update", "Versi terbaca, pre-check ownership lulus, prosedur restart dipahami."],
        ["[ ]", "Monitoring", "Disk, service, database, backup, dan certificate memiliki owner."],
        ["[ ]", "Dokumentasi", "IP, domain, kontak support, jadwal backup, dan credential owner diserahkan aman."],
    ]
    story.append(data_table(
        ["Cek", "Area", "Kriteria lulus"],
        checklist_rows,
        [14 * mm, 39 * mm, 117 * mm],
        header_color=GREEN,
    ))
    story.append(heading("14.1", "Reboot Test", level=2))
    story.append(code_block("""
sudo reboot

# Setelah VPS kembali online:
sudo systemctl is-active innersync nginx postgresql
curl -I https://DOMAIN_UTAMA/
"""))
    story.append(callout(
        "Instalasi selesai",
        "Customer dinyatakan siap operasi setelah seluruh checklist bertanda lulus, backup awal telah dipindahkan ke lokasi terpisah, dan PIC customer menerima akses serta prosedur eskalasi.",
        "success",
    ))

    # 15
    story.append(PageBreak())
    story.append(heading("15", "Referensi Operasional Singkat"))
    story.append(data_table(
        ["Kebutuhan", "Perintah"],
        [
            ["Status", "sudo systemctl status innersync --no-pager -l"],
            ["Restart", "sudo systemctl restart innersync"],
            ["Log terbaru", "sudo journalctl -u innersync -n 100 --no-pager"],
            ["Log live", "sudo journalctl -u innersync -f"],
            ["Nginx test", "sudo nginx -t"],
            ["Port", "sudo ss -lntup"],
            ["Disk", "df -h /"],
            ["Memory", "free -h"],
            ["Certificate", "sudo certbot certificates"],
            ["VPN", "sudo wg show"],
            ["App config", "/opt/innersync/config/innersync.env"],
            ["Service file", "/etc/systemd/system/innersync.service"],
            ["Nginx site", "/etc/nginx/sites-available/innersync"],
            ["App backups", "/opt/innersync/updates/app-backups"],
        ],
        [48 * mm, 122 * mm],
    ))
    story.append(heading("15.1", "Uninstall Terkendali", level=2))
    story.append(para("Backup database dan file penting terlebih dahulu. Uninstaller tidak otomatis menghapus database."))
    story.append(code_block("""
cd /home/innersyncadmin/innersync-linux-vX.Y.Z
sudo bash uninstall.sh
"""))
    story.append(callout(
        "Dokumen hidup",
        "Perbarui manual saat installer, nama service, struktur package, provider update, atau alur database berubah. Jangan mengandalkan langkah hotfix lama untuk instalasi customer baru.",
        "info",
    ))

    return story


def build():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc = ManualDocTemplate(str(OUTPUT))
    doc.multiBuild(build_story())
    print(OUTPUT)


if __name__ == "__main__":
    build()
