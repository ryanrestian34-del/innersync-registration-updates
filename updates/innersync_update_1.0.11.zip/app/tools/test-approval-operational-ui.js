const os = require("node:os");
const path = require("node:path");
const playwrightModule = process.env.PLAYWRIGHT_MODULE || "playwright";
const { chromium } = require(playwrightModule);

(async () => {
    const browser = await chromium.launch({ channel: "msedge", headless: true });
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    const pageErrors = [];
    page.on("pageerror", error => pageErrors.push(error.message));

    await page.goto("http://localhost:8081/login.html", { waitUntil: "domcontentloaded" });
    await page.fill("#username", "admin");
    await page.fill("#password", "admin123");
    const loginResponsePromise = page.waitForResponse(response => response.url().endsWith("/login") && response.request().method() === "POST");
    await page.click("#loginButton");
    const loginResponse = await loginResponsePromise;
    const loginResult = await loginResponse.json();
    if (!loginResult.success) {
        throw new Error(`Login test gagal: ${loginResult.message || JSON.stringify(loginResult)}`);
    }
    await page.goto("http://localhost:8081/dashboard.html", { waitUntil: "domcontentloaded" });

    await page.goto("http://localhost:8081/settings.html", { waitUntil: "domcontentloaded" });
    if (await page.locator("#sr_approval_timezone").count()) {
        throw new Error("Jam operasional masih tampil di halaman Pengaturan.");
    }

    await page.goto("http://localhost:8081/index.html", { waitUntil: "domcontentloaded" });
    await page.waitForSelector("#visitorSettingsButton", { state: "visible" });
    await page.click("#visitorSettingsButton");
    if (!await page.locator("#autoCheckoutSettingsTitle").isVisible() || !await page.locator("#approvalOperationalSettingsTitle").isVisible()) {
        throw new Error("Pilihan setting Visitor Registration tidak tampil.");
    }
    if (await page.locator("#autoCheckoutSettingsContent").isVisible() || await page.locator("#approvalOperationalSettingsContent").isVisible()) {
        throw new Error("Isi setting seharusnya tertutup saat popup pertama dibuka.");
    }
    await page.click("#autoCheckoutSettingsTitle");
    if (!await page.locator("#autoCheckoutSettingsContent").isVisible()) {
        throw new Error("Setting Auto Check-Out tidak terbuka setelah judul diklik.");
    }
    await page.click("#autoCheckoutSettingsTitle");
    await page.click("#approvalOperationalSettingsTitle");
    await page.waitForSelector("#visitor_approval_timezone", { state: "visible" });
    const settings = await page.evaluate(() => ({
        timeZone: document.getElementById("visitor_approval_timezone")?.value,
        bmStart: document.getElementById("visitor_bm_operational_start")?.value,
        bmEnd: document.getElementById("visitor_bm_operational_end")?.value,
        hostStart: document.getElementById("visitor_host_operational_start")?.value,
        hostEnd: document.getElementById("visitor_host_operational_end")?.value,
        bmDays: [...document.querySelectorAll("#visitor_bm_operational_days input:checked")].map(input => input.value),
        hostDays: [...document.querySelectorAll("#visitor_host_operational_days input:checked")].map(input => input.value),
        nationalHolidayToggle: document.getElementById("visitor_national_holidays_closed")?.checked,
        collectiveLeaveToggle: document.getElementById("visitor_collective_leave_closed")?.checked
    }));
    if (!settings.timeZone || !settings.bmStart || !settings.bmEnd || !settings.hostStart || !settings.hostEnd || !settings.bmDays.length || !settings.hostDays.length) {
        throw new Error(`Pengaturan jam approval tidak lengkap: ${JSON.stringify(settings)}`);
    }
    if (typeof settings.nationalHolidayToggle !== "boolean" || typeof settings.collectiveLeaveToggle !== "boolean") {
        throw new Error(`Toggle kalender libur tidak terbaca: ${JSON.stringify(settings)}`);
    }
    await page.click(".holiday-manager-toggle");
    await page.waitForSelector("#holidayManager:not([hidden])");
    const holidayRoundtrip = await page.evaluate(async () => {
        const createResponse = await fetch("/api/self-registration-holidays", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                holiday_date: "2099-12-31",
                holiday_type: "CUSTOM_CLOSED",
                holiday_name: "Test UI Kalender"
            })
        });
        const createResult = await createResponse.json();
        if (!createResponse.ok || !createResult.success) return { ok: false, step: "create", result: createResult };

        const listResponse = await fetch("/api/self-registration-holidays");
        const listResult = await listResponse.json();
        const saved = (listResult.data || []).find(item => item.holiday_date === "2099-12-31");
        if (!listResponse.ok || !listResult.success || !saved) return { ok: false, step: "list", result: listResult };

        const deleteResponse = await fetch(`/api/self-registration-holidays/${saved.holiday_id}`, { method: "DELETE" });
        const deleteResult = await deleteResponse.json();
        if (!deleteResponse.ok || !deleteResult.success) return { ok: false, step: "delete", result: deleteResult };
        return { ok: true };
    });
    if (!holidayRoundtrip.ok) {
        throw new Error(`Kalender libur API gagal pada step ${holidayRoundtrip.step}: ${JSON.stringify(holidayRoundtrip.result)}`);
    }
    await page.evaluate(() => loadHolidayCalendar());
    const screenshotPath = path.join(os.tmpdir(), "innersync-visitor-settings-operational.png");
    await page.screenshot({ path: screenshotPath, fullPage: true });

    await page.goto("http://localhost:8081/host.html", { waitUntil: "domcontentloaded" });
    if (await page.locator(".toolbar-left h2:has-text('Host List')").count()) {
        throw new Error("Tulisan Host List masih tampil di toolbar halaman Host.");
    }
    if (await page.locator("text=Setup Host Notification").isVisible().catch(() => false)) {
        throw new Error("Setup Host Notification masih tampil langsung di halaman Host.");
    }
    await page.click("button[title='Pengaturan Host']");
    if (!await page.locator("#hostSettingsModal >> text=Setup Host Notification").isVisible()) {
        throw new Error("Setup Host Notification tidak tampil di popup pengaturan Host.");
    }
    await page.click("#hostSettingsModal .close-btn");
    await page.click("button:has-text('Add Host')");
    if (!await page.locator("#approval_schedule_override").isVisible()) {
        throw new Error("Override jam operasional Host tidak ditemukan di popup Add Host.");
    }
    await page.check("#approval_schedule_override");
    if (!await page.locator("#approvalScheduleFields").isVisible()) {
        throw new Error("Field jam khusus Host tidak tampil saat override diaktifkan.");
    }
    if (!await page.locator("#approval_national_holidays_closed").isVisible() || !await page.locator("#approval_collective_leave_closed").isVisible()) {
        throw new Error("Setting tanggal merah/cuti bersama Host belum tampil.");
    }
    await page.click("#hostFormModal .close-btn");
    const hostHeaders = await page.locator("#hostDataTable thead th[data-column-key]").evaluateAll(headers => headers.map(header => header.textContent.trim()));
    if (!hostHeaders.includes("No") || !hostHeaders.includes("Action")) {
        throw new Error(`Header tabel Host belum lengkap: ${hostHeaders.join(", ")}`);
    }
    const hostResizerCount = await page.locator(".host-column-resizer").count();
    if (hostResizerCount < hostHeaders.length - 1) {
        throw new Error(`Resizer kolom Host belum lengkap: ${hostResizerCount}/${hostHeaders.length - 1}`);
    }
    const firstHostResizer = page.locator(".host-column-resizer").first();
    const box = await firstHostResizer.boundingBox();
    if (!box) throw new Error("Resizer kolom Host tidak bisa dibaca.");
    await firstHostResizer.dispatchEvent("mousedown", {
        bubbles: true,
        cancelable: true,
        clientX: box.x + box.width / 2,
        clientY: box.y + box.height / 2
    });
    await page.dispatchEvent("body", "mousemove", {
        bubbles: true,
        cancelable: true,
        clientX: box.x + box.width / 2 + 24,
        clientY: box.y + box.height / 2
    });
    await page.dispatchEvent("body", "mouseup", {
        bubbles: true,
        cancelable: true,
        clientX: box.x + box.width / 2 + 24,
        clientY: box.y + box.height / 2
    });
    const storedHostColumns = await page.evaluate(() => JSON.parse(localStorage.getItem("innersync.host.columnWidths.v1") || "{}"));
    if (!storedHostColumns.version || !storedHostColumns.ratios?.number) {
        throw new Error(`Lebar kolom Host belum tersimpan: ${JSON.stringify(storedHostColumns)}`);
    }

    await page.goto("http://localhost:8081/self-registration.html", { waitUntil: "domcontentloaded" });
    const countdownText = await page.evaluate(() => {
        const element = document.createElement("div");
        document.body.appendChild(element);
        const now = Date.now();
        const stop = ApprovalCountdown.mount(
            element,
            new Date(now + 7_200_000).toISOString(),
            () => {},
            { startAt: new Date(now + 3_600_000).toISOString(), timeZone: "Asia/Jakarta" }
        );
        const text = element.textContent;
        stop();
        element.remove();
        return text;
    });
    if (!countdownText.startsWith("Countdown mulai")) {
        throw new Error(`Countdown terjadwal tidak tampil benar: ${countdownText}`);
    }
    const pausedCountdownText = await page.evaluate(() => {
        const element = document.createElement("div");
        document.body.appendChild(element);
        const currentDate = Date;
        const fixedNow = new currentDate("2026-09-11T10:30:00.000Z"); // Jumat 17:30 WIB
        class MockDate extends currentDate {
            constructor(...args) {
                super(...(args.length ? args : [fixedNow.getTime()]));
            }
            static now() { return fixedNow.getTime(); }
        }
        MockDate.UTC = currentDate.UTC;
        MockDate.parse = currentDate.parse;
        window.Date = MockDate;
        const stop = ApprovalCountdown.mount(
            element,
            "2026-09-14T01:30:00.000Z",
            () => {},
            {
                startAt: "2026-09-11T09:30:00.000Z",
                timeZone: "Asia/Jakarta",
                operationalStart: "08:00",
                operationalEnd: "17:00",
                operationalDays: [1, 2, 3, 4, 5],
                timeoutMinutes: 60
            }
        );
        const text = element.textContent;
        stop();
        window.Date = currentDate;
        element.remove();
        return text;
    });
    if (!pausedCountdownText.includes("Countdown dijeda")) {
        throw new Error(`Countdown jeda tidak tampil benar: ${pausedCountdownText}`);
    }

    if (pageErrors.length) throw new Error(`Browser errors: ${pageErrors.join(" | ")}`);
    console.log(`Approval operational UI passed. ${countdownText} | ${pausedCountdownText}`);
    console.log(`Screenshot: ${screenshotPath}`);
    await browser.close();
})().catch(error => {
    console.error(error);
    process.exitCode = 1;
});
