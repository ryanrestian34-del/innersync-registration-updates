const fs = require("fs");
const path = require("path");
const readline = require("readline");
const {
    createSignedLicense,
    verifyLicenseToken
} = require("../license/licenseManager");

const ROOT_DIR = path.join(__dirname, "..");
const PRIVATE_KEY_PATH = path.join(ROOT_DIR, "license", "private_key.pem");
const OUTPUT_DIR = path.join(ROOT_DIR, "license", "generated");
const DEFAULT_FEATURES = "visitor_registration,visitor_logs,invitation,host,permission_group,api,middleware,reports,maintenance,settings,account_management,database_capacity,notifications,monitoring_account,software_activity_log";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function ask(question, fallback = "") {
    const suffix = fallback ? ` [${fallback}]` : "";
    return new Promise(resolve => {
        rl.question(`${question}${suffix}: `, answer => {
            resolve(String(answer || fallback).trim());
        });
    });
}

function cleanMachineId(value) {
    return String(value || "").replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
}

function slug(value) {
    return String(value || "customer")
        .trim()
        .replace(/[^a-zA-Z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "")
        .slice(0, 60) || "customer";
}

function todayKey() {
    const date = new Date();
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    const hh = String(date.getHours()).padStart(2, "0");
    const mi = String(date.getMinutes()).padStart(2, "0");
    return `${yyyy}${mm}${dd}_${hh}${mi}`;
}

function printLine() {
    console.log("=".repeat(72));
}

async function main() {
    printLine();
    console.log("INNERSYNC LICENSE GENERATOR");
    console.log("Tool ini hanya untuk owner/admin. Jangan berikan private_key.pem ke customer.");
    printLine();

    if (!fs.existsSync(PRIVATE_KEY_PATH)) {
        throw new Error(`Private key tidak ditemukan: ${PRIVATE_KEY_PATH}`);
    }

    const customer = await ask("Nama customer / company");
    const machineId = cleanMachineId(await ask("Machine ID customer"));
    const expires = await ask("Expired date YYYY-MM-DD atau PERMANENT", "2027-07-20");
    const edition = (await ask("Edition", "ENTERPRISE")).toUpperCase();
    const maxUsers = Number(await ask("Max users", "100"));
    const featuresText = await ask("Features", DEFAULT_FEATURES);

    if (!customer) throw new Error("Nama customer wajib diisi.");
    if (!machineId) throw new Error("Machine ID wajib diisi.");
    const permanent = String(expires || "").trim().toUpperCase() === "PERMANENT";
    if (!permanent && !/^\d{4}-\d{2}-\d{2}$/.test(expires)) throw new Error("Format expired harus YYYY-MM-DD atau PERMANENT.");
    if (!Number.isFinite(maxUsers) || maxUsers <= 0) throw new Error("Max users harus angka lebih dari 0.");

    const features = featuresText
        .split(",")
        .map(item => item.trim())
        .filter(Boolean);

    const expiresAt = permanent ? null : new Date(`${expires}T23:59:59+07:00`).toISOString();
    const privateKey = fs.readFileSync(PRIVATE_KEY_PATH, "utf8");
    const licenseKey = createSignedLicense({
        customer,
        machine_id: machineId,
        edition,
        max_users: maxUsers,
        features,
        expires_at: expiresAt
    }, privateKey);

    const verification = verifyLicenseToken(licenseKey, { machine_id: machineId });
    if (!verification.valid) {
        throw new Error(`License gagal diverifikasi: ${verification.message}`);
    }

    fs.mkdirSync(OUTPUT_DIR, { recursive: true });

    const baseName = `${slug(customer)}_${todayKey()}`;
    const txtPath = path.join(OUTPUT_DIR, `${baseName}.txt`);
    const jsonPath = path.join(OUTPUT_DIR, `${baseName}.json`);

    fs.writeFileSync(txtPath, licenseKey, "utf8");
    fs.writeFileSync(jsonPath, JSON.stringify({
        customer,
        machine_id: machineId,
        edition,
        max_users: maxUsers,
        features,
        expires_at: expiresAt,
        license_file: txtPath,
        created_at: new Date().toISOString()
    }, null, 2), "utf8");

    printLine();
    console.log("LICENSE BERHASIL DIBUAT");
    console.log(`Customer : ${customer}`);
    console.log(`Edition  : ${edition}`);
    console.log(`Expired  : ${permanent ? "PERMANENT" : expires}`);
    console.log(`Output   : ${txtPath}`);
    printLine();
    console.log(licenseKey);
    printLine();
    console.log("Kirim isi license key di atas atau file .txt ke customer.");
}

main()
    .catch(error => {
        printLine();
        console.error("ERROR:", error.message);
    })
    .finally(() => {
        rl.close();
        if (process.stdin.isTTY) {
            console.log("");
            console.log("Tekan Enter untuk keluar...");
            process.stdin.resume();
            process.stdin.once("data", () => process.exit(0));
        }
    });
