const express = require("express");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const multer = require("multer");
const { spawn } = require("child_process");
const { Readable } = require("stream");
const { pipeline } = require("stream/promises");

const pool = require("../database/db");
const { checkSession } = require("../middleware/authMiddleware");
const { runFullBackup } = require("./maintenanceRoutes");

const router = express.Router();

const APP_ROOT = process.cwd();
const UPDATE_ROOT = path.join(APP_ROOT, "updates");
const UPLOAD_DIR = path.join(UPDATE_ROOT, "uploads");
const STAGING_DIR = path.join(UPDATE_ROOT, "staging");
const APP_BACKUP_DIR = path.join(UPDATE_ROOT, "app-backups");
const CURRENT_VERSION_FILE = path.join(APP_ROOT, "config", "current_version.json");
const MAX_UPDATE_PACKAGE_BYTES = 250 * 1024 * 1024;
const DEFAULT_GITHUB_MANIFEST_URL = "https://raw.githubusercontent.com/ryanrestian34-del/innersync-registration-updates/main/latest.json";

const upload = multer({
    dest: UPLOAD_DIR,
    limits: { fileSize: 250 * 1024 * 1024 }
});

let schemaReady = false;

function ensureDirectory(folder) {
    fs.mkdirSync(folder, { recursive: true });
}

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function isSuperAdmin(req) {
    return String(req.session?.role_name || "").toUpperCase() === "SUPERADMIN";
}

function requireSuperAdmin(req, res, next) {
    if (!isSuperAdmin(req)) {
        return res.status(403).json({
            success: false,
            message: "Hanya SUPERADMIN yang bisa melakukan software update"
        });
    }
    next();
}

function timestampForFile(date = new Date()) {
    const pad = value => String(value).padStart(2, "0");
    return [
        date.getFullYear(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
    ].join("") + "_" + [
        pad(date.getHours()),
        pad(date.getMinutes()),
        pad(date.getSeconds())
    ].join("");
}

function readJsonSafe(filePath, fallback = null) {
    try {
        return JSON.parse(fs.readFileSync(filePath, "utf8"));
    } catch {
        return fallback;
    }
}

function normalizeUrl(value) {
    const text = String(value || "").trim();
    if (!text) return "";
    const parsed = new URL(text);
    if (!["http:", "https:"].includes(parsed.protocol)) {
        throw new Error("URL update harus http atau https.");
    }
    return parsed.toString();
}

function getInstalledVersionInfo() {
    const currentVersion = readJsonSafe(CURRENT_VERSION_FILE);
    const packageJson = readJsonSafe(path.join(APP_ROOT, "package.json"), {});
    return {
        version: currentVersion?.version || packageJson.version || "0.0.0",
        installed_at: currentVersion?.installed_at || null,
        source: currentVersion ? "current_version" : "package"
    };
}

function compareVersions(a, b) {
    const left = String(a || "0").split(/[.-]/).map(part => Number.parseInt(part, 10) || 0);
    const right = String(b || "0").split(/[.-]/).map(part => Number.parseInt(part, 10) || 0);
    const length = Math.max(left.length, right.length);
    for (let index = 0; index < length; index += 1) {
        const diff = (left[index] || 0) - (right[index] || 0);
        if (diff !== 0) return diff > 0 ? 1 : -1;
    }
    return 0;
}

function normalizeOnlineManifest(raw, manifestUrl) {
    if (!raw || typeof raw !== "object") {
        throw new Error("latest.json tidak valid.");
    }

    const latestVersion = String(raw.latest_version || raw.version || "").trim();
    const packageUrlValue = String(raw.package_url || raw.url || "").trim();
    if (!latestVersion) throw new Error("latest.json wajib memiliki latest_version atau version.");
    if (!packageUrlValue) throw new Error("latest.json wajib memiliki package_url.");

    const packageUrl = new URL(packageUrlValue, manifestUrl).toString();
    const sha256 = String(raw.sha256 || raw.package_sha256 || "").trim().toLowerCase();

    return {
        product: raw.product || "Innersync Registration Portal",
        latest_version: latestVersion,
        release_date: raw.release_date || null,
        mandatory: raw.mandatory === true,
        changelog: Array.isArray(raw.changelog) ? raw.changelog : [],
        package_url: packageUrl,
        sha256
    };
}

function classifyInternetStatus(error) {
    const message = String(error?.message || error || "");
    if (
        message.includes("Gagal membaca latest.json (") ||
        message.includes("Gagal download package (") ||
        message.includes("Checksum package")
    ) {
        return "OK";
    }
    return "NO_INTERNET";
}

async function fetchOnlineManifest(manifestUrl) {
    const url = normalizeUrl(manifestUrl);
    const response = await fetch(url, {
        headers: {
            "User-Agent": "InnersyncRegistrationPortal-Updater"
        }
    });

    if (!response.ok) {
        throw new Error(`Gagal membaca latest.json (${response.status} ${response.statusText})`);
    }

    const raw = await response.json();
    return normalizeOnlineManifest(raw, url);
}

async function downloadUrlToFile(url, targetPath) {
    const response = await fetch(normalizeUrl(url), {
        headers: {
            "User-Agent": "InnersyncRegistrationPortal-Updater"
        }
    });

    if (!response.ok) {
        throw new Error(`Gagal download package (${response.status} ${response.statusText})`);
    }

    const contentLength = Number(response.headers.get("content-length") || 0);
    if (contentLength > MAX_UPDATE_PACKAGE_BYTES) {
        throw new Error("Package update terlalu besar.");
    }

    ensureDirectory(path.dirname(targetPath));
    await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(targetPath));

    const stat = fs.statSync(targetPath);
    if (stat.size > MAX_UPDATE_PACKAGE_BYTES) {
        fs.unlinkSync(targetPath);
        throw new Error("Package update terlalu besar.");
    }

    return stat.size;
}

function normalizePackagePath(value) {
    const normalized = String(value || "").replace(/\\/g, "/").trim();
    if (!normalized || normalized.startsWith("/") || /^[a-zA-Z]:/.test(normalized)) {
        throw new Error(`Path update tidak valid: ${value}`);
    }

    const resolved = path.resolve(APP_ROOT, normalized);
    if (!resolved.startsWith(APP_ROOT + path.sep)) {
        throw new Error(`Path update keluar folder aplikasi: ${value}`);
    }

    const lower = normalized.toLowerCase();
    const protectedPrefixes = [
        ".git/",
        "backups/",
        "config/",
        "exports/",
        "node_modules/",
        "uploads/",
        "updates/",
        "service/",
        "license/generated/",
        "service/logs/"
    ];
    const protectedFiles = [
        "license/private_key.pem",
        "server.err.log",
        "server.out.log"
    ];

    if (protectedPrefixes.some(prefix => lower.startsWith(prefix)) || protectedFiles.includes(lower)) {
        throw new Error(`Path update dilindungi dan tidak boleh ditimpa: ${normalized}`);
    }

    return normalized;
}

function hashFile(filePath) {
    const hash = crypto.createHash("sha256");
    hash.update(fs.readFileSync(filePath));
    return hash.digest("hex");
}

function listFilesRecursive(folder) {
    const output = [];
    if (!fs.existsSync(folder)) return output;

    for (const entry of fs.readdirSync(folder, { withFileTypes: true })) {
        const fullPath = path.join(folder, entry.name);
        if (entry.isDirectory()) {
            output.push(...listFilesRecursive(fullPath));
        } else if (entry.isFile()) {
            output.push(fullPath);
        }
    }

    return output;
}

function runProcess(command, args, options = {}) {
    return new Promise((resolve, reject) => {
        const child = spawn(command, args, {
            windowsHide: true,
            ...options
        });

        let stdout = "";
        let stderr = "";
        child.stdout?.on("data", data => { stdout += data.toString(); });
        child.stderr?.on("data", data => { stderr += data.toString(); });
        child.on("error", reject);
        child.on("close", code => {
            if (code === 0) return resolve({ stdout, stderr });
            reject(new Error(stderr || stdout || `${command} exited with code ${code}`));
        });
    });
}

async function ensureSoftwareUpdateSchema() {
    if (schemaReady) return;

    ensureDirectory(UPLOAD_DIR);
    ensureDirectory(STAGING_DIR);
    ensureDirectory(APP_BACKUP_DIR);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS software_update_jobs (
            job_id SERIAL PRIMARY KEY,
            action VARCHAR(30) NOT NULL,
            status VARCHAR(20) NOT NULL,
            version_from VARCHAR(50),
            version_to VARCHAR(50),
            message TEXT,
            package_file TEXT,
            staging_folder TEXT,
            app_backup_folder TEXT,
            db_backup_file TEXT,
            manifest JSONB,
            created_by VARCHAR(120),
            started_at TIMESTAMP DEFAULT NOW(),
            finished_at TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS software_schema_migrations (
            migration_name VARCHAR(180) PRIMARY KEY,
            checksum VARCHAR(64) NOT NULL,
            version VARCHAR(50),
            update_job_id INTEGER REFERENCES software_update_jobs(job_id) ON DELETE SET NULL,
            applied_by VARCHAR(120),
            applied_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS software_update_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            update_manifest_url TEXT,
            auto_check_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            last_check_at TIMESTAMP,
            last_check_status VARCHAR(20),
            last_internet_status VARCHAR(30),
            last_check_message TEXT,
            last_latest_version VARCHAR(50),
            last_package_url TEXT,
            updated_by VARCHAR(120),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        INSERT INTO software_update_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);
    await pool.query("ALTER TABLE software_update_settings ADD COLUMN IF NOT EXISTS last_internet_status VARCHAR(30)");

    schemaReady = true;
}

async function getUpdateSettings() {
    await ensureSoftwareUpdateSchema();
    const result = await pool.query("SELECT * FROM software_update_settings WHERE setting_id = 1");
    const settings = result.rows[0] || {};
    return {
        ...settings,
        update_manifest_url: settings.update_manifest_url || DEFAULT_GITHUB_MANIFEST_URL
    };
}

async function updateLastOnlineCheck(status, message, manifest = null, internetStatus = null) {
    await pool.query(
        `UPDATE software_update_settings
         SET last_check_at = NOW(),
             last_check_status = $1,
             last_internet_status = $2,
             last_check_message = $3,
             last_latest_version = $4,
             last_package_url = $5,
             updated_at = NOW()
         WHERE setting_id = 1`,
        [
            status,
            internetStatus || (status === "SUCCESS" ? "OK" : "NO_INTERNET"),
            message,
            manifest?.latest_version || null,
            manifest?.package_url || null
        ]
    );
}

async function createUpdateJob(action, createdBy, extra = {}) {
    const result = await pool.query(
        `INSERT INTO software_update_jobs
            (action, status, version_from, version_to, message, package_file, staging_folder, manifest, created_by, started_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
         RETURNING *`,
        [
            action,
            extra.status || "RUNNING",
            extra.version_from || null,
            extra.version_to || null,
            extra.message || null,
            extra.package_file || null,
            extra.staging_folder || null,
            extra.manifest || null,
            createdBy
        ]
    );
    return result.rows[0];
}

async function finishUpdateJob(jobId, detail = {}) {
    const result = await pool.query(
        `UPDATE software_update_jobs
         SET status = $1,
             message = $2,
             app_backup_folder = COALESCE($3, app_backup_folder),
             db_backup_file = COALESCE($4, db_backup_file),
             manifest = COALESCE($5, manifest),
             finished_at = NOW()
         WHERE job_id = $6
         RETURNING *`,
        [
            detail.status || "SUCCESS",
            detail.message || null,
            detail.app_backup_folder || null,
            detail.db_backup_file || null,
            detail.manifest || null,
            jobId
        ]
    );
    return result.rows[0];
}

async function markUpdateJobFailed(jobId, error) {
    if (!jobId) return;
    await finishUpdateJob(jobId, {
        status: "FAILED",
        message: error.message || String(error)
    }).catch(() => {});
}

async function extractZip(zipPath, destination) {
    ensureDirectory(destination);
    await runProcess("powershell.exe", [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        "Expand-Archive -LiteralPath $env:INNER_UPDATE_ZIP -DestinationPath $env:INNER_UPDATE_DEST -Force"
    ], {
        env: {
            ...process.env,
            INNER_UPDATE_ZIP: zipPath,
            INNER_UPDATE_DEST: destination
        }
    });
}

function normalizeManifest(stagingFolder) {
    const manifestPath = path.join(stagingFolder, "manifest.json");
    if (!fs.existsSync(manifestPath)) {
        throw new Error("manifest.json tidak ditemukan di paket update.");
    }

    const manifest = readJsonSafe(manifestPath);
    if (!manifest || typeof manifest !== "object") {
        throw new Error("manifest.json tidak valid.");
    }

    if (!manifest.version) {
        throw new Error("manifest.json wajib memiliki field version.");
    }

    const appFolder = path.join(stagingFolder, "app");
    if (!fs.existsSync(appFolder)) {
        throw new Error("Folder app/ tidak ditemukan di paket update.");
    }

    const files = Array.isArray(manifest.files) && manifest.files.length
        ? manifest.files.map(file => ({
            path: normalizePackagePath(file.path),
            sha256: file.sha256 ? String(file.sha256).toLowerCase() : null
        }))
        : listFilesRecursive(appFolder).map(filePath => {
            const relPath = path.relative(appFolder, filePath).replace(/\\/g, "/");
            return {
                path: normalizePackagePath(relPath),
                sha256: hashFile(filePath)
            };
        });

    if (!files.length) {
        throw new Error("Tidak ada file update di folder app/.");
    }

    for (const file of files) {
        const sourcePath = path.join(appFolder, file.path);
        if (!fs.existsSync(sourcePath)) {
            throw new Error(`File update tidak ditemukan: app/${file.path}`);
        }
        if (file.sha256 && hashFile(sourcePath) !== file.sha256) {
            throw new Error(`Checksum SHA256 tidak cocok: ${file.path}`);
        }
    }

    const migrations = listMigrationFiles(stagingFolder);

    return {
        ...manifest,
        files,
        migrations,
        file_count: files.length,
        migration_count: migrations.length
    };
}

function listMigrationFiles(stagingFolder) {
    const migrationFolder = path.join(stagingFolder, "migrations");
    if (!fs.existsSync(migrationFolder)) return [];

    return listFilesRecursive(migrationFolder)
        .filter(filePath => filePath.toLowerCase().endsWith(".sql"))
        .map(filePath => {
            const relPath = path.relative(migrationFolder, filePath).replace(/\\/g, "/");
            if (relPath.startsWith("../") || relPath.includes("/../")) {
                throw new Error(`Path migration tidak valid: ${relPath}`);
            }
            return {
                name: relPath,
                sha256: hashFile(filePath)
            };
        })
        .sort((a, b) => a.name.localeCompare(b.name));
}

async function runMigrations(stagingFolder, manifest, jobId, appliedBy) {
    const migrations = manifest.migrations || [];
    if (!migrations.length) {
        return { applied: 0, skipped: 0 };
    }

    const migrationFolder = path.join(stagingFolder, "migrations");
    let applied = 0;
    let skipped = 0;

    for (const migration of migrations) {
        const existing = await pool.query(
            "SELECT checksum FROM software_schema_migrations WHERE migration_name = $1",
            [migration.name]
        );

        if (existing.rows.length) {
            if (existing.rows[0].checksum !== migration.sha256) {
                throw new Error(`Migration ${migration.name} sudah pernah jalan dengan checksum berbeda.`);
            }
            skipped += 1;
            continue;
        }

        const sqlPath = path.join(migrationFolder, migration.name);
        const sql = fs.readFileSync(sqlPath, "utf8").trim();
        if (!sql) {
            skipped += 1;
            continue;
        }

        await pool.query("BEGIN");
        try {
            await pool.query(sql);
            await pool.query(
                `INSERT INTO software_schema_migrations
                    (migration_name, checksum, version, update_job_id, applied_by, applied_at)
                 VALUES ($1, $2, $3, $4, $5, NOW())`,
                [migration.name, migration.sha256, manifest.version, jobId, appliedBy]
            );
            await pool.query("COMMIT");
            applied += 1;
        } catch (error) {
            await pool.query("ROLLBACK").catch(() => {});
            throw new Error(`Migration gagal (${migration.name}): ${error.message}`);
        }
    }

    return { applied, skipped };
}

function backupExistingFiles(files) {
    const backupFolder = path.join(APP_BACKUP_DIR, `innersync_app_backup_${timestampForFile()}`);
    ensureDirectory(backupFolder);

    const missingFiles = [];
    for (const file of files) {
        const sourcePath = path.join(APP_ROOT, file.path);
        if (!fs.existsSync(sourcePath)) {
            missingFiles.push(file.path);
            continue;
        }

        const targetPath = path.join(backupFolder, file.path);
        ensureDirectory(path.dirname(targetPath));
        fs.copyFileSync(sourcePath, targetPath);
    }

    fs.writeFileSync(
        path.join(backupFolder, "missing_files.json"),
        JSON.stringify(missingFiles, null, 2),
        "utf8"
    );

    return backupFolder;
}

function copyUpdateFiles(stagingFolder, files) {
    const appFolder = path.join(stagingFolder, "app");
    for (const file of files) {
        const sourcePath = path.join(appFolder, file.path);
        const targetPath = path.join(APP_ROOT, file.path);
        ensureDirectory(path.dirname(targetPath));
        fs.copyFileSync(sourcePath, targetPath);
    }
}

function ensurePathInsideAppRoot(targetPath, label) {
    const resolved = path.resolve(targetPath);
    if (resolved !== APP_ROOT && !resolved.startsWith(APP_ROOT + path.sep)) {
        throw new Error(`${label} tidak valid atau berada di luar folder aplikasi.`);
    }
    return resolved;
}

function backupCurrentFilesForRollback(relativeFiles, sourceJobId) {
    const backupFolder = path.join(APP_BACKUP_DIR, `innersync_before_rollback_${sourceJobId}_${timestampForFile()}`);
    ensureDirectory(backupFolder);

    const missingFiles = [];
    for (const relativeFile of relativeFiles) {
        const normalized = normalizePackagePath(relativeFile);
        const sourcePath = path.join(APP_ROOT, normalized);
        if (!fs.existsSync(sourcePath)) {
            missingFiles.push(normalized);
            continue;
        }

        const targetPath = path.join(backupFolder, normalized);
        ensureDirectory(path.dirname(targetPath));
        fs.copyFileSync(sourcePath, targetPath);
    }

    fs.writeFileSync(
        path.join(backupFolder, "missing_files.json"),
        JSON.stringify(missingFiles, null, 2),
        "utf8"
    );

    return backupFolder;
}

function restoreAppBackupFolder(appBackupFolder) {
    const backupFolder = ensurePathInsideAppRoot(appBackupFolder, "Folder backup rollback");
    if (!backupFolder.startsWith(APP_BACKUP_DIR + path.sep)) {
        throw new Error("Folder backup rollback tidak berasal dari backup update aplikasi.");
    }
    if (!fs.existsSync(backupFolder)) {
        throw new Error("Folder backup versi sebelumnya tidak ditemukan.");
    }

    const backupFiles = listFilesRecursive(backupFolder)
        .filter(filePath => path.basename(filePath).toLowerCase() !== "missing_files.json")
        .map(filePath => path.relative(backupFolder, filePath).replace(/\\/g, "/"))
        .sort((a, b) => a.localeCompare(b));

    if (!backupFiles.length) {
        throw new Error("Backup versi sebelumnya kosong, tidak ada file untuk rollback.");
    }

    const currentBackupFolder = backupCurrentFilesForRollback(backupFiles, path.basename(backupFolder));

    for (const relativeFile of backupFiles) {
        const normalized = normalizePackagePath(relativeFile);
        const sourcePath = path.join(backupFolder, normalized);
        const targetPath = path.join(APP_ROOT, normalized);
        ensureDirectory(path.dirname(targetPath));
        fs.copyFileSync(sourcePath, targetPath);
    }

    return {
        restored_files: backupFiles.length,
        current_backup_folder: currentBackupFolder
    };
}

router.use(["/api/software-update", "/api/software-updates"], async (req, res, next) => {
    try {
        await ensureSoftwareUpdateSchema();
        next();
    } catch (error) {
        next(error);
    }
});

router.get("/api/software-update/status", checkSession, async (req, res) => {
    try {
        const versionInfo = getInstalledVersionInfo();
        const jobs = await pool.query(`
            SELECT job_id, action, status, version_from, version_to, message, package_file,
                   staging_folder, app_backup_folder, db_backup_file, created_by, started_at, finished_at
            FROM software_update_jobs
            ORDER BY job_id DESC
            LIMIT 50
        `);

        const staged = await pool.query(`
            SELECT job_id, version_to, message, staging_folder, manifest, created_by, started_at
            FROM software_update_jobs
            WHERE status = 'STAGED'
            ORDER BY job_id DESC
            LIMIT 1
        `);

        res.json({
            success: true,
            current: versionInfo,
            settings: await getUpdateSettings(),
            staged: staged.rows[0] || null,
            history: jobs.rows
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/software-update/settings", checkSession, requireSuperAdmin, async (req, res) => {
    try {
        const manifestUrl = String(req.body?.update_manifest_url || "").trim();
        const normalizedUrl = manifestUrl ? normalizeUrl(manifestUrl) : "";

        const result = await pool.query(
            `UPDATE software_update_settings
             SET update_manifest_url = $1,
                 auto_check_enabled = $2,
                 updated_by = $3,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                normalizedUrl || null,
                req.body?.auto_check_enabled === true,
                getCurrentUsername(req)
            ]
        );

        res.json({ success: true, message: "Setting online update berhasil disimpan.", data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/software-update/check-online", checkSession, requireSuperAdmin, async (req, res) => {
    try {
        const settings = await getUpdateSettings();
        const manifestUrl = String(req.body?.update_manifest_url || settings.update_manifest_url || "").trim();
        if (!manifestUrl) {
            return res.status(400).json({ success: false, message: "Isi GitHub latest.json URL terlebih dahulu." });
        }

        const manifest = await fetchOnlineManifest(manifestUrl);
        const current = getInstalledVersionInfo();
        const updateAvailable = compareVersions(manifest.latest_version, current.version) > 0;
        const message = updateAvailable
            ? `Update ${manifest.latest_version} tersedia.`
            : `Software sudah versi terbaru (${current.version}).`;

        await updateLastOnlineCheck("SUCCESS", message, manifest, "OK");

        res.json({
            success: true,
            message,
            update_available: updateAvailable,
            current,
            latest: manifest
        });
    } catch (error) {
        const internetStatus = classifyInternetStatus(error);
        await updateLastOnlineCheck("FAILED", error.message, null, internetStatus).catch(() => {});
        res.status(500).json({ success: false, internet_status: internetStatus, error: error.message });
    }
});

router.post("/api/software-update/download-online", checkSession, requireSuperAdmin, async (req, res) => {
    let job;
    try {
        const settings = await getUpdateSettings();
        const manifestUrl = String(req.body?.update_manifest_url || settings.update_manifest_url || "").trim();
        if (!manifestUrl) {
            return res.status(400).json({ success: false, message: "Isi GitHub latest.json URL terlebih dahulu." });
        }

        const latest = await fetchOnlineManifest(manifestUrl);
        const installed = getInstalledVersionInfo();
        if (compareVersions(latest.latest_version, installed.version) <= 0 && req.body?.force !== true) {
            return res.status(400).json({ success: false, message: "Tidak ada versi baru untuk didownload." });
        }

        const stagingId = `${timestampForFile()}_${crypto.randomBytes(4).toString("hex")}`;
        const stagingFolder = path.join(STAGING_DIR, stagingId);
        const packageFile = path.join(UPLOAD_DIR, `online_${latest.latest_version.replace(/[^0-9A-Za-z._-]/g, "_")}_${stagingId}.zip`);

        job = await createUpdateJob("ONLINE_DOWNLOAD", getCurrentUsername(req), {
            status: "RUNNING",
            version_from: installed.version,
            version_to: latest.latest_version,
            package_file: packageFile,
            staging_folder: stagingFolder,
            manifest: latest
        });

        await downloadUrlToFile(latest.package_url, packageFile);

        if (latest.sha256 && hashFile(packageFile) !== latest.sha256) {
            throw new Error("Checksum package GitHub tidak cocok dengan latest.json.");
        }

        await extractZip(packageFile, stagingFolder);
        const packageManifest = normalizeManifest(stagingFolder);
        if (String(packageManifest.version) !== String(latest.latest_version)) {
            throw new Error(`Version package (${packageManifest.version}) tidak sama dengan latest.json (${latest.latest_version}).`);
        }

        const combinedManifest = {
            ...packageManifest,
            online: latest
        };

        await pool.query(
            `UPDATE software_update_jobs
             SET status = 'STAGED',
                 message = $1,
                 manifest = $2,
                 finished_at = NOW()
             WHERE job_id = $3`,
            [
                `Online update ${latest.latest_version} berhasil didownload dari GitHub. ${packageManifest.file_count} file dan ${packageManifest.migration_count} migration tervalidasi.`,
                combinedManifest,
                job.job_id
            ]
        );

        await updateLastOnlineCheck("SUCCESS", `Online update ${latest.latest_version} berhasil didownload.`, latest, "OK");

        res.json({
            success: true,
            message: "Online update berhasil didownload dan siap di-apply.",
            data: {
                job_id: job.job_id,
                version_from: installed.version,
                version_to: latest.latest_version,
                file_count: packageManifest.file_count,
                migration_count: packageManifest.migration_count,
                manifest: combinedManifest
            }
        });
    } catch (error) {
        await markUpdateJobFailed(job?.job_id, error);
        const internetStatus = classifyInternetStatus(error);
        await updateLastOnlineCheck("FAILED", error.message, null, internetStatus).catch(() => {});
        res.status(500).json({ success: false, internet_status: internetStatus, error: error.message });
    }
});

router.post("/api/software-update/update-now", checkSession, requireSuperAdmin, async (req, res) => {
    let job;
    try {
        const settings = await getUpdateSettings();
        const manifestUrl = String(req.body?.update_manifest_url || settings.update_manifest_url || DEFAULT_GITHUB_MANIFEST_URL).trim();
        if (!manifestUrl) {
            return res.status(400).json({ success: false, message: "GitHub latest.json URL belum disetting." });
        }

        const latest = await fetchOnlineManifest(manifestUrl);
        const installed = getInstalledVersionInfo();
        const updateAvailable = compareVersions(latest.latest_version, installed.version) > 0;

        if (!updateAvailable && req.body?.force !== true) {
            await updateLastOnlineCheck("SUCCESS", `Software sudah versi terbaru (${installed.version}).`, latest, "OK");
            return res.json({
                success: true,
                updated: false,
                internet_status: "OK",
                message: `Software sudah versi terbaru (${installed.version}).`,
                current: installed,
                latest
            });
        }

        const stagingId = `${timestampForFile()}_${crypto.randomBytes(4).toString("hex")}`;
        const stagingFolder = path.join(STAGING_DIR, stagingId);
        const packageFile = path.join(UPLOAD_DIR, `online_${latest.latest_version.replace(/[^0-9A-Za-z._-]/g, "_")}_${stagingId}.zip`);

        job = await createUpdateJob("ONLINE_UPDATE", getCurrentUsername(req), {
            status: "RUNNING",
            version_from: installed.version,
            version_to: latest.latest_version,
            package_file: packageFile,
            staging_folder: stagingFolder,
            manifest: latest
        });

        await downloadUrlToFile(latest.package_url, packageFile);
        if (latest.sha256 && hashFile(packageFile) !== latest.sha256) {
            throw new Error("Checksum package GitHub tidak cocok dengan latest.json.");
        }

        await extractZip(packageFile, stagingFolder);
        const packageManifest = normalizeManifest(stagingFolder);
        if (String(packageManifest.version) !== String(latest.latest_version)) {
            throw new Error(`Version package (${packageManifest.version}) tidak sama dengan latest.json (${latest.latest_version}).`);
        }

        const dbBackup = await runFullBackup("SOFTWARE_UPDATE_ONLINE");
        const appBackupFolder = backupExistingFiles(packageManifest.files);
        const migrationResult = await runMigrations(
            stagingFolder,
            packageManifest,
            job.job_id,
            getCurrentUsername(req)
        );
        copyUpdateFiles(stagingFolder, packageManifest.files);

        ensureDirectory(path.dirname(CURRENT_VERSION_FILE));
        fs.writeFileSync(
            CURRENT_VERSION_FILE,
            JSON.stringify({
                version: packageManifest.version,
                installed_at: new Date().toISOString(),
                update_job_id: job.job_id,
                source: "github"
            }, null, 2),
            "utf8"
        );

        const combinedManifest = {
            ...packageManifest,
            online: latest
        };

        const finished = await finishUpdateJob(job.job_id, {
            status: "SUCCESS",
            message: `Online update ${installed.version} ke ${packageManifest.version} berhasil. Migration applied ${migrationResult.applied}, skipped ${migrationResult.skipped}. Restart service diperlukan.`,
            app_backup_folder: appBackupFolder,
            db_backup_file: dbBackup.file_path,
            manifest: combinedManifest
        });

        await updateLastOnlineCheck("SUCCESS", `Online update ${packageManifest.version} berhasil di-apply.`, latest, "OK");

        res.json({
            success: true,
            updated: true,
            internet_status: "OK",
            message: "Update berhasil. Restart service diperlukan agar versi baru aktif penuh.",
            restart_required: true,
            current: installed,
            latest,
            data: finished
        });
    } catch (error) {
        await markUpdateJobFailed(job?.job_id, error);
        const internetStatus = classifyInternetStatus(error);
        await updateLastOnlineCheck("FAILED", error.message, null, internetStatus).catch(() => {});
        res.status(500).json({
            success: false,
            internet_status: internetStatus,
            error: error.message
        });
    }
});

router.post("/api/software-update/upload", checkSession, requireSuperAdmin, upload.single("update_file"), async (req, res) => {
    let job;
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "Pilih file update .zip terlebih dahulu." });
        }

        const originalName = req.file.originalname || "";
        if (!originalName.toLowerCase().endsWith(".zip")) {
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ success: false, message: "File update harus format .zip." });
        }

        const installed = getInstalledVersionInfo();
        const stagingId = `${timestampForFile()}_${crypto.randomBytes(4).toString("hex")}`;
        const stagingFolder = path.join(STAGING_DIR, stagingId);

        job = await createUpdateJob("UPLOAD", getCurrentUsername(req), {
            status: "RUNNING",
            version_from: installed.version,
            package_file: req.file.path,
            staging_folder: stagingFolder
        });

        await extractZip(req.file.path, stagingFolder);
        const manifest = normalizeManifest(stagingFolder);

        await pool.query(
            `UPDATE software_update_jobs
             SET status = 'STAGED',
                 version_to = $1,
                 message = $2,
                 manifest = $3,
                 finished_at = NOW()
             WHERE job_id = $4`,
            [
                manifest.version,
                `Paket update ${manifest.version} siap di-apply. ${manifest.file_count} file dan ${manifest.migration_count} migration tervalidasi.`,
                manifest,
                job.job_id
            ]
        );

        res.json({
            success: true,
            message: "Paket update berhasil divalidasi dan siap di-apply.",
            data: {
                job_id: job.job_id,
                version_from: installed.version,
                version_to: manifest.version,
                file_count: manifest.file_count,
                migration_count: manifest.migration_count,
                manifest
            }
        });
    } catch (error) {
        await markUpdateJobFailed(job?.job_id, error);
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/software-update/apply/:jobId", checkSession, requireSuperAdmin, async (req, res) => {
    let job;
    try {
        const result = await pool.query(
            "SELECT * FROM software_update_jobs WHERE job_id = $1 AND status = 'STAGED'",
            [req.params.jobId]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Paket update staged tidak ditemukan." });
        }

        job = result.rows[0];
        const stagingFolder = job.staging_folder;
        const manifest = normalizeManifest(stagingFolder);

        await pool.query(
            "UPDATE software_update_jobs SET status = 'RUNNING', started_at = NOW() WHERE job_id = $1",
            [job.job_id]
        );

        const dbBackup = await runFullBackup("SOFTWARE_UPDATE");
        const appBackupFolder = backupExistingFiles(manifest.files);
        const migrationResult = await runMigrations(
            stagingFolder,
            manifest,
            job.job_id,
            getCurrentUsername(req)
        );
        copyUpdateFiles(stagingFolder, manifest.files);

        ensureDirectory(path.dirname(CURRENT_VERSION_FILE));
        fs.writeFileSync(
            CURRENT_VERSION_FILE,
            JSON.stringify({
                version: manifest.version,
                installed_at: new Date().toISOString(),
                update_job_id: job.job_id
            }, null, 2),
            "utf8"
        );

        const finished = await finishUpdateJob(job.job_id, {
            status: "SUCCESS",
            message: `Update ${job.version_from || "-"} ke ${manifest.version} berhasil di-apply. Migration applied ${migrationResult.applied}, skipped ${migrationResult.skipped}. Restart service diperlukan.`,
            app_backup_folder: appBackupFolder,
            db_backup_file: dbBackup.file_path,
            manifest
        });

        res.json({
            success: true,
            message: "Update berhasil di-apply. Restart service diperlukan agar versi baru aktif penuh.",
            restart_required: true,
            data: finished
        });
    } catch (error) {
        await markUpdateJobFailed(job?.job_id, error);
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/software-update/cancel/:jobId", checkSession, requireSuperAdmin, async (req, res) => {
    try {
        const result = await pool.query(
            "SELECT * FROM software_update_jobs WHERE job_id = $1 AND status = 'STAGED'",
            [req.params.jobId]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Paket staged tidak ditemukan." });
        }

        await finishUpdateJob(result.rows[0].job_id, {
            status: "CANCELLED",
            message: "Paket update dibatalkan oleh user."
        });

        res.json({ success: true, message: "Paket update dibatalkan." });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/software-update/rollback/:jobId", checkSession, requireSuperAdmin, async (req, res) => {
    let rollbackJob;
    try {
        const sourceResult = await pool.query(
            `SELECT *
             FROM software_update_jobs
             WHERE job_id = $1
               AND status = 'SUCCESS'
               AND action IN ('ONLINE_UPDATE', 'UPLOAD', 'ROLLBACK')
               AND app_backup_folder IS NOT NULL`,
            [req.params.jobId]
        );

        if (!sourceResult.rows.length) {
            return res.status(404).json({
                success: false,
                message: "Backup update untuk rollback tidak ditemukan."
            });
        }

        const sourceJob = sourceResult.rows[0];
        const installed = getInstalledVersionInfo();
        const targetVersion = sourceJob.version_from || "unknown";

        rollbackJob = await createUpdateJob("ROLLBACK", getCurrentUsername(req), {
            status: "RUNNING",
            version_from: installed.version,
            version_to: targetVersion,
            message: `Rollback dari job update #${sourceJob.job_id}`
        });

        const restoreResult = restoreAppBackupFolder(sourceJob.app_backup_folder);

        ensureDirectory(path.dirname(CURRENT_VERSION_FILE));
        fs.writeFileSync(
            CURRENT_VERSION_FILE,
            JSON.stringify({
                version: targetVersion,
                installed_at: new Date().toISOString(),
                update_job_id: rollbackJob.job_id,
                source: "rollback",
                rollback_from_job_id: sourceJob.job_id
            }, null, 2),
            "utf8"
        );

        const finished = await finishUpdateJob(rollbackJob.job_id, {
            status: "SUCCESS",
            message: `Rollback ke versi ${targetVersion} berhasil. ${restoreResult.restored_files} file dipulihkan. Database tidak di-restore otomatis agar data transaksi terbaru tidak hilang. Restart service diperlukan.`,
            app_backup_folder: restoreResult.current_backup_folder
        });

        res.json({
            success: true,
            message: "Rollback berhasil. Restart service diperlukan agar versi sebelumnya aktif penuh.",
            restart_required: true,
            data: finished
        });
    } catch (error) {
        await markUpdateJobFailed(rollbackJob?.job_id, error);
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = {
    router,
    ensureSoftwareUpdateSchema
};
