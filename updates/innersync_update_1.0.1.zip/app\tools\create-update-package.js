const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");

const args = process.argv.slice(2);

function readArg(name, fallback = "") {
    const prefix = `--${name}=`;
    const found = args.find(arg => arg.startsWith(prefix));
    return found ? found.slice(prefix.length) : fallback;
}

function ensureDirectory(folder) {
    fs.mkdirSync(folder, { recursive: true });
}

function hashFile(filePath) {
    const hash = crypto.createHash("sha256");
    hash.update(fs.readFileSync(filePath));
    return hash.digest("hex");
}

function listFilesRecursive(folder) {
    const output = [];
    for (const entry of fs.readdirSync(folder, { withFileTypes: true })) {
        const fullPath = path.join(folder, entry.name);
        if (entry.isDirectory()) {
            output.push(...listFilesRecursive(fullPath));
        } else if (entry.isFile()) {
            output.push(fullPath);
        }
    }
    return output;
}

function runProcess(command, processArgs, options = {}) {
    return new Promise((resolve, reject) => {
        const child = spawn(command, processArgs, {
            windowsHide: true,
            ...options
        });
        let stdout = "";
        let stderr = "";
        child.stdout?.on("data", data => { stdout += data.toString(); });
        child.stderr?.on("data", data => { stderr += data.toString(); });
        child.on("error", reject);
        child.on("close", code => {
            if (code === 0) return resolve({ stdout, stderr });
            reject(new Error(stderr || stdout || `${command} exited with code ${code}`));
        });
    });
}

async function main() {
    const version = readArg("version");
    const source = readArg("source", process.cwd());
    const output = readArg("output", path.join(process.cwd(), "dist-updates"));
    const migrationSource = readArg("migrations", path.join(source, "migrations"));
    const packageUrl = readArg("package-url", "");
    const githubBaseUrl = readArg("github-base-url", "");
    const changelog = readArg("changelog", "");

    if (!version) {
        throw new Error("Isi --version=1.0.1");
    }

    const sourceFolder = path.resolve(source);
    if (!fs.existsSync(sourceFolder)) {
        throw new Error(`Source folder tidak ditemukan: ${sourceFolder}`);
    }

    const outputFolder = path.resolve(output);
    ensureDirectory(outputFolder);

    const tempFolder = path.join(os.tmpdir(), `innersync-update-${Date.now()}`);
    const appFolder = path.join(tempFolder, "app");
    const packageMigrationFolder = path.join(tempFolder, "migrations");
    ensureDirectory(appFolder);

    const files = listFilesRecursive(sourceFolder)
        .map(filePath => {
            const relPath = path.relative(sourceFolder, filePath).replace(/\\/g, "/");
            return { filePath, relPath };
        })
        .filter(file => {
            const lower = file.relPath.toLowerCase();
            return !lower.startsWith(".git/") &&
                !lower.startsWith("node_modules/") &&
                !lower.startsWith("config/") &&
                !lower.startsWith("backups/") &&
                !lower.startsWith("exports/") &&
                !lower.startsWith("uploads/") &&
                !lower.startsWith("updates/") &&
                !lower.startsWith("license/generated/") &&
                !lower.startsWith("migrations/") &&
                lower !== "license/private_key.pem" &&
                lower !== "server.out.log" &&
                lower !== "server.err.log";
        });

    for (const file of files) {
        const targetPath = path.join(appFolder, file.relPath);
        ensureDirectory(path.dirname(targetPath));
        fs.copyFileSync(file.filePath, targetPath);
    }

    const manifestFiles = files.map(file => ({
        path: file.relPath,
        sha256: hashFile(path.join(appFolder, file.relPath))
    }));

    const migrationFolder = path.resolve(migrationSource);
    const migrationFiles = fs.existsSync(migrationFolder)
        ? listFilesRecursive(migrationFolder)
            .filter(filePath => filePath.toLowerCase().endsWith(".sql"))
            .map(filePath => {
                const relPath = path.relative(migrationFolder, filePath).replace(/\\/g, "/");
                const targetPath = path.join(packageMigrationFolder, relPath);
                ensureDirectory(path.dirname(targetPath));
                fs.copyFileSync(filePath, targetPath);
                return {
                    name: relPath,
                    sha256: hashFile(targetPath)
                };
            })
            .sort((a, b) => a.name.localeCompare(b.name))
        : [];

    const manifest = {
        product: "Innersync Registration Portal",
        version,
        generated_at: new Date().toISOString(),
        changelog: changelog ? changelog.split("|").map(item => item.trim()).filter(Boolean) : [],
        files: manifestFiles,
        migrations: migrationFiles
    };

    fs.writeFileSync(
        path.join(tempFolder, "manifest.json"),
        JSON.stringify(manifest, null, 2),
        "utf8"
    );

    const zipPath = path.join(outputFolder, `innersync_update_${version.replace(/[^0-9A-Za-z._-]/g, "_")}.zip`);
    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

    await runProcess("powershell.exe", [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        "Compress-Archive -Path (Join-Path $env:INNER_UPDATE_SOURCE '*') -DestinationPath $env:INNER_UPDATE_ZIP -Force"
    ], {
        env: {
            ...process.env,
            INNER_UPDATE_SOURCE: tempFolder,
            INNER_UPDATE_ZIP: zipPath
        }
    });

    const zipHash = hashFile(zipPath);
    const finalPackageUrl = packageUrl || (githubBaseUrl
        ? `${githubBaseUrl.replace(/\/+$/, "")}/${path.basename(zipPath)}`
        : "");

    const latestManifest = {
        product: "Innersync Registration Portal",
        latest_version: version,
        release_date: new Date().toISOString().slice(0, 10),
        mandatory: false,
        changelog: manifest.changelog,
        package_url: finalPackageUrl,
        sha256: zipHash
    };

    fs.writeFileSync(
        path.join(outputFolder, "latest.json"),
        JSON.stringify(latestManifest, null, 2),
        "utf8"
    );

    console.log(`Update package created: ${zipPath}`);
    console.log(`latest.json created: ${path.join(outputFolder, "latest.json")}`);
    console.log(`Version: ${version}`);
    console.log(`Files: ${manifestFiles.length}`);
    console.log(`Migrations: ${migrationFiles.length}`);
    console.log(`Package SHA256: ${zipHash}`);
    if (!finalPackageUrl) {
        console.log("Package URL: kosong. Isi package_url di latest.json setelah upload ke GitHub.");
    } else {
        console.log(`Package URL: ${finalPackageUrl}`);
    }
}

main().catch(error => {
    console.error(error.message);
    process.exit(1);
});
