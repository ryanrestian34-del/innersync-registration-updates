const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const readline = require("readline");

const DEFAULT_OWNER = "ryanrestian34-del";
const DEFAULT_REPO = "innersync-registration-updates";
const DEFAULT_BRANCH = "main";
const DEFAULT_UPDATE_FOLDER = "D:\\20. Software Custom\\Innersync Updates";

const args = process.argv.slice(2);

function readArg(name, fallback = "") {
    const prefix = `--${name}=`;
    const found = args.find(arg => arg.startsWith(prefix));
    return found ? found.slice(prefix.length) : fallback;
}

function prompt(question, fallback = "") {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise(resolve => {
        const suffix = fallback ? ` [${fallback}]` : "";
        rl.question(`${question}${suffix}: `, answer => {
            rl.close();
            resolve(answer.trim() || fallback);
        });
    });
}

function hashFile(filePath) {
    const hash = crypto.createHash("sha256");
    hash.update(fs.readFileSync(filePath));
    return hash.digest("hex");
}

function readJson(filePath) {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
}

function getLatestZip(folder) {
    const files = fs.readdirSync(folder)
        .filter(file => /^innersync_update_.*\.zip$/i.test(file))
        .map(file => {
            const fullPath = path.join(folder, file);
            return {
                file,
                fullPath,
                mtimeMs: fs.statSync(fullPath).mtimeMs
            };
        })
        .sort((a, b) => b.mtimeMs - a.mtimeMs);

    return files[0] || null;
}

function encodeBase64(filePath) {
    return fs.readFileSync(filePath).toString("base64");
}

async function githubRequest(url, token, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            "Accept": "application/vnd.github+json",
            "Authorization": `Bearer ${token}`,
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "InnersyncUpdateUploader",
            ...(options.headers || {})
        }
    });

    const text = await response.text();
    let body = null;
    try {
        body = text ? JSON.parse(text) : null;
    } catch {
        body = text;
    }

    if (!response.ok) {
        const message = body?.message || text || `${response.status} ${response.statusText}`;
        throw new Error(`GitHub API error: ${message}`);
    }

    return body;
}

async function getExistingFileSha(owner, repo, branch, repoPath, token) {
    const encodedPath = repoPath.split("/").map(encodeURIComponent).join("/");
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodedPath}?ref=${encodeURIComponent(branch)}`;

    try {
        const data = await githubRequest(url, token);
        return data?.sha || null;
    } catch (error) {
        if (error.message.includes("Not Found")) return null;
        throw error;
    }
}

async function uploadFile(owner, repo, branch, repoPath, localPath, token, message) {
    const encodedPath = repoPath.split("/").map(encodeURIComponent).join("/");
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodedPath}`;
    const existingSha = await getExistingFileSha(owner, repo, branch, repoPath, token);

    const payload = {
        message,
        branch,
        content: encodeBase64(localPath)
    };

    if (existingSha) {
        payload.sha = existingSha;
    }

    return githubRequest(url, token, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });
}

async function main() {
    console.log("================================");
    console.log("Innersync GitHub Update Uploader");
    console.log("================================");
    console.log("");

    const owner = readArg("owner") || await prompt("GitHub owner", DEFAULT_OWNER);
    const repo = readArg("repo") || await prompt("Repository name", DEFAULT_REPO);
    const branch = readArg("branch") || await prompt("Branch", DEFAULT_BRANCH);
    const updateFolder = path.resolve(readArg("folder") || await prompt("Folder update package", DEFAULT_UPDATE_FOLDER));
    const token = readArg("token") || process.env.GITHUB_TOKEN || await prompt("Paste GitHub token");

    if (!token) {
        throw new Error("GitHub token wajib diisi.");
    }

    if (!fs.existsSync(updateFolder)) {
        throw new Error(`Folder update tidak ditemukan: ${updateFolder}`);
    }

    const latestJsonPath = path.join(updateFolder, "latest.json");
    if (!fs.existsSync(latestJsonPath)) {
        throw new Error(`latest.json tidak ditemukan di folder: ${updateFolder}`);
    }

    const latest = readJson(latestJsonPath);
    const latestZip = getLatestZip(updateFolder);
    if (!latestZip) {
        throw new Error(`File innersync_update_*.zip tidak ditemukan di folder: ${updateFolder}`);
    }

    const zipName = latestZip.file;
    latest.package_url = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/updates/${zipName}`;
    latest.sha256 = hashFile(latestZip.fullPath);
    if (!latest.latest_version) {
        latest.latest_version = String(zipName).replace(/^innersync_update_/i, "").replace(/\.zip$/i, "");
    }
    latest.product = latest.product || "Innersync Registration Portal";
    latest.release_date = latest.release_date || new Date().toISOString().slice(0, 10);
    latest.mandatory = latest.mandatory === true;
    latest.changelog = Array.isArray(latest.changelog) ? latest.changelog : [];

    writeJson(latestJsonPath, latest);

    console.log("");
    console.log(`Repo       : ${owner}/${repo}`);
    console.log(`Branch     : ${branch}`);
    console.log(`Zip        : ${latestZip.fullPath}`);
    console.log(`latest.json: ${latestJsonPath}`);
    console.log(`Version    : ${latest.latest_version}`);
    console.log(`SHA256     : ${latest.sha256}`);
    console.log("");

    await uploadFile(
        owner,
        repo,
        branch,
        `updates/${zipName}`,
        latestZip.fullPath,
        token,
        `Upload Innersync update package ${latest.latest_version}`
    );
    console.log(`Uploaded: updates/${zipName}`);

    await uploadFile(
        owner,
        repo,
        branch,
        "latest.json",
        latestJsonPath,
        token,
        `Update latest.json to ${latest.latest_version}`
    );
    console.log("Uploaded: latest.json");

    console.log("");
    console.log("Upload selesai.");
    console.log(`Raw latest.json: https://raw.githubusercontent.com/${owner}/${repo}/${branch}/latest.json`);
}

main().catch(error => {
    console.error("");
    console.error(error.message);
    process.exit(1);
});
