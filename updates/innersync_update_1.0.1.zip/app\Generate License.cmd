@echo off
cd /d "%~dp0"
node tools\generate-license-wizard.js
