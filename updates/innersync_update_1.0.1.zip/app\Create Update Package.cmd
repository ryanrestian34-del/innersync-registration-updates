@echo off
cd /d "%~dp0"
if not "%~1"=="" (
    node tools\create-update-package.js %*
    pause
    exit /b
)

echo ===============================
echo Innersync Update Package Builder
echo ===============================
echo.
set /p VERSION=Isi versi update, contoh 1.0.1: 
if "%VERSION%"=="" (
    echo Version wajib diisi.
    pause
    exit /b 1
)

set "SOURCE=%CD%"
set /p OUTPUT=Folder output zip [D:\20. Software Custom\Innersync Updates]: 
if "%OUTPUT%"=="" set "OUTPUT=D:\20. Software Custom\Innersync Updates"

set /p MIGRATIONS=Folder migrations SQL [kosongkan jika tidak ada]: 
set /p CHANGELOG=Changelog singkat, pisahkan dengan tanda ^| [optional]: 
set /p GITHUB_BASE=GitHub raw folder URL untuk file zip [optional]: 

if "%MIGRATIONS%"=="" (
    if "%GITHUB_BASE%"=="" (
        node tools\create-update-package.js --version=%VERSION% --source="%SOURCE%" --output="%OUTPUT%" --changelog="%CHANGELOG%"
    ) else (
        node tools\create-update-package.js --version=%VERSION% --source="%SOURCE%" --output="%OUTPUT%" --changelog="%CHANGELOG%" --github-base-url="%GITHUB_BASE%"
    )
) else (
    if "%GITHUB_BASE%"=="" (
        node tools\create-update-package.js --version=%VERSION% --source="%SOURCE%" --output="%OUTPUT%" --migrations="%MIGRATIONS%" --changelog="%CHANGELOG%"
    ) else (
        node tools\create-update-package.js --version=%VERSION% --source="%SOURCE%" --output="%OUTPUT%" --migrations="%MIGRATIONS%" --changelog="%CHANGELOG%" --github-base-url="%GITHUB_BASE%"
    )
)
pause
