const fs = require("fs");
const path = require("path");
const { createSignedLicense, verifyLicenseToken } = require("../license/licenseManager");
const DEFAULT_FEATURES = "visitor_registration,visitor_logs,invitation,host,permission_group,api,middleware,reports,maintenance,settings,account_management,database_capacity,notifications,monitoring_account,software_activity_log";

function getArg(name, fallback = "") {
    const prefix = `--${name}=`;
    const found = process.argv.find(arg => arg.startsWith(prefix));
    return found ? found.slice(prefix.length) : fallback;
}

function printUsage() {
    console.log(`
Usage:
  node tools/generate-license.js --customer="PT Customer" --machine=ABCD... --expires=2027-07-20 --edition=ENTERPRISE --max-users=50
  node tools/generate-license.js --customer="PT Customer" --machine=ABCD... --expires=PERMANENT --edition=ENTERPRISE --max-users=50

Optional:
  --features=${DEFAULT_FEATURES}
  --out=license/customer-license.txt

Important:
  license/private_key.pem jangan ikut dikirim ke customer.
`);
}

try {
    const customer = getArg("customer");
    const machineId = getArg("machine").replace(/-/g, "").toUpperCase();
    const expires = getArg("expires");
    const edition = getArg("edition", "STANDARD");
    const maxUsers = Number(getArg("max-users", "10"));
    const features = getArg("features", DEFAULT_FEATURES)
        .split(",")
        .map(item => item.trim())
        .filter(Boolean);
    const outFile = getArg("out");
    const privateKeyPath = path.join(__dirname, "..", "license", "private_key.pem");

    if (!customer || !machineId || !expires) {
        printUsage();
        process.exit(1);
    }

    if (!fs.existsSync(privateKeyPath)) {
        throw new Error(`Private key tidak ditemukan: ${privateKeyPath}`);
    }

    const permanent = String(expires || "").trim().toUpperCase() === "PERMANENT";
    let expiresAt = null;
    if (!permanent) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(expires)) {
            throw new Error("Format expires harus YYYY-MM-DD atau PERMANENT.");
        }
        expiresAt = new Date(`${expires}T23:59:59+07:00`).toISOString();
    }
    const token = createSignedLicense({
        customer,
        machine_id: machineId,
        edition,
        max_users: maxUsers,
        features,
        expires_at: expiresAt
    }, fs.readFileSync(privateKeyPath, "utf8"));

    const verification = verifyLicenseToken(token, { machine_id: machineId });
    if (!verification.valid) {
        throw new Error(`Generated license failed verification: ${verification.message}`);
    }

    if (outFile) {
        const fullOut = path.resolve(outFile);
        fs.mkdirSync(path.dirname(fullOut), { recursive: true });
        fs.writeFileSync(fullOut, token, "utf8");
        console.log(`License saved: ${fullOut}`);
    }

    console.log(token);
} catch (error) {
    console.error("Generate license failed:", error.message);
    process.exit(1);
}
