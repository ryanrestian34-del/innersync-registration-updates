function checkSession(req, res, next) {

    if (!req.session.user_id) {

        return res.status(401).json({

            success: false,
            message: "Session expired"

        });

    }

    if (!req.session.role_name) {

        req.session.destroy(() => {

            return res.status(401).json({

                success: false,
                message: "Invalid session"

            });

        });

        return;

    }

    next();

}

module.exports = {

    checkSession

};