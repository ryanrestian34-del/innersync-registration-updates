# Innersync Offline License

File penting:

- `public_key.pem`: boleh ikut di aplikasi/customer. Dipakai software untuk validasi license.
- `private_key.pem`: rahasia. Jangan ikut installer/customer. Dipakai hanya oleh owner untuk generate license.

License key memakai format:

```text
base64url(payload).base64url(signature)
```

Jika payload diubah, signature invalid dan software terkunci.
