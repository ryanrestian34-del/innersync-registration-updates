const express = require("express");
const router = express.Router();
const packageInfo = require("../package.json");
const {
    getMachineFingerprint,
    getStoredLicenseStatus,
    saveLicenseToken
} = require("../license/licenseManager");

const ALWAYS_ALLOWED_PREFIXES = [
    "/api/license",
    "/api/service-status"
];

const ALWAYS_ALLOWED_PATHS = new Set([
    "/license.html",
    "/logo.png",
    "/favicon.ico"
]);

function isAlwaysAllowedPath(pathname) {
    if (ALWAYS_ALLOWED_PATHS.has(pathname)) return true;
    return ALWAYS_ALLOWED_PREFIXES.some(prefix => pathname === prefix || pathname.startsWith(`${prefix}/`));
}

function wantsHtml(req) {
    return req.method === "GET" && (
        req.path === "/" ||
        req.path.endsWith(".html") ||
        String(req.headers.accept || "").includes("text/html")
    );
}

function licenseGate(req, res, next) {
    if (isAlwaysAllowedPath(req.path)) return next();

    const status = getStoredLicenseStatus();
    if (status.valid) return next();

    if (wantsHtml(req)) {
        return res.redirect("/license.html");
    }

    return res.status(403).json({
        success: false,
        license_required: true,
        reason: status.reason,
        message: status.message
    });
}

router.get("/api/license/status", (req, res) => {
    const status = getStoredLicenseStatus();
    res.json({
        success: true,
        valid: status.valid,
        reason: status.reason,
        message: status.message,
        access_mode: status.access_mode,
        license_valid: status.license_valid,
        license_days_until_expiry: status.license_days_until_expiry ?? null,
        expiry_warning: status.expiry_warning === true,
        has_license_file: status.has_license_file,
        license: status.payload || null,
        trial: status.trial || null,
        trial_active: status.trial_active,
        trial_remaining_days: status.trial_remaining_days || 0,
        app_version: packageInfo.version || "1.0.0",
        machine: {
            machine_id: status.machine?.machine_id || getMachineFingerprint().machine_id,
            display_id: status.machine?.display_id || getMachineFingerprint().display_id,
            hostname: status.machine?.parts?.hostname || null
        }
    });
});

router.post("/api/license/activate", (req, res) => {
    const token = req.body?.license_key;
    const result = saveLicenseToken(token);
    if (!result.valid) {
        return res.status(400).json({
            success: false,
            valid: false,
            reason: result.reason,
            message: result.message
        });
    }

    res.json({
        success: true,
        valid: true,
        message: "License berhasil diaktifkan.",
        license: result.payload,
        machine: {
            machine_id: result.machine.machine_id,
            display_id: result.machine.display_id,
            hostname: result.machine.parts.hostname
        }
    });
});

module.exports = {
    router,
    licenseGate
};
