const express = require("express");

const session = require("express-session");

const path = require("path");

const app = express();

const visitorRoutes = require("./routes/visitorRoutes");

const authRoutes = require("./routes/authRoutes");

const apiIntegrationRoutes = require("./routes/apiIntegrationRoutes");
const middlewareSyncRoutes = require("./routes/middlewareSyncRoutes");
const serviceStatusRoutes = require("./routes/serviceStatusRoutes");
const softwareUpdateRoutes = require("./routes/softwareUpdateRoutes");
const {
    router: licenseRoutes,
    licenseGate
} = require("./routes/licenseRoutes");
const {
    router: maintenanceRoutes,
    getServerListenSettings,
    startMaintenanceScheduler
} = require("./routes/maintenanceRoutes");

app.use(express.json());

app.use(

    session({

        secret: "innersync_secret_key",

        resave: false,

        saveUninitialized: false,

        cookie: {

            secure: false,

            maxAge: 1000 * 60 * 60 * 8

        }

    })

);

app.use("/", licenseRoutes);

app.use(licenseGate);

app.use(express.static(path.join(__dirname, "public")));

app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/", serviceStatusRoutes);

app.use("/", visitorRoutes);

app.use("/", authRoutes);

app.use("/", apiIntegrationRoutes);

app.use("/", middlewareSyncRoutes);

app.use("/", maintenanceRoutes);

app.use("/", softwareUpdateRoutes.router);

(async () => {
    const serverSettings = await getServerListenSettings();
    const port = Number(serverSettings.port || 3000);
    const host = serverSettings.host || "0.0.0.0";

    app.listen(port, host, () => {

        console.log("Innersync Middleware Running");

        console.log(`Server Host : ${host}`);

        console.log(`Server Port : ${port}`);

        startMaintenanceScheduler();
        if (typeof visitorRoutes.startAutoCheckoutScheduler === "function") {
            visitorRoutes.startAutoCheckoutScheduler();
        }
        if (typeof apiIntegrationRoutes.startApiHealthScheduler === "function") {
            apiIntegrationRoutes.startApiHealthScheduler();
        }
        if (typeof middlewareSyncRoutes.startMiddlewareSyncScheduler === "function") {
            middlewareSyncRoutes.startMiddlewareSyncScheduler();
        }

    });
})();
