const QRCode = require("qrcode");
const multer = require("multer");
const express = require("express");
const crypto = require("crypto");
const router = express.Router();
const pool = require("../database/db");
const ExcelJS = require("exceljs");
const nodemailer = require("nodemailer");
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const { executeActiveThirdPartyConfigs, hasActiveThirdPartyProvider } = require("./apiIntegrationRoutes");
const { ensureSystemNotificationSchema, createSystemNotification } = require("./notificationService");
let activePort = null;
let lastCard = "";
let schemaReady = false;
let autoCheckoutSchedulerStarted = false;
let autoCheckoutRunning = false;

// Tambahkan di baris paling atas visitorRoutes.js
console.log("Visitor Routes loaded successfully!");

async function ensureVisitorSchema() {
    if (schemaReady) return;

    await ensureSystemNotificationSchema();

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS host VARCHAR(150)
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS third_party_user_id VARCHAR(100)
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS schindler_person_id VARCHAR(100)
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS third_party_user_slots (
            slot_id SERIAL PRIMARY KEY,
            provider VARCHAR(50) NOT NULL DEFAULT 'innerrange',
            third_party_user_id VARCHAR(100) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
            current_visitor_id INTEGER,
            last_visitor_id INTEGER,
            last_assigned_time TIMESTAMP,
            last_released_time TIMESTAMP,
            created_time TIMESTAMP DEFAULT NOW(),
            modified_time TIMESTAMP,
            UNIQUE(provider, third_party_user_id)
        )
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS created_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW(),
        ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS permission_groups (
            group_id SERIAL PRIMARY KEY,
            group_name VARCHAR(100) UNIQUE NOT NULL,
            integration_id VARCHAR(80),
            floor_id INTEGER,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        ALTER TABLE permission_groups
        ADD COLUMN IF NOT EXISTS integration_id VARCHAR(80)
    `);

    await pool.query(`
        ALTER TABLE permission_groups
        ADD COLUMN IF NOT EXISTS floor_id INTEGER
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS schindler_floors (
            floor_id SERIAL PRIMARY KEY,
            floor_name VARCHAR(120) UNIQUE NOT NULL,
            destination_code VARCHAR(40) NOT NULL,
            return_code VARCHAR(40) NOT NULL DEFAULT '1',
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW(),
            modified_at TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_hosts (
            host_id SERIAL PRIMARY KEY,
            host_name VARCHAR(150) UNIQUE NOT NULL,
            host_email VARCHAR(255),
            location VARCHAR(150),
            note TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS host_email VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS location VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS note TEXT");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS modified_at TIMESTAMP");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS host_notification_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            email_subject TEXT DEFAULT 'Visitor Check-In - {{visitor_name}}',
            email_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS email_subject TEXT DEFAULT 'Visitor Check-In - {{visitor_name}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS email_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO host_notification_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_invitations (
            invitation_id SERIAL PRIMARY KEY,
            booking_code VARCHAR(40) UNIQUE NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            first_name VARCHAR(100) NOT NULL,
            second_name VARCHAR(100),
            company_name VARCHAR(150),
            email_address VARCHAR(255),
            phone_number VARCHAR(50),
            host VARCHAR(150),
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            permission_group VARCHAR(100),
            purpose_note TEXT,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP,
            sent_email_time TIMESTAMP,
            sent_whatsapp_time TIMESTAMP,
            checked_in_visitor_id INTEGER,
            checked_in_time TIMESTAMP,
            cancelled_time TIMESTAMP,
            cancel_reason TEXT
        )
    `);

    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS booking_code VARCHAR(40)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'PENDING'");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS first_name VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS second_name VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS company_name VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS phone_number VARCHAR(50)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS start_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS expiry_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS permission_group VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS purpose_note TEXT");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS sent_email_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS sent_whatsapp_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS checked_in_visitor_id INTEGER");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS checked_in_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS cancelled_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS cancel_reason TEXT");
    await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS visitor_invitations_booking_code_uq ON visitor_invitations (booking_code)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS auto_checkout_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            schedule_date DATE DEFAULT CURRENT_DATE,
            schedule_time VARCHAR(5) NOT NULL DEFAULT '18:00',
            schedule_type VARCHAR(20) NOT NULL DEFAULT 'ONCE',
            last_run_at TIMESTAMP,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_date DATE DEFAULT CURRENT_DATE");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_time VARCHAR(5) NOT NULL DEFAULT '18:00'");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_type VARCHAR(20) NOT NULL DEFAULT 'ONCE'");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS last_run_at TIMESTAMP");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO auto_checkout_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS qr_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            digit_length INTEGER NOT NULL DEFAULT 10,
            preview_title VARCHAR(100) NOT NULL DEFAULT 'Visitor QR Code',
            preview_subtitle VARCHAR(150) NOT NULL DEFAULT 'QR Code dibuat dari Card Number',
            show_card_number BOOLEAN NOT NULL DEFAULT TRUE,
            auto_email BOOLEAN NOT NULL DEFAULT FALSE,
            auto_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
            auto_sms BOOLEAN NOT NULL DEFAULT FALSE,
            public_base_url TEXT,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS smtp_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            smtp_host VARCHAR(255),
            smtp_port INTEGER DEFAULT 587,
            smtp_secure BOOLEAN NOT NULL DEFAULT FALSE,
            smtp_user VARCHAR(255),
            smtp_pass TEXT,
            from_email VARCHAR(255),
            from_name VARCHAR(150) DEFAULT 'Visitor Registration',
            email_subject TEXT DEFAULT 'Visitor QR Code - {{visitor_name}}',
            email_body TEXT DEFAULT 'Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}',
            invitation_email_subject TEXT DEFAULT 'Visitor Invitation - {{booking_code}}',
            invitation_email_body TEXT DEFAULT 'Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang.',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE smtp_settings ADD COLUMN IF NOT EXISTS invitation_email_subject TEXT DEFAULT 'Visitor Invitation - {{booking_code}}'");
    await pool.query("ALTER TABLE smtp_settings ADD COLUMN IF NOT EXISTS invitation_email_body TEXT DEFAULT 'Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang.'");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS whatsapp_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            send_mode VARCHAR(20) NOT NULL DEFAULT 'manual',
            provider VARCHAR(30) NOT NULL DEFAULT 'meta',
            access_token TEXT,
            phone_number_id VARCHAR(120),
            api_version VARCHAR(20) NOT NULL DEFAULT 'v20.0',
            message_template TEXT DEFAULT 'Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        ALTER TABLE qr_settings
        ADD COLUMN IF NOT EXISTS auto_email BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS auto_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS auto_sms BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS public_base_url TEXT
    `);

    await pool.query(`
        INSERT INTO qr_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        INSERT INTO smtp_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        INSERT INTO whatsapp_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    schemaReady = true;
}

function buildTemplate(template, data) {
    return String(template || "").replace(/\{\{(\w+)\}\}/g, (_, key) => data[key] ?? "");
}

function createSmtpTransport(settings) {
    if (!settings?.smtp_host || !settings?.smtp_port || !settings?.smtp_user || !settings?.smtp_pass) {
        throw new Error("Setting SMTP belum lengkap.");
    }

    return nodemailer.createTransport({
        host: settings.smtp_host,
        port: Number(settings.smtp_port),
        secure: settings.smtp_secure === true,
        auth: {
            user: settings.smtp_user,
            pass: settings.smtp_pass
        }
    });
}

async function getSmtpSettings() {
    const result = await pool.query("SELECT * FROM smtp_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function getQrSettings() {
    const result = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function getHostNotificationSettings() {
    const result = await pool.query("SELECT * FROM host_notification_settings WHERE setting_id = 1");
    return result.rows[0];
}

function formatDateTimeText(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString("en-GB");
}

async function sendHostCheckinEmail(req, visitor) {
    try {
        const notifySettings = await getHostNotificationSettings();
        if (notifySettings?.enabled !== true) return { skipped: true, reason: "Host notification disabled" };

        const hostName = String(visitor?.host || "").trim();
        if (!hostName) return { skipped: true, reason: "Host kosong" };

        const hostResult = await pool.query(
            "SELECT * FROM visitor_hosts WHERE host_name = $1 LIMIT 1",
            [hostName]
        );
        const host = hostResult.rows[0];
        const targetEmail = String(host?.host_email || "").trim();
        if (!targetEmail) return { skipped: true, reason: "Email host kosong" };

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const visitorName = getVisitorDisplayName(visitor);
        const templateData = {
            visitor_name: visitorName,
            first_name: visitor?.first_name || "",
            second_name: visitor?.second_name || "",
            company_name: visitor?.company_name || "-",
            host: hostName,
            host_email: targetEmail,
            host_location: host?.location || "-",
            purpose_note: visitor?.purpose_note || "-",
            card_number: visitor?.card_number || "-",
            permission_group: visitor?.permission_group || "-",
            check_in_time: formatDateTimeText(visitor?.check_in_time || new Date()),
            start: formatDateTimeText(visitor?.start_date),
            expiry: formatDateTimeText(visitor?.expiry_date)
        };

        const subject = buildTemplate(
            notifySettings.email_subject || "Visitor Check-In - {{visitor_name}}",
            templateData
        );
        const body = buildTemplate(
            notifySettings.email_body || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}",
            templateData
        );

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body
        });

        await saveActivityLog(
            req,
            "SEND_HOST_CHECKIN_EMAIL",
            `Send host check-in email to ${targetEmail} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_HOST",
            event_type: "CHECKIN",
            status: "SUCCESS",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail,
            title: "Email ke Host berhasil",
            message: `Informasi check-in ${visitorName} berhasil dikirim ke ${targetEmail}.`,
            detail: { host: hostName, card_number: visitor?.card_number || null }
        });

        return { success: true, to: targetEmail };
    } catch (error) {
        console.log("SEND HOST CHECKIN EMAIL ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_HOST_CHECKIN_EMAIL_FAILED",
            `Send host check-in email failed for ${getVisitorDisplayName(visitor)}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_HOST",
            event_type: "CHECKIN",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: getVisitorDisplayName(visitor),
            target: visitor?.host || null,
            title: "Email ke Host gagal",
            message: error.message,
            detail: { host: visitor?.host || null, card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

function buildQrShareUrlFromSettings(settings, visitor) {
    const baseUrl = String(settings?.public_base_url || "").trim().replace(/\/+$/, "");
    if (!baseUrl || !visitor?.card_number) return "-";
    const params = new URLSearchParams({
        qrCard: String(visitor.card_number || ""),
        visitor: getVisitorDisplayName(visitor)
    });
    return `${baseUrl}/qr-info.html?${params.toString()}`;
}

async function sendVisitorCheckinQrEmail(req, visitor) {
    const visitorName = getVisitorDisplayName(visitor);
    let targetEmail = String(visitor?.email_address || "").trim();

    try {
        const qrSettings = await getQrSettings();
        if (qrSettings?.auto_email !== true) return { skipped: true, reason: "Auto email QR disabled" };

        if (!targetEmail) {
            await createSystemNotification(req, {
                channel: "EMAIL_VISITOR",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_id: visitor?.visitor_id,
                visitor_name: visitorName,
                title: "Email QR ke Visitor gagal",
                message: "Email visitor belum diisi.",
                detail: { card_number: visitor?.card_number || null }
            });
            return { success: false, error: "Email visitor belum diisi." };
        }

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const shareUrl = buildQrShareUrlFromSettings(qrSettings, visitor);
        const templateData = {
            visitor_name: visitorName,
            first_name: visitor?.first_name || "",
            second_name: visitor?.second_name || "",
            company_name: visitor?.company_name || "-",
            host: visitor?.host || "-",
            start: formatDateTimeText(visitor?.start_date),
            expiry: formatDateTimeText(visitor?.expiry_date),
            card_number: visitor?.card_number || "-",
            share_url: shareUrl,
            purpose_note: visitor?.purpose_note || "-"
        };

        const subject = buildTemplate(settings.email_subject || "Visitor QR Code - {{visitor_name}}", templateData);
        const body = buildTemplate(
            settings.email_body || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
            templateData
        );
        const qrBuffer = await QRCode.toBuffer(String(visitor?.card_number || shareUrl || visitorName), {
            errorCorrectionLevel: "H",
            margin: 2,
            width: 480
        });

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body,
            attachments: [
                {
                    filename: `QR_${String(visitor?.card_number || "visitor").replace(/[^a-z0-9_-]+/gi, "_")}.png`,
                    content: qrBuffer,
                    contentType: "image/png"
                }
            ]
        });

        await saveActivityLog(
            req,
            "SEND_QR_EMAIL",
            `Auto send QR email to ${targetEmail} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"}, Card ${visitor?.card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail,
            title: "Email QR ke Visitor berhasil",
            message: `QR Code visitor berhasil dikirim otomatis ke ${targetEmail}.`,
            detail: { card_number: visitor?.card_number || null, share_url: shareUrl }
        });

        return { success: true, to: targetEmail };
    } catch (error) {
        console.log("SEND VISITOR QR EMAIL ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_QR_EMAIL_FAILED",
            `Auto send QR email failed for ${visitorName}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail || null,
            title: "Email QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

function normalizeBookingCode(value) {
    return String(value || "").trim().toUpperCase();
}

async function generateBookingCode() {
    const date = new Date();
    const datePart = `${date.getFullYear()}${pad2(date.getMonth() + 1)}${pad2(date.getDate())}`;
    for (let attempt = 0; attempt < 20; attempt += 1) {
        const randomPart = crypto.randomBytes(3).toString("hex").toUpperCase();
        const code = `INV-${datePart}-${randomPart}`;
        const existing = await pool.query("SELECT 1 FROM visitor_invitations WHERE booking_code = $1 LIMIT 1", [code]);
        if (existing.rows.length === 0) return code;
    }
    throw new Error("Gagal generate booking code unik.");
}

function invitationTemplateData(invitation) {
    const visitorName = `${invitation?.first_name || ""} ${invitation?.second_name || ""}`.trim() || "Visitor";
    return {
        booking_code: invitation?.booking_code || "-",
        visitor_name: visitorName,
        first_name: invitation?.first_name || "",
        second_name: invitation?.second_name || "",
        company_name: invitation?.company_name || "-",
        host: invitation?.host || "-",
        start: formatDateTimeText(invitation?.start_date),
        expiry: formatDateTimeText(invitation?.expiry_date),
        permission_group: invitation?.permission_group || "-",
        purpose_note: invitation?.purpose_note || "-"
    };
}

function buildBookingInvitationMessage(invitation) {
    const data = invitationTemplateData(invitation);
    return [
        "Visitor Invitation",
        `Booking Code: ${data.booking_code}`,
        `Nama: ${data.visitor_name}`,
        `Company: ${data.company_name}`,
        `Host: ${data.host}`,
        `Start: ${data.start}`,
        `Expiry: ${data.expiry}`,
        `Keperluan: ${data.purpose_note}`,
        "",
        "Tunjukkan booking code ini ke operator saat datang."
    ].join("\n");
}

async function sendBookingInvitationEmail(req, invitation) {
    const targetEmail = String(invitation?.email_address || "").trim();
    if (!targetEmail) throw new Error("Email visitor belum diisi.");

    const settings = await getSmtpSettings();
    const transporter = createSmtpTransport(settings);
    const data = invitationTemplateData(invitation);
    const subject = buildTemplate(settings.invitation_email_subject || "Visitor Invitation - {{booking_code}}", data);
    const body = buildTemplate(settings.invitation_email_body || buildBookingInvitationMessage(invitation), data);
    const qrDataUrl = await QRCode.toDataURL(data.booking_code, {
        errorCorrectionLevel: "H",
        margin: 2,
        width: 480
    });
    const qrBuffer = Buffer.from(qrDataUrl.replace(/^data:image\/png;base64,/, ""), "base64");

    await transporter.sendMail({
        from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
        to: targetEmail,
        subject,
        text: body,
        attachments: [
            {
                filename: `Booking_QR_${data.booking_code}.png`,
                content: qrBuffer,
                contentType: "image/png"
            }
        ]
    });

    await pool.query(
        "UPDATE visitor_invitations SET sent_email_time = NOW(), modified_by = $1, modified_time = NOW() WHERE invitation_id = $2",
        [getCurrentUsername(req), invitation.invitation_id]
    );

        await saveActivityLog(
            req,
            "SEND_INVITATION_EMAIL",
            `Send booking invitation ${data.booking_code} to ${targetEmail}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "INVITATION",
            status: "SUCCESS",
            visitor_name: data.visitor_name,
            target: targetEmail,
            title: "Email invitation berhasil",
            message: `Booking code ${data.booking_code} berhasil dikirim ke ${targetEmail}.`,
            detail: { booking_code: data.booking_code }
        });
}

async function getInvitationByBookingCode(code) {
    const bookingCode = normalizeBookingCode(code);
    if (!bookingCode) return null;
    const result = await pool.query("SELECT * FROM visitor_invitations WHERE booking_code = $1 LIMIT 1", [bookingCode]);
    return result.rows[0] || null;
}

async function validatePendingInvitationByCode(code) {
    const invitation = await getInvitationByBookingCode(code);
    if (!invitation) {
        return { ok: false, status: 404, message: "Booking code tidak ditemukan." };
    }
    if (invitation.status !== "PENDING") {
        return { ok: false, status: 400, message: `Booking code sudah berstatus ${invitation.status}.` };
    }
    if (invitation.expiry_date && new Date(invitation.expiry_date) < new Date()) {
        await pool.query(
            "UPDATE visitor_invitations SET status = 'EXPIRED', modified_time = NOW() WHERE invitation_id = $1",
            [invitation.invitation_id]
        );
        return { ok: false, status: 400, message: "Booking code sudah expired." };
    }
    return { ok: true, invitation };
}

async function getWhatsappSettings() {
    const result = await pool.query("SELECT * FROM whatsapp_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function isVisitorRegistrationApiMode() {
    try {
        const result = await pool.query("SELECT operation_mode FROM maintenance_settings WHERE setting_id = 1");
        return String(result.rows[0]?.operation_mode || "VISITOR_REGISTRATION").toUpperCase() !== "MIDDLEWARE_SYNC";
    } catch (error) {
        return true;
    }
}

function normalizeWhatsappPhone(phone) {
    let targetPhone = String(phone || "").replace(/[^0-9+]/g, "").replace(/^\+/, "");
    if (targetPhone.startsWith("0")) {
        targetPhone = `62${targetPhone.slice(1)}`;
    }
    return targetPhone;
}

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function normalizeTime(value, fallback = "18:00") {
    const text = String(value || "").trim();
    return /^\d{2}:\d{2}$/.test(text) ? text : fallback;
}

function normalizeDate(value) {
    if (value instanceof Date) return localDateKey(value);
    const text = String(value || "").trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.slice(0, 10);
    return localDateKey();
}

function normalizeScheduleType(value, fallback = "ONCE") {
    const type = String(value || fallback).trim().toUpperCase();
    return ["ONCE", "DAILY", "MONTHLY", "YEARLY"].includes(type) ? type : fallback;
}

function pad2(value) {
    return String(value).padStart(2, "0");
}

function localDateKey(date = new Date()) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

async function saveActivityLog(req, activityType, description) {
    try {
        await pool.query(
            `INSERT INTO activity_logs
            (
                username,
                activity_type,
                description,
                ip_address
            )
            VALUES ($1,$2,$3,$4)`,
            [
                getCurrentUsername(req),
                activityType,
                description,
                req.ip
            ]
        );
    } catch (error) {
        console.log("SAVE VISITOR ACTIVITY LOG ERROR:", error.message);
    }
}

router.get("/api/system-notifications/unread-count", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const result = await pool.query(
            "SELECT COUNT(*)::int AS unread_count FROM system_notifications WHERE is_read = FALSE"
        );
        res.json({ success: true, unread_count: result.rows[0]?.unread_count || 0 });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/system-notifications", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 500);
        const filters = [];
        const params = [];

        if (req.query.unread_only === "true") {
            filters.push("is_read = FALSE");
        }

        if (String(req.query.read_status || "").toUpperCase() === "READ") {
            filters.push("is_read = TRUE");
        } else if (String(req.query.read_status || "").toUpperCase() === "UNREAD") {
            filters.push("is_read = FALSE");
        }

        if (req.query.channel) {
            params.push(String(req.query.channel).toUpperCase());
            filters.push(`channel = $${params.length}`);
        }

        if (req.query.status) {
            params.push(String(req.query.status).toUpperCase());
            filters.push(`status = $${params.length}`);
        }

        if (req.query.search) {
            params.push(`%${String(req.query.search).trim()}%`);
            filters.push(`(title ILIKE $${params.length} OR message ILIKE $${params.length} OR visitor_name ILIKE $${params.length} OR target ILIKE $${params.length})`);
        }

        params.push(limit);
        const result = await pool.query(
            `SELECT *
             FROM system_notifications
             ${filters.length ? `WHERE ${filters.join(" AND ")}` : ""}
             ORDER BY created_time DESC
             LIMIT $${params.length}`,
            params
        );
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/system-notifications/mark-read", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationId = Number(req.body.notification_id || 0);
        if (notificationId) {
            await pool.query(
                `UPDATE system_notifications
                 SET is_read = TRUE,
                     read_by = $1,
                     read_time = NOW()
                 WHERE notification_id = $2`,
                [getCurrentUsername(req), notificationId]
            );
        } else {
            await pool.query(
                `UPDATE system_notifications
                 SET is_read = TRUE,
                     read_by = $1,
                     read_time = NOW()
                 WHERE is_read = FALSE`,
                [getCurrentUsername(req)]
            );
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/system-notifications/:id/retry-api", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationResult = await pool.query(
            "SELECT * FROM system_notifications WHERE notification_id = $1",
            [req.params.id]
        );
        const notification = notificationResult.rows[0];

        if (!notification) {
            return res.status(404).json({ success: false, message: "Notification tidak ditemukan." });
        }

        const channel = String(notification.channel || "").toUpperCase();
        const provider = String(notification.provider_type || channel.replace(/^API_/, "") || "").toUpperCase();
        const triggerEvent = String(notification.event_type || "").toUpperCase();
        const detail = notification.detail || {};
        const configId = detail.config_id ? Number(detail.config_id) : null;

        if (!channel.startsWith("API_") || !provider || notification.status !== "FAILED") {
            return res.status(400).json({ success: false, message: "Retry hanya tersedia untuk notification API yang statusnya FAILED." });
        }
        if (!notification.visitor_id) {
            return res.status(400).json({ success: false, message: "Visitor ID tidak tersedia untuk retry API." });
        }
        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Event API tidak tersedia untuk retry." });
        }

        const visitorResult = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [notification.visitor_id]);
        const visitor = visitorResult.rows[0];
        if (!visitor) {
            return res.status(404).json({ success: false, message: "Visitor tidak ditemukan." });
        }

        await saveActivityLog(
            req,
            "RETRY_THIRD_PARTY_API",
            `Retry ${provider} ${triggerEvent} API for ${getVisitorDisplayName(visitor)} (Visitor ID ${visitor.visitor_id}) from notification ${notification.notification_id}`
        );

        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, visitor, {
            providerType: provider,
            configId
        });
        const retryResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === provider);
        const ok = retryResults.some(item => item.success === true);

        res.json({
            success: ok,
            message: ok ? `Retry ${provider} ${triggerEvent} berhasil.` : `Retry ${provider} ${triggerEvent} gagal. Cek Log Activity API dan notification terbaru.`,
            data: retryResults,
            api_results: apiResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

async function allocateThirdPartyUserSlot(visitorId) {
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('innerrange_slot_allocation'))");

        const result = await client.query(
            `UPDATE third_party_user_slots
             SET status = 'IN_USE',
                 current_visitor_id = $1,
                 last_visitor_id = $1,
                 last_assigned_time = NOW(),
                 modified_time = NOW()
             WHERE slot_id = (
                 SELECT slot_id
                 FROM third_party_user_slots
                 WHERE provider = 'innerrange'
                   AND status = 'AVAILABLE'
                   AND NOT EXISTS (
                       SELECT 1
                       FROM visitor_registration v
                       WHERE v.third_party_user_id = third_party_user_slots.third_party_user_id
                         AND v.check_out_time IS NULL
                   )
                 ORDER BY last_released_time ASC NULLS FIRST, slot_id ASC
                 LIMIT 1
                 FOR UPDATE SKIP LOCKED
             )
             RETURNING third_party_user_id`,
            [visitorId]
        );

        await client.query("COMMIT");
        return result.rows[0]?.third_party_user_id || null;
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

async function upsertThirdPartyUserSlot(thirdPartyUserId, visitorId, status = "IN_USE") {
    if (!thirdPartyUserId) return;

    await pool.query(
        `INSERT INTO third_party_user_slots (
            provider,
            third_party_user_id,
            status,
            current_visitor_id,
            last_visitor_id,
            last_assigned_time,
            last_released_time,
            created_time,
            modified_time
        )
        VALUES (
            'innerrange',
            $1,
            $2::text,
            $3::integer,
            $3::integer,
            CASE WHEN $2::text = 'IN_USE' THEN NOW() ELSE NULL END,
            CASE WHEN $2::text = 'AVAILABLE' THEN NOW() ELSE NULL END,
            NOW(),
            NOW()
        )
        ON CONFLICT (provider, third_party_user_id)
        DO UPDATE SET
            status = EXCLUDED.status,
            current_visitor_id = EXCLUDED.current_visitor_id,
            last_visitor_id = EXCLUDED.last_visitor_id,
            last_assigned_time = CASE WHEN EXCLUDED.status = 'IN_USE' THEN NOW() ELSE third_party_user_slots.last_assigned_time END,
            last_released_time = CASE WHEN EXCLUDED.status = 'AVAILABLE' THEN NOW() ELSE third_party_user_slots.last_released_time END,
            modified_time = NOW()`,
        [thirdPartyUserId, status, visitorId]
    );
}

async function releaseThirdPartyUserSlot(thirdPartyUserId, visitorId) {
    if (!thirdPartyUserId) return;

    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('innerrange_slot_allocation'))");

        const existing = await client.query(
            `SELECT status, current_visitor_id
             FROM third_party_user_slots
             WHERE provider = 'innerrange'
               AND third_party_user_id = $1
             FOR UPDATE`,
            [thirdPartyUserId]
        );

        if (existing.rows.length > 0) {
            const currentVisitorId = existing.rows[0].current_visitor_id;
            const isHeldByAnotherVisitor = existing.rows[0].status === "IN_USE"
                && currentVisitorId
                && Number(currentVisitorId) !== Number(visitorId);

            if (isHeldByAnotherVisitor) {
                console.log(`SKIP RELEASE SLOT ${thirdPartyUserId}: held by visitor ${currentVisitorId}, not ${visitorId}`);
                await client.query("COMMIT");
                return;
            }
        }

        await client.query(
            `INSERT INTO third_party_user_slots (
                provider,
                third_party_user_id,
                status,
                current_visitor_id,
                last_visitor_id,
                last_released_time,
                created_time,
                modified_time
            )
            VALUES ('innerrange', $1, 'AVAILABLE', NULL, $2, NOW(), NOW(), NOW())
            ON CONFLICT (provider, third_party_user_id)
            DO UPDATE SET
                status = 'AVAILABLE',
                current_visitor_id = NULL,
                last_visitor_id = $2,
                last_released_time = NOW(),
                modified_time = NOW()`,
            [thirdPartyUserId, visitorId]
        );

        await client.query("COMMIT");
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

function hasProviderSuccess(apiResults, providerType) {
    return (apiResults || []).some(item =>
        String(item.provider_type || "").toUpperCase() === String(providerType || "").toUpperCase()
        && item.success === true
    );
}

function hasProviderResult(apiResults, providerType) {
    return (apiResults || []).some(item =>
        String(item.provider_type || "").toUpperCase() === String(providerType || "").toUpperCase()
    );
}

function shouldReleaseInnerrangeSlot(apiResults) {
    return !hasProviderResult(apiResults, "INNERRANGE") || hasProviderSuccess(apiResults, "INNERRANGE");
}

function getVisitorDisplayName(visitor) {
    return `${visitor?.first_name || ""} ${visitor?.second_name || ""}`.trim() || "Visitor";
}

async function generateSchindlerPersonId() {
    for (let attempt = 0; attempt < 10; attempt += 1) {
        const personId = crypto.randomUUID().replace(/-/g, "").toUpperCase();
        const existing = await pool.query(
            "SELECT 1 FROM visitor_registration WHERE schindler_person_id = $1 LIMIT 1",
            [personId]
        );
        if (existing.rows.length === 0) return personId;
    }

    throw new Error("Gagal generate Schindler Person ID unik.");
}

async function getAutoCheckoutSettings() {
    await ensureVisitorSchema();
    const result = await pool.query("SELECT * FROM auto_checkout_settings WHERE setting_id = 1");
    return result.rows[0] || {};
}

function shouldRunAutoCheckout(settings) {
    const now = new Date();
    const todayKey = localDateKey(now);
    const scheduleDateKey = normalizeDate(settings.schedule_date);
    const currentTime = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
    const lastRunKey = settings.last_run_at ? localDateKey(new Date(settings.last_run_at)) : "";
    return settings.enabled === true
        && todayKey >= scheduleDateKey
        && currentTime >= normalizeTime(settings.schedule_time)
        && lastRunKey !== todayKey;
}

function addAutoCheckoutScheduleInterval(dateValue, scheduleType) {
    const date = new Date(`${normalizeDate(dateValue)}T00:00:00`);
    if (scheduleType === "MONTHLY") date.setMonth(date.getMonth() + 1);
    else if (scheduleType === "YEARLY") date.setFullYear(date.getFullYear() + 1);
    else date.setDate(date.getDate() + 1);
    return localDateKey(date);
}

async function advanceAutoCheckoutSchedule(settings) {
    const scheduleType = normalizeScheduleType(settings.schedule_type);
    if (scheduleType === "ONCE") {
        await pool.query("UPDATE auto_checkout_settings SET enabled = FALSE, last_run_at = NOW(), updated_at = NOW() WHERE setting_id = 1");
        return;
    }

    const nextDate = addAutoCheckoutScheduleInterval(settings.schedule_date, scheduleType);
    await pool.query(
        "UPDATE auto_checkout_settings SET schedule_date = $1, last_run_at = NOW(), updated_at = NOW() WHERE setting_id = 1",
        [nextDate]
    );
}

async function checkoutVisitorRecord(visitor, reqLike, sourceLabel) {
    const result = await pool.query(
        `UPDATE visitor_registration
         SET check_out_time = NOW(),
             modified_by = $2,
             modified_time = NOW()
         WHERE visitor_id = $1
           AND check_out_time IS NULL
         RETURNING *`,
        [visitor.visitor_id, getCurrentUsername(reqLike)]
    );

    if (result.rows.length === 0) {
        return { success: false, visitor_id: visitor.visitor_id, message: "Visitor sudah check-out atau tidak ditemukan." };
    }

    const checkedOutVisitor = result.rows[0];
    await saveActivityLog(
        reqLike,
        sourceLabel === "AUTO_CHECKOUT" ? "AUTO_CHECK_OUT_VISITOR" : "CHECK_OUT_VISITOR",
        `${sourceLabel === "AUTO_CHECKOUT" ? "Auto check out" : "Check out"} visitor ${getVisitorDisplayName(checkedOutVisitor)} (Visitor ID ${checkedOutVisitor.visitor_id}, Card ${checkedOutVisitor.card_number || "-"})`
    );

    let apiResults = [];
    if (await isVisitorRegistrationApiMode()) {
        try {
            apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKOUT", checkedOutVisitor);
        } catch (apiError) {
            console.log("THIRD PARTY AUTO CHECKOUT API ERROR:", apiError.message);
        }
    }

    if (shouldReleaseInnerrangeSlot(apiResults)) {
        await releaseThirdPartyUserSlot(checkedOutVisitor.third_party_user_id, checkedOutVisitor.visitor_id);
    }

    return { success: true, visitor_id: checkedOutVisitor.visitor_id, api_results: apiResults };
}

async function runAutoCheckout(createdBy = "AUTO_CHECKOUT", ipAddress = "127.0.0.1") {
    if (autoCheckoutRunning) {
        throw new Error("Auto Check-Out sedang berjalan. Tunggu proses sebelumnya selesai.");
    }

    autoCheckoutRunning = true;
    const reqLike = {
        session: { user: { username: createdBy, full_name: createdBy } },
        ip: ipAddress
    };

    try {
        await ensureVisitorSchema();
        const activeVisitors = await pool.query(`
            SELECT *
            FROM visitor_registration
            WHERE check_out_time IS NULL
            ORDER BY check_in_time ASC, visitor_id ASC
        `);

        const results = [];
        for (const visitor of activeVisitors.rows) {
            results.push(await checkoutVisitorRecord(visitor, reqLike, "AUTO_CHECKOUT"));
        }

        await saveActivityLog(
            reqLike,
            "AUTO_CHECKOUT_RUN",
            `Auto Check-Out selesai. ${results.filter(item => item.success).length} dari ${activeVisitors.rows.length} visitor aktif berhasil di-checkout.`
        );

        return {
            total_active: activeVisitors.rows.length,
            checked_out: results.filter(item => item.success).length,
            failed: results.filter(item => !item.success).length,
            results
        };
    } finally {
        autoCheckoutRunning = false;
    }
}

async function runAutoCheckoutSchedulerTick() {
    try {
        const settings = await getAutoCheckoutSettings();
        if (!shouldRunAutoCheckout(settings)) return;

        runAutoCheckout("AUTO_CHECKOUT_SCHEDULER")
            .then(() => advanceAutoCheckoutSchedule(settings))
            .catch(error => console.log("AUTO CHECKOUT SCHEDULER ERROR:", error.message));
    } catch (error) {
        console.log("AUTO CHECKOUT SCHEDULER TICK ERROR:", error.message);
    }
}

function startAutoCheckoutScheduler() {
    if (autoCheckoutSchedulerStarted) return;
    autoCheckoutSchedulerStarted = true;
    setInterval(runAutoCheckoutSchedulerTick, 60 * 1000);
    setTimeout(runAutoCheckoutSchedulerTick, 5000);
}

function createBackgroundReq(req) {
    return {
        session: req.session,
        ip: req.ip,
        headers: req.headers,
        socket: req.socket
    };
}

function runBackgroundTask(label, task) {
    setImmediate(() => {
        Promise.resolve()
            .then(task)
            .catch(error => console.log(`${label} ERROR:`, error.message));
    });
}

async function runCheckinApiBackground(reqLike, visitor) {
    if (!(await isVisitorRegistrationApiMode())) {
        return;
    }

    const username = getCurrentUsername(reqLike);
    const workingVisitor = { ...(visitor || {}) };
    let reusableThirdPartyUserId = null;

    try {
        const hasInnerrangeCheckin = await hasActiveThirdPartyProvider("CHECKIN", "INNERRANGE");
        reusableThirdPartyUserId = hasInnerrangeCheckin
            ? await allocateThirdPartyUserSlot(workingVisitor.visitor_id)
            : null;

        if (reusableThirdPartyUserId) {
            workingVisitor.third_party_user_id = reusableThirdPartyUserId;
            workingVisitor.innerrange_user_id = reusableThirdPartyUserId;
            workingVisitor.reuse_third_party_user_id = true;
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = $1,
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE visitor_id = $3`,
                [reusableThirdPartyUserId, username, workingVisitor.visitor_id]
            );
        }

        const apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKIN", workingVisitor);
        const successResult = apiResults.find(item => item.success && String(item.provider_type || "").toUpperCase() === "INNERRANGE");
        const referenceResult = apiResults.find(item => item.success && item.reference_id && String(item.provider_type || "").toUpperCase() === "INNERRANGE");

        if (referenceResult?.reference_id) {
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = $1,
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE visitor_id = $3`,
                [referenceResult.reference_id, username, workingVisitor.visitor_id]
            );
            await upsertThirdPartyUserSlot(referenceResult.reference_id, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId && successResult) {
            await upsertThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId) {
            await releaseThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id);
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = NULL,
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE visitor_id = $2`,
                [username, workingVisitor.visitor_id]
            );
        }
    } catch (apiError) {
        console.log("THIRD PARTY CHECK-IN API BACKGROUND ERROR:", apiError.message);
        if (reusableThirdPartyUserId) {
            await releaseThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id);
        }
    }
}

function runCheckinFollowupBackground(req, visitor) {
    const reqLike = createBackgroundReq(req);
    const visitorSnapshot = { ...(visitor || {}) };
    runBackgroundTask(`CHECKIN FOLLOWUP VISITOR ${visitorSnapshot.visitor_id || "-"}`, async () => {
        await Promise.allSettled([
            sendHostCheckinEmail(reqLike, visitorSnapshot),
            sendVisitorCheckinQrEmail(reqLike, visitorSnapshot),
            runCheckinApiBackground(reqLike, visitorSnapshot)
        ]);
    });
}

const VISITOR_SCHEMA_PATHS = [
    "/register-visitor",
    "/visitors",
    "/api/public/qr-info",
    "/api/permission-groups",
    "/api/visitor-history",
    "/api/floors",
    "/api/invitations",
    "/api/hosts",
    "/api/host-notification-settings",
    "/api/qr-settings",
    "/api/smtp-settings",
    "/api/send-qr-email",
    "/api/whatsapp-settings",
    "/api/send-qr-whatsapp",
    "/api/whatsapp-opened",
    "/api/auto-checkout-settings",
    "/api/auto-checkout",
    "/api/visitor-log-filter-options",
    "/api/visitor-logs",
    "/api/visitor-stats",
    "/api/visitor-analytics",
    "/sync-acs",
    "/sync-lift",
    "/export-excel",
    "/card-reader"
];

router.use(VISITOR_SCHEMA_PATHS, async (req, res, next) => {
    try {
        await ensureVisitorSchema();
        next();
    } catch (error) {
        next(error);
    }
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, "uploads/"),
    filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage: storage });

// Register Visitor
router.post("/register-visitor", upload.fields([{ name: "visitor_photo", maxCount: 1 }, { name: "identity_photo", maxCount: 1 }]), async (req, res) => {
    try {
        const visitorPhoto = req.files["visitor_photo"] ? req.files["visitor_photo"][0].filename : null;
        const identityPhoto = req.files["identity_photo"] ? req.files["identity_photo"][0].filename : null;
        const { first_name, second_name, identity_number, identity_type, company_name, email_address, card_number, permission_group, purpose_note, start_date, expiry_date, host } = req.body;
        const bookingCode = normalizeBookingCode(req.body.booking_code);
        const phone_number = req.body.phone_number || req.body.telephone_number || null;
        const username = getCurrentUsername(req);
        const schindlerPersonId = await generateSchindlerPersonId();

        let bookingInvitation = null;
        if (bookingCode) {
            const validation = await validatePendingInvitationByCode(bookingCode);
            if (!validation.ok) {
                return res.status(validation.status).json({ success: false, message: validation.message });
            }
            bookingInvitation = validation.invitation;
        }
        
        const qrData = JSON.stringify({ first_name, second_name, company_name, host, card_number, start_date, expiry_date });
        const qrCode = await QRCode.toDataURL(qrData);
        
        const result = await pool.query(
            `INSERT INTO visitor_registration (
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note,
            visitor_photo,
            identity_photo,
            qr_code,
            start_date,
            expiry_date,
            schindler_person_id,
            created_by,
            created_time,
            check_in_time
            )
            VALUES (
            $1, $2, $3, $4, $5,
            $6, $7, $8, $9, $10,
            $11, $12, $13, $14, $15,
            $16, $17, $18,
            NOW(),
            NOW()
            )
            RETURNING *`,
            [
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note,
            visitorPhoto,
            identityPhoto,
            qrCode,
            start_date || null,
            expiry_date || null,
            schindlerPersonId,
            username
            ]
            );
            
        await saveActivityLog(
            req,
            "CHECK_IN_VISITOR",
            `Check in visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );

        if (bookingInvitation) {
            await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'CHECKED_IN',
                     checked_in_visitor_id = $1,
                     checked_in_time = NOW(),
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE invitation_id = $3`,
                [result.rows[0].visitor_id, username, bookingInvitation.invitation_id]
            );
            await saveActivityLog(
                req,
                "USE_BOOKING_CODE",
                `Use booking code ${bookingCode} for visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id})`
            );
        }

        runCheckinFollowupBackground(req, result.rows[0]);

        res.json({
            success: true,
            message: "Visitor registered",
            data: result.rows[0],
            api_results: [],
            background_processing: true
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Search Visitor by ID
router.get("/visitors/search", async (req, res) => {
    try {
        const { id } = req.query;
        const result = await pool.query("SELECT * FROM visitor_registration WHERE identity_number = $1 ORDER BY visitor_id DESC LIMIT 1", [id]);
        res.json(result.rows.length > 0 ? { found: true, ...result.rows[0] } : { found: false });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/api/public/qr-info", async (req, res) => {
    try {
        const cardNumber = String(req.query.card_number || "").trim();

        if (!cardNumber) {
            return res.status(400).json({ success: false, message: "Card number wajib diisi" });
        }

        const result = await pool.query(
            `SELECT first_name,
                    second_name,
                    company_name,
                    host,
                    permission_group,
                    purpose_note,
                    start_date,
                    expiry_date,
                    card_number
             FROM visitor_registration
             WHERE card_number = $1
             ORDER BY visitor_id DESC
             LIMIT 1`,
            [cardNumber]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "QR visitor tidak ditemukan" });
        }

        const settings = await pool.query("SELECT preview_title, preview_subtitle, show_card_number FROM qr_settings WHERE setting_id = 1");

        res.json({
            success: true,
            data: result.rows[0],
            settings: settings.rows[0] || {}
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/permission-groups", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT pg.group_id,
                   pg.group_name,
                   pg.integration_id,
                   pg.floor_id,
                   sf.floor_name,
                   sf.destination_code AS schindler_destination_floor_code,
                   sf.return_code AS schindler_return_floor_code,
                   CASE
                       WHEN sf.destination_code IS NOT NULL
                       THEN CONCAT('specific,', sf.destination_code, ',', sf.return_code)
                       ELSE ''
                   END AS schindler_auto_zone,
                   CASE
                       WHEN sf.destination_code IS NOT NULL
                       THEN CONCAT(sf.return_code, ',', sf.destination_code)
                       ELSE ''
                   END AS schindler_access_zones_always,
                   pg.description,
                   pg.created_at
            FROM permission_groups pg
            LEFT JOIN schindler_floors sf ON sf.floor_id = pg.floor_id
            ORDER BY pg.group_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/visitors/:id", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-history", async (req, res) => {
    try {
        const identityNumber = String(req.query.identity_number || "").trim();

        if (!identityNumber) {
            return res.status(400).json({ success: false, message: "Identity number wajib diisi" });
        }

        const result = await pool.query(
            `SELECT visitor_id,
                    first_name,
                    second_name,
                    identity_number,
                    company_name,
                    host,
                    permission_group,
                    purpose_note,
                    check_in_time,
                    check_out_time,
                    created_by
             FROM visitor_registration
             WHERE identity_number = $1
             ORDER BY check_in_time ASC NULLS LAST, visitor_id ASC`,
            [identityNumber]
        );

        res.json({
            success: true,
            data: {
                total_visits: result.rows.length,
                visits: result.rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/visitors/:id/check-integration", async (req, res) => {
    try {
        const provider = String(req.body.provider || "").trim().toUpperCase();
        const configId = req.body.config_id ? Number(req.body.config_id) : null;
        const triggerMap = {
            INNERRANGE: "CHECK_INNERRANGE",
            SCHINDLER: "CHECK_SCHINDLER"
        };
        const triggerEvent = triggerMap[provider];

        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Provider check tidak valid" });
        }

        const visitor = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);
        if (visitor.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, visitor.rows[0], {
            providerType: provider,
            configId
        });
        const providerResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === provider);

        if (providerResults.length === 0) {
            return res.status(400).json({
                success: false,
                message: `API check ${provider} belum dibuat/aktif. Buat setting API dengan mode ${triggerEvent}.`
            });
        }

        const ok = providerResults.some(item => item.success === true);

        res.json({
            success: ok,
            message: ok ? `Check ${provider} berhasil.` : `Check ${provider} gagal. Cek Log Activity API.`,
            data: providerResults,
            api_results: apiResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/visitors/:id/check-integration-configs", async (req, res) => {
    try {
        const provider = String(req.query.provider || "").trim().toUpperCase();
        const triggerMap = {
            INNERRANGE: "CHECK_INNERRANGE",
            SCHINDLER: "CHECK_SCHINDLER"
        };
        const triggerEvent = triggerMap[provider];

        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Provider check tidak valid" });
        }

        const result = await pool.query(
            `SELECT config_id,
                    config_name,
                    provider_type,
                    trigger_event,
                    action_type,
                    execution_order
             FROM third_party_api_configs
             WHERE is_active = TRUE
               AND provider_type = $1
               AND trigger_event = $2
             ORDER BY execution_order ASC, config_id ASC`,
            [provider, triggerEvent]
        );

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/visitors/:id", async (req, res) => {
    try {
        const {
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            telephone_number,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note
        } = req.body;

        const result = await pool.query(
            `UPDATE visitor_registration
             SET first_name = $1,
                 second_name = $2,
                 identity_number = $3,
                 identity_type = $4,
                 company_name = $5,
                 email_address = $6,
                 phone_number = $7,
                 host = $8,
                 card_number = $9,
                 permission_group = $10,
                 purpose_note = $11,
                 modified_by = $12,
                 modified_time = NOW()
             WHERE visitor_id = $13
             RETURNING *`,
            [
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number || telephone_number || null,
                host,
                card_number,
                permission_group,
                purpose_note,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            "EDIT_VISITOR",
            `Edit visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "EDIT", result.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY EDIT API ERROR:", apiError.message);
            }
        }

        res.json({ success: true, data: result.rows[0], api_results: apiResults });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/visitors/:id", async (req, res) => {
    try {
        const target = await pool.query(
            "SELECT * FROM visitor_registration WHERE visitor_id = $1",
            [req.params.id]
        );

        if (target.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "DELETE", target.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY DELETE API ERROR:", apiError.message);
            }
        }

        if (shouldReleaseInnerrangeSlot(apiResults)) {
            await releaseThirdPartyUserSlot(target.rows[0].third_party_user_id, target.rows[0].visitor_id);
        }

        await pool.query("DELETE FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);

        await saveActivityLog(
            req,
            "DELETE_VISITOR",
            `Delete visitor ${getVisitorDisplayName(target.rows[0])} (Visitor ID ${target.rows[0].visitor_id}, Card ${target.rows[0].card_number || "-"})`
        );

        res.json({ success: true, api_results: apiResults });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/permission-groups", async (req, res) => {
    try {
        const groupName = String(req.body.group_name || "").trim();
        const integrationId = String(req.body.integration_id || "").trim();
        const floorId = req.body.floor_id ? Number(req.body.floor_id) : null;
        const description = String(req.body.description || "").trim();

        if (!groupName) {
            return res.status(400).json({ success: false, message: "Nama grouping wajib diisi" });
        }

        const result = await pool.query(
            `INSERT INTO permission_groups (group_name, integration_id, floor_id, description)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [groupName, integrationId || null, floorId || null, description || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Grouping sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/permission-groups/:id", async (req, res) => {
    try {
        const groupName = String(req.body.group_name || "").trim();
        const integrationId = String(req.body.integration_id || "").trim();
        const floorId = req.body.floor_id ? Number(req.body.floor_id) : null;
        const description = String(req.body.description || "").trim();

        if (!groupName) {
            return res.status(400).json({ success: false, message: "Nama grouping wajib diisi" });
        }

        const result = await pool.query(
            `UPDATE permission_groups
             SET group_name = $1,
                 integration_id = $2,
                 floor_id = $3,
                 description = $4
             WHERE group_id = $5
             RETURNING *`,
            [groupName, integrationId || null, floorId || null, description || null, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Grouping tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Grouping sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/permission-groups/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM permission_groups WHERE group_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/floors", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT floor_id,
                   floor_name,
                   destination_code,
                   return_code,
                   CONCAT('specific,', destination_code, ',', return_code) AS schindler_auto_zone,
                   CONCAT(return_code, ',', destination_code) AS schindler_access_zones_always,
                   description,
                   created_at,
                   modified_at
            FROM schindler_floors
            ORDER BY floor_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/floors", async (req, res) => {
    try {
        const floorName = String(req.body.floor_name || "").trim();
        const destinationCode = String(req.body.destination_code || "").trim();
        const returnCode = String(req.body.return_code || "1").trim();
        const description = String(req.body.description || "").trim();

        if (!floorName) return res.status(400).json({ success: false, message: "Nama floor wajib diisi" });
        if (!destinationCode) return res.status(400).json({ success: false, message: "Kode lantai tujuan wajib diisi" });
        if (!returnCode) return res.status(400).json({ success: false, message: "Kode turun/lobby wajib diisi" });

        const result = await pool.query(
            `INSERT INTO schindler_floors (floor_name, destination_code, return_code, description)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [floorName, destinationCode, returnCode, description || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Floor sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/floors/:id", async (req, res) => {
    try {
        const floorName = String(req.body.floor_name || "").trim();
        const destinationCode = String(req.body.destination_code || "").trim();
        const returnCode = String(req.body.return_code || "1").trim();
        const description = String(req.body.description || "").trim();

        if (!floorName) return res.status(400).json({ success: false, message: "Nama floor wajib diisi" });
        if (!destinationCode) return res.status(400).json({ success: false, message: "Kode lantai tujuan wajib diisi" });
        if (!returnCode) return res.status(400).json({ success: false, message: "Kode turun/lobby wajib diisi" });

        const result = await pool.query(
            `UPDATE schindler_floors
             SET floor_name = $1,
                 destination_code = $2,
                 return_code = $3,
                 description = $4,
                 modified_at = NOW()
             WHERE floor_id = $5
             RETURNING *`,
            [floorName, destinationCode, returnCode, description || null, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Floor tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Floor sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/floors/:id", async (req, res) => {
    try {
        const usage = await pool.query("SELECT COUNT(*)::int AS total FROM permission_groups WHERE floor_id = $1", [req.params.id]);
        if ((usage.rows[0]?.total || 0) > 0) {
            return res.status(400).json({ success: false, message: "Floor masih dipakai di Permission Group" });
        }

        await pool.query("DELETE FROM schindler_floors WHERE floor_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/invitations", async (req, res) => {
    try {
        const includeCheckedIn = req.query.include_checked_in === "true";
        const statusFilter = includeCheckedIn ? "" : "WHERE status <> 'CHECKED_IN'";
        const result = await pool.query(`
            SELECT *
            FROM visitor_invitations
            ${statusFilter}
            ORDER BY invitation_id DESC
            LIMIT 500
        `);
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations", async (req, res) => {
    try {
        const body = req.body || {};
        const firstName = String(body.first_name || "").trim();
        const secondName = String(body.second_name || "").trim();
        const email = String(body.email_address || "").trim();
        const phone = String(body.phone_number || body.telephone_number || "").trim();
        const host = String(body.host || "").trim();

        if (!firstName) return res.status(400).json({ success: false, message: "First name wajib diisi." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib diisi." });
        if (!email && !phone) return res.status(400).json({ success: false, message: "Isi email atau nomor WhatsApp visitor." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const bookingCode = await generateBookingCode();
        const result = await pool.query(
            `INSERT INTO visitor_invitations (
                booking_code,
                status,
                first_name,
                second_name,
                company_name,
                email_address,
                phone_number,
                host,
                start_date,
                expiry_date,
                permission_group,
                purpose_note,
                created_by,
                created_time
             )
             VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())
             RETURNING *`,
            [
                bookingCode,
                firstName,
                secondName || null,
                String(body.company_name || "").trim() || null,
                email || null,
                phone || null,
                host,
                body.start_date || null,
                body.expiry_date || null,
                String(body.permission_group || "Visitor").trim() || "Visitor",
                String(body.purpose_note || "").trim() || null,
                getCurrentUsername(req)
            ]
        );

        const invitation = result.rows[0];
        let emailWarning = null;
        if (body.send_email === true && invitation.email_address) {
            try {
                await sendBookingInvitationEmail(req, invitation);
            } catch (emailError) {
                emailWarning = emailError.message;
                await createSystemNotification(req, {
                    channel: "EMAIL_VISITOR",
                    event_type: "INVITATION",
                    status: "FAILED",
                    visitor_name: getVisitorDisplayName(invitation),
                    target: invitation.email_address,
                    title: "Email invitation gagal",
                    message: emailError.message,
                    detail: { booking_code: bookingCode }
                });
            }
        }

        await saveActivityLog(
            req,
            "CREATE_VISITOR_INVITATION",
            `Create booking invitation ${bookingCode} for ${getVisitorDisplayName(invitation)}`
        );

        res.json({ success: true, data: invitation, email_warning: emailWarning });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function normalizeImportHeader(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "");
}

function getImportValue(row, aliases) {
    for (const alias of aliases) {
        const value = row[alias];
        if (value !== undefined && value !== null && String(value).trim() !== "") return value;
    }
    return "";
}

function normalizeExcelDateValue(value) {
    if (!value) return null;
    if (value instanceof Date) return value;
    const text = String(value).trim();
    if (!text) return null;

    const dmyMatch = text.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})(?:[,\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (dmyMatch) {
        const [, day, month, year, hour = "0", minute = "0", second = "0"] = dmyMatch;
        return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }

    const ymdMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (ymdMatch) {
        const [, year, month, day, hour = "0", minute = "0", second = "0"] = ymdMatch;
        return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }

    const date = new Date(text);
    return Number.isNaN(date.getTime()) ? text : date;
}

function isPastDateValue(value) {
    if (!value) return false;
    const date = value instanceof Date ? value : new Date(value);
    return !Number.isNaN(date.getTime()) && date < new Date();
}

async function sendImportedInvitationEmails(reqLike, invitations) {
    const list = Array.isArray(invitations) ? invitations : [];
    for (const invitation of list) {
        if (!invitation?.email_address) {
            await createSystemNotification(reqLike, {
                channel: "EMAIL_VISITOR",
                event_type: "INVITATION_IMPORT",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                title: "Email invitation import gagal",
                message: "Email visitor belum diisi, booking code tidak bisa dikirim otomatis.",
                detail: { booking_code: invitation?.booking_code || null, invitation_id: invitation?.invitation_id || null }
            });
            continue;
        }

        try {
            await sendBookingInvitationEmail(reqLike, invitation);
        } catch (emailError) {
            await createSystemNotification(reqLike, {
                channel: "EMAIL_VISITOR",
                event_type: "INVITATION_IMPORT",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                target: invitation.email_address,
                title: "Email invitation import gagal",
                message: emailError.message,
                detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id }
            });
        }
    }
}

router.get("/api/invitations/template", async (req, res) => {
    try {
        const workbook = new ExcelJS.Workbook();
        workbook.creator = "Innersync";
        workbook.created = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const sampleStart = `${tomorrow.getFullYear()}-${pad2(tomorrow.getMonth() + 1)}-${pad2(tomorrow.getDate())} 09:00`;
        const sampleExpiry = `${tomorrow.getFullYear()}-${pad2(tomorrow.getMonth() + 1)}-${pad2(tomorrow.getDate())} 17:00`;

        const worksheet = workbook.addWorksheet("Invitation Template");
        worksheet.columns = [
            { header: "First Name", key: "first_name", width: 18 },
            { header: "Second Name", key: "second_name", width: 18 },
            { header: "Company", key: "company", width: 24 },
            { header: "Email", key: "email", width: 28 },
            { header: "Phone", key: "phone", width: 18 },
            { header: "Host", key: "host", width: 24 },
            { header: "Start Date", key: "start_date", width: 22 },
            { header: "Expiry Date", key: "expiry_date", width: 22 },
            { header: "Grouping", key: "grouping", width: 18 },
            { header: "Keperluan", key: "keperluan", width: 32 }
        ];

        worksheet.getRow(1).eachCell((cell) => {
            cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
            cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1677FF" } };
            cell.alignment = { vertical: "middle", horizontal: "center" };
            cell.border = {
                top: { style: "thin", color: { argb: "FFD1D5DB" } },
                left: { style: "thin", color: { argb: "FFD1D5DB" } },
                bottom: { style: "thin", color: { argb: "FFD1D5DB" } },
                right: { style: "thin", color: { argb: "FFD1D5DB" } }
            };
        });
        worksheet.getRow(1).height = 24;

        worksheet.addRow({
            first_name: "Budi",
            second_name: "Santoso",
            company: "PT Contoh",
            email: "budi@example.com",
            phone: "081234567890",
            host: "PT EPCON MULTI GUNA",
            start_date: sampleStart,
            expiry_date: sampleExpiry,
            grouping: "Visitor",
            keperluan: "Meeting"
        });

        worksheet.views = [{ state: "frozen", ySplit: 1 }];
        worksheet.autoFilter = "A1:J1";
        worksheet.getColumn("start_date").numFmt = "yyyy-mm-dd hh:mm";
        worksheet.getColumn("expiry_date").numFmt = "yyyy-mm-dd hh:mm";

        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", "attachment; filename=\"invitation_import_template.xlsx\"");
        await workbook.xlsx.write(res);
        res.end();
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/import", upload.single("invitation_file"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "Pilih file Excel terlebih dahulu." });
        }

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(req.file.path);
        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
            return res.status(400).json({ success: false, message: "Sheet Excel tidak ditemukan." });
        }

        const headerRow = worksheet.getRow(1);
        const headers = {};
        headerRow.eachCell((cell, colNumber) => {
            const key = normalizeImportHeader(cell.value?.text || cell.value);
            if (key) headers[colNumber] = key;
        });

        const imported = [];
        const errors = [];

        for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber += 1) {
            const excelRow = worksheet.getRow(rowNumber);
            const row = {};
            excelRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                const key = headers[colNumber];
                if (!key) return;
                const value = cell.value?.text ?? cell.value?.result ?? cell.value;
                row[key] = value instanceof Date ? value : String(value ?? "").trim();
            });

            const firstName = String(getImportValue(row, ["first_name", "firstname", "nama_depan", "nama", "visitor_name", "name"]) || "").trim();
            const secondName = String(getImportValue(row, ["second_name", "lastname", "last_name", "nama_belakang"]) || "").trim();
            const email = String(getImportValue(row, ["email", "email_address", "email_visitor"]) || "").trim();
            const phone = String(getImportValue(row, ["phone", "phone_number", "whatsapp", "wa", "telephone", "telephone_number"]) || "").trim();
            const host = String(getImportValue(row, ["host", "nama_host"]) || "").trim();
            const startDateValue = normalizeExcelDateValue(getImportValue(row, ["start", "start_date", "tanggal_start", "check_in", "checkin"]));
            const expiryDateValue = normalizeExcelDateValue(getImportValue(row, ["expiry", "expiry_date", "expired", "tanggal_expiry"]));

            const isEmptyRow = !firstName && !secondName && !email && !phone && !host;
            if (isEmptyRow) continue;

            if (!firstName) {
                errors.push({ row: rowNumber, message: "First Name wajib diisi." });
                continue;
            }
            if (!host) {
                errors.push({ row: rowNumber, message: "Host wajib diisi." });
                continue;
            }
            if (!email && !phone) {
                errors.push({ row: rowNumber, message: "Email atau WhatsApp wajib diisi." });
                continue;
            }
            if (isPastDateValue(expiryDateValue)) {
                errors.push({ row: rowNumber, message: "Expiry Date sudah lewat, booking code tidak dibuat." });
                continue;
            }

            const bookingCode = await generateBookingCode();
            const result = await pool.query(
                `INSERT INTO visitor_invitations (
                    booking_code,
                    status,
                    first_name,
                    second_name,
                    company_name,
                    email_address,
                    phone_number,
                    host,
                    start_date,
                    expiry_date,
                    permission_group,
                    purpose_note,
                    created_by,
                    created_time
                 )
                 VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())
                 RETURNING *`,
                [
                    bookingCode,
                    firstName,
                    secondName || null,
                    String(getImportValue(row, ["company", "company_name", "perusahaan"]) || "").trim() || null,
                    email || null,
                    phone || null,
                    host,
                    startDateValue,
                    expiryDateValue,
                    String(getImportValue(row, ["grouping", "permission_group", "group"]) || "Visitor").trim() || "Visitor",
                    String(getImportValue(row, ["keperluan", "purpose", "purpose_note", "note", "notes"]) || "").trim() || null,
                    getCurrentUsername(req)
                ]
            );
            imported.push(result.rows[0]);
        }

        await saveActivityLog(
            req,
            "IMPORT_VISITOR_INVITATION",
            `Import invitation XLS selesai. Imported ${imported.length}, failed ${errors.length}.`
        );

        if (imported.length > 0) {
            const reqLike = createBackgroundReq(req);
            const importedSnapshot = imported.map(item => ({ ...item }));
            runBackgroundTask("IMPORT INVITATION EMAIL", () => sendImportedInvitationEmails(reqLike, importedSnapshot));
        }

        res.json({
            success: true,
            imported: imported.length,
            failed: errors.length,
            email_processing: imported.length > 0,
            email_total: imported.length,
            errors,
            data: imported
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/invitations/:id", async (req, res) => {
    try {
        const body = req.body || {};
        const firstName = String(body.first_name || "").trim();
        const host = String(body.host || "").trim();
        if (!firstName) return res.status(400).json({ success: false, message: "First name wajib diisi." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib diisi." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const current = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        if (!current.rows.length) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (!["PENDING", "EXPIRED"].includes(current.rows[0].status)) {
            return res.status(400).json({ success: false, message: "Invitation yang sudah check-in/cancel tidak bisa diedit." });
        }

        const result = await pool.query(
            `UPDATE visitor_invitations
             SET first_name = $1,
                 second_name = $2,
                 company_name = $3,
                 email_address = $4,
                 phone_number = $5,
                 host = $6,
                 start_date = $7,
                 expiry_date = $8,
                 permission_group = $9,
                 purpose_note = $10,
                 status = 'PENDING',
                 modified_by = $11,
                 modified_time = NOW()
             WHERE invitation_id = $12
             RETURNING *`,
            [
                firstName,
                String(body.second_name || "").trim() || null,
                String(body.company_name || "").trim() || null,
                String(body.email_address || "").trim() || null,
                String(body.phone_number || body.telephone_number || "").trim() || null,
                host,
                body.start_date || null,
                body.expiry_date || null,
                String(body.permission_group || "Visitor").trim() || "Visitor",
                String(body.purpose_note || "").trim() || null,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/:id/send-email", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        const invitation = result.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        await sendBookingInvitationEmail(req, invitation);
        res.json({ success: true, message: "Email booking code berhasil dikirim." });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "INVITATION",
            status: "FAILED",
            title: "Email invitation gagal",
            message: error.message,
            detail: { invitation_id: req.params.id }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/invitations/:id/whatsapp-sent", async (req, res) => {
    try {
        const result = await pool.query(
            "UPDATE visitor_invitations SET sent_whatsapp_time = NOW(), modified_by = $1, modified_time = NOW() WHERE invitation_id = $2 RETURNING *",
            [getCurrentUsername(req), req.params.id]
        );
        const invitation = result.rows[0];
        if (invitation) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "INVITATION",
                status: "OPENED",
                visitor_name: getVisitorDisplayName(invitation),
                target: normalizeWhatsappPhone(invitation.phone_number) || invitation.phone_number || null,
                title: "WhatsApp invitation dibuka",
                message: `WhatsApp booking code ${invitation.booking_code} sudah dibuka. Operator perlu klik kirim.`,
                detail: { booking_code: invitation.booking_code, mode: "MANUAL" }
            });
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/:id/cancel", async (req, res) => {
    try {
        const reason = String(req.body?.reason || "").trim();
        const result = await pool.query(
            `UPDATE visitor_invitations
             SET status = 'CANCELLED',
                 cancel_reason = $1,
                 cancelled_time = NOW(),
                 modified_by = $2,
                 modified_time = NOW()
             WHERE invitation_id = $3
               AND status IN ('PENDING', 'EXPIRED')
             RETURNING *`,
            [reason || null, getCurrentUsername(req), req.params.id]
        );
        if (!result.rows.length) return res.status(400).json({ success: false, message: "Invitation tidak bisa dicancel." });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/invitations/:id", async (req, res) => {
    try {
        const current = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        const invitation = current.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (!["CANCELLED", "EXPIRED"].includes(invitation.status)) {
            return res.status(400).json({ success: false, message: "Hanya invitation CANCELLED atau EXPIRED yang bisa dihapus." });
        }

        await pool.query("DELETE FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        await saveActivityLog(
            req,
            "DELETE_VISITOR_INVITATION",
            `Delete ${invitation.status.toLowerCase()} invitation ${invitation.booking_code} for ${getVisitorDisplayName(invitation)}`
        );
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/invitations/booking/:code", async (req, res) => {
    try {
        const validation = await validatePendingInvitationByCode(req.params.code);
        if (!validation.ok) return res.status(validation.status).json({ success: false, message: validation.message });
        res.json({ success: true, data: validation.invitation });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/hosts", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT host_id, host_name, host_email, location, note, description, created_at, modified_at
            FROM visitor_hosts
            ORDER BY host_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/hosts", async (req, res) => {
    try {
        const hostName = String(req.body.host_name || "").trim();
        const hostEmail = String(req.body.host_email || "").trim();
        const location = String(req.body.location || "").trim();
        const note = String(req.body.note || req.body.description || "").trim();

        if (!hostName) {
            return res.status(400).json({ success: false, message: "Nama host wajib diisi" });
        }

        const result = await pool.query(
            `INSERT INTO visitor_hosts (host_name, host_email, location, note, description)
             VALUES ($1, $2, $3, $4, $4)
             RETURNING *`,
            [hostName, hostEmail || null, location || null, note || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Host sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/hosts/:id", async (req, res) => {
    try {
        const hostName = String(req.body.host_name || "").trim();
        const hostEmail = String(req.body.host_email || "").trim();
        const location = String(req.body.location || "").trim();
        const note = String(req.body.note || req.body.description || "").trim();

        if (!hostName) {
            return res.status(400).json({ success: false, message: "Nama host wajib diisi" });
        }

        const result = await pool.query(
            `UPDATE visitor_hosts
             SET host_name = $1,
                 host_email = $2,
                 location = $3,
                 note = $4,
                 description = $4,
                 modified_at = NOW()
             WHERE host_id = $5
             RETURNING *`,
            [hostName, hostEmail || null, location || null, note || null, req.params.id]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Host tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Host sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.get("/api/hosts/:id/visitors", async (req, res) => {
    try {
        const hostResult = await pool.query(
            `SELECT host_id, host_name, host_email, location, note, description, created_at, modified_at
             FROM visitor_hosts
             WHERE host_id = $1`,
            [req.params.id]
        );

        if (!hostResult.rows.length) {
            return res.status(404).json({ success: false, message: "Host tidak ditemukan" });
        }

        const host = hostResult.rows[0];
        const visitorsResult = await pool.query(
            `SELECT visitor_id,
                    first_name,
                    second_name,
                    identity_number,
                    company_name,
                    email_address,
                    phone_number,
                    card_number,
                    permission_group,
                    purpose_note,
                    check_in_time,
                    check_out_time,
                    created_by,
                    created_time,
                    modified_by,
                    modified_time
             FROM visitor_registration
             WHERE host = $1
             ORDER BY check_in_time DESC NULLS LAST, visitor_id DESC`,
            [host.host_name]
        );

        const rows = visitorsResult.rows;
        const uniqueVisitors = new Set(
            rows.map(row => String(row.identity_number || "").trim()).filter(Boolean)
        );

        res.json({
            success: true,
            data: {
                host,
                summary: {
                    total_visits: rows.length,
                    active_visits: rows.filter(row => !row.check_out_time).length,
                    checked_out_visits: rows.filter(row => row.check_out_time).length,
                    unique_visitors: uniqueVisitors.size
                },
                visitors: rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/host-notification-settings", async (req, res) => {
    try {
        const settings = await getHostNotificationSettings();
        res.json({
            success: true,
            data: {
                enabled: settings?.enabled === true,
                email_subject: settings?.email_subject || "Visitor Check-In - {{visitor_name}}",
                email_body: settings?.email_body || ""
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/host-notification-settings", async (req, res) => {
    try {
        const emailSubject = String(req.body.email_subject || "Visitor Check-In - {{visitor_name}}").trim();
        const emailBody = String(req.body.email_body || "").trim()
            || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}";

        const result = await pool.query(
            `UPDATE host_notification_settings
             SET enabled = $1,
                 email_subject = $2,
                 email_body = $3,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [req.body.enabled === true, emailSubject, emailBody]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/hosts/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM visitor_hosts WHERE host_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/qr-settings", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/qr-settings", async (req, res) => {
    try {
        const digitLength = Math.min(Math.max(parseInt(req.body.digit_length, 10) || 10, 4), 24);
        const previewTitle = String(req.body.preview_title || "Visitor QR Code").trim();
        const previewSubtitle = String(req.body.preview_subtitle || "QR Code dibuat dari Card Number").trim();
        const showCardNumber = req.body.show_card_number !== false;
        const autoEmail = req.body.auto_email === true;
        const autoWhatsapp = req.body.auto_whatsapp === true;
        const autoSms = req.body.auto_sms === true;
        const publicBaseUrl = String(req.body.public_base_url || "").trim();

        const result = await pool.query(
            `UPDATE qr_settings
             SET digit_length = $1,
                 preview_title = $2,
                 preview_subtitle = $3,
                 show_card_number = $4,
                 auto_email = $5,
                 auto_whatsapp = $6,
                 auto_sms = $7,
                 public_base_url = $8,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [digitLength, previewTitle, previewSubtitle, showCardNumber, autoEmail, autoWhatsapp, autoSms, publicBaseUrl || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/smtp-settings", async (req, res) => {
    try {
        const settings = await getSmtpSettings();
        if (!settings) {
            return res.json({ success: true, data: null });
        }

        res.json({
            success: true,
            data: {
                smtp_host: settings.smtp_host || "",
                smtp_port: settings.smtp_port || 587,
                smtp_secure: settings.smtp_secure === true,
                smtp_user: settings.smtp_user || "",
                smtp_pass: settings.smtp_pass || "",
                password_configured: Boolean(settings.smtp_pass),
                from_email: settings.from_email || "",
                from_name: settings.from_name || "Visitor Registration",
                email_subject: settings.email_subject || "Visitor QR Code - {{visitor_name}}",
                email_body: settings.email_body || "",
                invitation_email_subject: settings.invitation_email_subject || "Visitor Invitation - {{booking_code}}",
                invitation_email_body: settings.invitation_email_body || "Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang."
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/smtp-settings", async (req, res) => {
    try {
        const current = await getSmtpSettings();
        const smtpHost = String(req.body.smtp_host || "").trim();
        const smtpPort = parseInt(req.body.smtp_port, 10) || 587;
        const smtpSecure = req.body.smtp_secure === true;
        const smtpUser = String(req.body.smtp_user || "").trim();
        const smtpPass = String(req.body.smtp_pass || "").trim();
        const fromEmail = String(req.body.from_email || "").trim();
        const fromName = String(req.body.from_name || "Visitor Registration").trim();
        const emailSubject = String(req.body.email_subject || "Visitor QR Code - {{visitor_name}}").trim();
        const emailBody = String(req.body.email_body || "").trim();
        const invitationEmailSubject = String(req.body.invitation_email_subject || "Visitor Invitation - {{booking_code}}").trim();
        const invitationEmailBody = String(req.body.invitation_email_body || "").trim();

        const result = await pool.query(
            `UPDATE smtp_settings
             SET smtp_host = $1,
                 smtp_port = $2,
                 smtp_secure = $3,
                 smtp_user = $4,
                 smtp_pass = $5,
                 from_email = $6,
                 from_name = $7,
                 email_subject = $8,
                 email_body = $9,
                 invitation_email_subject = $10,
                 invitation_email_body = $11,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                smtpHost || null,
                smtpPort,
                smtpSecure,
                smtpUser || null,
                smtpPass || current?.smtp_pass || null,
                fromEmail || null,
                fromName || "Visitor Registration",
                emailSubject || "Visitor QR Code - {{visitor_name}}",
                emailBody || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
                invitationEmailSubject || "Visitor Invitation - {{booking_code}}",
                invitationEmailBody || "Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang."
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/smtp-settings/test", async (req, res) => {
    try {
        const testEmail = String(req.body.test_email || "").trim();
        if (!testEmail) {
            return res.status(400).json({ success: false, message: "Email tujuan test wajib diisi." });
        }

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: testEmail,
            subject: "SMTP Test - Visitor Registration",
            text: "SMTP berhasil digunakan untuk mengirim email dari Visitor Registration Portal."
        });

        res.json({ success: true, message: "Test email berhasil dikirim." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/send-qr-email", async (req, res) => {
    try {
        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const {
            to_email,
            visitor_name,
            host,
            start,
            expiry,
            card_number,
            share_url,
            image_base64
        } = req.body;

        const targetEmail = String(to_email || "").trim();
        if (!targetEmail) {
            return res.status(400).json({ success: false, message: "Email visitor belum diisi." });
        }

        if (!image_base64) {
            return res.status(400).json({ success: false, message: "Gambar QR belum tersedia." });
        }

        const templateData = {
            visitor_name: visitor_name || "Visitor",
            host: host || "-",
            start: start || "-",
            expiry: expiry || "-",
            card_number: card_number || "-",
            share_url: share_url || "-"
        };

        const subject = buildTemplate(settings.email_subject, templateData);
        const body = buildTemplate(settings.email_body, templateData);
        const imageBuffer = Buffer.from(String(image_base64).replace(/^data:image\/png;base64,/, ""), "base64");

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body,
            attachments: [
                {
                    filename: `QR_${String(card_number || "visitor").replace(/[^a-z0-9_-]+/gi, "_")}.png`,
                    content: imageBuffer,
                    contentType: "image/png"
                }
            ]
        });

        await saveActivityLog(
            req,
            "SEND_QR_EMAIL",
            `Send QR email to ${targetEmail} for ${visitor_name || "Visitor"} (Card ${card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_name: visitor_name || "Visitor",
            target: targetEmail,
            title: "Email QR ke Visitor berhasil",
            message: `QR Code visitor berhasil dikirim ke ${targetEmail}.`,
            detail: { card_number: card_number || null, share_url: share_url || null }
        });

        res.json({ success: true, message: "Email QR berhasil dikirim." });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_name: req.body?.visitor_name || "Visitor",
            target: req.body?.to_email || null,
            title: "Email QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: req.body?.card_number || null }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/whatsapp-settings", async (req, res) => {
    try {
        const settings = await getWhatsappSettings();
        res.json({
            success: true,
            data: {
                send_mode: settings?.send_mode || "manual",
                provider: settings?.provider || "meta",
                phone_number_id: settings?.phone_number_id || "",
                api_version: settings?.api_version || "v20.0",
                token_configured: Boolean(settings?.access_token),
                message_template: settings?.message_template || ""
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/whatsapp-settings", async (req, res) => {
    try {
        const current = await getWhatsappSettings();
        const sendMode = ["manual", "api"].includes(req.body.send_mode) ? req.body.send_mode : "manual";
        const provider = String(req.body.provider || "meta").trim() || "meta";
        const accessToken = String(req.body.access_token || "").trim();
        const phoneNumberId = String(req.body.phone_number_id || "").trim();
        const apiVersion = String(req.body.api_version || "v20.0").trim() || "v20.0";
        const messageTemplate = String(req.body.message_template || "").trim()
            || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}";

        const result = await pool.query(
            `UPDATE whatsapp_settings
             SET send_mode = $1,
                 provider = $2,
                 access_token = $3,
                 phone_number_id = $4,
                 api_version = $5,
                 message_template = $6,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                sendMode,
                provider,
                accessToken || current?.access_token || null,
                phoneNumberId || null,
                apiVersion,
                messageTemplate
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/send-qr-whatsapp", async (req, res) => {
    try {
        const settings = await getWhatsappSettings();

        if (!settings || settings.send_mode !== "api") {
            return res.status(400).json({ success: false, message: "Mode WhatsApp API belum aktif." });
        }

        if (settings.provider !== "meta") {
            return res.status(400).json({ success: false, message: "Provider WhatsApp belum didukung. Gunakan Meta Cloud API." });
        }

        if (!settings.access_token || !settings.phone_number_id) {
            return res.status(400).json({ success: false, message: "Access token dan Phone Number ID wajib diisi." });
        }

        const {
            to_phone,
            visitor_name,
            host,
            start,
            expiry,
            card_number,
            share_url,
            image_base64
        } = req.body;

        const targetPhone = normalizeWhatsappPhone(to_phone);
        if (!targetPhone) {
            return res.status(400).json({ success: false, message: "Nomor WhatsApp visitor belum diisi." });
        }

        if (!image_base64) {
            return res.status(400).json({ success: false, message: "Gambar QR belum tersedia." });
        }

        const templateData = {
            visitor_name: visitor_name || "Visitor",
            host: host || "-",
            start: start || "-",
            expiry: expiry || "-",
            card_number: card_number || "-",
            share_url: share_url || "-"
        };
        const caption = buildTemplate(settings.message_template, templateData);
        const apiVersion = settings.api_version || "v20.0";
        const baseUrl = `https://graph.facebook.com/${apiVersion}/${settings.phone_number_id}`;
        const imageBuffer = Buffer.from(String(image_base64).replace(/^data:image\/png;base64,/, ""), "base64");

        const uploadForm = new FormData();
        uploadForm.append("messaging_product", "whatsapp");
        uploadForm.append("type", "image/png");
        uploadForm.append("file", new Blob([imageBuffer], { type: "image/png" }), `QR_${card_number || "visitor"}.png`);

        const uploadResponse = await fetch(`${baseUrl}/media`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${settings.access_token}`
            },
            body: uploadForm
        });
        const uploadResult = await uploadResponse.json();

        if (!uploadResponse.ok || !uploadResult.id) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_name: visitor_name || "Visitor",
                target: targetPhone,
                title: "WhatsApp QR gagal",
                message: uploadResult.error?.message || "Upload media WhatsApp gagal.",
                detail: { provider: "META", card_number: card_number || null, stage: "media_upload" }
            });
            return res.status(500).json({
                success: false,
                message: uploadResult.error?.message || "Upload media WhatsApp gagal."
            });
        }

        const sendResponse = await fetch(`${baseUrl}/messages`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${settings.access_token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                messaging_product: "whatsapp",
                to: targetPhone,
                type: "image",
                image: {
                    id: uploadResult.id,
                    caption
                }
            })
        });
        const sendResult = await sendResponse.json();

        if (!sendResponse.ok) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_name: visitor_name || "Visitor",
                target: targetPhone,
                title: "WhatsApp QR gagal",
                message: sendResult.error?.message || "Kirim WhatsApp API gagal.",
                detail: { provider: "META", card_number: card_number || null, stage: "message_send" }
            });
            return res.status(500).json({
                success: false,
                message: sendResult.error?.message || "Kirim WhatsApp API gagal."
            });
        }

        await saveActivityLog(
            req,
            "SEND_QR_WHATSAPP",
            `Send QR WhatsApp API to ${targetPhone} for ${visitor_name || "Visitor"} (Card ${card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_name: visitor_name || "Visitor",
            target: targetPhone,
            title: "WhatsApp QR berhasil",
            message: `QR Code visitor berhasil dikirim via WhatsApp Business API ke ${targetPhone}.`,
            detail: { provider: "META", card_number: card_number || null, response: sendResult }
        });

        res.json({ success: true, message: "WhatsApp QR berhasil dikirim via API.", data: sendResult });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_name: req.body?.visitor_name || "Visitor",
            target: req.body?.to_phone || null,
            title: "WhatsApp QR gagal",
            message: error.message,
            detail: { provider: "META", card_number: req.body?.card_number || null }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/whatsapp-opened", async (req, res) => {
    try {
        const targetPhone = normalizeWhatsappPhone(req.body?.to_phone);
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: req.body?.event_type || "QR_SHARE",
            status: "OPENED",
            visitor_id: req.body?.visitor_id || null,
            visitor_name: req.body?.visitor_name || "Visitor",
            target: targetPhone || req.body?.to_phone || null,
            title: "WhatsApp dibuka",
            message: targetPhone
                ? `WhatsApp dibuka ke nomor ${targetPhone}. Operator perlu klik kirim.`
                : "WhatsApp dibuka tanpa nomor tujuan. Operator perlu memilih nomor dan klik kirim.",
            detail: {
                mode: "MANUAL",
                card_number: req.body?.card_number || null,
                booking_code: req.body?.booking_code || null
            }
        });
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/auto-checkout-settings", async (req, res) => {
    try {
        const settings = await getAutoCheckoutSettings();
        res.json({
            success: true,
            data: {
                ...settings,
                schedule_date: normalizeDate(settings.schedule_date),
                schedule_time: normalizeTime(settings.schedule_time),
                schedule_type: normalizeScheduleType(settings.schedule_type)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/auto-checkout-settings", async (req, res) => {
    try {
        const body = req.body || {};
        const result = await pool.query(
            `UPDATE auto_checkout_settings
             SET enabled = $1,
                 schedule_date = $2,
                 schedule_time = $3,
                 schedule_type = $4,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                body.enabled === true,
                normalizeDate(body.schedule_date),
                normalizeTime(body.schedule_time),
                normalizeScheduleType(body.schedule_type)
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/auto-checkout/run-now", async (req, res) => {
    try {
        const result = await runAutoCheckout(getCurrentUsername(req), req.ip);
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update Check-In / Check-Out
router.post("/visitors/update-status", async (req, res) => {
    try {

        const { id, type } = req.body;

        const column =
            (type === 'checkin')
            ? 'check_in_time'
            : 'check_out_time';

        const result = await pool.query(
            `UPDATE visitor_registration
             SET ${column} = NOW(),
                 modified_by = $2,
                 modified_time = NOW()
             WHERE visitor_id = $1
             RETURNING *`,
            [id, getCurrentUsername(req)]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            type === "checkin" ? "CHECK_IN_VISITOR" : "CHECK_OUT_VISITOR",
            `${type === "checkin" ? "Check in" : "Check out"} visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );
        if (type === "checkin") {
            runCheckinFollowupBackground(req, result.rows[0]);
            return res.json({
                success: true,
                api_results: [],
                background_processing: true
            });
        }

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "CHECKOUT", result.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY STATUS API ERROR:", apiError.message);
            }
        }

        if (shouldReleaseInnerrangeSlot(apiResults)) {
            await releaseThirdPartyUserSlot(result.rows[0].third_party_user_id, result.rows[0].visitor_id);
        }

        res.json({
            success: true,
            api_results: apiResults
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});

// ACTIVE VISITORS ONLY
router.get("/visitors", async (req, res) => {
    try {

        const result = await pool.query(`

            SELECT *
            FROM visitor_registration
            WHERE check_out_time IS NULL
            ORDER BY check_in_time ASC, visitor_id ASC

        `);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});


// ALL VISITOR LOGS
router.get("/api/visitor-log-filter-options", async (req, res) => {
    try {
        const [operators, groups, hosts] = await Promise.all([
            pool.query(`
                SELECT DISTINCT created_by
                FROM visitor_registration
                WHERE created_by IS NOT NULL
                  AND TRIM(created_by) <> ''
                ORDER BY created_by ASC
            `),
            pool.query(`
                SELECT group_name
                FROM permission_groups
                ORDER BY group_name ASC
            `),
            pool.query(`
                SELECT host_name
                FROM visitor_hosts
                ORDER BY host_name ASC
            `)
        ]);

        res.json({
            success: true,
            data: {
                operators: operators.rows.map(row => row.created_by),
                groups: groups.rows.map(row => row.group_name),
                hosts: hosts.rows.map(row => row.host_name)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-logs", async (req, res) => {
    try {
        const {
            created_by,
            visitor_name,
            permission_group,
            host,
            check_in_from,
            check_in_to,
            check_out_from,
            check_out_to
        } = req.query;

        const filters = ["check_out_time IS NOT NULL"];
        const params = [];

        const addParam = (value) => {
            params.push(value);
            return `$${params.length}`;
        };

        if (created_by) {
            filters.push(`created_by = ${addParam(created_by)}`);
        }

        if (visitor_name) {
            filters.push(`CONCAT_WS(' ', first_name, second_name) ILIKE ${addParam(`%${visitor_name}%`)}`);
        }

        if (permission_group) {
            filters.push(`permission_group = ${addParam(permission_group)}`);
        }

        if (host) {
            filters.push(`host = ${addParam(host)}`);
        }

        if (check_in_from) {
            filters.push(`check_in_time >= ${addParam(check_in_from)}::timestamp`);
        }

        if (check_in_to) {
            filters.push(`check_in_time <= ${addParam(check_in_to)}::timestamp`);
        }

        if (check_out_from) {
            filters.push(`check_out_time >= ${addParam(check_out_from)}::timestamp`);
        }

        if (check_out_to) {
            filters.push(`check_out_time <= ${addParam(check_out_to)}::timestamp`);
        }

        const result = await pool.query(`

            SELECT *
            FROM visitor_registration
            WHERE ${filters.join(" AND ")}
            ORDER BY check_in_time ASC, visitor_id ASC

        `, params);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});

router.get("/api/visitor-stats", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                COUNT(*) FILTER (WHERE check_in_time::date = CURRENT_DATE) AS check_in_today,
                COUNT(*) FILTER (WHERE check_out_time::date = CURRENT_DATE) AS check_out_today,
                COUNT(*) FILTER (WHERE check_in_time::date = CURRENT_DATE) AS visitors_today,
                COUNT(*) FILTER (WHERE check_out_time IS NULL) AS active_visitors
            FROM visitor_registration
        `);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-analytics", async (req, res) => {
    try {
        const mode = ["daily", "monthly", "yearly"].includes(req.query.mode) ? req.query.mode : "daily";
        const dateExpression =
            mode === "yearly"
                ? "TO_CHAR(check_in_time, 'YYYY')"
                : mode === "monthly"
                    ? "TO_CHAR(check_in_time, 'YYYY-MM')"
                    : "TO_CHAR(check_in_time, 'YYYY-MM-DD')";

        const result = await pool.query(`
            SELECT ${dateExpression} AS period,
                   COUNT(*) AS check_in_count,
                   COUNT(*) FILTER (WHERE check_out_time IS NOT NULL) AS check_out_count
            FROM visitor_registration
            WHERE check_in_time IS NOT NULL
            GROUP BY period
            ORDER BY period ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// (Route sync-acs, sync-lift, dan export-excel Anda tetap di bawah sini...)
router.post("/sync-acs/:id", async (req, res) => { /* ... */ });
router.post("/sync-lift/:id", async (req, res) => { /* ... */ });
router.get("/export-excel", async (req, res) => { /* ... */ });
// 1. Route untuk daftar semua port COM yang aktif
router.get("/card-reader/list-ports", async (req, res) => {
    try {
        const ports = await SerialPort.list();
        // Mengembalikan daftar path port saja, contoh: ["COM1", "COM3"]
        res.json(ports.map(p => p.path));
    } catch (error) {
        res.status(500).json({ error: "Gagal mendeteksi port" });
    }
});

// 2. Route untuk konek ke port spesifik
// ... (kode sebelumnya) ...

// 2. Route untuk konek ke port spesifik
router.post("/card-reader/connect", (req, res) => {
    const { port, baudRate } = req.body;
    if (!port) return res.status(400).json({ success: false, message: "Port tidak dipilih" });

    try {
        // TANGANI KONEKSI LAMA
        if (activePort && activePort.isOpen) {
            activePort.close();
            activePort = null;
        }

        const selectedBaud = parseInt(baudRate) || 9600;
        
        // INISIALISASI BARU
        activePort = new SerialPort({ path: port, baudRate: selectedBaud });
        const parser = activePort.pipe(new ReadlineParser({ delimiter: '\r\n' }));

        activePort.on('open', () => {
            console.log("Koneksi berhasil ke:", port);
            res.json({ success: true, message: "Terhubung ke " + port });
        });

        parser.on('data', (data) => {
            lastCard = data.trim();
        });

        // TANGANI ERROR DALAM KONEKSI
        activePort.on('error', (err) => {
            console.error("Serial Error:", err);
            activePort = null; 
        });

        // TANGANI PENUTUPAN PORT
        activePort.on('close', () => {
            console.log("Port tertutup");
            activePort = null;
        });

    } catch (error) {
        console.error("Gagal inisialisasi:", error);
        activePort = null;
        res.status(500).json({ success: false, message: error.message });
    }
});

// Route untuk frontend mengambil data kartu (Polling)
router.get("/card-reader/data", (req, res) => {
    if (lastCard !== "") {
        res.json({ success: true, card: lastCard });
        lastCard = ""; 
    } else {
        res.json({ success: false });
    }
});


module.exports = router;
module.exports.startAutoCheckoutScheduler = startAutoCheckoutScheduler;
