# Cara Generate License Customer

## Cara paling mudah

Double-click file:

```text
Generate License.cmd
```

Isi data yang diminta:

- Nama customer / company
- Machine ID customer dari halaman `license.html`
- Expired date, format `YYYY-MM-DD`, atau isi `PERMANENT` untuk license tanpa expired
- Edition, contoh `ENTERPRISE`
- Max users
- Features

Hasil license otomatis tersimpan di:

```text
license/generated/
```

File `.txt` itulah yang bisa dikirim ke customer.

## Cara via command

```powershell
node tools/generate-license.js --customer="PT CUSTOMER" --machine="MACHINE_ID_CUSTOMER" --expires=2027-07-20 --edition=ENTERPRISE --max-users=100 --out="license/generated/PT_CUSTOMER.txt"
```

License permanent:

```powershell
node tools/generate-license.js --customer="PT CUSTOMER" --machine="MACHINE_ID_CUSTOMER" --expires=PERMANENT --edition=ENTERPRISE --max-users=100 --out="license/generated/PT_CUSTOMER_PERMANENT.txt"
```

## Penting

Jangan kirim file ini ke customer:

```text
license/private_key.pem
```

File tersebut adalah kunci rahasia untuk membuat license.
