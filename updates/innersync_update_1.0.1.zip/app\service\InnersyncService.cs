using System;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;

namespace InnersyncRegistrationPortalService
{
    public class InnersyncService : ServiceBase
    {
        private readonly string appDirectory;
        private readonly string nodePath;
        private readonly string nodeArguments;
        private Process nodeProcess;
        private string logFile;

        public InnersyncService(string[] args)
        {
            ServiceName = "InnersyncRegistrationPortal";
            CanStop = true;
            CanShutdown = true;
            AutoLog = true;

            appDirectory = args.Length > 0 ? args[0] : AppDomain.CurrentDomain.BaseDirectory;
            nodePath = args.Length > 1 ? args[1] : "node.exe";
            nodeArguments = args.Length > 2 ? args[2] : "server.js";
        }

        public static void Main(string[] args)
        {
            ServiceBase.Run(new InnersyncService(args));
        }

        protected override void OnStart(string[] args)
        {
            Directory.CreateDirectory(Path.Combine(appDirectory, "service", "logs"));
            logFile = Path.Combine(appDirectory, "service", "logs", "innersync-service.log");
            WriteLog("Service starting.");

            var startInfo = new ProcessStartInfo
            {
                FileName = nodePath,
                Arguments = nodeArguments,
                WorkingDirectory = appDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            nodeProcess = new Process { StartInfo = startInfo, EnableRaisingEvents = true };
            nodeProcess.OutputDataReceived += (sender, eventArgs) =>
            {
                if (!string.IsNullOrWhiteSpace(eventArgs.Data)) WriteLog(eventArgs.Data);
            };
            nodeProcess.ErrorDataReceived += (sender, eventArgs) =>
            {
                if (!string.IsNullOrWhiteSpace(eventArgs.Data)) WriteLog("ERR: " + eventArgs.Data);
            };
            nodeProcess.Exited += (sender, eventArgs) =>
            {
                WriteLog("Node process exited with code " + nodeProcess.ExitCode + ".");
            };

            nodeProcess.Start();
            nodeProcess.BeginOutputReadLine();
            nodeProcess.BeginErrorReadLine();
            WriteLog("Node process started. PID: " + nodeProcess.Id);
        }

        protected override void OnStop()
        {
            WriteLog("Service stopping.");
            StopNodeProcess();
            WriteLog("Service stopped.");
        }

        protected override void OnShutdown()
        {
            WriteLog("System shutdown received.");
            StopNodeProcess();
            base.OnShutdown();
        }

        private void StopNodeProcess()
        {
            try
            {
                if (nodeProcess == null || nodeProcess.HasExited) return;

                nodeProcess.Kill();
                nodeProcess.WaitForExit(10000);
                WriteLog("Node process stopped.");
            }
            catch (Exception ex)
            {
                WriteLog("Stop error: " + ex.Message);
            }
        }

        private void WriteLog(string message)
        {
            try
            {
                var path = logFile ?? Path.Combine(appDirectory, "service", "logs", "innersync-service.log");
                File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + message + Environment.NewLine);
            }
            catch
            {
                // Avoid service failure if logging is unavailable.
            }
        }
    }
}
