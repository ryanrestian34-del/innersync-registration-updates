const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");

const ROOT_DIR = path.join(__dirname, "..");
const PRODUCT_ID = "INNERSYNC_REGISTRATION_PORTAL";
const LICENSE_FILE = path.join(ROOT_DIR, "config", "license.dat");
const TRIAL_FILE = path.join(ROOT_DIR, "config", "trial.dat");
const PUBLIC_KEY_FILE = path.join(__dirname, "public_key.pem");
const TRIAL_DAYS = 30;

let cache = {
    mtimeMs: null,
    trialMtimeMs: null,
    token: null,
    result: null
};

function base64UrlEncode(input) {
    return Buffer.from(input).toString("base64url");
}

function base64UrlDecode(input) {
    return Buffer.from(String(input || ""), "base64url");
}

function normalizeLicenseKey(value) {
    return String(value || "").replace(/\s+/g, "").trim();
}

function safeExec(command, args) {
    try {
        return execFileSync(command, args, {
            encoding: "utf8",
            windowsHide: true,
            timeout: 1500
        }).trim();
    } catch (error) {
        return "";
    }
}

function readWindowsMachineGuid() {
    const output = safeExec("reg.exe", [
        "query",
        "HKLM\\SOFTWARE\\Microsoft\\Cryptography",
        "/v",
        "MachineGuid"
    ]);
    const match = output.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    return match ? match[1].trim() : "";
}

function getMacAddresses() {
    return Object.values(os.networkInterfaces())
        .flat()
        .filter(item => item && !item.internal && item.mac && item.mac !== "00:00:00:00:00:00")
        .map(item => item.mac.toUpperCase())
        .sort();
}

function getVolumeSerial() {
    const output = safeExec("cmd.exe", ["/c", "vol", process.env.SystemDrive || "C:"]);
    const match = output.match(/Serial Number is\s+([A-F0-9-]+)/i);
    return match ? match[1].trim().toUpperCase() : "";
}

function getMachineFingerprint() {
    const parts = {
        hostname: os.hostname().toUpperCase(),
        platform: os.platform(),
        arch: os.arch(),
        machine_guid: readWindowsMachineGuid(),
        mac_addresses: getMacAddresses(),
        volume_serial: getVolumeSerial()
    };

    const raw = JSON.stringify(parts);
    const machineId = crypto.createHash("sha256").update(raw).digest("hex").toUpperCase();

    return {
        machine_id: machineId,
        display_id: machineId.match(/.{1,4}/g).join("-"),
        parts
    };
}

function getPublicKey() {
    return fs.readFileSync(PUBLIC_KEY_FILE, "utf8");
}

function getTrialSecret() {
    return crypto
        .createHash("sha256")
        .update(`${PRODUCT_ID}:TRIAL:${getPublicKey()}`)
        .digest();
}

function signTrialPayload(payloadB64) {
    return crypto
        .createHmac("sha256", getTrialSecret())
        .update(payloadB64)
        .digest("base64url");
}

function parseLicenseToken(token) {
    const normalized = normalizeLicenseKey(token);
    const parts = normalized.split(".");
    if (parts.length !== 2) throw new Error("Format license key tidak valid.");

    const payloadText = base64UrlDecode(parts[0]).toString("utf8");
    const payload = JSON.parse(payloadText);

    return {
        payload,
        payloadB64: parts[0],
        signature: base64UrlDecode(parts[1]),
        normalized
    };
}

function verifyLicenseToken(token, machineFingerprint = getMachineFingerprint()) {
    if (!token) {
        return { valid: false, reason: "LICENSE_NOT_FOUND", message: "License belum diaktifkan." };
    }

    try {
        const parsed = parseLicenseToken(token);
        const verified = crypto.verify(
            null,
            Buffer.from(parsed.payloadB64),
            getPublicKey(),
            parsed.signature
        );

        if (!verified) {
            return { valid: false, reason: "INVALID_SIGNATURE", message: "Signature license tidak valid." };
        }

        const payload = parsed.payload || {};
        if (payload.product !== PRODUCT_ID) {
            return { valid: false, reason: "INVALID_PRODUCT", message: "License bukan untuk produk ini.", payload };
        }

        const licenseMachineId = String(payload.machine_id || "").toUpperCase();
        if (licenseMachineId !== "ANY" && licenseMachineId !== machineFingerprint.machine_id) {
            return { valid: false, reason: "MACHINE_MISMATCH", message: "License tidak cocok dengan Machine ID PC ini.", payload };
        }

        if (payload.expires_at) {
            const expiresAt = new Date(payload.expires_at);
            if (Number.isNaN(expiresAt.getTime())) {
                return { valid: false, reason: "INVALID_EXPIRY", message: "Tanggal expired license tidak valid.", payload };
            }
            if (Date.now() > expiresAt.getTime()) {
                return { valid: false, reason: "EXPIRED", message: "License sudah expired.", payload };
            }
        }

        return {
            valid: true,
            reason: "VALID",
            message: "License valid.",
            payload
        };
    } catch (error) {
        return { valid: false, reason: "INVALID_LICENSE", message: error.message };
    }
}

function readStoredLicenseToken() {
    try {
        return normalizeLicenseKey(fs.readFileSync(LICENSE_FILE, "utf8"));
    } catch (error) {
        return "";
    }
}

function readTrialToken() {
    try {
        return normalizeLicenseKey(fs.readFileSync(TRIAL_FILE, "utf8"));
    } catch (error) {
        return "";
    }
}

function createTrialToken(machine) {
    const startedAt = new Date();
    const expiresAt = new Date(startedAt.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
    const payload = {
        product: PRODUCT_ID,
        type: "TRIAL",
        machine_id: machine.machine_id,
        started_at: startedAt.toISOString(),
        expires_at: expiresAt.toISOString(),
        trial_days: TRIAL_DAYS
    };
    const payloadB64 = base64UrlEncode(JSON.stringify(payload));
    const signature = signTrialPayload(payloadB64);
    return `${payloadB64}.${signature}`;
}

function verifyTrialToken(token, machine) {
    if (!token) {
        return { active: false, reason: "TRIAL_NOT_STARTED", message: "Trial belum dimulai." };
    }

    try {
        const parts = normalizeLicenseKey(token).split(".");
        if (parts.length !== 2) throw new Error("Format trial tidak valid.");

        const expectedSignature = signTrialPayload(parts[0]);
        const actualSignature = parts[1];
        const signatureOk = crypto.timingSafeEqual(
            Buffer.from(expectedSignature),
            Buffer.from(actualSignature)
        );
        if (!signatureOk) {
            return { active: false, reason: "TRIAL_TAMPERED", message: "Trial data tidak valid atau sudah dimodifikasi." };
        }

        const payload = JSON.parse(base64UrlDecode(parts[0]).toString("utf8"));
        if (payload.product !== PRODUCT_ID || payload.type !== "TRIAL") {
            return { active: false, reason: "INVALID_TRIAL", message: "Trial bukan untuk produk ini.", trial: payload };
        }
        if (String(payload.machine_id || "").toUpperCase() !== machine.machine_id) {
            return { active: false, reason: "TRIAL_MACHINE_MISMATCH", message: "Trial tidak cocok dengan PC ini.", trial: payload };
        }

        const startedAt = new Date(payload.started_at);
        const expiresAt = new Date(payload.expires_at);
        if (Number.isNaN(startedAt.getTime()) || Number.isNaN(expiresAt.getTime())) {
            return { active: false, reason: "INVALID_TRIAL_DATE", message: "Tanggal trial tidak valid.", trial: payload };
        }

        const now = Date.now();
        if (now < startedAt.getTime() - 5 * 60 * 1000) {
            return { active: false, reason: "TRIAL_CLOCK_INVALID", message: "Tanggal komputer lebih kecil dari tanggal mulai trial.", trial: payload };
        }
        if (now > expiresAt.getTime()) {
            return { active: false, reason: "TRIAL_EXPIRED", message: "Trial 30 hari sudah expired. Silakan aktivasi license.", trial: payload };
        }

        const remainingMs = expiresAt.getTime() - now;
        return {
            active: true,
            reason: "TRIAL_ACTIVE",
            message: "Trial aktif.",
            trial: payload,
            remaining_days: Math.max(0, Math.ceil(remainingMs / (24 * 60 * 60 * 1000)))
        };
    } catch (error) {
        return { active: false, reason: "INVALID_TRIAL", message: error.message };
    }
}

function getOrCreateTrialStatus(machine) {
    fs.mkdirSync(path.dirname(TRIAL_FILE), { recursive: true });

    let token = readTrialToken();
    if (!token) {
        token = createTrialToken(machine);
        fs.writeFileSync(TRIAL_FILE, token, "utf8");
    }

    return verifyTrialToken(token, machine);
}

function getDaysUntil(value) {
    if (!value) return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return null;
    return Math.ceil((date.getTime() - Date.now()) / (24 * 60 * 60 * 1000));
}

function getStoredLicenseStatus() {
    let stat = null;
    let trialStat = null;
    try {
        stat = fs.statSync(LICENSE_FILE);
    } catch (error) {
        stat = null;
    }
    try {
        trialStat = fs.statSync(TRIAL_FILE);
    } catch (error) {
        trialStat = null;
    }

    const token = stat ? readStoredLicenseToken() : "";
    if (
        cache.result &&
        cache.mtimeMs === (stat ? stat.mtimeMs : null) &&
        cache.trialMtimeMs === (trialStat ? trialStat.mtimeMs : null) &&
        cache.token === token
    ) {
        return cache.result;
    }

    const machine = getMachineFingerprint();
    const licenseStatus = verifyLicenseToken(token, machine);
    let result;

    if (licenseStatus.valid) {
        const licenseDaysUntilExpiry = getDaysUntil(licenseStatus.payload?.expires_at);
        result = {
            ...licenseStatus,
            access_mode: "LICENSE",
            license_valid: true,
            license_days_until_expiry: licenseDaysUntilExpiry,
            expiry_warning: licenseDaysUntilExpiry !== null && licenseDaysUntilExpiry >= 0 && licenseDaysUntilExpiry <= 7,
            trial_active: false,
            trial: null,
            machine,
            has_license_file: Boolean(token)
        };
    } else {
        const trialStatus = getOrCreateTrialStatus(machine);
        result = {
            valid: trialStatus.active,
            reason: trialStatus.active ? "TRIAL_ACTIVE" : trialStatus.reason,
            message: trialStatus.active ? "Trial 30 hari aktif." : trialStatus.message,
            access_mode: trialStatus.active ? "TRIAL" : "LOCKED",
            license_valid: false,
            license_reason: licenseStatus.reason,
            license_message: licenseStatus.message,
            payload: null,
            trial_active: trialStatus.active,
            trial: trialStatus.trial || null,
            trial_remaining_days: trialStatus.remaining_days || 0,
            expiry_warning: trialStatus.active && (trialStatus.remaining_days || 0) <= 7,
            machine,
            has_license_file: Boolean(token)
        };
    }

    try {
        trialStat = fs.statSync(TRIAL_FILE);
    } catch (error) {
        trialStat = null;
    }

    cache = {
        mtimeMs: stat ? stat.mtimeMs : null,
        trialMtimeMs: trialStat ? trialStat.mtimeMs : null,
        token,
        result
    };

    return result;
}

function saveLicenseToken(token) {
    const normalized = normalizeLicenseKey(token);
    const validation = verifyLicenseToken(normalized);
    if (!validation.valid) return validation;

    fs.mkdirSync(path.dirname(LICENSE_FILE), { recursive: true });
    fs.writeFileSync(LICENSE_FILE, normalized, "utf8");
    cache = { mtimeMs: null, trialMtimeMs: null, token: null, result: null };

    return getStoredLicenseStatus();
}

function createSignedLicense(payload, privateKeyPem) {
    const normalizedPayload = {
        product: PRODUCT_ID,
        license_id: payload.license_id || crypto.randomUUID(),
        customer: String(payload.customer || "").trim(),
        edition: String(payload.edition || "STANDARD").trim().toUpperCase(),
        machine_id: String(payload.machine_id || "").replace(/-/g, "").trim().toUpperCase(),
        features: Array.isArray(payload.features) ? payload.features : ["visitor_registration"],
        max_users: Number(payload.max_users || 10),
        issued_at: payload.issued_at || new Date().toISOString(),
        expires_at: payload.expires_at || null
    };

    if (!normalizedPayload.customer) throw new Error("customer wajib diisi.");
    if (!normalizedPayload.machine_id) throw new Error("machine_id wajib diisi.");

    const payloadB64 = base64UrlEncode(JSON.stringify(normalizedPayload));
    const signature = crypto.sign(null, Buffer.from(payloadB64), privateKeyPem);
    return `${payloadB64}.${signature.toString("base64url")}`;
}

module.exports = {
    PRODUCT_ID,
    LICENSE_FILE,
    TRIAL_FILE,
    TRIAL_DAYS,
    getMachineFingerprint,
    getStoredLicenseStatus,
    saveLicenseToken,
    verifyLicenseToken,
    createSignedLicense,
    normalizeLicenseKey
};
