const { Pool } = require("pg");

const pool = new Pool({

    user: "postgres",
    host: "localhost",
    database: "Innersync_db",
    password: "Epc0n@123!",
    port: 5432,
    max: Number(process.env.PG_POOL_MAX || 50),
    idleTimeoutMillis: Number(process.env.PG_IDLE_TIMEOUT_MS || 30000),
    connectionTimeoutMillis: Number(process.env.PG_CONNECTION_TIMEOUT_MS || 3000),

});

module.exports = pool;
