# Innersync Software Update Package

Software Update di dashboard menerima file `.zip` dengan struktur:

```text
manifest.json
app/
  public/
  routes/
  server.js
  package.json
migrations/
  20260720_001_add_column_example.sql
```

`manifest.json` minimal:

```json
{
  "product": "Innersync Registration Portal",
  "version": "1.0.1",
  "changelog": ["Fix bug", "Tambah fitur"],
  "files": [
    {
      "path": "public/dashboard.html",
      "sha256": "..."
    }
  ],
  "migrations": [
    {
      "name": "20260720_001_add_column_example.sql",
      "sha256": "..."
    }
  ]
}
```

Cara membuat package dari folder project saat ini:

```powershell
npm run update:package -- --version=1.0.1 --source="D:\20. Software Custom\innersync_registration_portal" --output="D:\Innersync Updates" --migrations="D:\20. Software Custom\innersync_registration_portal\migrations" --changelog="Fix bug|Tambah fitur"
```

Atau jalankan:

```text
Create Update Package.cmd --version=1.0.1 --source="D:\20. Software Custom\innersync_registration_portal" --output="D:\Innersync Updates" --migrations="D:\20. Software Custom\innersync_registration_portal\migrations"
```

## Online Update Dengan GitHub

Buat repository GitHub khusus update, contoh:

```text
innersync-registration-updates
```

Struktur repository:

```text
latest.json
updates/
  innersync_update_1.0.1.zip
  innersync_update_1.0.2.zip
```

Contoh raw URL yang dipakai di Software Update:

```text
https://raw.githubusercontent.com/USERNAME/innersync-registration-updates/main/latest.json
```

Kalau ingin `latest.json` otomatis berisi `package_url`, isi GitHub raw folder URL saat menjalankan tool:

```text
https://raw.githubusercontent.com/USERNAME/innersync-registration-updates/main/updates
```

Tool akan membuat dua file di folder output:

```text
innersync_update_1.0.1.zip
latest.json
```

Upload `innersync_update_1.0.1.zip` ke folder `updates/` di GitHub, lalu upload `latest.json` ke root repository.

Isi `latest.json`:

```json
{
  "product": "Innersync Registration Portal",
  "latest_version": "1.0.1",
  "release_date": "2026-07-20",
  "mandatory": false,
  "changelog": [
    "Fix bug",
    "Tambah fitur"
  ],
  "package_url": "https://raw.githubusercontent.com/USERNAME/innersync-registration-updates/main/updates/innersync_update_1.0.1.zip",
  "sha256": "checksum_zip"
}
```

Di aplikasi customer:

1. Buka Dashboard > Software Update.
2. Isi GitHub `latest.json URL`.
3. Klik `Save URL`.
4. Klik `Check Update`.
5. Jika versi baru tersedia, klik `Download Latest`.
6. Klik `Apply Update`.

Folder yang tidak akan ikut package:

- `.git`
- `node_modules`
- `config`
- `backups`
- `exports`
- `uploads`
- `updates`
- `license/private_key.pem`
- file log service/server

Saat apply update dari dashboard, sistem akan:

1. Validasi `manifest.json` dan checksum file.
2. Backup full database PostgreSQL.
3. Backup file aplikasi yang akan ditimpa.
4. Jalankan SQL di folder `migrations/` yang belum pernah dijalankan.
5. Copy file dari `app/` ke folder aplikasi.
6. Menandai restart service diperlukan.

Migration dicatat di tabel `software_schema_migrations`, jadi file SQL yang sama tidak akan dijalankan dua kali. Gunakan nama file berurutan seperti:

```text
20260720_001_create_table_notification.sql
20260720_002_add_column_host_email.sql
```

Isi SQL sebaiknya idempotent, misalnya:

```sql
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS email VARCHAR(150);
CREATE TABLE IF NOT EXISTS sample_table (
    sample_id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT NOW()
);
```
