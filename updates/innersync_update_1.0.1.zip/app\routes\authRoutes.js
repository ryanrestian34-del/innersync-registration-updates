const {
    checkSession
} = require("../middleware/authMiddleware");

const express = require("express");
const router = express.Router();

const bcrypt = require("bcrypt");

const pool = require("../database/db");

let activeSessionSchemaReady = false;
let roleSchemaReady = false;
let assignableRoleNameCache = null;
const activeSessionTouchCache = new Map();
const ACTIVE_SESSION_TOUCH_INTERVAL_MS = 15000;
const DEVELOPER_SUPERADMIN_USERNAME = "admin";

const ROLE_MODULES = [
    "dashboard",
    "visitor_registration",
    "visitor_logs",
    "activity_logs",
    "host",
    "permission_group",
    "api_configuration",
    "middleware_sync",
    "settings",
    "account_management",
    "monitoring_account",
    "software_activity_log",
    "database_capacity"
];

function isSuperAdminSession(req) {
    return String(req.session?.role_name || "").toUpperCase() === "SUPERADMIN";
}

function isDeveloperSuperAdminRow(row = {}) {
    return String(row.username || "").toLowerCase() === DEVELOPER_SUPERADMIN_USERNAME &&
        String(row.role_name || "").toUpperCase() === "SUPERADMIN";
}

function requireSuperAdmin(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    if (!isSuperAdminSession(req)) {
        return res.status(403).json({ success: false, message: "Hanya SUPERADMIN yang bisa melakukan action ini" });
    }

    next();
}

function normalizeRoleName(value) {
    return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9_ -]/g, "").replace(/\s+/g, "_");
}

function normalizePermissionBody(body = {}) {
    const permissions = body.permissions && typeof body.permissions === "object" ? body.permissions : {};
    return ROLE_MODULES.map(moduleKey => {
        const item = permissions[moduleKey] || {};
        return {
            module_key: moduleKey,
            can_view: item.can_view === true,
            can_add: item.can_add === true,
            can_edit: item.can_edit === true,
            can_delete: item.can_delete === true,
            can_export: item.can_export === true,
            can_execute: item.can_execute === true
        };
    });
}

function defaultRolePermissions(roleName) {
    const normalized = normalizeRoleName(roleName);
    const allTrue = normalized === "SUPERADMIN";
    const adminLike = normalized === "ADMIN";
    const operatorLike = normalized === "OPERATOR";

    const modules = {};
    ROLE_MODULES.forEach(moduleKey => {
        const protectedModule = ["api_configuration", "middleware_sync"].includes(moduleKey);
        modules[moduleKey] = {
            can_view: allTrue || (adminLike && !protectedModule) || (operatorLike && ["dashboard", "visitor_registration", "visitor_logs", "host"].includes(moduleKey)),
            can_add: allTrue || (adminLike && !protectedModule) || (operatorLike && ["visitor_registration"].includes(moduleKey)),
            can_edit: allTrue || (adminLike && !protectedModule) || (operatorLike && ["visitor_registration"].includes(moduleKey)),
            can_delete: allTrue || (adminLike && ["visitor_registration", "visitor_logs", "host", "permission_group"].includes(moduleKey)),
            can_export: allTrue || (adminLike && !protectedModule) || (operatorLike && ["visitor_logs"].includes(moduleKey)),
            can_execute: allTrue || (adminLike && !protectedModule) || (operatorLike && ["visitor_registration"].includes(moduleKey))
        };
    });

    return modules;
}

async function ensureRoleSchema() {
    if (roleSchemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS account_roles (
            role_id SERIAL PRIMARY KEY,
            role_name VARCHAR(80) UNIQUE NOT NULL,
            description TEXT,
            is_system BOOLEAN NOT NULL DEFAULT FALSE,
            created_by VARCHAR(120),
            created_at TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(120),
            modified_at TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS account_role_permissions (
            permission_id SERIAL PRIMARY KEY,
            role_id INTEGER NOT NULL REFERENCES account_roles(role_id) ON DELETE CASCADE,
            module_key VARCHAR(80) NOT NULL,
            can_view BOOLEAN NOT NULL DEFAULT FALSE,
            can_add BOOLEAN NOT NULL DEFAULT FALSE,
            can_edit BOOLEAN NOT NULL DEFAULT FALSE,
            can_delete BOOLEAN NOT NULL DEFAULT FALSE,
            can_export BOOLEAN NOT NULL DEFAULT FALSE,
            can_execute BOOLEAN NOT NULL DEFAULT FALSE,
            UNIQUE(role_id, module_key)
        )
    `);

    await pool.query("ALTER TABLE account_roles ADD COLUMN IF NOT EXISTS description TEXT");
    await pool.query("ALTER TABLE account_roles ADD COLUMN IF NOT EXISTS is_system BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE account_roles ADD COLUMN IF NOT EXISTS created_by VARCHAR(120)");
    await pool.query("ALTER TABLE account_roles ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE account_roles ADD COLUMN IF NOT EXISTS modified_by VARCHAR(120)");
    await pool.query("ALTER TABLE account_roles ADD COLUMN IF NOT EXISTS modified_at TIMESTAMP");

    for (const roleName of ["SUPERADMIN", "ADMIN", "OPERATOR"]) {
        const roleResult = await pool.query(
            `INSERT INTO account_roles (role_name, description, is_system, created_by)
             VALUES ($1, $2, $3, 'SYSTEM')
             ON CONFLICT (role_name)
             DO UPDATE SET is_system = EXCLUDED.is_system
             RETURNING role_id`,
            [roleName, `${roleName} system role`, roleName === "SUPERADMIN"]
        );

        const roleId = roleResult.rows[0].role_id;
        const defaults = defaultRolePermissions(roleName);
        for (const moduleKey of ROLE_MODULES) {
            const permission = defaults[moduleKey];
            await pool.query(
                `INSERT INTO account_role_permissions
                 (role_id, module_key, can_view, can_add, can_edit, can_delete, can_export, can_execute)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                 ON CONFLICT (role_id, module_key) DO NOTHING`,
                [
                    roleId,
                    moduleKey,
                    permission.can_view,
                    permission.can_add,
                    permission.can_edit,
                    permission.can_delete,
                    permission.can_export,
                    permission.can_execute
                ]
            );
        }
    }

    roleSchemaReady = true;
}

async function getRoleWithPermissions(roleName) {
    await ensureRoleSchema();
    const roleResult = await pool.query("SELECT * FROM account_roles WHERE role_name = $1", [normalizeRoleName(roleName)]);
    if (!roleResult.rows.length) return null;

    const permissionResult = await pool.query(
        `SELECT module_key, can_view, can_add, can_edit, can_delete, can_export, can_execute
         FROM account_role_permissions
         WHERE role_id = $1
         ORDER BY module_key ASC`,
        [roleResult.rows[0].role_id]
    );

    return {
        ...roleResult.rows[0],
        permissions: permissionResult.rows.reduce((acc, row) => {
            acc[row.module_key] = {
                can_view: row.can_view,
                can_add: row.can_add,
                can_edit: row.can_edit,
                can_delete: row.can_delete,
                can_export: row.can_export,
                can_execute: row.can_execute
            };
            return acc;
        }, {})
    };
}

async function ensureAssignableRole(req, roleName) {
    const normalized = normalizeRoleName(roleName || "OPERATOR") || "OPERATOR";

    if (normalized === "SUPERADMIN") {
        throw new Error("Role SUPERADMIN tidak bisa dipilih untuk account");
    }

    if (!assignableRoleNameCache) {
        await ensureRoleSchema();
        const result = await pool.query("SELECT role_name FROM account_roles WHERE role_name <> 'SUPERADMIN'");
        assignableRoleNameCache = new Set(result.rows.map(row => row.role_name));
    }

    if (!assignableRoleNameCache.has(normalized)) {
        throw new Error(`Role ${normalized} belum dibuat di Role Management`);
    }

    return normalized;
}

function getClientIp(req) {
    return String(req.headers["x-forwarded-for"] || req.ip || req.socket?.remoteAddress || "")
        .split(",")[0]
        .replace(/^::ffff:/, "")
        .trim();
}

function getWorkstationName(req) {
    const headerName = String(req.headers["x-workstation-name"] || req.headers["x-pc-name"] || "").trim();
    if (headerName) return headerName;

    const userAgent = String(req.headers["user-agent"] || "").trim();
    if (!userAgent) return "Unknown Workstation";

    if (userAgent.includes("Edg/")) return "Microsoft Edge";
    if (userAgent.includes("Chrome/")) return "Google Chrome";
    if (userAgent.includes("Firefox/")) return "Mozilla Firefox";
    if (userAgent.includes("Safari/")) return "Safari";
    return userAgent.slice(0, 80);
}

async function ensureActiveSessionSchema() {
    if (activeSessionSchemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS active_account_sessions (
            session_id VARCHAR(160) PRIMARY KEY,
            user_id INTEGER,
            username VARCHAR(120),
            full_name VARCHAR(160),
            role_name VARCHAR(80),
            workstation VARCHAR(160),
            ip_address VARCHAR(80),
            user_agent TEXT,
            login_time TIMESTAMP DEFAULT NOW(),
            last_seen TIMESTAMP DEFAULT NOW()
        )
    `);

    activeSessionSchemaReady = true;
}

async function upsertActiveSession(req, options = {}) {
    if (!req.session?.user || !req.sessionID) return;

    const nowMs = Date.now();
    const lastTouch = activeSessionTouchCache.get(req.sessionID) || 0;
    if (!options.force && nowMs - lastTouch < ACTIVE_SESSION_TOUCH_INTERVAL_MS) return;

    await ensureActiveSessionSchema();

    await pool.query(
        `INSERT INTO active_account_sessions (
            session_id,
            user_id,
            username,
            full_name,
            role_name,
            workstation,
            ip_address,
            user_agent,
            login_time,
            last_seen
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),NOW())
        ON CONFLICT (session_id)
        DO UPDATE SET
            user_id = EXCLUDED.user_id,
            username = EXCLUDED.username,
            full_name = EXCLUDED.full_name,
            role_name = EXCLUDED.role_name,
            workstation = EXCLUDED.workstation,
            ip_address = EXCLUDED.ip_address,
            user_agent = EXCLUDED.user_agent,
            last_seen = NOW()`,
        [
            req.sessionID,
            req.session.user.user_id || req.session.user_id,
            req.session.user.username,
            req.session.user.full_name || req.session.user.username,
            req.session.user.role_name || req.session.role_name,
            getWorkstationName(req),
            getClientIp(req),
            req.headers["user-agent"] || ""
        ]
    );
    activeSessionTouchCache.set(req.sessionID, nowMs);
}

async function removeActiveSession(req) {
    if (!req.sessionID) return;
    await ensureActiveSessionSchema();
    await pool.query("DELETE FROM active_account_sessions WHERE session_id = $1", [req.sessionID]);
    activeSessionTouchCache.delete(req.sessionID);
}

function getStoredSession(req, sessionId) {
    if (!req.sessionStore?.get) return Promise.resolve(null);

    return new Promise(resolve => {
        req.sessionStore.get(sessionId, (error, sessionData) => {
            if (error || !sessionData) return resolve(null);
            resolve(sessionData);
        });
    });
}

/* SAVE ACTIVITY LOG */

async function saveLog(
    username,
    activityType,
    description,
    ipAddress
) {

    try {

        await pool.query(

            `INSERT INTO activity_logs
            (
                username,
                activity_type,
                description,
                ip_address
            )
            VALUES ($1,$2,$3,$4)`,

            [
                username,
                activityType,
                description,
                ipAddress
            ]

        );

    } catch (error) {

        console.log(error);

    }

}

/* LOGIN */

router.post("/login", async (req, res) => {

    try {

        const {
            username,
            password
        } = req.body;

        const result = await pool.query(

            `SELECT *
             FROM system_users
             WHERE username = $1`,

            [username]

        );

        if (result.rows.length === 0) {

            return res.status(401).json({

                success: false,
                message: "Username not found"

            });

        }

        const user = result.rows[0];

        /* BLOCK CHECK */

        if (

            user.role_name !== "SUPERADMIN"
        
            &&
        
            user.is_blocked
        
        ) {

            return res.json({

                success: false,
            
                message: "User blocked by administrator"
            
            });

        }

        /* APPROVAL CHECK */

        if (

            user.role_name !== "SUPERADMIN"
        
            &&
        
            user.approval_status !== "APPROVED"
        
        ) {
        
            return res.status(401).json({
        
                success: false,
        
                message: "Please wait admin approval"
        
            });
        
        }

        /* START / EXPIRY CHECK */

        if (!user.is_permanent) {

            const now =
                new Date();

            const startDate =
                new Date(user.start_date);

            const expiryDate =
                new Date(user.expiry_date);

            if (now < startDate) {

                return res.json({

                    success: false,
                    message: "Account not active yet"

                });

            }

            if (now > expiryDate) {

                return res.json({

                    success: false,
                    message: "Account expired.\n\nPlease contact your Administrator."

                });

            }

        }

        /* PASSWORD CHECK */

        if (

            user.must_change_password &&
        
            (
                user.password === null ||
        
                user.password === "" ||
        
                !user.password
            )
        
        ) {
        
            req.session.user = {
        
                user_id: user.user_id,
        
                username: user.username,
        
                role_name: user.role_name
        
            };
        
            req.session.user_id =
            user.user_id;

            req.session.user = {

                user_id: user.user_id,
            
                username: user.username,
            
                role_name: user.role_name
            
            };
            
            req.session.user_id =
            user.user_id;
            
            req.session.role_name =
            user.role_name;
        
            return res.json({
        
                success:true,
        
                must_change_password:true
        
            });
        
        }

        const validPassword = await bcrypt.compare(

            password,
            user.password

        );

        if (!validPassword) {

            return res.status(401).json({

                success: false,
                message: "Invalid password"

            });

        }

        /* SAVE SESSION */

        req.session.user = {

            user_id: user.user_id,
            username: user.username,
            full_name: user.full_name,
            role_name: user.role_name

        };

        req.session.user_id =
            user.user_id;

        req.session.role_name =
            user.role_name;

        /* SAVE LOGIN LOG */

        await saveLog(

            user.username,

            "LOGIN",

            "Login success",

            req.ip

        );

        await upsertActiveSession(req, { force: true });

        res.json({

            success: true,
        
            message: "Login success",
        
            user: req.session.user,
        
            must_change_password:
            user.must_change_password
        
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* LOGOUT */

router.post("/logout", async (req, res) => {

    try {

        if (req.session.user) {

            await saveLog(

                req.session.user.username,

                "LOGOUT",

                "Logout success",

                req.ip

            );

            await removeActiveSession(req);

        }

        req.session.destroy(() => {

            res.json({

                success: true,
                message: "Logout success"

            });

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* CURRENT USER */

router.get("/current-user", async (req, res) => {

    try {

        if (!req.session.user_id) {

            return res.status(401).json({

                success: false

            });

        }

        await upsertActiveSession(req);

        res.json({

            success: true,

            user_id: req.session.user_id,

            role_name: req.session.role_name,

            username: req.session.user.username,

            full_name: req.session.user.full_name

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

router.get("/api/roles", checkSession, async (req, res) => {
    try {
        await ensureRoleSchema();
        const roles = await pool.query(`
            SELECT role_id, role_name, description, is_system, created_by, created_at, modified_by, modified_at
            FROM account_roles
            WHERE role_name <> 'SUPERADMIN'
            ORDER BY
                CASE role_name
                    WHEN 'ADMIN' THEN 2
                    WHEN 'OPERATOR' THEN 3
                    ELSE 10
                END,
                role_name ASC
        `);

        const permissions = await pool.query(`
            SELECT p.*, r.role_name
            FROM account_role_permissions p
            JOIN account_roles r ON r.role_id = p.role_id
            ORDER BY p.module_key ASC
        `);

        const permissionByRole = {};
        permissions.rows.forEach(row => {
            if (!permissionByRole[row.role_id]) permissionByRole[row.role_id] = {};
            permissionByRole[row.role_id][row.module_key] = {
                can_view: row.can_view,
                can_add: row.can_add,
                can_edit: row.can_edit,
                can_delete: row.can_delete,
                can_export: row.can_export,
                can_execute: row.can_execute
            };
        });

        res.json({
            success: true,
            modules: ROLE_MODULES,
            data: roles.rows.map(role => ({
                ...role,
                permissions: permissionByRole[role.role_id] || {}
            }))
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/roles", checkSession, requireSuperAdmin, async (req, res) => {
    try {
        await ensureRoleSchema();
        const roleName = normalizeRoleName(req.body.role_name);
        const description = String(req.body.description || "").trim();

        if (!roleName) return res.status(400).json({ success: false, message: "Nama role wajib diisi" });
        if (roleName === "SUPERADMIN") {
            return res.status(400).json({ success: false, message: "SUPERADMIN adalah role system dan tidak bisa dibuat ulang" });
        }

        const result = await pool.query(
            `INSERT INTO account_roles (role_name, description, is_system, created_by)
             VALUES ($1,$2,FALSE,$3)
             RETURNING *`,
            [roleName, description || null, req.session.user.username]
        );

        const role = result.rows[0];
        const permissions = normalizePermissionBody(req.body);
        for (const permission of permissions) {
            await pool.query(
                `INSERT INTO account_role_permissions
                 (role_id, module_key, can_view, can_add, can_edit, can_delete, can_export, can_execute)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
                [
                    role.role_id,
                    permission.module_key,
                    permission.can_view,
                    permission.can_add,
                    permission.can_edit,
                    permission.can_delete,
                    permission.can_export,
                    permission.can_execute
                ]
            );
        }

        assignableRoleNameCache = null;
        await saveLog(req.session.user.username, "CREATE_ROLE", `Create role ${roleName}`, req.ip);
        res.json({ success: true, data: await getRoleWithPermissions(roleName), message: "Role berhasil dibuat" });
    } catch (error) {
        const message = error.code === "23505" ? "Role sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/roles/:id", checkSession, requireSuperAdmin, async (req, res) => {
    try {
        await ensureRoleSchema();
        const roleId = req.params.id;
        const existing = await pool.query("SELECT * FROM account_roles WHERE role_id = $1", [roleId]);
        if (!existing.rows.length) return res.status(404).json({ success: false, message: "Role tidak ditemukan" });
        if (existing.rows[0].role_name === "SUPERADMIN") {
            return res.status(403).json({ success: false, message: "Role SUPERADMIN tidak bisa diedit" });
        }

        const roleName = existing.rows[0].is_system
            ? existing.rows[0].role_name
            : normalizeRoleName(req.body.role_name || existing.rows[0].role_name);
        const description = String(req.body.description || "").trim();

        await pool.query(
            `UPDATE account_roles
             SET role_name = $1, description = $2, modified_by = $3, modified_at = NOW()
             WHERE role_id = $4`,
            [roleName, description || null, req.session.user.username, roleId]
        );

        const permissions = normalizePermissionBody(req.body);
        for (const permission of permissions) {
            await pool.query(
                `INSERT INTO account_role_permissions
                 (role_id, module_key, can_view, can_add, can_edit, can_delete, can_export, can_execute)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                 ON CONFLICT (role_id, module_key)
                 DO UPDATE SET
                    can_view = EXCLUDED.can_view,
                    can_add = EXCLUDED.can_add,
                    can_edit = EXCLUDED.can_edit,
                    can_delete = EXCLUDED.can_delete,
                    can_export = EXCLUDED.can_export,
                    can_execute = EXCLUDED.can_execute`,
                [
                    roleId,
                    permission.module_key,
                    permission.can_view,
                    permission.can_add,
                    permission.can_edit,
                    permission.can_delete,
                    permission.can_export,
                    permission.can_execute
                ]
            );
        }

        assignableRoleNameCache = null;
        await saveLog(req.session.user.username, "EDIT_ROLE", `Edit role ${roleName}`, req.ip);
        res.json({ success: true, data: await getRoleWithPermissions(roleName), message: "Role berhasil diupdate" });
    } catch (error) {
        const message = error.code === "23505" ? "Role sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/roles/:id", checkSession, requireSuperAdmin, async (req, res) => {
    try {
        await ensureRoleSchema();
        const existing = await pool.query("SELECT * FROM account_roles WHERE role_id = $1", [req.params.id]);
        if (!existing.rows.length) return res.status(404).json({ success: false, message: "Role tidak ditemukan" });
        if (existing.rows[0].is_system || existing.rows[0].role_name === "SUPERADMIN") {
            return res.status(403).json({ success: false, message: "Role system tidak bisa dihapus" });
        }

        const usage = await pool.query("SELECT COUNT(*)::int AS total FROM system_users WHERE role_name = $1", [existing.rows[0].role_name]);
        if (usage.rows[0].total > 0) {
            return res.status(400).json({ success: false, message: "Role sedang dipakai user, tidak bisa dihapus" });
        }

        await pool.query("DELETE FROM account_roles WHERE role_id = $1", [req.params.id]);
        assignableRoleNameCache = null;
        await saveLog(req.session.user.username, "DELETE_ROLE", `Delete role ${existing.rows[0].role_name}`, req.ip);
        res.json({ success: true, message: "Role berhasil dihapus" });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/active-sessions", checkSession, async (req, res) => {
    try {
        await ensureActiveSessionSchema();

        await pool.query("DELETE FROM active_account_sessions WHERE last_seen < NOW() - INTERVAL '8 hours'");

        const result = await pool.query(`
            SELECT
                session_id,
                user_id,
                username,
                full_name,
                role_name,
                workstation,
                ip_address,
                user_agent,
                login_time,
                last_seen,
                EXTRACT(EPOCH FROM (NOW() - login_time))::INTEGER AS active_seconds
            FROM active_account_sessions
            ORDER BY login_time DESC
        `);

        const activeRows = [];
        const staleSessionIds = [];

        for (const row of result.rows) {
            const sessionData = await getStoredSession(req, row.session_id);
            if (sessionData?.user_id && sessionData?.user) {
                activeRows.push(row);
            } else {
                staleSessionIds.push(row.session_id);
            }
        }

        if (staleSessionIds.length) {
            await pool.query(
                "DELETE FROM active_account_sessions WHERE session_id = ANY($1::text[])",
                [staleSessionIds]
            );
        }

        res.json({ success: true, data: activeRows });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/active-sessions/:sessionId/end-task", checkSession, async (req, res) => {
    try {
        if (!["ADMIN", "SUPERADMIN"].includes(req.session.role_name)) {
            return res.status(403).json({ success: false, message: "Forbidden" });
        }

        await ensureActiveSessionSchema();

        const targetSessionId = String(req.params.sessionId || "").trim();
        if (!targetSessionId) {
            return res.status(400).json({ success: false, message: "Session ID tidak valid" });
        }

        const target = await pool.query(
            "SELECT * FROM active_account_sessions WHERE session_id = $1",
            [targetSessionId]
        );

        if (target.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Session tidak ditemukan atau sudah logout" });
        }

        if (String(target.rows[0].role_name || "").toUpperCase() === "SUPERADMIN") {
            return res.status(403).json({
                success: false,
                message: "SUPERADMIN tidak bisa di End Task oleh siapapun"
            });
        }

        if (req.sessionStore?.destroy) {
            await new Promise(resolve => req.sessionStore.destroy(targetSessionId, resolve));
        }

        await pool.query("DELETE FROM active_account_sessions WHERE session_id = $1", [targetSessionId]);

        await saveLog(
            req.session.user.username,
            "END_TASK_ACCOUNT",
            `Force logout account ${target.rows[0].username || "-"} from ${target.rows[0].ip_address || "-"}`,
            req.ip
        );

        res.json({ success: true, message: "Account berhasil di-end task" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/* GET USERS */

router.get("/users", checkSession, async (req, res) => {

    try {

        const result = await pool.query(

            `SELECT

                user_id,
                username,
                full_name,
                role_name,
                approval_status,
                is_blocked,
                created_by,
                modified_by,
                modified_date,
                created_at,
                start_date,
                expiry_date,
                is_permanent

                FROM system_users

                WHERE NOT (LOWER(username) = $1 AND role_name = 'SUPERADMIN')

                ORDER BY user_id ASC`

            ,
            [DEVELOPER_SUPERADMIN_USERNAME]

        );

        res.json({

            success: true,
            data: result.rows

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* CREATE USER */

router.post("/create-user", async (req, res) => {

    try {

        console.log(req.body);

        const {

            username,
            password,
            full_name,
            role_name,
            start_date,
            expiry_date,
            is_permanent

        } = req.body;

        /* VALIDATION */

        if (!username) {

            return res.status(400).json({

                success: false,
                message: "Username required"

            });

        }

        if (!password || password.length < 8) {

            return res.status(400).json({

                success: false,
                message: "Password minimum 8 characters"

            });

        }

        /* CHECK USER EXIST */

        const checkUser =
            await pool.query(

                `SELECT user_id
                 FROM system_users
                 WHERE username = $1`,

                [username]

            );

        if (checkUser.rows.length > 0) {

            return res.status(400).json({

                success: false,
                message: "Username already exists"

            });

        }

        /* HASH PASSWORD */

        const hashedPassword =
            await bcrypt.hash(password, 10);
        const assignableRole = await ensureAssignableRole(req, role_name || "OPERATOR");

        /* INSERT USER */

        await pool.query(

            `INSERT INTO system_users
            (
                username,
                password,
                full_name,
                role_name,
                approval_status,
                is_blocked,
                created_by,
                created_at,
                start_date,
                expiry_date,
                is_permanent
            )

            VALUES
            (
                $1,
                $2,
                $3,
                $4,
                'PENDING',
                false,
                $5,
                NOW(),
                $6,
                $7,
                $8
            )`,

            [

                username,

                hashedPassword,

                full_name || "",

                assignableRole,

                req.session?.user?.username ||

                "SELF-REGISTER",

                (is_permanent ?? true)

?

null

:

start_date || new Date(),

(is_permanent ?? true)

?

null

:

expiry_date || new Date("2035-12-31"),

                is_permanent ?? true

            ]

        );

        /* SAVE LOG */

        await saveLog(

            req.session?.user?.username ||

            "SELF-REGISTER",

            "CREATE_USER",

            `Create user ${username}`,

            req.ip

        );

        res.json({

            success: true,
            message: "User created"

        });

    } catch (error) {

        console.log("CREATE USER ERROR:");
        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* APPROVE USER */

router.post("/approve-user/:id", checkSession, async (req, res) => {

    try {

        if (

            !["ADMIN","SUPERADMIN"]
            
            .includes(
            
            req.session.role_name
            
            )
            
            ) {

            return res.status(403).json({

                success: false,
                message: "Access denied"

            });

        }

        const userId = req.params.id;

        const targetUser =
            await pool.query(

                `SELECT username
                 FROM system_users
                 WHERE user_id = $1`,

                [userId]

            );

        await pool.query(

            `UPDATE system_users

             SET
             approval_status = 'APPROVED',
             modified_by = $1,
             modified_date = NOW()

             WHERE user_id = $2`,

            [

                req.session.user.username,
                userId

            ]

        );

        await saveLog(

            req.session.user.username,

            "APPROVE_USER",

            `Approve user ${targetUser.rows[0].username} (ID ${userId})`,

            req.ip

        );

        res.json({

            success: true,
            message: "User approved"

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* RESET PASSWORD */

router.post("/reset-password/:id", checkSession, async (req, res) => {

    try {

        if (

            !["ADMIN","SUPERADMIN"]
            
            .includes(
            
            req.session.role_name
            
            )
            
            ) {

            return res.status(403).json({

                success: false,
                message: "Access denied"

            });

        }

        const userId = req.params.id;

        const roleCheck =
await pool.query(

`
SELECT role_name
FROM system_users
WHERE user_id = $1
`,

[userId]

);

if (

roleCheck.rows[0]
?.role_name ===
"SUPERADMIN"

) {

return res.json({

success:false,

message:
"SUPERADMIN password cannot be reset"

});
 
}

        const targetUser =
            await pool.query(

                `SELECT username
                 FROM system_users
                 WHERE user_id = $1`,

                [userId]

            );

        const newPassword =
            await bcrypt.hash("12345678", 10);

        await pool.query(

            `UPDATE system_users

             SET
             password = $1,
             modified_by = $2,
             modified_date = NOW()

             WHERE user_id = $3`,

            [

                newPassword,
                req.session.user.username,
                userId

            ]

        );

        await saveLog(

            req.session.user.username,

            "RESET_PASSWORD",

            `Reset password user ${targetUser.rows[0].username} (ID ${userId})`,

            req.ip

        );

        res.json({

            success: true,
            message: "Password reset success"

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* DELETE USER */

router.delete("/delete-user/:id", checkSession, async (req, res) => {

    try {

        if (

            !["ADMIN","SUPERADMIN"]
            
            .includes(
            
            req.session.role_name
            
            )
            
            ) {

            return res.status(403).json({

                success: false,
                message: "Access denied"

            });

        }

        const userId = req.params.id;

        const roleCheck =
await pool.query(

`
SELECT role_name
FROM system_users
WHERE user_id = $1
`,

[userId]

);

if (

roleCheck.rows[0]
?.role_name ===
"SUPERADMIN"

) {

return res.json({

success:false,

message:
"SUPERADMIN cannot be deleted"

});

}

        const targetUser =
            await pool.query(

                `SELECT username
                 FROM system_users
                 WHERE user_id = $1`,

                [userId]

            );

        await pool.query(

            `DELETE FROM system_users
             WHERE user_id = $1`,

            [userId]

        );

        await saveLog(

            req.session.user.username,

            "DELETE_USER",

            `Delete user ${targetUser.rows[0].username} (ID ${userId})`,

            req.ip

        );

        res.json({

            success: true

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* BLOCK / UNBLOCK USER */

router.post(

    "/toggle-block/:id",

    checkSession,

    async (req, res) => {

        try {

            if (

                !["ADMIN","SUPERADMIN"]
                
                .includes(
                
                req.session.role_name
                
                )
                
                ) {

                return res.status(403).json({

                    success: false

                });

            }

            const userId =
                req.params.id;

            const result =
                await pool.query(

                    `SELECT
                    is_blocked,
                    username,
                    role_name

                     FROM system_users

                     WHERE user_id = $1`,

                    [userId]

                );

            const currentStatus =
                result.rows[0].is_blocked;

            const targetUsername =
                result.rows[0].username;

                if (

                    result.rows[0]
                    .role_name ===
                    "SUPERADMIN"
                    
                    ) {
                    
                    return res.json({
                    
                    success:false,
                    
                    message:
                    "SUPERADMIN cannot be blocked"
                    
                    });
                    
                    }

            await pool.query(

                `UPDATE system_users

                 SET
                 is_blocked = $1,
                 modified_by = $2,
                 modified_date = NOW()

                 WHERE user_id = $3`,

                [

                    !currentStatus,
                    req.session.user.username,
                    userId

                ]

            );

            await saveLog(

                req.session.user.username,

                currentStatus

                ?

                "UNBLOCK_USER"

                :

                "BLOCK_USER",

                currentStatus

                ?

                `Unblock user ${targetUsername} (ID ${userId})`

                :

                `Block user ${targetUsername} (ID ${userId})`,

                req.ip

            );

            res.json({

                success: true

            });

        } catch (error) {

            console.log(error);

            res.status(500).json({

                success: false,
                error: error.message

            });

        }

    }

);

/* EDIT USER */

router.put("/edit-user/:id", checkSession, async (req, res) => {

    try {

        if (

            !["ADMIN","SUPERADMIN"]
            
            .includes(
            
            req.session.role_name
            
            )
            
            ) {

            return res.status(403).json({

                success: false,
                message: "Access denied"

            });

        }

        const userId =
            req.params.id;

            const currentUser =
await pool.query(

`
SELECT role_name
FROM system_users
WHERE user_id = $1
`,

[userId]

);

if (

currentUser.rows[0]
?.role_name ===
"SUPERADMIN"

) {

return res.json({

success:false,

message:
"SUPERADMIN cannot be modified"

});

}

        const {

            username,
            full_name,
            password,
            role_name,
            start_date,
            expiry_date,
            is_permanent

        } = req.body;

        if (

            password &&
            password.length < 8

        ) {

            return res.status(400).json({

                success: false,
                message: "Password minimum 8 characters"

            });

        }

        const assignableRole = await ensureAssignableRole(req, role_name || "OPERATOR");

        if (password && password !== "") {

            const hashedPassword =
                await bcrypt.hash(password, 10);

            await pool.query(

                `UPDATE system_users

                 SET

                 username = $1,
                 full_name = $2,
                 password = $3,
                 role_name = $4,
                 start_date = $5,
                 expiry_date = $6,
                 is_permanent = $7,
                 modified_by = $8,
                 modified_date = NOW()

                 WHERE user_id = $9`,

                [

                    username,
                    full_name,
                    hashedPassword,
                    assignableRole,
                    start_date || null,
                    expiry_date || null,
                    is_permanent,
                    req.session.user.username,
                    userId

                ]

            );

        } else {

            await pool.query(

                `UPDATE system_users

                 SET

                 username = $1,
                 full_name = $2,
                 role_name = $3,
                 start_date = $4,
                 expiry_date = $5,
                 is_permanent = $6,
                 modified_by = $7,
                 modified_date = NOW()

                 WHERE user_id = $8`,

                [

                    username,
                    full_name,
                    assignableRole,
                    start_date || null,
                    expiry_date || null,
                    is_permanent,
                    req.session.user.username,
                    userId

                ]

            );

        }

        await saveLog(

            req.session.user.username,

            "EDIT_USER",

            `Edit user ${username} (ID ${userId})`,

            req.ip

        );

        res.json({

            success: true,
            message: "User updated"

        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            success: false,
            error: error.message

        });

    }

});

/* GET ACTIVITY LOGS */

router.get(

    "/activity-logs",

    checkSession,

    async (req, res) => {

        try {

            const result =
                await pool.query(

                    `SELECT *

                     FROM activity_logs

                     ORDER BY created_at DESC`

                );

            res.json({

                success: true,

                data: result.rows

            });

        } catch (error) {

            console.log(error);

            res.status(500).json({

                success: false,
                error: error.message

            });

        }

    }

);

router.post(

    "/forgot-password",

    async (req, res) => {

        try {

            const { username } = req.body;

            const result = await pool.query(

                `
                SELECT *
                FROM system_users
                WHERE username = $1
                `,

                [username]

            );

            if (result.rows.length === 0) {

                return res.json({

                    success:false,

                    message:"Username not found"

                });

            }

            const resetCode =

                "INS-" +

                Math.random()
                .toString(36)
                .substring(2, 6)
                .toUpperCase()

                +

                "-"

                +

                Math.random()
                .toString(36)
                .substring(2, 6)
                .toUpperCase();

                const expiry = new Date(

                    Date.now()
                
                    +
                
                    1000 * 60 * 60 * 24
                
                );

            await pool.query(

                `
                UPDATE system_users
                SET
                    reset_code = $1,
                    reset_expired_at = $2,
                    approval_status = 'RESET'
                WHERE username = $3
                `,

                [
                    resetCode,
                    expiry,
                    username
                ]

            );

            res.json({

                success:true,
            
                reset_code:resetCode,
            
                expiry:expiry
            
            });

        }

        catch (err) {

            console.log(err);

            res.status(500).json({

                success:false,

                message:"Server error"

            });

        }

    }

);

router.post(

    "/verify-reset-code/:id",

    checkSession,

    async (req, res) => {

        try {

            if (

                !["ADMIN","SUPERADMIN"]
                
                .includes(
                
                req.session.role_name
                
                )
                
                )
                 {

                return res.status(403).json({

                    success:false,

                    message:"Access denied"

                });

            }

            const userId =
                req.params.id;

            const { reset_code } =
                req.body;

            const result =
                await pool.query(

                    `
                    SELECT *

                    FROM system_users

                    WHERE user_id = $1
                    `,

                    [userId]

                );

            if (

                result.rows.length === 0

            ) {

                return res.json({

                    success:false,

                    message:"User not found"

                });

            }

            const user =
                result.rows[0];

            if (

                user.reset_code !==
                reset_code

            ) {

                return res.json({

                    success:false,

                    message:"Invalid reset code"

                });

            }

            if (

                !user.reset_expired_at ||

                new Date() >

                new Date(
                    user.reset_expired_at
                )

            ) {

                return res.json({

                    success:false,

                    message:"Reset code expired"

                });

            }

            await pool.query(

                `
                UPDATE system_users

                SET

                password = NULL,

                must_change_password = true,

                approval_status = 'APPROVED',

                reset_code = null,

                reset_expired_at = null,

                modified_by = $1,

                modified_date = NOW()

                WHERE user_id = $2
                `,

                [

                    req.session.user.username,

                    userId

                ]

            );

            await saveLog(

                req.session.user.username,

                "VERIFY_RESET_CODE",

                `Verify reset code user ${user.username} (ID ${userId})`,

                req.ip

            );

            res.json({

                success:true,

                message:"Reset verified"

            });

        }
        catch (error) {

            console.log(error);

            res.status(500).json({

                success:false,

                message:"Server error"

            });

        }

    }

);

router.post(

    "/change-password",

    checkSession,

    async (req, res) => {

        try {

            const { password } =
                req.body;

            if (

                !password ||

                password.length < 8

            ) {

                return res.json({

                    success:false,

                    message:
                    "Password minimum 8 characters"

                });

            }

            const hashedPassword =
                await bcrypt.hash(password, 10);

            await pool.query(

                `
                UPDATE system_users

                SET

                password = $1,

                must_change_password = false,

                modified_by = $2,

                modified_date = NOW()

                WHERE user_id = $3
                `,

                [

                    hashedPassword,

                    req.session.user.username,

                    req.session.user_id

                ]

            );

            await saveLog(

                req.session.user.username,

                "CHANGE_PASSWORD",

                "Change password after reset",

                req.ip

            );

            res.json({

                success:true,

                message:"Password updated"

            });

        }
        catch (error) {

            console.log(error);

            res.status(500).json({

                success:false,

                message:"Server error"

            });

        }

    }

);

module.exports = router;
