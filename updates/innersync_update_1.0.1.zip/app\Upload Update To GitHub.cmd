@echo off
cd /d "%~dp0"
node tools\upload-update-to-github.js %*
pause
