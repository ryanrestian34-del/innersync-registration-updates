const express = require("express");
const router = express.Router();
const pool = require("../database/db");
const crypto = require("crypto");
const { createSystemNotification } = require("./notificationService");

let schemaReady = false;
let healthSchedulerStarted = false;
let healthCheckRunning = false;
const dynamicTokenRefreshPromises = new Map();
const THIRD_PARTY_REQUEST_TIMEOUT_MS = Number(process.env.THIRD_PARTY_REQUEST_TIMEOUT_MS || 3000);
const THIRD_PARTY_AUTH_TIMEOUT_MS = Number(process.env.THIRD_PARTY_AUTH_TIMEOUT_MS || 3000);

const DEFAULT_INNERRANGE_TEMPLATE = `<User>
  <FirstName>{first_name}</FirstName>
  <SecondName>{second_name}</SecondName>
  <IsVisitor>True</IsVisitor>
  <PrimaryPermissionGroup>
    <Ref Type="PermissionGroup" PartitionID="0" ID="QG2" />
  </PrimaryPermissionGroup>
  <Cards>
    <Card>
      <CardType>
        <Ref Type="CardTemplate" ID="TM2"/>
      </CardType>
      <CardNumber>{card_number}</CardNumber>
    </Card>
  </Cards>
  <StartDateTime>{start_date_iso}</StartDateTime>
  <ExpiryDateTime>{expiry_date_iso}</ExpiryDateTime>
  <Notes>{purpose_note}</Notes>
  <UserCancelled>False</UserCancelled>
  <Site>
    <Ref Type="SiteKeyword" ID="1" Name="RS. PIK" />
  </Site>
</User>`;

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function requireSuperAdminHttp(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    if (String(req.session?.role_name || "").toUpperCase() !== "SUPERADMIN") {
        return res.status(403).json({ success: false, message: "API Configuration hanya bisa diakses SUPERADMIN" });
    }

    next();
}

const API_INTEGRATION_PATHS = [
    "/api/third-party-settings",
    "/api/api-health-status",
    "/api/api-templates",
    "/api/testing-api",
    "/api/api-activity-logs"
];

router.use(API_INTEGRATION_PATHS, requireSuperAdminHttp);

function getPayloadVisitorName(payload) {
    return `${payload?.first_name || ""} ${payload?.second_name || ""}`.trim() || payload?.visitor_name || "Visitor";
}

async function notifyThirdPartyResult(req, triggerEvent, payload, result) {
    if (result?.skipped) return;
    const provider = String(result?.provider_type || "GENERIC").toUpperCase();
    const eventType = String(triggerEvent || result?.action_type || "API").toUpperCase();
    const success = result?.success === true;
    const visitorName = getPayloadVisitorName(payload);
    await createSystemNotification(req, {
        channel: `API_${provider}`,
        event_type: eventType,
        provider_type: provider,
        status: success ? "SUCCESS" : "FAILED",
        visitor_id: payload?.visitor_id || null,
        visitor_name: visitorName,
        target: result?.config_name || null,
        title: `${provider} ${eventType} ${success ? "berhasil" : "gagal"}`,
        message: success
            ? `${result?.config_name || provider} berhasil diproses${result?.status ? ` (${result.status})` : ""}.`
            : (result?.error || `${result?.config_name || provider} gagal diproses.`),
        detail: {
            config_id: result?.config_id || null,
            config_name: result?.config_name || null,
            status: result?.status || null,
            duration_ms: result?.duration_ms || null,
            reference_id: result?.reference_id || null,
            card_number: payload?.card_number || null
        }
    });
}

function safeJson(value, fallback) {
    if (!value) return fallback;
    if (typeof value === "object") return value;
    try {
        return JSON.parse(value);
    } catch (error) {
        return fallback;
    }
}

async function ensureApiSchema() {
    if (schemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS third_party_api_configs (
            config_id SERIAL PRIMARY KEY,
            config_name VARCHAR(120) NOT NULL,
            description TEXT,
            base_url TEXT NOT NULL,
            endpoint_path TEXT,
            http_method VARCHAR(12) NOT NULL DEFAULT 'POST',
            provider_type VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE',
            execution_order INTEGER NOT NULL DEFAULT 100,
            request_timeout_ms INTEGER NOT NULL DEFAULT 0,
            stop_on_failed BOOLEAN NOT NULL DEFAULT FALSE,
            trigger_event VARCHAR(30) NOT NULL DEFAULT 'CHECKIN',
            action_type VARCHAR(30) NOT NULL DEFAULT 'ADD',
            auth_type VARCHAR(30) NOT NULL DEFAULT 'NONE',
            api_key_header VARCHAR(80),
            api_key TEXT,
            token TEXT,
            dynamic_auth_url TEXT,
            dynamic_auth_method VARCHAR(12) NOT NULL DEFAULT 'POST',
            dynamic_auth_body TEXT,
            dynamic_token_path VARCHAR(120) NOT NULL DEFAULT '[0].token',
            dynamic_expiry_path VARCHAR(120) NOT NULL DEFAULT '[0].exp',
            dynamic_auth_header VARCHAR(80) NOT NULL DEFAULT 'Authorization',
            dynamic_auth_prefix VARCHAR(40) NOT NULL DEFAULT 'Bearer',
            username TEXT,
            password TEXT,
            custom_headers JSONB DEFAULT '{}'::jsonb,
            field_mapping JSONB DEFAULT '{}'::jsonb,
            template_mode VARCHAR(20) NOT NULL DEFAULT 'CUSTOM',
            template_id INTEGER,
            body_type VARCHAR(20) NOT NULL DEFAULT 'JSON',
            body_template TEXT,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS api_templates (
            template_id SERIAL PRIMARY KEY,
            template_name VARCHAR(120) UNIQUE NOT NULL,
            description TEXT,
            body_type VARCHAR(20) NOT NULL DEFAULT 'XML',
            field_mapping JSONB DEFAULT '{}'::jsonb,
            body_template TEXT NOT NULL,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS api_activity_logs (
            log_id SERIAL PRIMARY KEY,
            config_id INTEGER,
            config_name VARCHAR(120),
            action_type VARCHAR(30),
            http_method VARCHAR(12),
            request_url TEXT,
            request_headers JSONB DEFAULT '{}'::jsonb,
            request_payload JSONB DEFAULT '{}'::jsonb,
            response_status INTEGER,
            response_body TEXT,
            success BOOLEAN NOT NULL DEFAULT FALSE,
            error_message TEXT,
            duration_ms INTEGER,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS api_token_cache (
            cache_id SERIAL PRIMARY KEY,
            config_id INTEGER NOT NULL UNIQUE,
            auth_cache_key TEXT,
            provider_type VARCHAR(30),
            token TEXT NOT NULL,
            expires_at TIMESTAMP,
            raw_response TEXT,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);
    await pool.query("ALTER TABLE api_token_cache ADD COLUMN IF NOT EXISTS auth_cache_key TEXT");
    await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS idx_api_token_cache_auth_cache_key ON api_token_cache (auth_cache_key) WHERE auth_cache_key IS NOT NULL");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS api_test_presets (
            preset_id SERIAL PRIMARY KEY,
            request_name VARCHAR(120) NOT NULL,
            request_url TEXT NOT NULL,
            http_method VARCHAR(12) NOT NULL DEFAULT 'GET',
            auth_type VARCHAR(30) NOT NULL DEFAULT 'NONE',
            api_key_header VARCHAR(80),
            api_key TEXT,
            token TEXT,
            username TEXT,
            password TEXT,
            headers JSONB DEFAULT '{}'::jsonb,
            query_params JSONB DEFAULT '{}'::jsonb,
            request_body JSONB DEFAULT '{}'::jsonb,
            body_type VARCHAR(20) NOT NULL DEFAULT 'JSON',
            raw_body TEXT,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS api_provider_health_status (
            status_id SERIAL PRIMARY KEY,
            config_id INTEGER UNIQUE,
            config_name VARCHAR(120),
            provider_type VARCHAR(30),
            status VARCHAR(20) NOT NULL DEFAULT 'UNKNOWN',
            previous_status VARCHAR(20),
            response_status INTEGER,
            duration_ms INTEGER,
            error_message TEXT,
            last_check_time TIMESTAMP,
            last_success_time TIMESTAMP,
            last_fail_time TIMESTAMP,
            checked_by VARCHAR(100),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE api_test_presets ADD COLUMN IF NOT EXISTS body_type VARCHAR(20) NOT NULL DEFAULT 'JSON'");
    await pool.query("ALTER TABLE api_test_presets ADD COLUMN IF NOT EXISTS raw_body TEXT");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS body_type VARCHAR(20) NOT NULL DEFAULT 'JSON'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS body_template TEXT");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS template_mode VARCHAR(20) NOT NULL DEFAULT 'CUSTOM'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS template_id INTEGER");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS trigger_event VARCHAR(30) NOT NULL DEFAULT 'CHECKIN'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS provider_type VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS execution_order INTEGER NOT NULL DEFAULT 100");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS request_timeout_ms INTEGER NOT NULL DEFAULT 0");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS stop_on_failed BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_auth_url TEXT");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_auth_method VARCHAR(12) NOT NULL DEFAULT 'POST'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_auth_body TEXT");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_token_path VARCHAR(120) NOT NULL DEFAULT '[0].token'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_expiry_path VARCHAR(120) NOT NULL DEFAULT '[0].exp'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_auth_header VARCHAR(80) NOT NULL DEFAULT 'Authorization'");
    await pool.query("ALTER TABLE third_party_api_configs ADD COLUMN IF NOT EXISTS dynamic_auth_prefix VARCHAR(40) NOT NULL DEFAULT 'Bearer'");

    await pool.query(
        `INSERT INTO api_templates (
            template_name,
            description,
            body_type,
            field_mapping,
            body_template,
            created_by,
            created_time
        )
        VALUES ($1,$2,$3,$4,$5,$6,NOW())
        ON CONFLICT (template_name) DO NOTHING`,
        [
            "Innerrange Add User",
            "Template XML default untuk add/update visitor ke Innerrange",
            "XML",
            {},
            DEFAULT_INNERRANGE_TEMPLATE,
            "SYSTEM"
        ]
    );

    schemaReady = true;
}

router.use(API_INTEGRATION_PATHS, async (req, res, next) => {
    try {
        await ensureApiSchema();
        next();
    } catch (error) {
        next(error);
    }
});

function normalizeConfigBody(body) {
    return {
        config_name: String(body.config_name || "").trim(),
        description: String(body.description || "").trim(),
        base_url: String(body.base_url || "").trim(),
        endpoint_path: String(body.endpoint_path || "").trim(),
        http_method: String(body.http_method || "POST").toUpperCase(),
        provider_type: String(body.provider_type || "GENERIC").toUpperCase(),
        execution_order: Number.isFinite(Number(body.execution_order)) ? Number(body.execution_order) : 100,
        request_timeout_ms: Number.isFinite(Number(body.request_timeout_ms)) ? Number(body.request_timeout_ms) : 0,
        stop_on_failed: body.stop_on_failed === true,
        trigger_event: String(body.trigger_event || "CHECKIN").toUpperCase(),
        action_type: String(body.action_type || "ADD").toUpperCase(),
        auth_type: String(body.auth_type || "NONE").toUpperCase(),
        api_key_header: String(body.api_key_header || "").trim(),
        api_key: String(body.api_key || "").trim(),
        token: String(body.token || "").trim(),
        dynamic_auth_url: String(body.dynamic_auth_url || "").trim(),
        dynamic_auth_method: String(body.dynamic_auth_method || "POST").toUpperCase(),
        dynamic_auth_body: String(body.dynamic_auth_body || ""),
        dynamic_token_path: String(body.dynamic_token_path || "[0].token").trim(),
        dynamic_expiry_path: String(body.dynamic_expiry_path || "[0].exp").trim(),
        dynamic_auth_header: String(body.dynamic_auth_header || "Authorization").trim(),
        dynamic_auth_prefix: String(body.dynamic_auth_prefix || "Bearer").trim(),
        username: String(body.username || "").trim(),
        password: String(body.password || "").trim(),
        custom_headers: safeJson(body.custom_headers, {}),
        field_mapping: safeJson(body.field_mapping, {}),
        template_mode: String(body.template_mode || "CUSTOM").toUpperCase(),
        template_id: body.template_id ? Number(body.template_id) : null,
        body_type: String(body.body_type || "JSON").toUpperCase(),
        body_template: String(body.body_template || ""),
        is_active: body.is_active !== false
    };
}

function validateConfig(config) {
    if (!config.config_name) return "Nama setting wajib diisi";
    if (!config.base_url) return "Base URL wajib diisi";
    if (!["GET", "POST", "PUT", "PATCH", "DELETE"].includes(config.http_method)) return "HTTP method tidak valid";
    if (!["GENERIC", "INNERRANGE", "SCHINDLER"].includes(config.provider_type)) return "Provider type tidak valid";
    if (config.request_timeout_ms < 0 || config.request_timeout_ms > 60000) return "Request timeout harus 0 sampai 60000 ms";
    if (!["CHECKIN", "EDIT", "DELETE", "CHECKOUT", "CHECK_INNERRANGE", "CHECK_SCHINDLER", "HEALTH_CHECK", "SYNC_ADD", "SYNC_UPDATE", "SYNC_DELETE", "SYNC_CANCEL", "SYNC_EXPIRE", "SYNC_DISABLE"].includes(config.trigger_event)) return "Mode aktif tidak valid";
    if (!["GET", "ADD", "EDIT", "PUT", "DELETE", "CANCEL", "EXPIRE", "DISABLE", "CUSTOM"].includes(config.action_type)) return "Action tidak valid";
    if (!["NONE", "API_KEY", "BEARER", "BASIC", "CUSTOM_HEADER", "DYNAMIC_BEARER"].includes(config.auth_type)) return "Auth type tidak valid";
    if (config.auth_type === "DYNAMIC_BEARER" && !config.dynamic_auth_url) return "Login URL dynamic token wajib diisi";
    if (config.auth_type === "DYNAMIC_BEARER" && !["POST", "GET"].includes(config.dynamic_auth_method)) return "Login method dynamic token tidak valid";
    if (!["CUSTOM", "TEMPLATE"].includes(config.template_mode)) return "Mode template tidak valid";
    if (config.template_mode === "TEMPLATE" && !config.template_id) return "Pilih template API terlebih dahulu";
    if (!["JSON", "XML", "TEXT"].includes(config.body_type)) return "Body type tidak valid";
    return null;
}

function normalizeTemplateBody(body) {
    return {
        template_name: String(body.template_name || "").trim(),
        description: String(body.description || "").trim(),
        body_type: String(body.body_type || "XML").toUpperCase(),
        field_mapping: safeJson(body.field_mapping, {}),
        body_template: String(body.body_template || "")
    };
}

function validateTemplate(template) {
    if (!template.template_name) return "Nama template wajib diisi";
    if (!["JSON", "XML", "TEXT"].includes(template.body_type)) return "Body type template tidak valid";
    if (!template.body_template.trim()) return "Body template wajib diisi";
    return null;
}

function joinUrl(baseUrl, endpointPath) {
    const cleanBase = String(baseUrl || "").replace(/\/+$/, "");
    const cleanPath = String(endpointPath || "").replace(/^\/+/, "");
    return cleanPath ? `${cleanBase}/${cleanPath}` : cleanBase;
}

function getDefaultContentType(bodyType) {
    if (bodyType === "XML") return "application/xml";
    if (bodyType === "TEXT") return "text/plain";
    return "application/json";
}

function readPath(source, path) {
    if (!path) return undefined;
    const tokens = String(path)
        .replace(/\[(\d+)\]/g, ".$1")
        .replace(/^\./, "")
        .split(".")
        .filter(Boolean);

    return tokens.reduce((current, key) => {
        if (current === undefined || current === null) return undefined;
        return current[key];
    }, source);
}

async function fetchWithTimeout(url, options = {}, timeoutMs = THIRD_PARTY_REQUEST_TIMEOUT_MS) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
        return await fetch(url, {
            ...options,
            signal: controller.signal
        });
    } catch (error) {
        if (error.name === "AbortError") {
            throw new Error(`Request timeout setelah ${timeoutMs} ms`);
        }
        throw error;
    } finally {
        clearTimeout(timeout);
    }
}

function getConfigRequestTimeout(config) {
    const configuredTimeout = Number(config.request_timeout_ms || 0);
    if (Number.isFinite(configuredTimeout) && configuredTimeout > 0) {
        return configuredTimeout;
    }

    const providerType = String(config.provider_type || "").toUpperCase();
    const triggerEvent = String(config.trigger_event || "").toUpperCase();
    if (providerType === "INNERRANGE" && ["DELETE", "CHECKOUT"].includes(triggerEvent)) {
        return 6000;
    }

    return THIRD_PARTY_REQUEST_TIMEOUT_MS;
}

function getDynamicAuthCacheKey(config) {
    const parts = [
        String(config.provider_type || "").toUpperCase(),
        String(config.dynamic_auth_method || "POST").toUpperCase(),
        String(config.dynamic_auth_url || "").trim(),
        String(config.dynamic_auth_body || "{}"),
        String(config.dynamic_token_path || "[0].token"),
        String(config.dynamic_expiry_path || "[0].exp"),
        String(config.dynamic_auth_header || "Authorization"),
        String(config.dynamic_auth_prefix || "Bearer")
    ];
    return crypto.createHash("sha1").update(parts.join("|")).digest("hex");
}

async function readCachedDynamicBearerToken(config) {
    const authCacheKey = getDynamicAuthCacheKey(config);
    const cached = await pool.query(
        `SELECT token, expires_at
         FROM api_token_cache
         WHERE (auth_cache_key = $1 OR config_id = $2)
           AND (expires_at IS NULL OR expires_at > NOW() + INTERVAL '60 seconds')
         ORDER BY updated_at DESC
         LIMIT 1`,
        [authCacheKey, config.config_id]
    );

    if (cached.rows[0]?.token) {
        return cached.rows[0].token;
    }

    return null;
}

async function getDynamicBearerToken(req, config, forceRefresh = false) {
    const authCacheKey = getDynamicAuthCacheKey(config);
    if (!forceRefresh) {
        const cachedToken = await readCachedDynamicBearerToken(config);
        if (cachedToken) return cachedToken;
    }

    if (dynamicTokenRefreshPromises.has(authCacheKey)) {
        return dynamicTokenRefreshPromises.get(authCacheKey);
    }

    const refreshPromise = loginDynamicBearerToken(req, config, forceRefresh)
        .finally(() => dynamicTokenRefreshPromises.delete(authCacheKey));

    dynamicTokenRefreshPromises.set(authCacheKey, refreshPromise);
    return refreshPromise;
}

async function loginDynamicBearerToken(req, config, forceRefresh = false) {
    const authCacheKey = getDynamicAuthCacheKey(config);
    if (forceRefresh) {
        await pool.query("DELETE FROM api_token_cache WHERE config_id = $1 OR auth_cache_key = $2", [config.config_id, authCacheKey]);
    } else {
        const cachedToken = await readCachedDynamicBearerToken(config);
        if (cachedToken) return cachedToken;
    }

    const loginHeaders = { "Content-Type": "application/json" };
    const loginOptions = {
        method: config.dynamic_auth_method || "POST",
        headers: loginHeaders
    };

    if (loginOptions.method !== "GET") {
        loginOptions.body = config.dynamic_auth_body || "{}";
    }

    const started = Date.now();
    const response = await fetchWithTimeout(config.dynamic_auth_url, loginOptions, THIRD_PARTY_AUTH_TIMEOUT_MS);
    const responseText = await response.text();
    const durationMs = Date.now() - started;

    await writeApiLog(req, {
        config_id: config.config_id,
        config_name: `${config.config_name} - Login Token`,
        action_type: "AUTH_LOGIN",
        http_method: loginOptions.method,
        request_url: config.dynamic_auth_url,
        request_headers: loginHeaders,
        request_payload: loginOptions.body ? { body: "***" } : {},
        response_status: response.status,
        response_body: responseText.slice(0, 5000),
        success: response.ok,
        duration_ms: durationMs
    });

    if (!response.ok) {
        throw new Error(`Login token gagal. Status ${response.status}`);
    }

    let parsed;
    try {
        parsed = JSON.parse(responseText);
    } catch (error) {
        throw new Error("Response login token bukan JSON valid.");
    }

    const token = readPath(parsed, config.dynamic_token_path || "[0].token");
    const expiryValue = readPath(parsed, config.dynamic_expiry_path || "[0].exp");
    if (!token) {
        throw new Error(`Token tidak ditemukan pada path ${config.dynamic_token_path || "[0].token"}`);
    }

    const expiresAt = expiryValue
        ? new Date(Number(expiryValue) * 1000)
        : new Date(Date.now() + 60 * 60 * 1000);

    await pool.query("DELETE FROM api_token_cache WHERE config_id = $1 OR auth_cache_key = $2", [config.config_id, authCacheKey]);
    await pool.query(
        `INSERT INTO api_token_cache (
            config_id,
            auth_cache_key,
            provider_type,
            token,
            expires_at,
            raw_response,
            updated_at
        )
        VALUES ($1,$2,$3,$4,$5,$6,NOW())
        ON CONFLICT (config_id)
        DO UPDATE SET
            auth_cache_key = EXCLUDED.auth_cache_key,
            provider_type = EXCLUDED.provider_type,
            token = EXCLUDED.token,
            expires_at = EXCLUDED.expires_at,
            raw_response = EXCLUDED.raw_response,
            updated_at = NOW()`,
        [
            config.config_id,
            authCacheKey,
            config.provider_type || null,
            token,
            expiresAt,
            responseText.slice(0, 5000)
        ]
    );

    return token;
}

async function buildHeaders(req, config, bodyType = "JSON", forceTokenRefresh = false) {
    const headers = {
        "Content-Type": getDefaultContentType(bodyType),
        ...(config.custom_headers || {})
    };

    if (config.api_key) {
        headers[config.api_key_header || "x-api-key"] = config.api_key;
    }

    if (config.auth_type === "BEARER" && config.token) {
        headers.Authorization = `Bearer ${config.token}`;
    }

    if (config.auth_type === "DYNAMIC_BEARER") {
        const dynamicToken = await getDynamicBearerToken(req, config, forceTokenRefresh);
        const headerName = config.dynamic_auth_header || "Authorization";
        const prefix = config.dynamic_auth_prefix || "Bearer";
        headers[headerName] = prefix ? `${prefix} ${dynamicToken}` : dynamicToken;
    }

    if (config.auth_type === "BASIC" && (config.username || config.password)) {
        const encoded = Buffer.from(`${config.username || ""}:${config.password || ""}`).toString("base64");
        headers.Authorization = `Basic ${encoded}`;
    }

    return headers;
}

function redactHeaders(headers) {
    const redacted = { ...(headers || {}) };
    Object.keys(redacted).forEach(key => {
        if (key.toLowerCase() === "authorization" || /api[-_ ]?key|token|session/i.test(key)) {
            redacted[key] = "***";
        }
    });
    return redacted;
}

function getByPath(source, path) {
    if (!path) return undefined;
    return String(path).split(".").reduce((current, key) => {
        if (current === undefined || current === null) return undefined;
        return current[key];
    }, source);
}

function pad2(value) {
    return String(value).padStart(2, "0");
}

function formatLocalApiDate(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    const offsetMinutes = -date.getTimezoneOffset();
    const sign = offsetMinutes >= 0 ? "+" : "-";
    const absOffset = Math.abs(offsetMinutes);
    return [
        `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`,
        `T${pad2(date.getHours())}:${pad2(date.getMinutes())}:${pad2(date.getSeconds())}`,
        `${sign}${pad2(Math.floor(absOffset / 60))}:${pad2(absOffset % 60)}`
    ].join("");
}

function formatPlainApiDate(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return [
        `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`,
        `${pad2(date.getHours())}:${pad2(date.getMinutes())}:${pad2(date.getSeconds())}`
    ].join(" ");
}

function isUsableApiDate(value) {
    if (!value) return false;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return false;
    return date.getFullYear() >= 1970;
}

function firstUsableApiDate(...values) {
    const value = values.find(isUsableApiDate);
    return value || null;
}

function permanentExpiryDate() {
    return new Date("2099-12-31T23:59:59+07:00");
}

function padSchindlerBadgeNumber(value) {
    const badgeNumber = String(value ?? "").trim();
    if (!badgeNumber) return "";
    const normalized = badgeNumber.length > 18 ? badgeNumber.slice(-18) : badgeNumber;
    return normalized.length >= 18 ? normalized : normalized.padStart(18, "0");
}

function buildApiContext(payload) {
    const source = payload || {};
    const visitorName = `${source.first_name || ""} ${source.second_name || ""}`.trim();
    const thirdPartyUserId = source.third_party_user_id || source.innerrange_user_id || "";
    const usableStartDate = firstUsableApiDate(source.start_date, source.check_in_time, source.creation_date, source.modified_date) || new Date();
    const usableExpiryDate = firstUsableApiDate(source.expiry_date, source.check_out_time) || permanentExpiryDate();
    return {
        ...source,
        visitor_name: visitorName,
        full_name: visitorName,
        third_party_user_id: thirdPartyUserId,
        innerrange_user_id: thirdPartyUserId,
        schindler_person_id: source.schindler_person_id || "",
        schindler_profile_name: source.schindler_profile_name || source.cf_profile_name || "default",
        schindler_badge_no1: padSchindlerBadgeNumber(source.card_number),
        start_date_iso: formatLocalApiDate(usableStartDate),
        expiry_date_iso: formatLocalApiDate(usableExpiryDate),
        start_date_text: formatPlainApiDate(usableStartDate),
        expiry_date_text: formatPlainApiDate(usableExpiryDate),
        schindler_start_date_text: formatPlainApiDate(usableStartDate),
        schindler_expiry_date_text: formatPlainApiDate(usableExpiryDate),
        check_in_time_iso: formatLocalApiDate(source.check_in_time),
        check_out_time_iso: formatLocalApiDate(source.check_out_time),
        check_in_time_text: formatPlainApiDate(source.check_in_time),
        check_out_time_text: formatPlainApiDate(source.check_out_time)
    };
}

function applyFieldMapping(context, fieldMapping) {
    const mapping = fieldMapping && typeof fieldMapping === "object" ? fieldMapping : {};
    const entries = Object.entries(mapping);
    if (entries.length === 0) return { ...context };

    return entries.reduce((mapped, [targetKey, sourcePath]) => {
        mapped[targetKey] = getByPath(context, sourcePath);
        return mapped;
    }, {});
}

function escapeXml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}

function renderBodyTemplate(template, context, escapeValues) {
    return String(template || "").replace(/\{([a-zA-Z0-9_.-]+)\}/g, (_, key) => {
        const value = getByPath(context, key);
        return escapeValues ? escapeXml(value) : String(value ?? "");
    });
}

function escapeJsonString(value) {
    return JSON.stringify(String(value ?? "")).slice(1, -1);
}

function renderJsonTemplate(template, context) {
    return String(template || "").replace(/\{([a-zA-Z0-9_.-]+)\}/g, (_, key) => {
        const value = getByPath(context, key);
        return escapeJsonString(value);
    });
}

function renderUrlTemplate(template, context) {
    return String(template || "").replace(/\{([a-zA-Z0-9_.-]+)\}/g, (_, key) => {
        const value = getByPath(context, key);
        return encodeURIComponent(String(value ?? ""));
    });
}

function normalizeSchindlerJsonBody(parsedBody) {
    const parameter = parsedBody?.jdata?.parameter;
    if (parameter && Object.prototype.hasOwnProperty.call(parameter, "badgeNo1")) {
        parameter.badgeNo1 = padSchindlerBadgeNumber(parameter.badgeNo1);
    }
    return parsedBody;
}

function ensurePermissionGroupRef(xmlBody, context) {
    const integrationId = context.permission_group_integration_id || context.innerrange_permission_group_id;
    if (!integrationId || !/<Ref\b[^>]*\bType\s*=\s*["']PermissionGroup["']/i.test(xmlBody)) {
        return xmlBody;
    }

    const escapedIntegrationId = escapeXml(integrationId);
    return xmlBody.replace(/<Ref\b([^>]*\bType\s*=\s*["']PermissionGroup["'][^>]*)>/gi, (match, attributes) => {
        if (/\bID\s*=\s*["'][^"']*["']/i.test(attributes)) {
            return `<Ref${attributes.replace(/\bID\s*=\s*["'][^"']*["']/i, `ID="${escapedIntegrationId}"`)}>`;
        }
        return `<Ref${attributes} ID="${escapedIntegrationId}">`;
    });
}

function shouldInjectUserAddress(config, context) {
    if (String(config.provider_type || "GENERIC").toUpperCase() !== "INNERRANGE") {
        return false;
    }

    const triggerEvent = String(config.trigger_event || "").toUpperCase();
    if (triggerEvent === "EDIT") return true;
    if (triggerEvent === "CHECKIN" && context.reuse_third_party_user_id === true) return true;
    return false;
}

function ensureUserAddress(xmlBody, config, context) {
    if (!shouldInjectUserAddress(config, context)) {
        return xmlBody;
    }

    if (!/<User\b/i.test(xmlBody)) {
        return xmlBody;
    }

    const userId = context.innerrange_user_id || context.third_party_user_id;
    if (!userId) {
        throw new Error("Innerrange User ID belum tersedia. API dibatalkan agar tidak membuat user baru yang tidak diinginkan.");
    }

    const escapedUserId = escapeXml(userId);
    if (/<User\b[^>]*\bAddress\s*=\s*["'][^"']+["'][^>]*>/i.test(xmlBody)) {
        return xmlBody;
    }

    if (/<User\b[^>]*\bAddress\s*=\s*["'][^"']*["'][^>]*>/i.test(xmlBody)) {
        return xmlBody.replace(/\bAddress\s*=\s*["'][^"']*["']/i, `Address="${escapedUserId}"`);
    }

    return xmlBody.replace(/<User\b([^>]*)>/i, `<User Address="${escapedUserId}"$1>`);
}

function buildConfiguredPayload(config, sourcePayload) {
    const baseContext = buildApiContext(sourcePayload);
    const mappedPayload = applyFieldMapping(baseContext, config.field_mapping);
    const templateContext = { ...baseContext, ...mappedPayload };
    return { baseContext, mappedPayload, templateContext };
}

function extractThirdPartyReferenceId(responseText) {
    const text = String(responseText || "");
    const patterns = [
        /<Ref\b[^>]*\bType=["']User["'][^>]*\bID=["']([^"']+)["']/i,
        /<User\b[^>]*\bID=["']([^"']+)["']/i,
        /<Address>\s*(U\d+)\s*<\/Address>/i,
        /<ID>\s*(U\d+)\s*<\/ID>/i,
        /"ID"\s*:\s*"(U[^"]+)"/i,
        /"id"\s*:\s*"(U[^"]+)"/i
    ];

    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match?.[1]) return match[1];
    }

    return null;
}

function getProviderResponseError(config, responseText) {
    const providerType = String(config.provider_type || "GENERIC").toUpperCase();
    const text = String(responseText || "");

    if (providerType === "SCHINDLER") {
        try {
            const parsed = JSON.parse(text);
            const data = parsed?.data || parsed?.[0]?.data || parsed;
            if (String(data?.status || "").toLowerCase() === "fail") {
                return data?.message || data?.msg || "Schindler API mengembalikan status fail.";
            }

            const isHealthCheck = String(config.trigger_event || "").toUpperCase() === "HEALTH_CHECK"
                || String(config.action_type || "").toUpperCase() === "HEALTH_CHECK";
            if (isHealthCheck) {
                const message = data?.message || {};
                const serviceStatus = Array.isArray(message?.serviceStatus) ? message.serviceStatus : [];
                const databaseOnlineLine = serviceStatus.find(item => /^database online\s*:/i.test(String(item || "")));
                const databaseOnlineValue = String(databaseOnlineLine || "").split(":").slice(1).join(":").trim();

                if (!databaseOnlineLine) {
                    return "Schindler database online tidak ditemukan di response serviceStatus.";
                }

                if (!databaseOnlineValue || databaseOnlineValue === "0") {
                    return "Schindler database offline.";
                }
            }
        } catch (error) {
            return null;
        }
    }

    if (providerType === "INNERRANGE") {
        const isHealthCheck = String(config.trigger_event || "").toUpperCase() === "HEALTH_CHECK"
            || String(config.action_type || "").toUpperCase() === "HEALTH_CHECK";
        const endpointPath = String(config.endpoint_path || "");

        if (isHealthCheck && /ApiVersion/i.test(endpointPath)) {
            const hasApiVersionResponse = /<ApiVersion>\s*[^<]*\/restApi\/ApiVersion\/v2\s*<\/ApiVersion>/i.test(text);
            if (!hasApiVersionResponse) {
                return "Innerrange ApiVersion response tidak valid.";
            }
        }

        if (/<Success>\s*false\s*<\/Success>/i.test(text)) {
            const message = text.match(/<Message>\s*([\s\S]*?)\s*<\/Message>/i)?.[1];
            return message || "Innerrange API mengembalikan Success false.";
        }
    }

    return null;
}

async function resolveConfigTemplate(config) {
    if (String(config.template_mode || "CUSTOM").toUpperCase() !== "TEMPLATE" || !config.template_id) {
        return config;
    }

    const result = await pool.query("SELECT * FROM api_templates WHERE template_id = $1", [config.template_id]);
    if (result.rows.length === 0) {
        return config;
    }

    const template = result.rows[0];
    return {
        ...config,
        body_type: template.body_type || config.body_type,
        body_template: template.body_template || config.body_template,
        field_mapping: template.field_mapping || config.field_mapping
    };
}

async function writeApiLog(req, detail) {
    await pool.query(
        `INSERT INTO api_activity_logs (
            config_id,
            config_name,
            action_type,
            http_method,
            request_url,
            request_headers,
            request_payload,
            response_status,
            response_body,
            success,
            error_message,
            duration_ms,
            created_by,
            created_time
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,NOW())`,
        [
            detail.config_id || null,
            detail.config_name || null,
            detail.action_type || null,
            detail.http_method || null,
            detail.request_url || null,
            detail.request_headers || {},
            detail.request_payload || {},
            detail.response_status || null,
            detail.response_body || null,
            detail.success === true,
            detail.error_message || null,
            detail.duration_ms || null,
            getCurrentUsername(req)
        ]
    );
}

async function executeThirdPartyRequest(req, config, payload, options = {}) {
    const effectiveConfig = await resolveConfigTemplate(config);
    const method = String(effectiveConfig.http_method || "POST").toUpperCase();
    const bodyType = String(effectiveConfig.body_type || "JSON").toUpperCase();
    const started = Date.now();
    const { mappedPayload, templateContext } = buildConfiguredPayload(effectiveConfig, payload);
    const renderedEndpointPath = renderUrlTemplate(effectiveConfig.endpoint_path, templateContext);
    let requestUrl = joinUrl(effectiveConfig.base_url, renderedEndpointPath);
    let requestPayloadForLog = mappedPayload;
    let requestBody = null;

    if (["GET", "DELETE"].includes(method)) {
        const url = new URL(requestUrl);
        const hasExplicitMapping = Object.keys(effectiveConfig.field_mapping || {}).length > 0;
        const queryPayload = hasExplicitMapping ? mappedPayload : {};
        Object.entries(queryPayload || {}).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== "") {
                url.searchParams.set(key, String(value));
            }
        });
        requestUrl = url.toString();
        requestPayloadForLog = queryPayload;
    } else if (bodyType === "XML" || bodyType === "TEXT") {
        let renderedBody = renderBodyTemplate(effectiveConfig.body_template, templateContext, bodyType === "XML");
        if (bodyType === "XML") {
            if (String(effectiveConfig.provider_type || "GENERIC").toUpperCase() === "INNERRANGE") {
                renderedBody = ensurePermissionGroupRef(renderedBody, templateContext);
            }
            renderedBody = ensureUserAddress(renderedBody, effectiveConfig, templateContext);
        }
        requestBody = renderedBody;
        requestPayloadForLog = { body_type: bodyType, body: renderedBody };
    } else if (bodyType === "JSON" && String(effectiveConfig.body_template || "").trim()) {
        let renderedBody = renderJsonTemplate(effectiveConfig.body_template, templateContext);
        const parsedBody = JSON.parse(renderedBody);
        if (String(effectiveConfig.provider_type || "GENERIC").toUpperCase() === "SCHINDLER") {
            renderedBody = JSON.stringify(normalizeSchindlerJsonBody(parsedBody));
        }
        requestBody = renderedBody;
        requestPayloadForLog = { body_type: bodyType, body: renderedBody };
    } else {
        requestBody = JSON.stringify(mappedPayload || {});
    }

    try {
        const requestTimeoutMs = getConfigRequestTimeout(effectiveConfig);
        const sendRequest = async (forceTokenRefresh = false) => {
            const headers = await buildHeaders(req, effectiveConfig, bodyType, forceTokenRefresh);
            const fetchOptions = { method, headers };
            if (!["GET", "DELETE"].includes(method) && requestBody !== null) {
                fetchOptions.body = requestBody;
            }
            const response = await fetchWithTimeout(requestUrl, fetchOptions, requestTimeoutMs);
            const responseText = await response.text();
            return { response, responseText, headers };
        };

        let { response, responseText, headers } = await sendRequest(false);

        const shouldRefreshDynamicToken =
            String(effectiveConfig.auth_type || "").toUpperCase() === "DYNAMIC_BEARER"
            && (response.status === 401 || /login-error|token|unauthor/i.test(responseText));

        if (shouldRefreshDynamicToken) {
            ({ response, responseText, headers } = await sendRequest(true));
        }

        const durationMs = Date.now() - started;
        const providerError = getProviderResponseError(effectiveConfig, responseText);
        const isSuccess = response.ok && !providerError;

        if (options.logApi !== false) {
            await writeApiLog(req, {
                config_id: effectiveConfig.config_id,
                config_name: effectiveConfig.config_name,
                action_type: effectiveConfig.action_type,
                http_method: method,
                request_url: requestUrl,
                request_headers: redactHeaders(headers),
                request_payload: requestPayloadForLog,
                response_status: response.status,
                response_body: responseText.slice(0, 5000),
                success: isSuccess,
                error_message: providerError,
                duration_ms: durationMs
            });
        }

        return {
            success: isSuccess,
            status: response.status,
            body: responseText,
            reference_id: extractThirdPartyReferenceId(responseText),
            error_message: providerError,
            duration_ms: durationMs,
            request_url: requestUrl,
            http_method: method,
            request_headers: redactHeaders(headers),
            request_payload: requestPayloadForLog
        };
    } catch (error) {
        const durationMs = Date.now() - started;

        if (options.logApi !== false) {
            await writeApiLog(req, {
                config_id: effectiveConfig.config_id,
                config_name: effectiveConfig.config_name,
                action_type: effectiveConfig.action_type,
                http_method: method,
                request_url: requestUrl,
                request_headers: {},
                request_payload: requestPayloadForLog,
                success: false,
                error_message: error.message,
                duration_ms: durationMs
            });
        }

        error.request_url = requestUrl;
        error.http_method = method;
        error.request_payload = requestPayloadForLog;
        error.duration_ms = durationMs;

        throw error;
    }
}

async function enrichPayloadForApi(payload) {
    const source = payload || {};
    const permissionGroup = String(source.permission_group || "").trim();
    if (!permissionGroup) return source;

    const result = await pool.query(
        `SELECT pg.integration_id,
                sf.destination_code,
                sf.return_code
         FROM permission_groups pg
         LEFT JOIN schindler_floors sf ON sf.floor_id = pg.floor_id
         WHERE pg.group_name = $1
         LIMIT 1`,
        [permissionGroup]
    );

    const group = result.rows[0] || {};
    const integrationId = group.integration_id || "";
    const destinationCode = group.destination_code || "";
    const returnCode = group.return_code || "";
    const mappedAutoZone = destinationCode ? `specific,${destinationCode},${returnCode}` : "";
    const mappedAccessZones = destinationCode ? `${returnCode},${destinationCode}` : "";
    return {
        ...source,
        permission_group_integration_id: integrationId,
        innerrange_permission_group_id: integrationId,
        schindler_destination_floor_code: destinationCode,
        schindler_return_floor_code: returnCode,
        schindler_auto_zone: source.schindler_auto_zone || mappedAutoZone,
        schindler_access_zones_always: source.schindler_access_zones_always || mappedAccessZones,
        schindler_profile_name: source.schindler_profile_name || source.cf_profile_name || "default"
    };
}

function getSkipReasonForConfig(config, apiPayload) {
    const providerType = String(config.provider_type || "GENERIC").toUpperCase();
    const triggerEvent = String(config.trigger_event || "").toUpperCase();

    if (
        providerType === "INNERRANGE"
        && ["EDIT", "DELETE", "CHECKOUT", "CHECK_INNERRANGE"].includes(triggerEvent)
        && !apiPayload.innerrange_user_id
        && !apiPayload.third_party_user_id
    ) {
        return "Innerrange User ID belum tersedia, API dilewati agar tidak mengirim Address kosong.";
    }

    if (
        providerType === "SCHINDLER"
        && triggerEvent === "CHECK_SCHINDLER"
        && !apiPayload.schindler_person_id
    ) {
        return "Schindler Person ID belum tersedia, API check dilewati.";
    }

    if (
        triggerEvent === "SYNC_DELETE"
        && (
            apiPayload.user_cancelled === true
            || apiPayload.user_expired === true
            || apiPayload.disabled === true
            || ["CANCEL", "EXPIRE", "DISABLE"].includes(String(apiPayload.sync_event_type || "").toUpperCase())
        )
    ) {
        return "SYNC_DELETE dilewati karena source user bukan hard delete, tetapi cancel/expire/disable.";
    }

    return null;
}

async function executeActiveThirdPartyConfigs(req, triggerEvent, payload, options = {}) {
    await ensureApiSchema();
    const apiPayload = await enrichPayloadForApi(payload);
    const params = [String(triggerEvent || "").toUpperCase()];
    let filterSql = "is_active = TRUE AND trigger_event = $1";

    if (options.providerType) {
        params.push(String(options.providerType || "").toUpperCase());
        filterSql += ` AND provider_type = $${params.length}`;
    }

    if (options.configId) {
        params.push(Number(options.configId));
        filterSql += ` AND config_id = $${params.length}`;
    }

    const result = await pool.query(
        `SELECT *
         FROM third_party_api_configs
         WHERE ${filterSql}
         ORDER BY execution_order ASC, config_id ASC`,
        params
    );

    const results = [];
    const batches = result.rows.reduce((groups, config) => {
        const order = Number(config.execution_order || 100);
        if (!groups.has(order)) groups.set(order, []);
        groups.get(order).push(config);
        return groups;
    }, new Map());

    for (const [order, configs] of batches) {
        const batchResults = await Promise.all(configs.map(async config => {
            const baseResult = {
                config_id: config.config_id,
                config_name: config.config_name,
                provider_type: config.provider_type,
                execution_order: order,
                stop_on_failed: config.stop_on_failed === true
            };

            const skipReason = getSkipReasonForConfig(config, apiPayload);
            if (skipReason) {
                return {
                    ...baseResult,
                    success: false,
                    skipped: true,
                    error: skipReason
                };
            }

            try {
                const response = await executeThirdPartyRequest(req, config, apiPayload);
                return {
                    ...baseResult,
                    success: response.success,
                    status: response.status,
                    reference_id: response.reference_id,
                    error: response.error_message || null,
                    duration_ms: response.duration_ms
                };
            } catch (error) {
                return {
                    ...baseResult,
                    success: false,
                    error: error.message
                };
            }
        }));

        results.push(...batchResults);
        await Promise.all(batchResults.map(item => notifyThirdPartyResult(req, triggerEvent, apiPayload, item)));

        if (batchResults.some(item => item.stop_on_failed && item.success !== true)) {
            break;
        }
    }

    return results;
}

async function hasActiveThirdPartyProvider(triggerEvent, providerType) {
    await ensureApiSchema();
    const result = await pool.query(
        `SELECT 1
         FROM third_party_api_configs
         WHERE is_active = TRUE
           AND trigger_event = $1
           AND provider_type = $2
         LIMIT 1`,
        [String(triggerEvent || "").toUpperCase(), String(providerType || "").toUpperCase()]
    );

    return result.rows.length > 0;
}

async function upsertHealthStatus(req, config, checkResult) {
    const current = await pool.query(
        "SELECT * FROM api_provider_health_status WHERE config_id = $1",
        [config.config_id]
    );
    const previous = current.rows[0];
    const newStatus = checkResult.success ? "ONLINE" : "OFFLINE";
    const previousStatus = previous?.status || "UNKNOWN";
    const shouldWriteLog =
        newStatus === "OFFLINE"
        || (previous && previousStatus !== newStatus);
    const shouldNotify =
        !previous
            ? newStatus === "OFFLINE"
            : previousStatus !== newStatus;

    await pool.query(
        `INSERT INTO api_provider_health_status (
            config_id,
            config_name,
            provider_type,
            status,
            previous_status,
            response_status,
            duration_ms,
            error_message,
            last_check_time,
            last_success_time,
            last_fail_time,
            checked_by,
            updated_at
         )
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),$9,$10,$11,NOW())
         ON CONFLICT (config_id)
         DO UPDATE SET
            config_name = EXCLUDED.config_name,
            provider_type = EXCLUDED.provider_type,
            status = EXCLUDED.status,
            previous_status = api_provider_health_status.status,
            response_status = EXCLUDED.response_status,
            duration_ms = EXCLUDED.duration_ms,
            error_message = EXCLUDED.error_message,
            last_check_time = NOW(),
            last_success_time = COALESCE(EXCLUDED.last_success_time, api_provider_health_status.last_success_time),
            last_fail_time = COALESCE(EXCLUDED.last_fail_time, api_provider_health_status.last_fail_time),
            checked_by = EXCLUDED.checked_by,
            updated_at = NOW()`,
        [
            config.config_id,
            config.config_name,
            config.provider_type,
            newStatus,
            previousStatus,
            checkResult.response_status || null,
            checkResult.duration_ms || null,
            checkResult.error_message || null,
            newStatus === "ONLINE" ? new Date() : null,
            newStatus === "OFFLINE" ? new Date() : null,
            getCurrentUsername(req)
        ]
    );

    if (shouldWriteLog) {
        await writeApiLog(req, {
            config_id: config.config_id,
            config_name: config.config_name,
            action_type: "HEALTH_CHECK",
            http_method: checkResult.http_method || config.http_method,
            request_url: checkResult.request_url || joinUrl(config.base_url, config.endpoint_path || ""),
            request_headers: checkResult.request_headers || {},
            request_payload: checkResult.request_payload || {},
            response_status: checkResult.response_status || null,
            response_body: checkResult.response_body || null,
            success: checkResult.success === true,
            error_message: checkResult.error_message || null,
            duration_ms: checkResult.duration_ms || null
        });
    }

    if (shouldNotify) {
        await createSystemNotification(req, {
            channel: `API_${String(config.provider_type || "GENERIC").toUpperCase()}`,
            event_type: "HEALTH_CHECK",
            provider_type: config.provider_type,
            status: newStatus === "ONLINE" ? "SUCCESS" : "FAILED",
            target: config.config_name,
            title: `${config.provider_type} Server ${newStatus}`,
            message: newStatus === "ONLINE"
                ? `${config.config_name} kembali online.`
                : `${config.config_name} offline: ${checkResult.error_message || `Status ${checkResult.response_status || "-"}`}`,
            detail: {
                config_id: config.config_id,
                config_name: config.config_name,
                previous_status: previousStatus,
                status: newStatus,
                response_status: checkResult.response_status || null,
                duration_ms: checkResult.duration_ms || null
            }
        });
    }

    return {
        config_id: config.config_id,
        config_name: config.config_name,
        provider_type: config.provider_type,
        status: newStatus,
        previous_status: previousStatus,
        response_status: checkResult.response_status || null,
        duration_ms: checkResult.duration_ms || null,
        error_message: checkResult.error_message || null
    };
}

async function checkApiHealthConfig(req, config) {
    try {
        const response = await executeThirdPartyRequest(req, config, {}, { logApi: false });
        return upsertHealthStatus(req, config, {
            success: response.success === true,
            response_status: response.status,
            response_body: String(response.body || "").slice(0, 1000),
            duration_ms: response.duration_ms,
            error_message: response.error_message || null,
            request_url: response.request_url,
            http_method: response.http_method,
            request_headers: response.request_headers,
            request_payload: response.request_payload
        });
    } catch (error) {
        return upsertHealthStatus(req, config, {
            success: false,
            duration_ms: error.duration_ms || null,
            error_message: error.message,
            request_url: error.request_url,
            http_method: error.http_method || config.http_method,
            request_payload: error.request_payload || {}
        });
    }
}

async function runApiHealthChecks(createdBy = "API_HEALTH_SCHEDULER", reqOverride = null) {
    await ensureApiSchema();
    if (healthCheckRunning) {
        return { skipped: true, message: "Health check sedang berjalan." };
    }

    healthCheckRunning = true;
    const req = reqOverride || {
        session: { user: { username: createdBy, full_name: createdBy } },
        ip: "127.0.0.1"
    };

    try {
        const configs = await pool.query(
            `SELECT *
             FROM third_party_api_configs
             WHERE is_active = TRUE
               AND trigger_event = 'HEALTH_CHECK'
             ORDER BY provider_type ASC, execution_order ASC, config_id ASC`
        );

        const results = await Promise.all(configs.rows.map(config => checkApiHealthConfig(req, config)));
        return { success: true, total: configs.rows.length, data: results };
    } finally {
        healthCheckRunning = false;
    }
}

function startApiHealthScheduler() {
    if (healthSchedulerStarted) return;
    healthSchedulerStarted = true;
    setInterval(() => {
        runApiHealthChecks("API_HEALTH_SCHEDULER")
            .catch(error => console.log("API HEALTH SCHEDULER ERROR:", error.message));
    }, 60 * 1000);
    setTimeout(() => {
        runApiHealthChecks("API_HEALTH_SCHEDULER")
            .catch(error => console.log("API HEALTH INITIAL ERROR:", error.message));
    }, 10 * 1000);
}

function normalizeRawTestBody(body) {
    return {
        request_name: String(body.request_name || "Manual API Test").trim(),
        request_url: String(body.request_url || "").trim(),
        http_method: String(body.http_method || "GET").toUpperCase(),
        auth_type: String(body.auth_type || "NONE").toUpperCase(),
        api_key_header: String(body.api_key_header || "").trim(),
        api_key: String(body.api_key || "").trim(),
        token: String(body.token || "").trim(),
        username: String(body.username || "").trim(),
        password: String(body.password || "").trim(),
        headers: safeJson(body.headers, {}),
        query_params: safeJson(body.query_params, {}),
        request_body: safeJson(body.request_body, {}),
        body_type: String(body.body_type || "JSON").toUpperCase(),
        raw_body: String(body.raw_body || "")
    };
}

function validateRawTest(test) {
    if (!test.request_url) return "URL wajib diisi";
    if (!["GET", "POST", "PUT", "PATCH", "DELETE"].includes(test.http_method)) return "HTTP method tidak valid";
    if (!["NONE", "API_KEY", "BEARER", "BASIC"].includes(test.auth_type)) return "Auth type tidak valid";
    if (!["JSON", "XML", "TEXT"].includes(test.body_type)) return "Body type tidak valid";

    try {
        const url = new URL(test.request_url);
        if (!["http:", "https:"].includes(url.protocol)) return "URL harus menggunakan http atau https";
    } catch (error) {
        return "Format URL tidak valid";
    }

    return null;
}

async function executeRawApiTest(req, test) {
    let requestUrl = test.request_url;
    const started = Date.now();
    const defaultContentType = test.body_type === "XML" ? "application/xml" : test.body_type === "TEXT" ? "text/plain" : "application/json";
    const headers = {
        "Content-Type": defaultContentType,
        ...(test.headers || {})
    };

    if (test.api_key) {
        headers[test.api_key_header || "x-api-key"] = test.api_key;
    }

    if (test.auth_type === "BEARER" && test.token) {
        headers.Authorization = `Bearer ${test.token}`;
    }

    if (test.auth_type === "BASIC" && (test.username || test.password)) {
        const encoded = Buffer.from(`${test.username || ""}:${test.password || ""}`).toString("base64");
        headers.Authorization = `Basic ${encoded}`;
    }

    const fetchOptions = { method: test.http_method, headers };

    if (["GET", "DELETE"].includes(test.http_method)) {
        const url = new URL(requestUrl);
        Object.entries(test.query_params || {}).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== "") {
                url.searchParams.set(key, String(value));
            }
        });
        requestUrl = url.toString();
    } else if (test.body_type === "JSON") {
        fetchOptions.body = JSON.stringify(test.request_body || {});
    } else {
        fetchOptions.body = test.raw_body || "";
    }

    try {
        const response = await fetchWithTimeout(requestUrl, fetchOptions, THIRD_PARTY_REQUEST_TIMEOUT_MS);
        const responseText = await response.text();
        const durationMs = Date.now() - started;
        const responseHeaders = Object.fromEntries(response.headers.entries());

        await writeApiLog(req, {
            config_name: test.request_name,
            action_type: "RAW_TEST",
            http_method: test.http_method,
            request_url: requestUrl,
            request_headers: redactHeaders(headers),
            request_payload: ["GET", "DELETE"].includes(test.http_method) ? test.query_params : test.body_type === "JSON" ? test.request_body : { raw_body: test.raw_body },
            response_status: response.status,
            response_body: responseText.slice(0, 5000),
            success: response.ok,
            duration_ms: durationMs
        });

        return {
            success: response.ok,
            status: response.status,
            status_text: response.statusText,
            duration_ms: durationMs,
            response_headers: responseHeaders,
            response_body: responseText
        };
    } catch (error) {
        const durationMs = Date.now() - started;

        await writeApiLog(req, {
            config_name: test.request_name,
            action_type: "RAW_TEST",
            http_method: test.http_method,
            request_url: requestUrl,
            request_headers: redactHeaders(headers),
            request_payload: ["GET", "DELETE"].includes(test.http_method) ? test.query_params : test.body_type === "JSON" ? test.request_body : { raw_body: test.raw_body },
            success: false,
            error_message: error.message,
            duration_ms: durationMs
        });

        throw error;
    }
}

router.get("/api/third-party-settings", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT c.*, t.template_name
            FROM third_party_api_configs c
            LEFT JOIN api_templates t ON t.template_id = c.template_id
            ORDER BY config_id DESC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/api-health-status", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT c.config_id,
                   c.config_name,
                   c.provider_type,
                   c.base_url,
                   c.endpoint_path,
                   c.http_method,
                   c.is_active,
                   COALESCE(h.status, 'UNKNOWN') AS status,
                   h.previous_status,
                   h.response_status,
                   h.duration_ms,
                   h.error_message,
                   h.last_check_time,
                   h.last_success_time,
                   h.last_fail_time,
                   h.checked_by,
                   h.updated_at
            FROM third_party_api_configs c
            LEFT JOIN api_provider_health_status h ON h.config_id = c.config_id
            WHERE c.trigger_event = 'HEALTH_CHECK'
            ORDER BY c.provider_type ASC, c.execution_order ASC, c.config_id ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/api-health-status/check-now", async (req, res) => {
    try {
        const result = await runApiHealthChecks(getCurrentUsername(req), req);
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/api-templates", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT *
            FROM api_templates
            ORDER BY template_id DESC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/api-templates", async (req, res) => {
    try {
        const template = normalizeTemplateBody(req.body);
        const validationError = validateTemplate(template);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `INSERT INTO api_templates (
                template_name,
                description,
                body_type,
                field_mapping,
                body_template,
                created_by,
                created_time
            )
            VALUES ($1,$2,$3,$4,$5,$6,NOW())
            RETURNING *`,
            [
                template.template_name,
                template.description || null,
                template.body_type,
                template.field_mapping,
                template.body_template,
                getCurrentUsername(req)
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const status = error.code === "23505" ? 409 : 500;
        res.status(status).json({ success: false, error: error.message });
    }
});

router.put("/api/api-templates/:id", async (req, res) => {
    try {
        const template = normalizeTemplateBody(req.body);
        const validationError = validateTemplate(template);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `UPDATE api_templates
             SET template_name = $1,
                 description = $2,
                 body_type = $3,
                 field_mapping = $4,
                 body_template = $5,
                 modified_by = $6,
                 modified_time = NOW()
             WHERE template_id = $7
             RETURNING *`,
            [
                template.template_name,
                template.description || null,
                template.body_type,
                template.field_mapping,
                template.body_template,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Template API tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const status = error.code === "23505" ? 409 : 500;
        res.status(status).json({ success: false, error: error.message });
    }
});

router.delete("/api/api-templates/:id", async (req, res) => {
    try {
        const usage = await pool.query("SELECT COUNT(*)::int AS total FROM third_party_api_configs WHERE template_id = $1", [req.params.id]);
        if (usage.rows[0]?.total > 0) {
            return res.status(400).json({ success: false, message: "Template masih dipakai di Setting API." });
        }

        await pool.query("DELETE FROM api_templates WHERE template_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/third-party-settings/:id", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT c.*, t.template_name
            FROM third_party_api_configs c
            LEFT JOIN api_templates t ON t.template_id = c.template_id
            WHERE c.config_id = $1
        `, [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Setting API tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/third-party-settings", async (req, res) => {
    try {
        const config = normalizeConfigBody(req.body);
        const validationError = validateConfig(config);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `INSERT INTO third_party_api_configs (
                config_name,
                description,
                base_url,
                endpoint_path,
                http_method,
                provider_type,
                execution_order,
                request_timeout_ms,
                stop_on_failed,
                trigger_event,
                action_type,
                auth_type,
                api_key_header,
                api_key,
                token,
                dynamic_auth_url,
                dynamic_auth_method,
                dynamic_auth_body,
                dynamic_token_path,
                dynamic_expiry_path,
                dynamic_auth_header,
                dynamic_auth_prefix,
                username,
                password,
                custom_headers,
                field_mapping,
                template_mode,
                template_id,
                body_type,
                body_template,
                is_active,
                created_by,
                created_time
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,NOW())
            RETURNING *`,
            [
                config.config_name,
                config.description || null,
                config.base_url,
                config.endpoint_path || null,
                config.http_method,
                config.provider_type,
                config.execution_order,
                config.request_timeout_ms,
                config.stop_on_failed,
                config.trigger_event,
                config.action_type,
                config.auth_type,
                config.api_key_header || null,
                config.api_key || null,
                config.token || null,
                config.dynamic_auth_url || null,
                config.dynamic_auth_method,
                config.dynamic_auth_body || null,
                config.dynamic_token_path,
                config.dynamic_expiry_path,
                config.dynamic_auth_header,
                config.dynamic_auth_prefix,
                config.username || null,
                config.password || null,
                config.custom_headers,
                config.field_mapping,
                config.template_mode,
                config.template_id,
                config.body_type,
                config.body_template || null,
                config.is_active,
                getCurrentUsername(req)
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/third-party-settings/:id", async (req, res) => {
    try {
        const config = normalizeConfigBody(req.body);
        const validationError = validateConfig(config);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `UPDATE third_party_api_configs
             SET config_name = $1,
                 description = $2,
                 base_url = $3,
                 endpoint_path = $4,
                 http_method = $5,
                 provider_type = $6,
                 execution_order = $7,
                 request_timeout_ms = $8,
                 stop_on_failed = $9,
                 trigger_event = $10,
                 action_type = $11,
                 auth_type = $12,
                 api_key_header = $13,
                 api_key = $14,
                 token = $15,
                 dynamic_auth_url = $16,
                 dynamic_auth_method = $17,
                 dynamic_auth_body = $18,
                 dynamic_token_path = $19,
                 dynamic_expiry_path = $20,
                 dynamic_auth_header = $21,
                 dynamic_auth_prefix = $22,
                 username = $23,
                 password = $24,
                 custom_headers = $25,
                 field_mapping = $26,
                 template_mode = $27,
                 template_id = $28,
                 body_type = $29,
                 body_template = $30,
                 is_active = $31,
                 modified_by = $32,
                 modified_time = NOW()
             WHERE config_id = $33
             RETURNING *`,
            [
                config.config_name,
                config.description || null,
                config.base_url,
                config.endpoint_path || null,
                config.http_method,
                config.provider_type,
                config.execution_order,
                config.request_timeout_ms,
                config.stop_on_failed,
                config.trigger_event,
                config.action_type,
                config.auth_type,
                config.api_key_header || null,
                config.api_key || null,
                config.token || null,
                config.dynamic_auth_url || null,
                config.dynamic_auth_method,
                config.dynamic_auth_body || null,
                config.dynamic_token_path,
                config.dynamic_expiry_path,
                config.dynamic_auth_header,
                config.dynamic_auth_prefix,
                config.username || null,
                config.password || null,
                config.custom_headers,
                config.field_mapping,
                config.template_mode,
                config.template_id,
                config.body_type,
                config.body_template || null,
                config.is_active,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Setting API tidak ditemukan" });
        }

        await pool.query("DELETE FROM api_token_cache WHERE config_id = $1", [req.params.id]);
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/third-party-settings/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM api_token_cache WHERE config_id = $1", [req.params.id]);
        await pool.query("DELETE FROM third_party_api_configs WHERE config_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/third-party-settings/:id/test", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM third_party_api_configs WHERE config_id = $1", [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Setting API tidak ditemukan" });
        }

        const config = result.rows[0];
        if (!config.is_active) {
            return res.status(400).json({ success: false, message: "Setting API tidak aktif" });
        }

        const payload = safeJson(req.body.payload, {});
        const response = await executeThirdPartyRequest(req, config, payload);
        res.json({ success: response.success, data: response });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/testing-api/send", async (req, res) => {
    try {
        const test = normalizeRawTestBody(req.body);
        const validationError = validateRawTest(test);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const response = await executeRawApiTest(req, test);
        res.json({ success: response.success, data: response });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/testing-api/presets", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT *
            FROM api_test_presets
            ORDER BY preset_id DESC
        `);
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/testing-api/presets", async (req, res) => {
    try {
        const test = normalizeRawTestBody(req.body);
        const validationError = validateRawTest(test);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `INSERT INTO api_test_presets (
                request_name,
                request_url,
                http_method,
                auth_type,
                api_key_header,
                api_key,
                token,
                username,
                password,
                headers,
                query_params,
                request_body,
                body_type,
                raw_body,
                created_by,
                created_time
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,NOW())
            RETURNING *`,
            [
                test.request_name,
                test.request_url,
                test.http_method,
                test.auth_type,
                test.api_key_header || null,
                test.api_key || null,
                test.token || null,
                test.username || null,
                test.password || null,
                test.headers,
                test.query_params,
                test.request_body,
                test.body_type,
                test.raw_body || null,
                getCurrentUsername(req)
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/testing-api/presets/:id", async (req, res) => {
    try {
        const test = normalizeRawTestBody(req.body);
        const validationError = validateRawTest(test);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `UPDATE api_test_presets
             SET request_name = $1,
                 request_url = $2,
                 http_method = $3,
                 auth_type = $4,
                 api_key_header = $5,
                 api_key = $6,
                 token = $7,
                 username = $8,
                 password = $9,
                 headers = $10,
                 query_params = $11,
                 request_body = $12,
                 body_type = $13,
                 raw_body = $14,
                 modified_by = $15,
                 modified_time = NOW()
             WHERE preset_id = $16
             RETURNING *`,
            [
                test.request_name,
                test.request_url,
                test.http_method,
                test.auth_type,
                test.api_key_header || null,
                test.api_key || null,
                test.token || null,
                test.username || null,
                test.password || null,
                test.headers,
                test.query_params,
                test.request_body,
                test.body_type,
                test.raw_body || null,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Preset tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/testing-api/presets/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM api_test_presets WHERE preset_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/api-activity-logs", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT *
            FROM api_activity_logs
            ORDER BY log_id DESC
            LIMIT 1000
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = router;
module.exports.executeActiveThirdPartyConfigs = executeActiveThirdPartyConfigs;
module.exports.hasActiveThirdPartyProvider = hasActiveThirdPartyProvider;
module.exports.startApiHealthScheduler = startApiHealthScheduler;
