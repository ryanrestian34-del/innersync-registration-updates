const pool = require("../database/db");

let notificationSchemaReady = false;

function getCurrentUsername(req) {
    return req?.session?.user?.username || req?.session?.user?.full_name || "SYSTEM";
}

async function ensureSystemNotificationSchema() {
    if (notificationSchemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS system_notifications (
            notification_id SERIAL PRIMARY KEY,
            channel VARCHAR(80) NOT NULL,
            event_type VARCHAR(80),
            provider_type VARCHAR(80),
            status VARCHAR(30) NOT NULL,
            visitor_id INTEGER,
            visitor_name VARCHAR(200),
            target VARCHAR(255),
            title TEXT NOT NULL,
            message TEXT,
            detail JSONB DEFAULT '{}'::jsonb,
            is_read BOOLEAN NOT NULL DEFAULT FALSE,
            read_by VARCHAR(100),
            read_time TIMESTAMP,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_read_time ON system_notifications (is_read, created_time DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_created_time ON system_notifications (created_time DESC)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_system_notifications_channel ON system_notifications (channel)");

    notificationSchemaReady = true;
}

async function createSystemNotification(req, notification) {
    try {
        await ensureSystemNotificationSchema();
        const detail = notification.detail && typeof notification.detail === "object"
            ? notification.detail
            : {};

        await pool.query(
            `INSERT INTO system_notifications (
                channel,
                event_type,
                provider_type,
                status,
                visitor_id,
                visitor_name,
                target,
                title,
                message,
                detail,
                created_by,
                created_time
             )
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, NOW())`,
            [
                String(notification.channel || "SYSTEM").toUpperCase(),
                notification.event_type ? String(notification.event_type).toUpperCase() : null,
                notification.provider_type ? String(notification.provider_type).toUpperCase() : null,
                String(notification.status || "INFO").toUpperCase(),
                notification.visitor_id || null,
                notification.visitor_name || null,
                notification.target || null,
                notification.title || "System Notification",
                notification.message || null,
                detail,
                notification.created_by || getCurrentUsername(req)
            ]
        );
    } catch (error) {
        console.log("CREATE SYSTEM NOTIFICATION ERROR:", error.message);
    }
}

module.exports = {
    ensureSystemNotificationSchema,
    createSystemNotification
};
