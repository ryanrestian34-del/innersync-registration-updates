const express = require("express");
const crypto = require("crypto");
const router = express.Router();
const pool = require("../database/db");
const { executeActiveThirdPartyConfigs } = require("./apiIntegrationRoutes");

let schemaReady = false;
const runningSourceConfigIds = new Set();
let schedulerStarted = false;
const syncStreamClients = new Set();

const SOURCE_TIMEOUT_MS = Number(process.env.MIDDLEWARE_SOURCE_TIMEOUT_MS || 15000);
const INCREMENTAL_PAGE_SIZE = Math.max(10, Math.min(Number(process.env.MIDDLEWARE_INCREMENTAL_PAGE_SIZE || 25), 25));
const DELETE_RECONCILE_PAGE_SIZE = Math.max(10, Math.min(Number(process.env.MIDDLEWARE_DELETE_RECONCILE_PAGE_SIZE || 75), 75));

function isSyncRunning() {
    return runningSourceConfigIds.size > 0;
}

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function requireSuperAdminHttp(req, res, next) {
    if (!req.session?.user_id) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    if (String(req.session?.role_name || "").toUpperCase() !== "SUPERADMIN") {
        return res.status(403).json({ success: false, message: "Middleware Sync hanya bisa diakses SUPERADMIN" });
    }

    next();
}

router.use("/api/middleware-sync", requireSuperAdminHttp);

function safeJson(value, fallback) {
    if (!value) return fallback;
    if (typeof value === "object") return value;
    try {
        return JSON.parse(value);
    } catch (error) {
        return fallback;
    }
}

async function ensureSyncSchema() {
    if (schemaReady) return;

    await pool.query(`
        CREATE TABLE IF NOT EXISTS middleware_sync_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            source_name VARCHAR(120) NOT NULL DEFAULT 'Innerrange Source',
            provider_type VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE',
            base_url TEXT NOT NULL DEFAULT 'http://127.0.0.1:7777',
            endpoint_path TEXT NOT NULL DEFAULT '/restApi/v2/User/User',
            auth_type VARCHAR(30) NOT NULL DEFAULT 'NONE',
            username VARCHAR(120),
            password TEXT,
            token TEXT,
            api_key_header VARCHAR(80),
            api_key TEXT,
            page_size INTEGER NOT NULL DEFAULT 100,
            poll_interval_sec INTEGER NOT NULL DEFAULT 60,
            sync_mode VARCHAR(30) NOT NULL DEFAULT 'FAST_INCREMENTAL',
            full_reconcile_interval_sec INTEGER NOT NULL DEFAULT 3600,
            sync_filter VARCHAR(30) NOT NULL DEFAULT 'ALL',
            auto_run BOOLEAN NOT NULL DEFAULT FALSE,
            is_active BOOLEAN NOT NULL DEFAULT FALSE,
            last_poll_time TIMESTAMP,
            last_success_time TIMESTAMP,
            last_full_reconcile_time TIMESTAMP,
            last_source_modified_time TIMESTAMP,
            last_error TEXT,
            last_total_records INTEGER NOT NULL DEFAULT 0,
            last_processed_count INTEGER NOT NULL DEFAULT 0,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS middleware_sync_snapshots (
            snapshot_id SERIAL PRIMARY KEY,
            source_provider VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE',
            source_user_id VARCHAR(80) NOT NULL UNIQUE,
            numeric_id VARCHAR(80),
            partition_id VARCHAR(30),
            row_version VARCHAR(80),
            creation_date TIMESTAMP,
            modified_date TIMESTAMP,
            first_name VARCHAR(160),
            second_name VARCHAR(160),
            user_name VARCHAR(240),
            notes TEXT,
            is_visitor BOOLEAN NOT NULL DEFAULT FALSE,
            user_cancelled BOOLEAN NOT NULL DEFAULT FALSE,
            user_expired BOOLEAN NOT NULL DEFAULT FALSE,
            disabled BOOLEAN NOT NULL DEFAULT FALSE,
            card_number VARCHAR(120),
            permission_group_id VARCHAR(80),
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            schindler_person_id VARCHAR(100),
            raw_data JSONB NOT NULL DEFAULT '{}'::jsonb,
            checksum VARCHAR(80),
            source_deleted BOOLEAN NOT NULL DEFAULT FALSE,
            last_seen_at TIMESTAMP,
            last_event_type VARCHAR(30),
            last_sync_status VARCHAR(30),
            created_time TIMESTAMP DEFAULT NOW(),
            updated_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS middleware_sync_events (
            event_id SERIAL PRIMARY KEY,
            source_provider VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE',
            source_user_id VARCHAR(80) NOT NULL,
            event_type VARCHAR(30) NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
            retry_count INTEGER NOT NULL DEFAULT 0,
            error_message TEXT,
            payload JSONB NOT NULL DEFAULT '{}'::jsonb,
            old_snapshot JSONB,
            new_snapshot JSONB,
            api_results JSONB,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            processed_time TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS middleware_card_snapshots (
            snapshot_id SERIAL PRIMARY KEY,
            source_provider VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE',
            source_card_id VARCHAR(100) NOT NULL UNIQUE,
            card_name VARCHAR(160),
            card_number VARCHAR(120),
            card_number_numeric VARCHAR(120),
            card_data VARCHAR(160),
            associated_user_id VARCHAR(80),
            previous_associated_user_id VARCHAR(80),
            state VARCHAR(80),
            row_version VARCHAR(80),
            creation_date TIMESTAMP,
            modified_date TIMESTAMP,
            last_used TIMESTAMP,
            card_type_id VARCHAR(80),
            notes TEXT,
            raw_data JSONB NOT NULL DEFAULT '{}'::jsonb,
            checksum VARCHAR(80),
            source_deleted BOOLEAN NOT NULL DEFAULT FALSE,
            last_seen_at TIMESTAMP,
            last_event_type VARCHAR(30),
            created_time TIMESTAMP DEFAULT NOW(),
            updated_time TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS middleware_source_configs (
            config_id SERIAL PRIMARY KEY,
            config_name VARCHAR(140) NOT NULL,
            provider_type VARCHAR(30) NOT NULL DEFAULT 'INNERRANGE',
            entity_type VARCHAR(30) NOT NULL DEFAULT 'USER',
            base_url TEXT NOT NULL DEFAULT 'http://127.0.0.1:7777',
            endpoint_path TEXT NOT NULL DEFAULT '/restApi/v2/User/User',
            http_method VARCHAR(12) NOT NULL DEFAULT 'GET',
            auth_type VARCHAR(30) NOT NULL DEFAULT 'NONE',
            username VARCHAR(120),
            password TEXT,
            token TEXT,
            api_key_header VARCHAR(80),
            api_key TEXT,
            page_size INTEGER NOT NULL DEFAULT 500,
            incremental_page_size INTEGER NOT NULL DEFAULT 25,
            poll_interval_sec INTEGER NOT NULL DEFAULT 3,
            sync_mode VARCHAR(30) NOT NULL DEFAULT 'FAST_INCREMENTAL',
            full_reconcile_interval_sec INTEGER NOT NULL DEFAULT 3600,
            full_reconcile_time VARCHAR(5) NOT NULL DEFAULT '00:00',
            sync_filter VARCHAR(30) NOT NULL DEFAULT 'ALL',
            sort_property VARCHAR(80) NOT NULL DEFAULT 'ModifiedDate',
            sort_order VARCHAR(20) NOT NULL DEFAULT 'Descending',
            watermark_field VARCHAR(80) NOT NULL DEFAULT 'ModifiedDate',
            full_object BOOLEAN NOT NULL DEFAULT TRUE,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            last_poll_time TIMESTAMP,
            last_success_time TIMESTAMP,
            last_full_reconcile_time TIMESTAMP,
            last_source_modified_time TIMESTAMP,
            last_error TEXT,
            last_total_records INTEGER NOT NULL DEFAULT 0,
            last_processed_count INTEGER NOT NULL DEFAULT 0,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_sync_snapshots_source_deleted ON middleware_sync_snapshots (source_deleted)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_sync_snapshots_source_user_id ON middleware_sync_snapshots (source_user_id)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_sync_snapshots_modified_date ON middleware_sync_snapshots (modified_date)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_sync_snapshots_user_name ON middleware_sync_snapshots (LOWER(COALESCE(user_name, '')))");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_sync_snapshots_card_number ON middleware_sync_snapshots (LOWER(COALESCE(card_number, '')))");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_card_snapshots_card_number ON middleware_card_snapshots (LOWER(COALESCE(card_number, '')))");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_card_snapshots_user_id ON middleware_card_snapshots (associated_user_id)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_card_snapshots_modified_date ON middleware_card_snapshots (modified_date)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_card_snapshots_source_deleted ON middleware_card_snapshots (source_deleted)");
    await pool.query(`
        UPDATE middleware_card_snapshots card
        SET previous_associated_user_id = card.associated_user_id,
            associated_user_id = NULL,
            last_event_type = 'UNASSIGN',
            updated_time = NOW()
        FROM middleware_sync_snapshots usr
        WHERE card.associated_user_id = usr.source_user_id
          AND usr.source_deleted = TRUE
    `);

    await pool.query("ALTER TABLE middleware_sync_settings ADD COLUMN IF NOT EXISTS sync_mode VARCHAR(30) NOT NULL DEFAULT 'FAST_INCREMENTAL'");
    await pool.query("ALTER TABLE middleware_sync_settings ADD COLUMN IF NOT EXISTS full_reconcile_interval_sec INTEGER NOT NULL DEFAULT 3600");
    await pool.query("ALTER TABLE middleware_sync_settings ADD COLUMN IF NOT EXISTS last_full_reconcile_time TIMESTAMP");
    await pool.query("ALTER TABLE middleware_sync_settings ADD COLUMN IF NOT EXISTS last_source_modified_time TIMESTAMP");
    await pool.query("ALTER TABLE middleware_source_configs ADD COLUMN IF NOT EXISTS full_reconcile_time VARCHAR(5) NOT NULL DEFAULT '00:00'");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_middleware_source_configs_active ON middleware_source_configs (is_active, entity_type)");
    await pool.query("UPDATE middleware_source_configs SET incremental_page_size = 25 WHERE incremental_page_size > 25");

    await pool.query(`
        INSERT INTO middleware_sync_settings (setting_id, created_by)
        VALUES (1, 'SYSTEM')
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        UPDATE middleware_sync_settings
        SET page_size = CASE WHEN page_size < 500 THEN 500 ELSE page_size END,
            sync_mode = COALESCE(NULLIF(sync_mode, ''), 'FAST_INCREMENTAL'),
            full_reconcile_interval_sec = CASE
                WHEN full_reconcile_interval_sec < 30 THEN 3600
                ELSE full_reconcile_interval_sec
            END,
            last_source_modified_time = COALESCE(
                last_source_modified_time,
                (SELECT MAX(modified_date) FROM middleware_sync_snapshots WHERE source_deleted = FALSE)
            ),
            last_full_reconcile_time = COALESCE(
                last_full_reconcile_time,
                CASE
                    WHEN EXISTS (SELECT 1 FROM middleware_sync_snapshots WHERE source_deleted = FALSE)
                    THEN NOW()
                    ELSE NULL
                END
            )
        WHERE setting_id = 1
    `);

    await pool.query(`
        INSERT INTO middleware_source_configs (
            config_name,
            provider_type,
            entity_type,
            base_url,
            endpoint_path,
            http_method,
            auth_type,
            username,
            password,
            token,
            api_key_header,
            api_key,
            page_size,
            incremental_page_size,
            poll_interval_sec,
            sync_mode,
            full_reconcile_interval_sec,
            sync_filter,
            sort_property,
            sort_order,
            watermark_field,
            full_object,
            is_active,
            last_source_modified_time,
            last_full_reconcile_time,
            created_by
        )
        SELECT
            COALESCE(source_name, 'INNERRANGE - GET USER'),
            provider_type,
            'USER',
            base_url,
            endpoint_path,
            'GET',
            auth_type,
            username,
            password,
            token,
            api_key_header,
            api_key,
            CASE WHEN page_size < 500 THEN 500 ELSE page_size END,
            100,
            poll_interval_sec,
            sync_mode,
            full_reconcile_interval_sec,
            sync_filter,
            'ModifiedDate',
            'Descending',
            'ModifiedDate',
            TRUE,
            is_active,
            COALESCE(last_source_modified_time, (SELECT MAX(modified_date) FROM middleware_sync_snapshots WHERE source_deleted = FALSE)),
            COALESCE(last_full_reconcile_time, CASE WHEN EXISTS (SELECT 1 FROM middleware_sync_snapshots WHERE source_deleted = FALSE) THEN NOW() ELSE NULL END),
            'SYSTEM'
        FROM middleware_sync_settings
        WHERE setting_id = 1
          AND NOT EXISTS (SELECT 1 FROM middleware_source_configs)
    `);

    schemaReady = true;
}

function normalizeSettings(body) {
    return {
        source_name: String(body.source_name || "Innerrange Source").trim(),
        provider_type: "INNERRANGE",
        base_url: String(body.base_url || "http://127.0.0.1:7777").trim(),
        endpoint_path: String(body.endpoint_path || "/restApi/v2/User/User").trim(),
        auth_type: String(body.auth_type || "NONE").toUpperCase(),
        username: String(body.username || "").trim(),
        password: String(body.password || ""),
        token: String(body.token || "").trim(),
        api_key_header: String(body.api_key_header || "").trim(),
        api_key: String(body.api_key || "").trim(),
        page_size: Math.max(1, Math.min(Number(body.page_size || 500), 1000)),
        poll_interval_sec: Math.max(2, Math.min(Number(body.poll_interval_sec || 60), 3600)),
        sync_mode: String(body.sync_mode || "FAST_INCREMENTAL").toUpperCase(),
        full_reconcile_interval_sec: Math.max(30, Math.min(Number(body.full_reconcile_interval_sec || 3600), 86400)),
        sync_filter: String(body.sync_filter || "ALL").toUpperCase(),
        auto_run: body.auto_run === true,
        is_active: body.is_active === true
    };
}

function validateSettings(settings) {
    if (!settings.source_name) return "Nama source wajib diisi";
    if (!settings.base_url) return "Base URL wajib diisi";
    if (!settings.endpoint_path) return "Endpoint list user wajib diisi";
    if (!["NONE", "BASIC", "BEARER", "API_KEY"].includes(settings.auth_type)) return "Auth source tidak valid";
    if (!["ALL", "VISITOR_ONLY", "NON_VISITOR_ONLY"].includes(settings.sync_filter)) return "Filter sync tidak valid";
    if (!["FAST_INCREMENTAL", "FULL_RECONCILE"].includes(settings.sync_mode)) return "Mode sync tidak valid";
    return null;
}

function normalizeSourceConfig(body) {
    return {
        config_name: String(body.config_name || body.source_name || "INNERRANGE - GET USER").trim(),
        provider_type: String(body.provider_type || "INNERRANGE").toUpperCase(),
        entity_type: String(body.entity_type || "USER").toUpperCase(),
        base_url: String(body.base_url || "http://127.0.0.1:7777").trim(),
        endpoint_path: String(body.endpoint_path || "/restApi/v2/User/User").trim(),
        http_method: String(body.http_method || "GET").toUpperCase(),
        auth_type: String(body.auth_type || "NONE").toUpperCase(),
        username: String(body.username || "").trim(),
        password: String(body.password || ""),
        token: String(body.token || "").trim(),
        api_key_header: String(body.api_key_header || "").trim(),
        api_key: String(body.api_key || "").trim(),
        page_size: Math.max(1, Math.min(Number(body.page_size || 500), 1000)),
        incremental_page_size: Math.max(10, Math.min(Number(body.incremental_page_size || 25), 25)),
        poll_interval_sec: Math.max(2, Math.min(Number(body.poll_interval_sec || 3), 3600)),
        sync_mode: String(body.sync_mode || "FAST_INCREMENTAL").toUpperCase(),
        full_reconcile_interval_sec: Math.max(30, Math.min(Number(body.full_reconcile_interval_sec || 3600), 86400)),
        full_reconcile_time: normalizeDailyTime(body.full_reconcile_time, "00:00"),
        sync_filter: String(body.sync_filter || "ALL").toUpperCase(),
        sort_property: String(body.sort_property || "ModifiedDate").trim(),
        sort_order: String(body.sort_order || "Descending").trim(),
        watermark_field: String(body.watermark_field || "ModifiedDate").trim(),
        full_object: body.full_object !== false,
        is_active: body.is_active !== false
    };
}

async function getOperationMode() {
    try {
        const result = await pool.query("SELECT operation_mode FROM maintenance_settings WHERE setting_id = 1");
        return String(result.rows[0]?.operation_mode || "VISITOR_REGISTRATION").toUpperCase();
    } catch (error) {
        return "VISITOR_REGISTRATION";
    }
}

async function isMiddlewareSyncMode() {
    return (await getOperationMode()) === "MIDDLEWARE_SYNC";
}

function normalizeDailyTime(value, fallback = "00:00") {
    const text = String(value || "").trim();
    return /^\d{2}:\d{2}$/.test(text) ? text : fallback;
}

function localDateKey(date) {
    return [
        date.getFullYear(),
        String(date.getMonth() + 1).padStart(2, "0"),
        String(date.getDate()).padStart(2, "0")
    ].join("-");
}

function isDailyFullReconcileDue(lastFullReconcileTime, scheduledTime) {
    const time = normalizeDailyTime(scheduledTime, "00:00");
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    if (currentTime < time) return false;

    if (!lastFullReconcileTime) return true;
    const last = new Date(lastFullReconcileTime);
    if (Number.isNaN(last.getTime())) return true;
    return localDateKey(last) !== localDateKey(now);
}

function validateSourceConfig(config) {
    if (!config.config_name) return "Nama source config wajib diisi";
    if (!config.base_url) return "Base URL wajib diisi";
    if (!config.endpoint_path) return "Endpoint wajib diisi";
    if (!["INNERRANGE", "SCHINDLER", "GENERIC"].includes(config.provider_type)) return "Provider source tidak valid";
    if (!["USER", "CARD", "GENERIC"].includes(config.entity_type)) return "Entity type tidak valid";
    if (!["GET", "POST"].includes(config.http_method)) return "Method source tidak valid";
    if (!["NONE", "BASIC", "BEARER", "API_KEY"].includes(config.auth_type)) return "Auth source tidak valid";
    if (!["ALL", "VISITOR_ONLY", "NON_VISITOR_ONLY"].includes(config.sync_filter)) return "Filter sync tidak valid";
    if (!["FAST_INCREMENTAL", "FULL_RECONCILE"].includes(config.sync_mode)) return "Mode sync tidak valid";
    return null;
}

function sendSse(res, eventName, payload) {
    res.write(`event: ${eventName}\n`);
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
}

function broadcastSyncUpdate(type, detail = {}) {
    const payload = {
        type,
        time: new Date().toISOString(),
        ...detail
    };
    for (const res of syncStreamClients) {
        try {
            sendSse(res, "sync-update", payload);
        } catch (error) {
            syncStreamClients.delete(res);
        }
    }
}

function joinUrl(baseUrl, endpointPath) {
    const base = String(baseUrl || "").replace(/\/+$/, "");
    const endpoint = String(endpointPath || "").replace(/^\/+/, "");
    return `${base}/${endpoint}`;
}

function decodeXml(value) {
    return String(value || "")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, "\"")
        .replace(/&apos;/g, "'")
        .replace(/&amp;/g, "&")
        .trim();
}

function tagValue(xml, tagName) {
    const match = String(xml || "").match(new RegExp(`<${tagName}\\b[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "i"));
    return match ? decodeXml(match[1]) : "";
}

function tagValues(xml, tagName) {
    return Array.from(String(xml || "").matchAll(new RegExp(`<${tagName}\\b[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "ig")))
        .map(match => decodeXml(match[1]));
}

function firstValidDateTag(xml, tagName) {
    const values = tagValues(xml, tagName);
    return values.find(value => dateOrNull(value)) || values[0] || "";
}

function boolTag(xml, tagName) {
    return /^true$/i.test(tagValue(xml, tagName));
}

function attrValue(xml, name) {
    const match = String(xml || "").match(new RegExp(`\\b${name}\\s*=\\s*["']([^"']*)["']`, "i"));
    return match ? decodeXml(match[1]) : "";
}

function dateOrNull(value) {
    if (!value || /^0001-01-01/i.test(value)) return null;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
}

function extractTopLevelElements(xml, tagName) {
    const text = String(xml || "");
    const openRegex = new RegExp(`<${tagName}\\b[^>]*>`, "ig");
    const closeRegex = new RegExp(`<\\/${tagName}>`, "ig");
    const elements = [];
    let searchIndex = 0;

    while (searchIndex < text.length) {
        openRegex.lastIndex = searchIndex;
        const firstOpen = openRegex.exec(text);
        if (!firstOpen) break;

        let depth = 1;
        let cursor = openRegex.lastIndex;
        while (depth > 0 && cursor < text.length) {
            openRegex.lastIndex = cursor;
            closeRegex.lastIndex = cursor;
            const nextOpen = openRegex.exec(text);
            const nextClose = closeRegex.exec(text);
            if (!nextClose) break;

            if (nextOpen && nextOpen.index < nextClose.index) {
                depth += 1;
                cursor = openRegex.lastIndex;
            } else {
                depth -= 1;
                cursor = closeRegex.lastIndex;
            }
        }

        if (depth === 0) {
            elements.push(text.slice(firstOpen.index, cursor));
            searchIndex = cursor;
        } else {
            break;
        }
    }

    return elements;
}

function firstMatch(text, pattern) {
    const match = String(text || "").match(pattern);
    return match ? decodeXml(match[1]) : "";
}

function parseInnerrangeUser(userXml) {
    const cardsXml = tagValue(userXml, "Cards");
    const primaryGroupXml = tagValue(userXml, "PrimaryPermissionGroup");
    const permissionGroupId = firstMatch(primaryGroupXml, /<Ref\b[^>]*\bType=["']PermissionGroup["'][^>]*\bID=["']([^"']+)["']/i);
    const address = tagValue(userXml, "Address") || attrValue(userXml, "ID");
    const firstName = tagValue(userXml, "FirstName");
    const secondName = tagValue(userXml, "SecondName");
    const sourceUserId = address || attrValue(userXml, "ID");
    const autoZoneFloor = tagValue(userXml, "cf_AutoZoneFloor");
    const zoneFloorCode = tagValue(userXml, "cf_ZoneFloorCode");
    const profileName = tagValue(userXml, "cf_ProfileName");
    const raw = {
        source_user_id: sourceUserId,
        numeric_id: tagValue(userXml, "ID"),
        partition_id: attrValue(userXml, "PartitionID"),
        row_version: tagValue(userXml, "RowVersion"),
        creation_date: tagValue(userXml, "CreationDate"),
        modified_date: tagValue(userXml, "ModifiedDate"),
        first_name: firstName,
        second_name: secondName,
        user_name: tagValue(userXml, "Name") || `${firstName} ${secondName}`.trim(),
        notes: tagValue(userXml, "Notes"),
        is_visitor: boolTag(userXml, "IsVisitor"),
        user_cancelled: boolTag(userXml, "UserCancelled"),
        user_expired: boolTag(userXml, "UserExpired"),
        disabled: boolTag(userXml, "Disabled"),
        card_number: tagValue(cardsXml, "CardNumber"),
        permission_group_id: permissionGroupId,
        start_date: firstValidDateTag(userXml, "StartDateTime"),
        expiry_date: firstValidDateTag(userXml, "ExpiryDateTime"),
        cf_auto_zone_floor: autoZoneFloor,
        cf_zone_floor_code: zoneFloorCode,
        cf_profile_name: profileName,
        schindler_auto_zone: autoZoneFloor ? `specific,${autoZoneFloor}` : "",
        schindler_access_zones_always: zoneFloorCode || "",
        schindler_profile_name: profileName || "default"
    };

    raw.schindler_person_id = crypto
        .createHash("sha1")
        .update(`innersync-schindler-${raw.source_user_id}`)
        .digest("hex")
        .slice(0, 32)
        .toUpperCase();

    return raw;
}

function parseInnerrangeCard(cardXml) {
    const userXml = tagValue(cardXml, "User");
    const cardTypeXml = tagValue(cardXml, "CardType");
    const sourceCardId = attrValue(cardXml, "ID") || tagValue(cardXml, "ID");
    return {
        source_card_id: sourceCardId,
        card_name: tagValue(cardXml, "Name"),
        card_number: tagValue(cardXml, "CardNumber"),
        card_number_numeric: tagValue(cardXml, "CardNumberNumeric"),
        card_data: tagValue(cardXml, "CardData"),
        associated_user_id: firstMatch(userXml, /<Ref\b[^>]*\bType=["']User["'][^>]*\bID=["']([^"']+)["']/i),
        state: tagValue(cardXml, "State"),
        row_version: tagValue(cardXml, "RowVersion"),
        creation_date: tagValue(cardXml, "CreationDate"),
        modified_date: tagValue(cardXml, "ModifiedDate"),
        last_used: firstValidDateTag(cardXml, "LastUsed"),
        card_type_id: firstMatch(cardTypeXml, /<Ref\b[^>]*\bType=["']CardTemplate["'][^>]*\bID=["']([^"']+)["']/i),
        notes: tagValue(cardXml, "Notes")
    };
}

function checksumUser(user) {
    const tracked = {
        row_version: user.row_version,
        modified_date: user.modified_date,
        first_name: user.first_name,
        second_name: user.second_name,
        user_name: user.user_name,
        notes: user.notes,
        is_visitor: user.is_visitor,
        user_cancelled: user.user_cancelled,
        user_expired: user.user_expired,
        disabled: user.disabled,
        card_number: user.card_number,
        permission_group_id: user.permission_group_id,
        start_date: user.start_date,
        expiry_date: user.expiry_date,
        cf_auto_zone_floor: user.cf_auto_zone_floor,
        cf_zone_floor_code: user.cf_zone_floor_code,
        cf_profile_name: user.cf_profile_name,
        schindler_auto_zone: user.schindler_auto_zone,
        schindler_access_zones_always: user.schindler_access_zones_always,
        schindler_profile_name: user.schindler_profile_name
    };
    return crypto.createHash("sha1").update(JSON.stringify(tracked)).digest("hex");
}

function checksumCard(card) {
    const tracked = {
        row_version: card.row_version,
        modified_date: card.modified_date,
        card_number: card.card_number,
        card_number_numeric: card.card_number_numeric,
        card_data: card.card_data,
        associated_user_id: card.associated_user_id,
        state: card.state,
        card_type_id: card.card_type_id
    };
    return crypto.createHash("sha1").update(JSON.stringify(tracked)).digest("hex");
}

function userToApiPayload(user, eventType) {
    return {
        source_provider: "INNERRANGE",
        source_user_id: user.source_user_id,
        innerrange_user_id: user.source_user_id,
        third_party_user_id: user.source_user_id,
        schindler_person_id: user.schindler_person_id,
        first_name: user.first_name || user.user_name || "",
        second_name: user.second_name || "",
        visitor_name: user.user_name || `${user.first_name || ""} ${user.second_name || ""}`.trim(),
        full_name: user.user_name || `${user.first_name || ""} ${user.second_name || ""}`.trim(),
        company: "",
        card_number: user.card_number || "",
        permission_group: user.permission_group_id || "",
        permission_group_integration_id: user.permission_group_id || "",
        innerrange_permission_group_id: user.permission_group_id || "",
        cf_auto_zone_floor: user.cf_auto_zone_floor || "",
        cf_zone_floor_code: user.cf_zone_floor_code || "",
        cf_profile_name: user.cf_profile_name || "",
        schindler_auto_zone: user.schindler_auto_zone || (user.cf_auto_zone_floor ? `specific,${user.cf_auto_zone_floor}` : ""),
        schindler_access_zones_always: user.schindler_access_zones_always || user.cf_zone_floor_code || "",
        schindler_profile_name: user.schindler_profile_name || user.cf_profile_name || "default",
        purpose_note: user.notes || "",
        notes: user.notes || "",
        start_date: user.start_date || null,
        expiry_date: user.expiry_date || null,
        is_visitor: user.is_visitor,
        user_cancelled: user.user_cancelled,
        user_expired: user.user_expired,
        disabled: user.disabled,
        row_version: user.row_version || "",
        creation_date: user.creation_date || null,
        modified_date: user.modified_date || null,
        sync_event_type: eventType
    };
}

function shouldIncludeByFilter(user, filter) {
    if (filter === "VISITOR_ONLY") return user.is_visitor === true;
    if (filter === "NON_VISITOR_ONLY") return user.is_visitor !== true;
    return true;
}

function buildSourceHeaders(settings) {
    const headers = {};
    if (settings.auth_type === "BASIC" && (settings.username || settings.password)) {
        headers.Authorization = `Basic ${Buffer.from(`${settings.username || ""}:${settings.password || ""}`).toString("base64")}`;
    }
    if (settings.auth_type === "BEARER" && settings.token) {
        headers.Authorization = `Bearer ${settings.token}`;
    }
    if (settings.auth_type === "API_KEY" && settings.api_key) {
        headers[settings.api_key_header || "x-api-key"] = settings.api_key;
    }
    return headers;
}

async function fetchWithTimeout(url, options = {}, timeoutMs = SOURCE_TIMEOUT_MS) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
        return await fetch(url, { ...options, signal: controller.signal });
    } catch (error) {
        if (error.name === "AbortError") throw new Error(`Source timeout setelah ${timeoutMs} ms`);
        throw error;
    } finally {
        clearTimeout(timeout);
    }
}

function buildPageUrl(settings, page, overrides = {}) {
    const url = new URL(joinUrl(settings.base_url, settings.endpoint_path));
    url.searchParams.set("Page", String(page));
    url.searchParams.set("PageSize", String(overrides.pageSize || settings.page_size || 100));
    url.searchParams.set("SortProperty", overrides.sortProperty || url.searchParams.get("SortProperty") || "ID");
    url.searchParams.set("SortOrder", overrides.sortOrder || url.searchParams.get("SortOrder") || "Ascending");
    const fullObject = Object.prototype.hasOwnProperty.call(overrides, "fullObject")
        ? overrides.fullObject !== false
        : settings.full_object !== false;
    if (!url.searchParams.has("FullObject")) url.searchParams.set("FullObject", fullObject ? "true" : "false");
    return url.toString();
}

function sourceModifiedDate(user) {
    return dateOrNull(user.modified_date) || dateOrNull(user.creation_date);
}

function cardModifiedDate(card) {
    return dateOrNull(card.modified_date) || dateOrNull(card.creation_date);
}

function maxSourceModifiedDate(users, fallback = null) {
    let maxDate = fallback ? new Date(fallback) : null;
    if (maxDate && Number.isNaN(maxDate.getTime())) maxDate = null;

    for (const user of users) {
        const date = sourceModifiedDate(user);
        if (date && (!maxDate || date > maxDate)) maxDate = date;
    }

    return maxDate;
}

function maxCardModifiedDate(cards, fallback = null) {
    let maxDate = fallback ? new Date(fallback) : null;
    if (maxDate && Number.isNaN(maxDate.getTime())) maxDate = null;

    for (const card of cards) {
        const date = cardModifiedDate(card);
        if (date && (!maxDate || date > maxDate)) maxDate = date;
    }

    return maxDate;
}

function buildIncrementalSinceDate(value) {
    const date = value ? new Date(value) : null;
    if (!date || Number.isNaN(date.getTime())) return null;
    return new Date(date.getTime() - 5000);
}

async function fetchInnerrangeUsers(settings) {
    const headers = buildSourceHeaders(settings);
    const users = [];
    let totalRecords = 0;
    let page = 1;
    let totalPages = 1;

    do {
        const response = await fetchWithTimeout(buildPageUrl(settings, page), { method: "GET", headers });
        const text = await response.text();
        if (!response.ok) {
            throw new Error(`Innerrange source gagal. HTTP ${response.status}: ${text.slice(0, 300)}`);
        }

        totalRecords = Number(tagValue(text, "TotalRecords") || 0);
        const pageSize = Number(tagValue(text, "PageSize") || settings.page_size || 100);
        totalPages = Math.max(1, Math.ceil(totalRecords / Math.max(pageSize, 1)));
        extractTopLevelElements(tagValue(text, "Rows"), "User")
            .map(parseInnerrangeUser)
            .filter(user => user.source_user_id && shouldIncludeByFilter(user, settings.sync_filter))
            .forEach(user => users.push(user));

        page += 1;
    } while (page <= totalPages);

    return {
        totalRecords,
        users,
        maxModifiedDate: maxSourceModifiedDate(users),
        pagesFetched: page - 1,
        mode: "FULL"
    };
}

async function fetchInnerrangeChangedUsers(settings, sinceValue) {
    const since = buildIncrementalSinceDate(sinceValue);
    if (!since) return { totalRecords: 0, users: [], maxModifiedDate: null, pagesFetched: 0, mode: "INCREMENTAL" };

    const headers = buildSourceHeaders(settings);
    const users = [];
    let totalRecords = 0;
    let page = 1;
    let totalPages = 1;
    let shouldContinue = true;

    do {
        const response = await fetchWithTimeout(
            buildPageUrl(settings, page, {
                sortProperty: "ModifiedDate",
                sortOrder: "Descending",
                pageSize: Math.min(Number(settings.incremental_page_size || INCREMENTAL_PAGE_SIZE), INCREMENTAL_PAGE_SIZE)
            }),
            { method: "GET", headers }
        );
        const text = await response.text();
        if (!response.ok) {
            throw new Error(`Innerrange source gagal. HTTP ${response.status}: ${text.slice(0, 300)}`);
        }

        totalRecords = Number(tagValue(text, "TotalRecords") || 0);
        const pageSize = Number(tagValue(text, "PageSize") || settings.page_size || 100);
        totalPages = Math.max(1, Math.ceil(totalRecords / Math.max(pageSize, 1)));
        const pageUsers = extractTopLevelElements(tagValue(text, "Rows"), "User")
            .map(parseInnerrangeUser)
            .filter(user => user.source_user_id && shouldIncludeByFilter(user, settings.sync_filter));

        const freshUsers = pageUsers.filter(user => {
            const modifiedDate = sourceModifiedDate(user);
            return modifiedDate && modifiedDate > since;
        });
        users.push(...freshUsers);

        const oldestDate = pageUsers.reduce((oldest, user) => {
            const modifiedDate = sourceModifiedDate(user);
            if (!modifiedDate) return oldest;
            return !oldest || modifiedDate < oldest ? modifiedDate : oldest;
        }, null);

        shouldContinue = page < totalPages && oldestDate && oldestDate > since;
        page += 1;
    } while (shouldContinue);

    return {
        totalRecords,
        users,
        maxModifiedDate: maxSourceModifiedDate(users, sinceValue),
        pagesFetched: page - 1,
        mode: "INCREMENTAL"
    };
}

async function fetchInnerrangeUserIds(settings) {
    const headers = buildSourceHeaders(settings);
    const sourceIds = new Set();
    let totalRecords = 0;
    let page = 1;
    let totalPages = 1;

    do {
        const response = await fetchWithTimeout(
            buildPageUrl(settings, page, {
                sortProperty: "ID",
                sortOrder: "Ascending",
                pageSize: DELETE_RECONCILE_PAGE_SIZE,
                fullObject: false
            }),
            { method: "GET", headers }
        );
        const text = await response.text();
        if (!response.ok) {
            throw new Error(`Innerrange source ID check gagal. HTTP ${response.status}: ${text.slice(0, 300)}`);
        }

        totalRecords = Number(tagValue(text, "TotalRecords") || 0);
        const pageSize = Number(tagValue(text, "PageSize") || settings.page_size || 500);
        totalPages = Math.max(1, Math.ceil(totalRecords / Math.max(pageSize, 1)));
        extractTopLevelElements(tagValue(text, "Rows"), "User")
            .map(parseInnerrangeUser)
            .filter(user => user.source_user_id)
            .forEach(user => sourceIds.add(user.source_user_id));

        page += 1;
    } while (page <= totalPages);

    return {
        totalRecords,
        sourceIds,
        pagesFetched: page - 1
    };
}

async function fetchInnerrangeCards(settings) {
    const headers = buildSourceHeaders(settings);
    const cards = [];
    let totalRecords = 0;
    let page = 1;
    let totalPages = 1;

    do {
        const response = await fetchWithTimeout(buildPageUrl(settings, page), { method: "GET", headers });
        const text = await response.text();
        if (!response.ok) {
            throw new Error(`Innerrange card source gagal. HTTP ${response.status}: ${text.slice(0, 300)}`);
        }

        totalRecords = Number(tagValue(text, "TotalRecords") || 0);
        const pageSize = Number(tagValue(text, "PageSize") || settings.page_size || 100);
        totalPages = Math.max(1, Math.ceil(totalRecords / Math.max(pageSize, 1)));
        extractTopLevelElements(tagValue(text, "Rows"), "Card")
            .map(parseInnerrangeCard)
            .filter(card => card.source_card_id)
            .forEach(card => cards.push(card));

        page += 1;
    } while (page <= totalPages);

    return {
        totalRecords,
        cards,
        maxModifiedDate: maxCardModifiedDate(cards),
        pagesFetched: page - 1,
        mode: "FULL"
    };
}

async function fetchInnerrangeChangedCards(settings, sinceValue) {
    const since = buildIncrementalSinceDate(sinceValue);
    if (!since) return { totalRecords: 0, cards: [], maxModifiedDate: null, pagesFetched: 0, mode: "INCREMENTAL" };

    const headers = buildSourceHeaders(settings);
    const cards = [];
    let totalRecords = 0;
    let page = 1;
    let totalPages = 1;
    let shouldContinue = true;

    do {
        const response = await fetchWithTimeout(
            buildPageUrl(settings, page, {
                sortProperty: settings.sort_property || "ModifiedDate",
                sortOrder: settings.sort_order || "Descending",
                pageSize: Math.min(Number(settings.incremental_page_size || INCREMENTAL_PAGE_SIZE), INCREMENTAL_PAGE_SIZE)
            }),
            { method: "GET", headers }
        );
        const text = await response.text();
        if (!response.ok) {
            throw new Error(`Innerrange card source gagal. HTTP ${response.status}: ${text.slice(0, 300)}`);
        }

        totalRecords = Number(tagValue(text, "TotalRecords") || 0);
        const pageSize = Number(tagValue(text, "PageSize") || settings.incremental_page_size || settings.page_size || 100);
        totalPages = Math.max(1, Math.ceil(totalRecords / Math.max(pageSize, 1)));
        const pageCards = extractTopLevelElements(tagValue(text, "Rows"), "Card")
            .map(parseInnerrangeCard)
            .filter(card => card.source_card_id);
        const freshCards = pageCards.filter(card => {
            const modifiedDate = cardModifiedDate(card);
            return modifiedDate && modifiedDate > since;
        });
        cards.push(...freshCards);

        const oldestDate = pageCards.reduce((oldest, card) => {
            const modifiedDate = cardModifiedDate(card);
            if (!modifiedDate) return oldest;
            return !oldest || modifiedDate < oldest ? modifiedDate : oldest;
        }, null);

        shouldContinue = page < totalPages && oldestDate && oldestDate > since;
        page += 1;
    } while (shouldContinue);

    return {
        totalRecords,
        cards,
        maxModifiedDate: maxCardModifiedDate(cards, sinceValue),
        pagesFetched: page - 1,
        mode: "INCREMENTAL"
    };
}

async function insertEvent(req, client, eventType, user, oldSnapshot) {
    const payload = userToApiPayload(user, eventType);
    const result = await client.query(
        `INSERT INTO middleware_sync_events (
            source_user_id,
            event_type,
            status,
            payload,
            old_snapshot,
            new_snapshot,
            created_by,
            created_time
         )
         VALUES ($1,$2,'PENDING',$3,$4,$5,$6,NOW())
         RETURNING *`,
        [
            user.source_user_id,
            eventType,
            JSON.stringify(payload),
            oldSnapshot ? JSON.stringify(oldSnapshot) : null,
            JSON.stringify(user),
            getCurrentUsername(req)
        ]
    );
    return result.rows[0];
}

async function upsertSnapshot(client, user, eventType, syncStatus) {
    const checksum = checksumUser(user);
    await client.query(
        `INSERT INTO middleware_sync_snapshots (
            source_user_id,
            numeric_id,
            partition_id,
            row_version,
            creation_date,
            modified_date,
            first_name,
            second_name,
            user_name,
            notes,
            is_visitor,
            user_cancelled,
            user_expired,
            disabled,
            card_number,
            permission_group_id,
            start_date,
            expiry_date,
            schindler_person_id,
            raw_data,
            checksum,
            source_deleted,
            last_seen_at,
            last_event_type,
            last_sync_status,
            updated_time
         )
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,FALSE,NOW(),$22,$23,NOW())
         ON CONFLICT (source_user_id)
         DO UPDATE SET
            numeric_id = EXCLUDED.numeric_id,
            partition_id = EXCLUDED.partition_id,
            row_version = EXCLUDED.row_version,
            creation_date = EXCLUDED.creation_date,
            modified_date = EXCLUDED.modified_date,
            first_name = EXCLUDED.first_name,
            second_name = EXCLUDED.second_name,
            user_name = EXCLUDED.user_name,
            notes = EXCLUDED.notes,
            is_visitor = EXCLUDED.is_visitor,
            user_cancelled = EXCLUDED.user_cancelled,
            user_expired = EXCLUDED.user_expired,
            disabled = EXCLUDED.disabled,
            card_number = EXCLUDED.card_number,
            permission_group_id = EXCLUDED.permission_group_id,
            start_date = EXCLUDED.start_date,
            expiry_date = EXCLUDED.expiry_date,
            schindler_person_id = EXCLUDED.schindler_person_id,
            raw_data = EXCLUDED.raw_data,
            checksum = EXCLUDED.checksum,
            source_deleted = FALSE,
            last_seen_at = NOW(),
            last_event_type = COALESCE(EXCLUDED.last_event_type, middleware_sync_snapshots.last_event_type),
            last_sync_status = COALESCE(EXCLUDED.last_sync_status, middleware_sync_snapshots.last_sync_status),
            updated_time = NOW()`,
        [
            user.source_user_id,
            user.numeric_id || null,
            user.partition_id || null,
            user.row_version || null,
            dateOrNull(user.creation_date),
            dateOrNull(user.modified_date),
            user.first_name || null,
            user.second_name || null,
            user.user_name || null,
            user.notes || null,
            user.is_visitor === true,
            user.user_cancelled === true,
            user.user_expired === true,
            user.disabled === true,
            user.card_number || null,
            user.permission_group_id || null,
            dateOrNull(user.start_date),
            dateOrNull(user.expiry_date),
            user.schindler_person_id || null,
            user,
            checksum,
            eventType || null,
            syncStatus || null
        ]
    );
}

function deletedUserFromSnapshot(snapshot) {
    const raw = snapshot.raw_data || {};
    return {
        ...raw,
        source_user_id: snapshot.source_user_id,
        numeric_id: snapshot.numeric_id || raw.numeric_id,
        row_version: snapshot.row_version || raw.row_version,
        first_name: snapshot.first_name || raw.first_name,
        second_name: snapshot.second_name || raw.second_name,
        user_name: snapshot.user_name || raw.user_name || snapshot.source_user_id,
        notes: snapshot.notes || raw.notes,
        is_visitor: snapshot.is_visitor === true || raw.is_visitor === true,
        user_cancelled: true,
        user_expired: snapshot.user_expired === true || raw.user_expired === true,
        disabled: snapshot.disabled === true || raw.disabled === true,
        card_number: snapshot.card_number || raw.card_number,
        permission_group_id: snapshot.permission_group_id || raw.permission_group_id,
        start_date: snapshot.start_date || raw.start_date,
        expiry_date: snapshot.expiry_date || raw.expiry_date,
        schindler_person_id: snapshot.schindler_person_id || raw.schindler_person_id,
        cf_auto_zone_floor: raw.cf_auto_zone_floor || "",
        cf_zone_floor_code: raw.cf_zone_floor_code || "",
        cf_profile_name: raw.cf_profile_name || "",
        schindler_auto_zone: raw.schindler_auto_zone || (raw.cf_auto_zone_floor ? `specific,${raw.cf_auto_zone_floor}` : ""),
        schindler_access_zones_always: raw.schindler_access_zones_always || raw.cf_zone_floor_code || "",
        schindler_profile_name: raw.schindler_profile_name || raw.cf_profile_name || "default"
    };
}

function userFromSnapshot(snapshot) {
    const raw = snapshot.raw_data || {};
    return {
        ...raw,
        source_user_id: snapshot.source_user_id,
        numeric_id: snapshot.numeric_id || raw.numeric_id,
        partition_id: snapshot.partition_id || raw.partition_id,
        row_version: snapshot.row_version || raw.row_version,
        first_name: snapshot.first_name || raw.first_name,
        second_name: snapshot.second_name || raw.second_name,
        user_name: snapshot.user_name || raw.user_name || snapshot.source_user_id,
        notes: snapshot.notes || raw.notes,
        is_visitor: snapshot.is_visitor === true || raw.is_visitor === true,
        user_cancelled: snapshot.user_cancelled === true || raw.user_cancelled === true,
        user_expired: snapshot.user_expired === true || raw.user_expired === true,
        disabled: snapshot.disabled === true || raw.disabled === true,
        card_number: snapshot.card_number || raw.card_number,
        permission_group_id: snapshot.permission_group_id || raw.permission_group_id,
        start_date: snapshot.start_date || raw.start_date,
        expiry_date: snapshot.expiry_date || raw.expiry_date,
        creation_date: snapshot.creation_date || raw.creation_date,
        modified_date: snapshot.modified_date || raw.modified_date,
        schindler_person_id: snapshot.schindler_person_id || raw.schindler_person_id,
        cf_auto_zone_floor: raw.cf_auto_zone_floor || "",
        cf_zone_floor_code: raw.cf_zone_floor_code || "",
        cf_profile_name: raw.cf_profile_name || "",
        schindler_auto_zone: raw.schindler_auto_zone || (raw.cf_auto_zone_floor ? `specific,${raw.cf_auto_zone_floor}` : ""),
        schindler_access_zones_always: raw.schindler_access_zones_always || raw.cf_zone_floor_code || "",
        schindler_profile_name: raw.schindler_profile_name || raw.cf_profile_name || "default"
    };
}

async function payloadForEvent(event) {
    const snapshotResult = await pool.query(
        "SELECT * FROM middleware_sync_snapshots WHERE source_user_id = $1 LIMIT 1",
        [event.source_user_id]
    );
    const snapshot = snapshotResult.rows[0];
    if (!snapshot) return event.payload || {};

    const user = snapshot.source_deleted === true
        ? deletedUserFromSnapshot(snapshot)
        : userFromSnapshot(snapshot);
    return {
        ...(event.payload || {}),
        ...userToApiPayload(user, event.event_type)
    };
}

async function isUserAlreadyCancelledOrDeleted(client, sourceUserId) {
    if (!sourceUserId) return false;
    const result = await client.query(
        `SELECT user_cancelled, user_expired, disabled, source_deleted, last_event_type, raw_data
         FROM middleware_sync_snapshots
         WHERE source_user_id = $1
         LIMIT 1`,
        [sourceUserId]
    );
    const row = result.rows[0];
    const raw = row?.raw_data || {};
    const rawCancelled = raw.user_cancelled === true || String(raw.UserCancelled || "").toLowerCase() === "true";
    const rawExpired = raw.user_expired === true || String(raw.UserExpired || "").toLowerCase() === "true";
    const rawDisabled = raw.disabled === true || String(raw.Disabled || "").toLowerCase() === "true";
    return row
        && (
            row.user_cancelled === true
            || row.user_expired === true
            || row.disabled === true
            || row.source_deleted === true
            || rawCancelled
            || rawExpired
            || rawDisabled
            || ["CANCEL", "EXPIRE", "DISABLE", "DELETE"].includes(String(row.last_event_type || "").toUpperCase())
        );
}

async function reconcileDeletedUsersOnly(req, client, settings) {
    const source = await fetchInnerrangeUserIds(settings);
    const previousActive = await client.query(
        `SELECT *
         FROM middleware_sync_snapshots
         WHERE source_deleted = FALSE`
    );
    const createdEvents = [];

    for (const snapshot of previousActive.rows) {
        if (source.sourceIds.has(snapshot.source_user_id)) continue;

        const user = deletedUserFromSnapshot(snapshot);
        await client.query(
            `UPDATE middleware_sync_snapshots
             SET source_deleted = TRUE,
                 last_event_type = 'DELETE',
                 last_sync_status = 'PENDING',
                 updated_time = NOW()
             WHERE source_user_id = $1`,
            [snapshot.source_user_id]
        );
        await client.query(
            `UPDATE middleware_card_snapshots
             SET previous_associated_user_id = associated_user_id,
                 associated_user_id = NULL,
                 last_event_type = 'UNASSIGN',
                 updated_time = NOW()
             WHERE associated_user_id = $1`,
            [snapshot.source_user_id]
        );
        createdEvents.push(await insertEvent(req, client, "DELETE", user, snapshot.raw_data || null));
    }

    return {
        total_records: source.totalRecords,
        missing_count: createdEvents.length,
        pages_fetched: source.pagesFetched,
        pending_events: createdEvents
    };
}

async function upsertCardSnapshot(client, card, eventType, previousAssociatedUserId) {
    const checksum = checksumCard(card);
    await client.query(
        `INSERT INTO middleware_card_snapshots (
            source_card_id,
            card_name,
            card_number,
            card_number_numeric,
            card_data,
            associated_user_id,
            previous_associated_user_id,
            state,
            row_version,
            creation_date,
            modified_date,
            last_used,
            card_type_id,
            notes,
            raw_data,
            checksum,
            source_deleted,
            last_seen_at,
            last_event_type,
            updated_time
         )
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,FALSE,NOW(),$17,NOW())
         ON CONFLICT (source_card_id)
         DO UPDATE SET
            card_name = EXCLUDED.card_name,
            card_number = EXCLUDED.card_number,
            card_number_numeric = EXCLUDED.card_number_numeric,
            card_data = EXCLUDED.card_data,
            associated_user_id = EXCLUDED.associated_user_id,
            previous_associated_user_id = EXCLUDED.previous_associated_user_id,
            state = EXCLUDED.state,
            row_version = EXCLUDED.row_version,
            creation_date = EXCLUDED.creation_date,
            modified_date = EXCLUDED.modified_date,
            last_used = EXCLUDED.last_used,
            card_type_id = EXCLUDED.card_type_id,
            notes = EXCLUDED.notes,
            raw_data = EXCLUDED.raw_data,
            checksum = EXCLUDED.checksum,
            source_deleted = FALSE,
            last_seen_at = NOW(),
            last_event_type = COALESCE(EXCLUDED.last_event_type, middleware_card_snapshots.last_event_type),
            updated_time = NOW()`,
        [
            card.source_card_id,
            card.card_name || null,
            card.card_number || null,
            card.card_number_numeric || null,
            card.card_data || null,
            card.associated_user_id || null,
            previousAssociatedUserId || null,
            card.state || null,
            card.row_version || null,
            dateOrNull(card.creation_date),
            dateOrNull(card.modified_date),
            dateOrNull(card.last_used),
            card.card_type_id || null,
            card.notes || null,
            card,
            checksum,
            eventType || null
        ]
    );
}

async function processEvent(req, event) {
    const triggerEvent = `SYNC_${event.event_type}`;
    try {
        const freshPayload = await payloadForEvent(event);
        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, freshPayload);
        if (!apiResults.length) {
            await pool.query(
                `UPDATE middleware_sync_events
                 SET status = 'FAILED',
                     error_message = $1,
                     payload = $2,
                     api_results = $3,
                     processed_time = NOW()
                 WHERE event_id = $4`,
                [`Tidak ada API target aktif untuk ${triggerEvent}.`, JSON.stringify(freshPayload), JSON.stringify([]), event.event_id]
            );
            await pool.query(
                `UPDATE middleware_sync_snapshots
                 SET last_sync_status = 'FAILED',
                     updated_time = NOW()
                 WHERE source_user_id = $1`,
                [event.source_user_id]
            );
            return { ...event, status: "FAILED", error_message: `Tidak ada API target aktif untuk ${triggerEvent}.`, api_results: [] };
        }
        const failed = apiResults.filter(item => item.success !== true && item.skipped !== true);
        const skipped = apiResults.filter(item => item.skipped === true);
        const status = failed.length ? "FAILED" : "SYNCED";
        const errorMessage = failed.map(item => item.error || item.config_name).filter(Boolean).join("; ")
            || (skipped.length && !apiResults.length ? "Tidak ada API target aktif." : null);

        await pool.query(
            `UPDATE middleware_sync_events
             SET status = $1,
                 error_message = $2,
                 payload = $3,
                 api_results = $4,
                 processed_time = NOW()
             WHERE event_id = $5`,
            [status, errorMessage, JSON.stringify(freshPayload), JSON.stringify(apiResults), event.event_id]
        );
        await pool.query(
            `UPDATE middleware_sync_snapshots
             SET last_sync_status = $1,
                 updated_time = NOW()
             WHERE source_user_id = $2`,
            [status, event.source_user_id]
        );
        return { ...event, status, error_message: errorMessage, api_results: apiResults };
    } catch (error) {
        await pool.query(
            `UPDATE middleware_sync_events
             SET status = 'FAILED',
                 retry_count = retry_count + 1,
                 error_message = $1,
                 processed_time = NOW()
             WHERE event_id = $2`,
            [error.message, event.event_id]
        );
        await pool.query(
            `UPDATE middleware_sync_snapshots
             SET last_sync_status = 'FAILED',
                 updated_time = NOW()
             WHERE source_user_id = $1`,
            [event.source_user_id]
        );
        return { ...event, status: "FAILED", error_message: error.message };
    }
}

async function processUserSourceConfig(req, client, settings) {
    await pool.query(
        `UPDATE middleware_source_configs
         SET last_poll_time = NOW(),
             last_error = NULL
         WHERE config_id = $1`,
        [settings.config_id]
    );

    const snapshotMeta = await client.query(`
        SELECT COUNT(*)::int AS total_snapshots,
               MAX(modified_date) AS max_modified_date
        FROM middleware_sync_snapshots
        WHERE source_deleted = FALSE
    `);
    const totalSnapshots = snapshotMeta.rows[0]?.total_snapshots || 0;
    const maxSnapshotModified = snapshotMeta.rows[0]?.max_modified_date || null;
    const lastSourceModified = settings.last_source_modified_time || maxSnapshotModified;
    const dueFullReconcile = isDailyFullReconcileDue(settings.last_full_reconcile_time, settings.full_reconcile_time);
    let shouldFullReconcile =
        String(settings.sync_mode || "FAST_INCREMENTAL").toUpperCase() === "FULL_RECONCILE"
        || totalSnapshots === 0
        || !lastSourceModified
        || dueFullReconcile;
    let sourceResult = shouldFullReconcile
        ? await fetchInnerrangeUsers(settings)
        : await fetchInnerrangeChangedUsers(settings, lastSourceModified);
    let deleteReconcileResult = null;
    if (!shouldFullReconcile && Number(sourceResult.totalRecords || 0) < Number(totalSnapshots || 0)) {
        deleteReconcileResult = await reconcileDeletedUsersOnly(req, client, settings);
        sourceResult = {
            ...sourceResult,
            totalRecords: deleteReconcileResult.total_records,
            pagesFetched: Number(sourceResult.pagesFetched || 0) + Number(deleteReconcileResult.pages_fetched || 0),
            mode: `${sourceResult.mode}+DELETE_RECONCILE`
        };
    }
    const { totalRecords, users } = sourceResult;
    const seenIds = new Set(users.map(user => user.source_user_id));
    const createdEvents = [...(deleteReconcileResult?.pending_events || [])];

    for (const user of users) {
        const checksum = checksumUser(user);
        const existing = await client.query(
            "SELECT * FROM middleware_sync_snapshots WHERE source_user_id = $1",
            [user.source_user_id]
        );
        const snapshot = existing.rows[0];
        let eventType = null;

        if (!snapshot) {
            eventType = "ADD";
        } else if (user.user_cancelled) {
            if (snapshot.last_event_type !== "CANCEL" || snapshot.checksum !== checksum) eventType = "CANCEL";
        } else if (user.user_expired) {
            if (snapshot.last_event_type !== "EXPIRE" || snapshot.checksum !== checksum) eventType = "EXPIRE";
        } else if (user.disabled) {
            if (snapshot.last_event_type !== "DISABLE" || snapshot.checksum !== checksum) eventType = "DISABLE";
        } else if (snapshot.source_deleted === true) {
            eventType = "ADD";
        } else if (snapshot.checksum !== checksum) {
            eventType = "UPDATE";
        }

        await upsertSnapshot(client, user, eventType, eventType ? "PENDING" : snapshot?.last_sync_status);
        if (eventType) {
            createdEvents.push(await insertEvent(req, client, eventType, user, snapshot?.raw_data || null));
        }
    }

    if (shouldFullReconcile) {
        const previousActive = await client.query(
            `SELECT *
             FROM middleware_sync_snapshots
             WHERE source_deleted = FALSE`
        );
        for (const snapshot of previousActive.rows) {
            if (!seenIds.has(snapshot.source_user_id)) {
                const raw = snapshot.raw_data || {};
                const user = {
                    ...raw,
                    source_user_id: snapshot.source_user_id,
                    schindler_person_id: snapshot.schindler_person_id || raw.schindler_person_id,
                    user_cancelled: true
                };
                await client.query(
                    `UPDATE middleware_sync_snapshots
                     SET source_deleted = TRUE,
                         last_event_type = 'DELETE',
                         last_sync_status = 'PENDING',
                         updated_time = NOW()
                     WHERE source_user_id = $1`,
                    [snapshot.source_user_id]
                );
                createdEvents.push(await insertEvent(req, client, "DELETE", user, snapshot.raw_data || null));
            }
        }
    }

    const newSourceModified = maxSourceModifiedDate(users, lastSourceModified);

    await pool.query(
        `UPDATE middleware_source_configs
         SET last_success_time = NOW(),
             last_error = NULL,
             last_total_records = $1,
             last_processed_count = $2,
             last_source_modified_time = COALESCE($3, last_source_modified_time),
             last_full_reconcile_time = CASE WHEN $4 THEN NOW() ELSE last_full_reconcile_time END
         WHERE config_id = $5`,
        [totalRecords, users.length, newSourceModified, shouldFullReconcile, settings.config_id]
    );

    return {
        config_id: settings.config_id,
        config_name: settings.config_name || settings.source_name,
        entity_type: settings.entity_type,
        success: true,
        total_records: totalRecords,
        processed_users: users.length,
        events_created: createdEvents.length,
        pages_fetched: sourceResult.pagesFetched,
        sync_mode: sourceResult.mode,
        pending_events: createdEvents,
        events: []
    };
}

async function processCardSourceConfig(req, client, settings) {
    await pool.query(
        `UPDATE middleware_source_configs
         SET last_poll_time = NOW(),
             last_error = NULL
         WHERE config_id = $1`,
        [settings.config_id]
    );

    const cardMeta = await client.query(`
        SELECT COUNT(*)::int AS total_cards,
               MAX(modified_date) AS max_modified_date
        FROM middleware_card_snapshots
        WHERE source_deleted = FALSE
    `);
    const totalCards = cardMeta.rows[0]?.total_cards || 0;
    const maxCardModified = cardMeta.rows[0]?.max_modified_date || null;
    const lastSourceModified = settings.last_source_modified_time || maxCardModified;
    const dueFullReconcile = isDailyFullReconcileDue(settings.last_full_reconcile_time, settings.full_reconcile_time);
    let shouldFullReconcile =
        String(settings.sync_mode || "FAST_INCREMENTAL").toUpperCase() === "FULL_RECONCILE"
        || totalCards === 0
        || !lastSourceModified
        || dueFullReconcile;
    let sourceResult = shouldFullReconcile
        ? await fetchInnerrangeCards(settings)
        : await fetchInnerrangeChangedCards(settings, lastSourceModified);
    if (!shouldFullReconcile && Number(sourceResult.totalRecords || 0) < Number(totalCards || 0)) {
        sourceResult = await fetchInnerrangeCards(settings);
        sourceResult.mode = "FULL_DELETE_RECONCILE";
        shouldFullReconcile = true;
    }
    const { totalRecords, cards } = sourceResult;
    const seenIds = new Set(cards.map(card => card.source_card_id));
    const createdEvents = [];

    for (const card of cards) {
        const checksum = checksumCard(card);
        const existing = await client.query(
            "SELECT * FROM middleware_card_snapshots WHERE source_card_id = $1",
            [card.source_card_id]
        );
        const snapshot = existing.rows[0];
        const previousAssociatedUserId = snapshot?.associated_user_id || null;
        let eventType = null;

        if (!snapshot) {
            eventType = "ADD";
        } else if (previousAssociatedUserId && !card.associated_user_id) {
            eventType = "UNASSIGN";
            const alreadyHandledByUserEvent = await isUserAlreadyCancelledOrDeleted(client, previousAssociatedUserId);
            if (!alreadyHandledByUserEvent) {
                const user = {
                    ...(snapshot.raw_data || {}),
                    source_user_id: previousAssociatedUserId,
                    user_name: previousAssociatedUserId,
                    card_number: card.card_number || snapshot.card_number,
                    user_cancelled: true
                };
                createdEvents.push(await insertEvent(req, client, "DELETE", user, snapshot.raw_data || null));
            }
        } else if (previousAssociatedUserId && card.associated_user_id && previousAssociatedUserId !== card.associated_user_id) {
            eventType = "REASSIGN";
            const alreadyHandledByUserEvent = await isUserAlreadyCancelledOrDeleted(client, previousAssociatedUserId);
            if (!alreadyHandledByUserEvent) {
                const user = {
                    ...(snapshot.raw_data || {}),
                    source_user_id: previousAssociatedUserId,
                    user_name: previousAssociatedUserId,
                    card_number: card.card_number || snapshot.card_number,
                    user_cancelled: true
                };
                createdEvents.push(await insertEvent(req, client, "DELETE", user, snapshot.raw_data || null));
            }
        } else if (snapshot.source_deleted === true) {
            eventType = "ADD";
        } else if (snapshot.checksum !== checksum) {
            eventType = "UPDATE";
        }

        await upsertCardSnapshot(client, card, eventType, previousAssociatedUserId);
    }

    if (shouldFullReconcile) {
        const previousActive = await client.query(
            `SELECT *
             FROM middleware_card_snapshots
             WHERE source_deleted = FALSE`
        );
        for (const snapshot of previousActive.rows) {
            if (!seenIds.has(snapshot.source_card_id)) {
                await client.query(
                    `UPDATE middleware_card_snapshots
                     SET source_deleted = TRUE,
                         last_event_type = 'DELETE',
                         updated_time = NOW()
                     WHERE source_card_id = $1`,
                    [snapshot.source_card_id]
                );
                if (snapshot.associated_user_id && !(await isUserAlreadyCancelledOrDeleted(client, snapshot.associated_user_id))) {
                    const user = {
                        ...(snapshot.raw_data || {}),
                        source_user_id: snapshot.associated_user_id,
                        user_name: snapshot.associated_user_id,
                        card_number: snapshot.card_number,
                        user_cancelled: true
                    };
                    createdEvents.push(await insertEvent(req, client, "DELETE", user, snapshot.raw_data || null));
                }
            }
        }
    }

    const newSourceModified = maxCardModifiedDate(cards, lastSourceModified);

    await pool.query(
        `UPDATE middleware_source_configs
         SET last_success_time = NOW(),
             last_error = NULL,
             last_total_records = $1,
             last_processed_count = $2,
             last_source_modified_time = COALESCE($3, last_source_modified_time),
             last_full_reconcile_time = CASE WHEN $4 THEN NOW() ELSE last_full_reconcile_time END
         WHERE config_id = $5`,
        [totalRecords, cards.length, newSourceModified, shouldFullReconcile, settings.config_id]
    );

    return {
        config_id: settings.config_id,
        config_name: settings.config_name,
        entity_type: settings.entity_type,
        success: true,
        total_records: totalRecords,
        processed_users: 0,
        processed_cards: cards.length,
        events_created: createdEvents.length,
        pages_fetched: sourceResult.pagesFetched,
        sync_mode: sourceResult.mode,
        pending_events: createdEvents,
        events: []
    };
}

async function runMiddlewarePoll(req) {
    await ensureSyncSchema();

    const client = await pool.connect();
    try {
        if (!(await isMiddlewareSyncMode())) {
            return {
                success: false,
                skipped: true,
                message: "Middleware Sync tidak berjalan karena Operation Mode saat ini Visitor Registration."
            };
        }

        const settingsResult = await client.query("SELECT * FROM middleware_sync_settings WHERE setting_id = 1");
        const globalSettings = settingsResult.rows[0];
        if (!globalSettings?.is_active) {
            return { success: false, message: "Middleware Sync belum aktif." };
        }

        await pool.query(
            `UPDATE middleware_sync_settings
             SET last_poll_time = NOW(),
                 last_error = NULL
             WHERE setting_id = 1`
        );

        const sourceConfigsResult = await client.query(`
            SELECT *
            FROM middleware_source_configs
            WHERE is_active = TRUE
            ORDER BY config_id ASC
        `);
        const forceRun = req?.manual_run === true;
        const sourceConfigs = sourceConfigsResult.rows.filter(config => {
            if (forceRun) return true;
            if (runningSourceConfigIds.has(Number(config.config_id))) return false;
            const lastPoll = config.last_poll_time ? new Date(config.last_poll_time).getTime() : 0;
            const dueMs = Number(config.poll_interval_sec || globalSettings.poll_interval_sec || 3) * 1000;
            return Date.now() - lastPoll >= dueMs;
        });
        if (!sourceConfigs.length) {
            return { skipped: true, message: "Belum ada Source Configuration yang due untuk polling." };
        }

        const results = [];
        const runnableConfigs = [];
        for (const sourceConfig of sourceConfigs) {
            const entityType = String(sourceConfig.entity_type || "USER").toUpperCase();
            if (!["USER", "CARD"].includes(entityType)) {
                results.push({
                    config_id: sourceConfig.config_id,
                    config_name: sourceConfig.config_name,
                    entity_type: sourceConfig.entity_type,
                    skipped: true,
                    message: `${sourceConfig.entity_type} source sudah tersimpan, parser akan aktif setelah mapping entity disambungkan.`
                });
                continue;
            }

            if (runningSourceConfigIds.has(Number(sourceConfig.config_id))) {
                results.push({
                    config_id: sourceConfig.config_id,
                    config_name: sourceConfig.config_name,
                    entity_type: sourceConfig.entity_type,
                    skipped: true,
                    message: "Source config ini masih berjalan."
                });
                continue;
            }

            runnableConfigs.push({ sourceConfig, entityType });
        }

        const runSourceConfig = async ({ sourceConfig, entityType }) => {
            runningSourceConfigIds.add(Number(sourceConfig.config_id));
            const sourceClient = await pool.connect();
            try {
                await sourceClient.query("BEGIN");
                const result = entityType === "CARD"
                    ? await processCardSourceConfig(req, sourceClient, sourceConfig)
                    : await processUserSourceConfig(req, sourceClient, sourceConfig);
                await sourceClient.query("COMMIT");
                const processedEvents = [];
                for (const event of result.pending_events || []) {
                    processedEvents.push(await processEvent(req, event));
                }
                result.events = processedEvents;
                delete result.pending_events;
                await pool.query(
                    `UPDATE middleware_sync_settings
                     SET last_success_time = NOW(),
                         last_error = NULL
                     WHERE setting_id = 1`
                );
                broadcastSyncUpdate("SOURCE_POLL_SUCCESS", {
                    config_id: sourceConfig.config_id,
                    config_name: sourceConfig.config_name,
                    entity_type: sourceConfig.entity_type
                });
                return result;
            } catch (error) {
                try { await sourceClient.query("ROLLBACK"); } catch (_) {}
                await pool.query(
                    `UPDATE middleware_source_configs
                     SET last_poll_time = NOW(),
                         last_error = $1
                     WHERE config_id = $2`,
                    [error.message, sourceConfig.config_id]
                );
                return {
                    config_id: sourceConfig.config_id,
                    config_name: sourceConfig.config_name,
                    entity_type: sourceConfig.entity_type,
                    success: false,
                    error: error.message
                };
            } finally {
                runningSourceConfigIds.delete(Number(sourceConfig.config_id));
                sourceClient.release();
            }
        };

        for (const entityType of ["USER", "CARD"]) {
            const group = runnableConfigs.filter(item => item.entityType === entityType);
            if (group.length) {
                results.push(...await Promise.all(group.map(runSourceConfig)));
            }
        }

        const totalRecords = results.reduce((sum, item) => sum + Number(item.total_records || 0), 0);
        const processedUsers = results.reduce((sum, item) => sum + Number(item.processed_users || 0), 0);
        const eventsCreated = results.reduce((sum, item) => sum + Number(item.events_created || 0), 0);
        const hasFailure = results.some(item => item.success === false);

        await pool.query(
            `UPDATE middleware_sync_settings
             SET last_success_time = NOW(),
                 last_error = $1,
                 last_total_records = $2,
                 last_processed_count = $3
             WHERE setting_id = 1`,
            [hasFailure ? "Ada Source Configuration yang gagal. Cek detail source list." : null, totalRecords, processedUsers]
        );

        broadcastSyncUpdate("POLL_SUCCESS", {
            total_records: totalRecords,
            processed_users: processedUsers,
            events_created: eventsCreated,
            source_count: results.length
        });

        return {
            success: true,
            total_records: totalRecords,
            processed_users: processedUsers,
            events_created: eventsCreated,
            source_count: results.length,
            results
        };
    } catch (error) {
        await pool.query(
            `UPDATE middleware_sync_settings
             SET last_poll_time = NOW(),
                 last_error = $1
             WHERE setting_id = 1`,
            [error.message]
        );
        broadcastSyncUpdate("POLL_FAILED", { error_message: error.message });
        throw error;
    } finally {
        client.release();
    }
}

router.get("/api/middleware-sync/stream", async (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();

    syncStreamClients.add(res);
    sendSse(res, "sync-update", {
        type: "CONNECTED",
        time: new Date().toISOString()
    });

    const keepAlive = setInterval(() => {
        try {
            sendSse(res, "ping", { time: new Date().toISOString() });
        } catch (error) {
            clearInterval(keepAlive);
            syncStreamClients.delete(res);
        }
    }, 25000);

    req.on("close", () => {
        clearInterval(keepAlive);
        syncStreamClients.delete(res);
    });
});

router.get("/api/middleware-sync/settings", async (req, res) => {
    try {
        await ensureSyncSchema();
        const result = await pool.query("SELECT * FROM middleware_sync_settings WHERE setting_id = 1");
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/middleware-sync/source-configs", async (req, res) => {
    try {
        await ensureSyncSchema();
        const result = await pool.query(`
            SELECT *
            FROM middleware_source_configs
            ORDER BY config_id ASC
        `);
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/middleware-sync/source-configs", async (req, res) => {
    try {
        await ensureSyncSchema();
        const config = normalizeSourceConfig(req.body);
        const validationError = validateSourceConfig(config);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `INSERT INTO middleware_source_configs (
                config_name, provider_type, entity_type, base_url, endpoint_path, http_method,
                auth_type, username, password, token, api_key_header, api_key,
                page_size, incremental_page_size, poll_interval_sec, sync_mode,
                full_reconcile_interval_sec, full_reconcile_time, sync_filter, sort_property, sort_order,
                watermark_field, full_object, is_active, created_by, created_time
             )
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,NOW())
             RETURNING *`,
            [
                config.config_name,
                config.provider_type,
                config.entity_type,
                config.base_url,
                config.endpoint_path,
                config.http_method,
                config.auth_type,
                config.username || null,
                config.password || null,
                config.token || null,
                config.api_key_header || null,
                config.api_key || null,
                config.page_size,
                config.incremental_page_size,
                config.poll_interval_sec,
                config.sync_mode,
                config.full_reconcile_interval_sec,
                config.full_reconcile_time,
                config.sync_filter,
                config.sort_property,
                config.sort_order,
                config.watermark_field,
                config.full_object,
                config.is_active,
                getCurrentUsername(req)
            ]
        );
        broadcastSyncUpdate("SOURCE_CONFIG_CREATED", { config_id: result.rows[0]?.config_id });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/middleware-sync/source-configs/:id", async (req, res) => {
    try {
        await ensureSyncSchema();
        const config = normalizeSourceConfig(req.body);
        const validationError = validateSourceConfig(config);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `UPDATE middleware_source_configs
             SET config_name = $1,
                 provider_type = $2,
                 entity_type = $3,
                 base_url = $4,
                 endpoint_path = $5,
                 http_method = $6,
                 auth_type = $7,
                 username = $8,
                 password = $9,
                 token = $10,
                 api_key_header = $11,
                 api_key = $12,
                 page_size = $13,
                 incremental_page_size = $14,
                 poll_interval_sec = $15,
                 sync_mode = $16,
                full_reconcile_interval_sec = $17,
                 full_reconcile_time = $18,
                 sync_filter = $19,
                 sort_property = $20,
                 sort_order = $21,
                 watermark_field = $22,
                 full_object = $23,
                 is_active = $24,
                 modified_by = $25,
                 modified_time = NOW()
             WHERE config_id = $26
             RETURNING *`,
            [
                config.config_name,
                config.provider_type,
                config.entity_type,
                config.base_url,
                config.endpoint_path,
                config.http_method,
                config.auth_type,
                config.username || null,
                config.password || null,
                config.token || null,
                config.api_key_header || null,
                config.api_key || null,
                config.page_size,
                config.incremental_page_size,
                config.poll_interval_sec,
                config.sync_mode,
                config.full_reconcile_interval_sec,
                config.full_reconcile_time,
                config.sync_filter,
                config.sort_property,
                config.sort_order,
                config.watermark_field,
                config.full_object,
                config.is_active,
                getCurrentUsername(req),
                Number(req.params.id)
            ]
        );
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Source config tidak ditemukan." });
        broadcastSyncUpdate("SOURCE_CONFIG_UPDATED", { config_id: result.rows[0]?.config_id });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/middleware-sync/source-configs/:id", async (req, res) => {
    try {
        await ensureSyncSchema();
        const result = await pool.query("DELETE FROM middleware_source_configs WHERE config_id = $1 RETURNING *", [Number(req.params.id)]);
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Source config tidak ditemukan." });
        broadcastSyncUpdate("SOURCE_CONFIG_DELETED", { config_id: Number(req.params.id) });
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/middleware-sync/settings", async (req, res) => {
    try {
        await ensureSyncSchema();
        const settings = normalizeSettings(req.body);
        const validationError = validateSettings(settings);
        if (validationError) return res.status(400).json({ success: false, message: validationError });

        const result = await pool.query(
            `UPDATE middleware_sync_settings
             SET source_name = $1,
                 provider_type = $2,
                 base_url = $3,
                 endpoint_path = $4,
                 auth_type = $5,
                 username = $6,
                 password = $7,
                 token = $8,
                 api_key_header = $9,
                 api_key = $10,
                 page_size = $11,
                 poll_interval_sec = $12,
                 sync_mode = $13,
                 full_reconcile_interval_sec = $14,
                 sync_filter = $15,
                 auto_run = $16,
                 is_active = $17,
                 modified_by = $18,
                 modified_time = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                settings.source_name,
                settings.provider_type,
                settings.base_url,
                settings.endpoint_path,
                settings.auth_type,
                settings.username || null,
                settings.password || null,
                settings.token || null,
                settings.api_key_header || null,
                settings.api_key || null,
                settings.page_size,
                settings.poll_interval_sec,
                settings.sync_mode,
                settings.full_reconcile_interval_sec,
                settings.sync_filter,
                settings.auto_run,
                settings.is_active,
                getCurrentUsername(req)
            ]
        );

        broadcastSyncUpdate("SETTING_UPDATED", {
            poll_interval_sec: result.rows[0]?.poll_interval_sec,
            is_active: result.rows[0]?.is_active,
            auto_run: result.rows[0]?.auto_run
        });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/middleware-sync/run-poll", async (req, res) => {
    try {
        req.manual_run = true;
        const result = await runMiddlewarePoll(req);
        if (result?.success === false) {
            return res.status(400).json({ success: false, message: result.message || "Run poll gagal.", data: result });
        }
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/middleware-sync/retry-failed", async (req, res) => {
    try {
        await ensureSyncSchema();
        if (!(await isMiddlewareSyncMode())) {
            return res.status(400).json({
                success: false,
                message: "Retry Middleware Sync hanya aktif saat Operation Mode = Middleware Sync."
            });
        }
        const requestedLimit = Number(req.body?.limit || req.query.limit || 10);
        const retryLimit = Math.max(1, Math.min(requestedLimit || 10, 100));
        const failed = await pool.query(
            `SELECT *
             FROM middleware_sync_events
             WHERE status = 'FAILED'
             ORDER BY event_id DESC
             LIMIT $1`,
            [retryLimit]
        );
        const results = [];
        for (const event of failed.rows) {
            results.push(await processEvent(req, event));
        }
        const remainingResult = await pool.query(
            "SELECT COUNT(*)::int AS total FROM middleware_sync_events WHERE status = 'FAILED'"
        );
        const remaining_failed = remainingResult.rows[0]?.total || 0;
        broadcastSyncUpdate("RETRY_FINISHED", { total: results.length, remaining_failed });
        res.json({ success: true, data: { total: results.length, remaining_failed, limit: retryLimit, results } });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/middleware-sync/status", async (req, res) => {
    try {
        await ensureSyncSchema();
        const settings = await pool.query("SELECT * FROM middleware_sync_settings WHERE setting_id = 1");
        const summary = await pool.query(`
            SELECT
                COUNT(*)::int AS snapshots,
                COUNT(*) FILTER (WHERE source_deleted = FALSE)::int AS active_snapshots,
                COUNT(*) FILTER (WHERE source_deleted = TRUE)::int AS source_deleted,
                COUNT(*) FILTER (WHERE source_deleted = FALSE AND last_sync_status = 'SYNCED')::int AS synced,
                COUNT(*) FILTER (WHERE source_deleted = FALSE AND last_sync_status = 'FAILED')::int AS failed,
                COUNT(*) FILTER (WHERE source_deleted = FALSE AND last_sync_status = 'PENDING')::int AS pending
            FROM middleware_sync_snapshots
        `);
        const events = await pool.query(`
            SELECT
                COUNT(*)::int AS total_events,
                COUNT(*) FILTER (WHERE status = 'SYNCED')::int AS synced_events,
                COUNT(*) FILTER (WHERE status = 'FAILED')::int AS failed_events,
                COUNT(*) FILTER (WHERE status = 'PENDING')::int AS pending_events
            FROM middleware_sync_events
        `);
        res.json({
            success: true,
            data: {
                running: isSyncRunning(),
                running_sources: Array.from(runningSourceConfigIds),
                settings: settings.rows[0],
                summary: summary.rows[0],
                events: events.rows[0]
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/middleware-sync/events", async (req, res) => {
    try {
        await ensureSyncSchema();
        let page = Math.max(Number(req.query.page || 1), 1);
        const pageSize = Math.max(1, Math.min(Number(req.query.page_size || 25), 1000));
        const totalResult = await pool.query(`
            SELECT COUNT(*)::int AS total
            FROM middleware_sync_events
        `);
        const total = totalResult.rows[0]?.total || 0;
        const totalPages = Math.max(Math.ceil(total / pageSize), 1);
        page = Math.min(page, totalPages);
        const offset = (page - 1) * pageSize;
        const result = await pool.query(`
            SELECT *
            FROM middleware_sync_events
            ORDER BY event_id DESC
            LIMIT $1
            OFFSET $2
        `, [pageSize, offset]);
        res.json({
            success: true,
            data: result.rows,
            pagination: {
                page,
                page_size: pageSize,
                total,
                total_pages: totalPages
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/middleware-sync/snapshots", async (req, res) => {
    try {
        await ensureSyncSchema();
        const includeDeleted = String(req.query.include_deleted || "").toLowerCase() === "true";
        let page = Math.max(Number(req.query.page || 1), 1);
        const pageSize = Math.max(1, Math.min(Number(req.query.page_size || 25), 1000));
        const userId = String(req.query.user_id || "").trim();
        const name = String(req.query.name || "").trim();
        const card = String(req.query.card || "").trim();
        const whereParts = [];
        const params = [];

        if (!includeDeleted) whereParts.push("source_deleted = FALSE");
        if (userId) {
            params.push(`%${userId}%`);
            whereParts.push(`source_user_id ILIKE $${params.length}`);
        }
        if (name) {
            params.push(`%${name}%`);
            whereParts.push(`COALESCE(user_name, CONCAT_WS(' ', first_name, second_name), '') ILIKE $${params.length}`);
        }
        if (card) {
            params.push(`%${card}%`);
            whereParts.push(`COALESCE(card_number, '') ILIKE $${params.length}`);
        }

        const whereSql = whereParts.length ? `WHERE ${whereParts.join(" AND ")}` : "";
        const orderSql = `
            ORDER BY
                COALESCE(LENGTH(NULLIF(regexp_replace(COALESCE(source_user_id, ''), '[^0-9]', '', 'g'), '')), 2147483647) ASC,
                NULLIF(regexp_replace(COALESCE(source_user_id, ''), '[^0-9]', '', 'g'), '') ASC NULLS LAST,
                COALESCE(LENGTH(NULLIF(regexp_replace(COALESCE(numeric_id, ''), '[^0-9]', '', 'g'), '')), 2147483647) ASC,
                NULLIF(regexp_replace(COALESCE(numeric_id, ''), '[^0-9]', '', 'g'), '') ASC NULLS LAST,
                source_user_id ASC
        `;

        const totalResult = await pool.query(
            `SELECT COUNT(*)::int AS total
             FROM middleware_sync_snapshots
             ${whereSql}`,
            params
        );
        const total = totalResult.rows[0]?.total || 0;
        const totalPages = Math.max(Math.ceil(total / pageSize), 1);
        page = Math.min(page, totalPages);
        const offset = (page - 1) * pageSize;
        const dataParams = [...params, pageSize, offset];
        const result = await pool.query(`
            SELECT *
            FROM middleware_sync_snapshots
            ${whereSql}
            ${orderSql}
            LIMIT $${params.length + 1}
            OFFSET $${params.length + 2}
        `, dataParams);
        res.json({
            success: true,
            data: result.rows,
            pagination: {
                page,
                page_size: pageSize,
                total,
                total_pages: totalPages
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/middleware-sync/card-snapshots", async (req, res) => {
    try {
        await ensureSyncSchema();
        const includeDeleted = String(req.query.include_deleted || "").toLowerCase() === "true";
        let page = Math.max(Number(req.query.page || 1), 1);
        const pageSize = Math.max(1, Math.min(Number(req.query.page_size || 25), 1000));
        const card = String(req.query.card || "").trim();
        const userId = String(req.query.user_id || "").trim();
        const state = String(req.query.state || "").trim();
        const whereParts = [];
        const params = [];

        if (!includeDeleted) whereParts.push("source_deleted = FALSE");
        if (card) {
            params.push(`%${card}%`);
            whereParts.push(`COALESCE(card_number, '') ILIKE $${params.length}`);
        }
        if (userId) {
            params.push(`%${userId}%`);
            whereParts.push(`COALESCE(associated_user_id, '') ILIKE $${params.length}`);
        }
        if (state) {
            params.push(`%${state}%`);
            whereParts.push(`COALESCE(state, '') ILIKE $${params.length}`);
        }

        const whereSql = whereParts.length ? `WHERE ${whereParts.join(" AND ")}` : "";
        const totalResult = await pool.query(
            `SELECT COUNT(*)::int AS total
             FROM middleware_card_snapshots
             ${whereSql}`,
            params
        );
        const total = totalResult.rows[0]?.total || 0;
        const totalPages = Math.max(Math.ceil(total / pageSize), 1);
        page = Math.min(page, totalPages);
        const offset = (page - 1) * pageSize;
        const dataParams = [...params, pageSize, offset];
        const result = await pool.query(`
            SELECT *
            FROM middleware_card_snapshots
            ${whereSql}
            ORDER BY
                COALESCE(LENGTH(NULLIF(regexp_replace(COALESCE(card_number, ''), '[^0-9]', '', 'g'), '')), 2147483647) ASC,
                NULLIF(regexp_replace(COALESCE(card_number, ''), '[^0-9]', '', 'g'), '') ASC NULLS LAST,
                card_number ASC,
                source_card_id ASC
            LIMIT $${params.length + 1}
            OFFSET $${params.length + 2}
        `, dataParams);

        res.json({
            success: true,
            data: result.rows,
            pagination: {
                page,
                page_size: pageSize,
                total,
                total_pages: totalPages
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

async function runSchedulerTick() {
    await ensureSyncSchema();
    if (!(await isMiddlewareSyncMode())) return;

    const result = await pool.query("SELECT * FROM middleware_sync_settings WHERE setting_id = 1");
    const settings = result.rows[0];
    if (!settings?.is_active || !settings?.auto_run) return;

    const lastPoll = settings.last_poll_time ? new Date(settings.last_poll_time).getTime() : 0;
    const dueMs = Number(settings.poll_interval_sec || 60) * 1000;
    if (Date.now() - lastPoll < dueMs) return;

    const reqLike = {
        session: { user: { username: "MIDDLEWARE_SYNC", full_name: "MIDDLEWARE_SYNC" } },
        ip: "127.0.0.1"
    };
    await runMiddlewarePoll(reqLike);
}

function startMiddlewareSyncScheduler() {
    if (schedulerStarted) return;
    schedulerStarted = true;
    setInterval(() => {
        runSchedulerTick().catch(error => console.log("MIDDLEWARE SYNC ERROR:", error.message));
    }, 1000);
}

module.exports = router;
module.exports.startMiddlewareSyncScheduler = startMiddlewareSyncScheduler;
