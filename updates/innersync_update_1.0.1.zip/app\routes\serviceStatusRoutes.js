const express = require("express");
const router = express.Router();
const pool = require("../database/db");

const APP_STARTED_AT = new Date();
const DB_CHECK_TIMEOUT_MS = 1500;

function formatUptime(totalSeconds) {
    const seconds = Math.max(0, Math.floor(totalSeconds));
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
}

async function checkDatabase() {
    const started = Date.now();
    try {
        await Promise.race([
            pool.query("SELECT 1 AS ok"),
            new Promise((_, reject) => setTimeout(() => reject(new Error("Database check timeout")), DB_CHECK_TIMEOUT_MS))
        ]);

        return {
            connected: true,
            status: "CONNECTED",
            latency_ms: Date.now() - started,
            error: null
        };
    } catch (error) {
        return {
            connected: false,
            status: "DISCONNECTED",
            latency_ms: Date.now() - started,
            error: error.message
        };
    }
}

router.get("/api/service-status", async (req, res) => {
    const database = await checkDatabase();

    res.json({
        success: true,
        checked_at: new Date().toISOString(),
        app: {
            running: true,
            status: "RUNNING",
            uptime_seconds: Math.floor(process.uptime()),
            uptime_text: formatUptime(process.uptime()),
            started_at: APP_STARTED_AT.toISOString(),
            host: req.socket.localAddress || null,
            port: req.socket.localPort || null
        },
        database
    });
});

module.exports = router;
