const QRCode = require("qrcode");
const multer = require("multer");
const express = require("express");
const crypto = require("crypto");
const router = express.Router();
const pool = require("../database/db");
const ExcelJS = require("exceljs");
const nodemailer = require("nodemailer");
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const { executeActiveThirdPartyConfigs, hasActiveThirdPartyProvider } = require("./apiIntegrationRoutes");
const {
    ensureDeviceSchema,
    executeDeviceSyncForVisitor,
    syncPermissionGroupDevices,
    normalizeDeviceIds
} = require("./deviceRoutes");
const { ensureSystemNotificationSchema, createSystemNotification } = require("./notificationService");
const {
    ensureCardFormatSchema,
    getCardFormatSettings,
    normalizeCardFormatSettings,
    formatCardNumber,
    analyzeCardFormats
} = require("../utils/cardFormatMapping");
let activePort = null;
let lastCard = "";
let schemaReady = false;
let autoCheckoutSchedulerStarted = false;
let autoCheckoutRunning = false;

function parseLooseBoolean(value) {
    return ["true", "1", "yes", "on"].includes(String(value || "").trim().toLowerCase());
}

// Tambahkan di baris paling atas visitorRoutes.js
console.log("Visitor Routes loaded successfully!");

async function ensureVisitorSchema() {
    if (schemaReady) return;

    await ensureSystemNotificationSchema();
    await ensureCardFormatSchema(pool);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS host VARCHAR(150)
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS third_party_user_id VARCHAR(100)
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS schindler_person_id VARCHAR(100)
    `);

    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS watchlist_status VARCHAR(20)");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS watchlist_entry_id INTEGER");
    await pool.query("ALTER TABLE visitor_registration ADD COLUMN IF NOT EXISTS watchlist_note TEXT");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_watchlist_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            blacklist_mode VARCHAR(30) NOT NULL DEFAULT 'WARNING_ONLY',
            notify_security BOOLEAN NOT NULL DEFAULT TRUE,
            updated_by VARCHAR(100),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        INSERT INTO visitor_watchlist_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_watchlist (
            watchlist_id SERIAL PRIMARY KEY,
            list_type VARCHAR(20) NOT NULL,
            visitor_name VARCHAR(200),
            identity_number VARCHAR(120),
            phone_number VARCHAR(80),
            email_address VARCHAR(255),
            company_name VARCHAR(180),
            reason TEXT,
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP
        )
    `);

    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS list_type VARCHAR(20) NOT NULL DEFAULT 'BLACKLIST'");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS visitor_name VARCHAR(200)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS identity_number VARCHAR(120)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS phone_number VARCHAR(80)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS company_name VARCHAR(180)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS reason TEXT");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS start_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS expiry_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_watchlist ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_watchlist_identity ON visitor_watchlist (identity_number)");
    await pool.query("CREATE INDEX IF NOT EXISTS idx_visitor_watchlist_type_active ON visitor_watchlist (list_type, is_active)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS third_party_user_slots (
            slot_id SERIAL PRIMARY KEY,
            provider VARCHAR(50) NOT NULL DEFAULT 'innerrange',
            third_party_user_id VARCHAR(100) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
            current_visitor_id INTEGER,
            last_visitor_id INTEGER,
            last_assigned_time TIMESTAMP,
            last_released_time TIMESTAMP,
            created_time TIMESTAMP DEFAULT NOW(),
            modified_time TIMESTAMP,
            UNIQUE(provider, third_party_user_id)
        )
    `);

    await pool.query(`
        ALTER TABLE visitor_registration
        ADD COLUMN IF NOT EXISTS created_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW(),
        ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100),
        ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS permission_groups (
            group_id SERIAL PRIMARY KEY,
            group_name VARCHAR(100) UNIQUE NOT NULL,
            integration_id VARCHAR(80),
            floor_id INTEGER,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        ALTER TABLE permission_groups
        ADD COLUMN IF NOT EXISTS integration_id VARCHAR(80)
    `);

    await pool.query(`
        ALTER TABLE permission_groups
        ADD COLUMN IF NOT EXISTS floor_id INTEGER
    `);

    await ensureDeviceSchema();

    await pool.query(`
        CREATE TABLE IF NOT EXISTS schindler_floors (
            floor_id SERIAL PRIMARY KEY,
            floor_name VARCHAR(120) UNIQUE NOT NULL,
            destination_code VARCHAR(40) NOT NULL,
            return_code VARCHAR(40) NOT NULL DEFAULT '1',
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW(),
            modified_at TIMESTAMP
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_hosts (
            host_id SERIAL PRIMARY KEY,
            host_name VARCHAR(150) UNIQUE NOT NULL,
            host_email VARCHAR(255),
            host_whatsapp VARCHAR(80),
            location VARCHAR(150),
            note TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS host_email VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS host_whatsapp VARCHAR(80)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS location VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS note TEXT");
    await pool.query("ALTER TABLE visitor_hosts ADD COLUMN IF NOT EXISTS modified_at TIMESTAMP");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS host_notification_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            email_subject TEXT DEFAULT 'Visitor Check-In - {{visitor_name}}',
            email_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS email_subject TEXT DEFAULT 'Visitor Check-In - {{visitor_name}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS email_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS whatsapp_enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS whatsapp_body TEXT DEFAULT 'Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}'");
    await pool.query("ALTER TABLE host_notification_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO host_notification_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS visitor_invitations (
            invitation_id SERIAL PRIMARY KEY,
            booking_code VARCHAR(40) UNIQUE NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
            first_name VARCHAR(100) NOT NULL,
            second_name VARCHAR(100),
            identity_number VARCHAR(120),
            identity_type VARCHAR(80),
            company_name VARCHAR(150),
            email_address VARCHAR(255),
            phone_number VARCHAR(50),
            visitor_photo VARCHAR(255),
            identity_photo VARCHAR(255),
            host VARCHAR(150),
            start_date TIMESTAMP,
            expiry_date TIMESTAMP,
            permission_group VARCHAR(100),
            purpose_note TEXT,
            created_by VARCHAR(100),
            created_time TIMESTAMP DEFAULT NOW(),
            modified_by VARCHAR(100),
            modified_time TIMESTAMP,
            sent_email_time TIMESTAMP,
            sent_whatsapp_time TIMESTAMP,
            checked_in_visitor_id INTEGER,
            checked_in_time TIMESTAMP,
            cancelled_time TIMESTAMP,
            cancel_reason TEXT
        )
    `);

    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS booking_code VARCHAR(40)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'PENDING'");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS first_name VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS second_name VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS identity_number VARCHAR(120)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS identity_type VARCHAR(80)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS company_name VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS email_address VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS phone_number VARCHAR(50)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS visitor_photo VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS identity_photo VARCHAR(255)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS host VARCHAR(150)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS start_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS expiry_date TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS permission_group VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS purpose_note TEXT");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS created_time TIMESTAMP DEFAULT NOW()");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS modified_by VARCHAR(100)");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS modified_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS sent_email_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS sent_whatsapp_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS checked_in_visitor_id INTEGER");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS checked_in_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS cancelled_time TIMESTAMP");
    await pool.query("ALTER TABLE visitor_invitations ADD COLUMN IF NOT EXISTS cancel_reason TEXT");
    await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS visitor_invitations_booking_code_uq ON visitor_invitations (booking_code)");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS auto_checkout_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            enabled BOOLEAN NOT NULL DEFAULT FALSE,
            schedule_date DATE DEFAULT CURRENT_DATE,
            schedule_time VARCHAR(5) NOT NULL DEFAULT '18:00',
            schedule_type VARCHAR(20) NOT NULL DEFAULT 'ONCE',
            last_run_at TIMESTAMP,
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS enabled BOOLEAN NOT NULL DEFAULT FALSE");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_date DATE DEFAULT CURRENT_DATE");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_time VARCHAR(5) NOT NULL DEFAULT '18:00'");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS schedule_type VARCHAR(20) NOT NULL DEFAULT 'ONCE'");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS last_run_at TIMESTAMP");
    await pool.query("ALTER TABLE auto_checkout_settings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW()");

    await pool.query(`
        INSERT INTO auto_checkout_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS qr_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            digit_length INTEGER NOT NULL DEFAULT 10,
            preview_title VARCHAR(100) NOT NULL DEFAULT 'Visitor QR Code',
            preview_subtitle VARCHAR(150) NOT NULL DEFAULT 'QR Code dibuat dari Card Number',
            show_card_number BOOLEAN NOT NULL DEFAULT TRUE,
            auto_email BOOLEAN NOT NULL DEFAULT FALSE,
            auto_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
            auto_sms BOOLEAN NOT NULL DEFAULT FALSE,
            public_base_url TEXT,
            self_registration_qr_title VARCHAR(150) NOT NULL DEFAULT 'Visitor Self Registration',
            self_registration_qr_subtitle VARCHAR(200) NOT NULL DEFAULT 'Scan QR untuk isi form kunjungan mandiri',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        CREATE TABLE IF NOT EXISTS smtp_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            smtp_host VARCHAR(255),
            smtp_port INTEGER DEFAULT 587,
            smtp_secure BOOLEAN NOT NULL DEFAULT FALSE,
            smtp_user VARCHAR(255),
            smtp_pass TEXT,
            from_email VARCHAR(255),
            from_name VARCHAR(150) DEFAULT 'Visitor Registration',
            email_subject TEXT DEFAULT 'Visitor QR Code - {{visitor_name}}',
            email_body TEXT DEFAULT 'Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}',
            invitation_email_subject TEXT DEFAULT 'Visitor Invitation - {{booking_code}}',
            invitation_email_body TEXT DEFAULT 'Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang.',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query("ALTER TABLE smtp_settings ADD COLUMN IF NOT EXISTS invitation_email_subject TEXT DEFAULT 'Visitor Invitation - {{booking_code}}'");
    await pool.query("ALTER TABLE smtp_settings ADD COLUMN IF NOT EXISTS invitation_email_body TEXT DEFAULT 'Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang.'");

    await pool.query(`
        CREATE TABLE IF NOT EXISTS whatsapp_settings (
            setting_id INTEGER PRIMARY KEY DEFAULT 1,
            send_mode VARCHAR(20) NOT NULL DEFAULT 'manual',
            provider VARCHAR(30) NOT NULL DEFAULT 'meta',
            access_token TEXT,
            phone_number_id VARCHAR(120),
            api_version VARCHAR(20) NOT NULL DEFAULT 'v20.0',
            message_template TEXT DEFAULT 'Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}',
            updated_at TIMESTAMP DEFAULT NOW()
        )
    `);

    await pool.query(`
        ALTER TABLE qr_settings
        ADD COLUMN IF NOT EXISTS auto_email BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS auto_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS auto_sms BOOLEAN NOT NULL DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS public_base_url TEXT,
        ADD COLUMN IF NOT EXISTS self_registration_qr_title VARCHAR(150) NOT NULL DEFAULT 'Visitor Self Registration',
        ADD COLUMN IF NOT EXISTS self_registration_qr_subtitle VARCHAR(200) NOT NULL DEFAULT 'Scan QR untuk isi form kunjungan mandiri'
    `);

    await pool.query(`
        INSERT INTO qr_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        INSERT INTO smtp_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    await pool.query(`
        INSERT INTO whatsapp_settings (setting_id)
        VALUES (1)
        ON CONFLICT (setting_id) DO NOTHING
    `);

    schemaReady = true;
}

function buildTemplate(template, data) {
    return String(template || "").replace(/\{\{(\w+)\}\}/g, (_, key) => data[key] ?? "");
}

function createSmtpTransport(settings) {
    if (!settings?.smtp_host || !settings?.smtp_port || !settings?.smtp_user || !settings?.smtp_pass) {
        throw new Error("Setting SMTP belum lengkap.");
    }

    return nodemailer.createTransport({
        host: settings.smtp_host,
        port: Number(settings.smtp_port),
        secure: settings.smtp_secure === true,
        auth: {
            user: settings.smtp_user,
            pass: settings.smtp_pass
        }
    });
}

async function getSmtpSettings() {
    const result = await pool.query("SELECT * FROM smtp_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function getQrSettings() {
    const result = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function getHostNotificationSettings() {
    const result = await pool.query("SELECT * FROM host_notification_settings WHERE setting_id = 1");
    return result.rows[0];
}

function formatDateTimeText(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString("en-GB");
}

async function sendHostCheckinEmail(req, visitor) {
    try {
        const notifySettings = await getHostNotificationSettings();
        const emailEnabled = notifySettings?.enabled === true;
        const whatsappEnabled = notifySettings?.whatsapp_enabled === true;
        if (!emailEnabled && !whatsappEnabled) return { skipped: true, reason: "Host notification disabled" };

        const hostName = String(visitor?.host || "").trim();
        if (!hostName) return { skipped: true, reason: "Host kosong" };

        const hostResult = await pool.query(
            "SELECT * FROM visitor_hosts WHERE host_name = $1 LIMIT 1",
            [hostName]
        );
        const host = hostResult.rows[0];
        const targetEmail = String(host?.host_email || "").trim();
        const targetWhatsapp = String(host?.host_whatsapp || "").trim();
        if (emailEnabled && !targetEmail && whatsappEnabled && !targetWhatsapp) {
            return { skipped: true, reason: "Email dan WhatsApp host kosong" };
        }
        if (emailEnabled && !targetEmail && !whatsappEnabled) return { skipped: true, reason: "Email host kosong" };
        if (whatsappEnabled && !targetWhatsapp && !emailEnabled) return { skipped: true, reason: "WhatsApp host kosong" };

        const visitorName = getVisitorDisplayName(visitor);
        const templateData = {
            visitor_name: visitorName,
            first_name: visitor?.first_name || "",
            second_name: visitor?.second_name || "",
            company_name: visitor?.company_name || "-",
            host: hostName,
            host_email: targetEmail,
            host_whatsapp: targetWhatsapp,
            host_location: host?.location || "-",
            purpose_note: visitor?.purpose_note || "-",
            card_number: visitor?.card_number || "-",
            permission_group: visitor?.permission_group || "-",
            check_in_time: formatDateTimeText(visitor?.check_in_time || new Date()),
            start: formatDateTimeText(visitor?.start_date),
            expiry: formatDateTimeText(visitor?.expiry_date)
        };

        const results = [];

        if (emailEnabled && targetEmail) {
            const settings = await getSmtpSettings();
            const transporter = createSmtpTransport(settings);
            const subject = buildTemplate(
                notifySettings.email_subject || "Visitor Check-In - {{visitor_name}}",
                templateData
            );
            const body = buildTemplate(
                notifySettings.email_body || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}",
                templateData
            );

            await transporter.sendMail({
                from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
                to: targetEmail,
                subject,
                text: body
            });

            await saveActivityLog(
                req,
                "SEND_HOST_CHECKIN_EMAIL",
                `Send host check-in email to ${targetEmail} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"})`
            );
            await createSystemNotification(req, {
                channel: "EMAIL_HOST",
                event_type: "CHECKIN",
                status: "SUCCESS",
                visitor_id: visitor?.visitor_id,
                visitor_name: visitorName,
                target: targetEmail,
                title: "Email ke Host berhasil",
                message: `Informasi check-in ${visitorName} berhasil dikirim ke ${targetEmail}.`,
                detail: { host: hostName, card_number: visitor?.card_number || null }
            });
            results.push({ channel: "email", success: true, to: targetEmail });
        }

        if (whatsappEnabled && targetWhatsapp) {
            const whatsappSettings = await getWhatsappSettings();
            const body = buildTemplate(
                notifySettings.whatsapp_body || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}",
                templateData
            );

            await sendPlainWhatsappMessage(whatsappSettings, targetWhatsapp, body);
            await saveActivityLog(
                req,
                "SEND_HOST_CHECKIN_WHATSAPP",
                `Send host check-in WhatsApp to ${targetWhatsapp} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"})`
            );
            await createSystemNotification(req, {
                channel: "WHATSAPP_HOST",
                event_type: "CHECKIN",
                status: "SUCCESS",
                visitor_id: visitor?.visitor_id,
                visitor_name: visitorName,
                target: targetWhatsapp,
                title: "WhatsApp ke Host berhasil",
                message: `Informasi check-in ${visitorName} berhasil dikirim ke ${targetWhatsapp}.`,
                detail: { host: hostName, card_number: visitor?.card_number || null }
            });
            results.push({ channel: "whatsapp", success: true, to: targetWhatsapp });
        }

        return { success: true, results };
    } catch (error) {
        console.log("SEND HOST CHECKIN NOTIFICATION ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_HOST_CHECKIN_NOTIFICATION_FAILED",
            `Send host check-in notification failed for ${getVisitorDisplayName(visitor)}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "HOST_NOTIFICATION",
            event_type: "CHECKIN",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: getVisitorDisplayName(visitor),
            target: visitor?.host || null,
            title: "Notifikasi ke Host gagal",
            message: error.message,
            detail: { host: visitor?.host || null, card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

async function getFormattedQrCardNumber(cardNumber) {
    const settings = await getCardFormatSettings(pool);
    const preview = formatCardNumber(cardNumber || "", settings);
    return settings.enabled && settings.apply_to_qr ? preview.formatted : preview.raw;
}

async function buildQrShareUrlFromSettings(settings, visitor, qrCardNumber = null) {
    const baseUrl = String(settings?.public_base_url || "").trim().replace(/\/+$/, "");
    if (!baseUrl || !visitor?.card_number) return "-";
    const params = new URLSearchParams({
        qrCard: String(qrCardNumber || visitor.card_number || ""),
        visitor: getVisitorDisplayName(visitor)
    });
    return `${baseUrl}/qr-info.html?${params.toString()}`;
}

async function sendVisitorCheckinQrEmail(req, visitor) {
    const visitorName = getVisitorDisplayName(visitor);
    let targetEmail = String(visitor?.email_address || "").trim();

    try {
        const qrSettings = await getQrSettings();
        if (qrSettings?.auto_email !== true) return { skipped: true, reason: "Auto email QR disabled" };

        if (!targetEmail) {
            await createSystemNotification(req, {
                channel: "EMAIL_VISITOR",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_id: visitor?.visitor_id,
                visitor_name: visitorName,
                title: "Email QR ke Visitor gagal",
                message: "Email visitor belum diisi.",
                detail: { card_number: visitor?.card_number || null }
            });
            return { success: false, error: "Email visitor belum diisi." };
        }

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const qrCardNumber = await getFormattedQrCardNumber(visitor?.card_number);
        const shareUrl = await buildQrShareUrlFromSettings(qrSettings, visitor, qrCardNumber);
        const templateData = {
            visitor_name: visitorName,
            first_name: visitor?.first_name || "",
            second_name: visitor?.second_name || "",
            company_name: visitor?.company_name || "-",
            host: visitor?.host || "-",
            start: formatDateTimeText(visitor?.start_date),
            expiry: formatDateTimeText(visitor?.expiry_date),
            card_number: qrCardNumber || "-",
            card_number_raw: visitor?.card_number || "-",
            share_url: shareUrl,
            purpose_note: visitor?.purpose_note || "-"
        };

        const subject = buildTemplate(settings.email_subject || "Visitor QR Code - {{visitor_name}}", templateData);
        const body = buildTemplate(
            settings.email_body || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
            templateData
        );
        const qrBuffer = await QRCode.toBuffer(String(qrCardNumber || shareUrl || visitorName), {
            errorCorrectionLevel: "H",
            margin: 2,
            width: 480
        });

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body,
            attachments: [
                {
                    filename: `QR_${String(qrCardNumber || "visitor").replace(/[^a-z0-9_-]+/gi, "_")}.png`,
                    content: qrBuffer,
                    contentType: "image/png"
                }
            ]
        });

        await saveActivityLog(
            req,
            "SEND_QR_EMAIL",
            `Auto send QR email to ${targetEmail} for ${visitorName} (Visitor ID ${visitor?.visitor_id || "-"}, Card ${visitor?.card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail,
            title: "Email QR ke Visitor berhasil",
            message: `QR Code visitor berhasil dikirim otomatis ke ${targetEmail}.`,
            detail: { card_number: qrCardNumber || null, card_number_raw: visitor?.card_number || null, share_url: shareUrl }
        });

        return { success: true, to: targetEmail };
    } catch (error) {
        console.log("SEND VISITOR QR EMAIL ERROR:", error.message);
        await saveActivityLog(
            req,
            "SEND_QR_EMAIL_FAILED",
            `Auto send QR email failed for ${visitorName}: ${error.message}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_id: visitor?.visitor_id,
            visitor_name: visitorName,
            target: targetEmail || null,
            title: "Email QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: visitor?.card_number || null }
        });
        return { success: false, error: error.message };
    }
}

function normalizeBookingCode(value) {
    return String(value || "").trim().toUpperCase();
}

function safeUploadFilename(value) {
    const raw = String(value || "").trim();
    if (!raw) return null;
    const filename = raw
        .replace(/^\/?uploads[\\/]/i, "")
        .split(/[\\/]/)
        .pop();
    if (!filename || filename === "." || filename === ".." || filename.includes("..")) return null;
    return filename;
}

async function generateBookingCode() {
    const date = new Date();
    const datePart = `${date.getFullYear()}${pad2(date.getMonth() + 1)}${pad2(date.getDate())}`;
    for (let attempt = 0; attempt < 20; attempt += 1) {
        const randomPart = crypto.randomBytes(3).toString("hex").toUpperCase();
        const code = `INV-${datePart}-${randomPart}`;
        const existing = await pool.query("SELECT 1 FROM visitor_invitations WHERE booking_code = $1 LIMIT 1", [code]);
        if (existing.rows.length === 0) return code;
    }
    throw new Error("Gagal generate booking code unik.");
}

function invitationTemplateData(invitation) {
    const visitorName = `${invitation?.first_name || ""} ${invitation?.second_name || ""}`.trim() || "Visitor";
    return {
        booking_code: invitation?.booking_code || "-",
        visitor_name: visitorName,
        first_name: invitation?.first_name || "",
        second_name: invitation?.second_name || "",
        company_name: invitation?.company_name || "-",
        host: invitation?.host || "-",
        start: formatDateTimeText(invitation?.start_date),
        expiry: formatDateTimeText(invitation?.expiry_date),
        permission_group: invitation?.permission_group || "-",
        purpose_note: invitation?.purpose_note || "-"
    };
}

function buildBookingInvitationMessage(invitation) {
    const data = invitationTemplateData(invitation);
    return [
        "Visitor Invitation",
        `Booking Code: ${data.booking_code}`,
        `Nama: ${data.visitor_name}`,
        `Company: ${data.company_name}`,
        `Host: ${data.host}`,
        `Start: ${data.start}`,
        `Expiry: ${data.expiry}`,
        `Keperluan: ${data.purpose_note}`,
        "",
        "Tunjukkan booking code ini ke operator saat datang."
    ].join("\n");
}

async function sendBookingInvitationEmail(req, invitation) {
    const targetEmail = String(invitation?.email_address || "").trim();
    if (!targetEmail) throw new Error("Email visitor belum diisi.");

    const settings = await getSmtpSettings();
    const transporter = createSmtpTransport(settings);
    const data = invitationTemplateData(invitation);
    const subject = buildTemplate(settings.invitation_email_subject || "Visitor Invitation - {{booking_code}}", data);
    const body = buildTemplate(settings.invitation_email_body || buildBookingInvitationMessage(invitation), data);
    const qrDataUrl = await QRCode.toDataURL(data.booking_code, {
        errorCorrectionLevel: "H",
        margin: 2,
        width: 480
    });
    const qrBuffer = Buffer.from(qrDataUrl.replace(/^data:image\/png;base64,/, ""), "base64");

    await transporter.sendMail({
        from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
        to: targetEmail,
        subject,
        text: body,
        attachments: [
            {
                filename: `Booking_QR_${data.booking_code}.png`,
                content: qrBuffer,
                contentType: "image/png"
            }
        ]
    });

    await pool.query(
        "UPDATE visitor_invitations SET sent_email_time = NOW(), modified_by = $1, modified_time = NOW() WHERE invitation_id = $2",
        [getCurrentUsername(req), invitation.invitation_id]
    );

        await saveActivityLog(
            req,
            "SEND_INVITATION_EMAIL",
            `Send booking invitation ${data.booking_code} to ${targetEmail}`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "INVITATION",
            status: "SUCCESS",
            visitor_name: data.visitor_name,
            target: targetEmail,
            title: "Email invitation berhasil",
            message: `Booking code ${data.booking_code} berhasil dikirim ke ${targetEmail}.`,
            detail: { booking_code: data.booking_code }
        });
}

async function getInvitationByBookingCode(code) {
    const bookingCode = normalizeBookingCode(code);
    if (!bookingCode) return null;
    const result = await pool.query("SELECT * FROM visitor_invitations WHERE booking_code = $1 LIMIT 1", [bookingCode]);
    return result.rows[0] || null;
}

async function validatePendingInvitationByCode(code) {
    const invitation = await getInvitationByBookingCode(code);
    if (!invitation) {
        return { ok: false, status: 404, message: "Booking code tidak ditemukan." };
    }
    if (invitation.status !== "PENDING") {
        return { ok: false, status: 400, message: `Booking code sudah berstatus ${invitation.status}.` };
    }
    if (invitation.expiry_date && new Date(invitation.expiry_date) < new Date()) {
        await pool.query(
            "UPDATE visitor_invitations SET status = 'EXPIRED', modified_time = NOW() WHERE invitation_id = $1",
            [invitation.invitation_id]
        );
        return { ok: false, status: 400, message: "Booking code sudah expired." };
    }
    return { ok: true, invitation };
}

async function getWhatsappSettings() {
    const result = await pool.query("SELECT * FROM whatsapp_settings WHERE setting_id = 1");
    return result.rows[0];
}

async function isVisitorRegistrationApiMode() {
    try {
        const result = await pool.query("SELECT operation_mode FROM maintenance_settings WHERE setting_id = 1");
        return String(result.rows[0]?.operation_mode || "VISITOR_REGISTRATION").toUpperCase() !== "MIDDLEWARE_SYNC";
    } catch (error) {
        return true;
    }
}

function normalizeWhatsappPhone(phone) {
    let targetPhone = String(phone || "").replace(/[^0-9+]/g, "").replace(/^\+/, "");
    if (targetPhone.startsWith("0")) {
        targetPhone = `62${targetPhone.slice(1)}`;
    }
    return targetPhone;
}

async function sendPlainWhatsappMessage(settings, toPhone, body) {
    if (!settings || settings.send_mode !== "api") {
        throw new Error("Mode WhatsApp API belum aktif.");
    }

    if (settings.provider !== "meta") {
        throw new Error("Provider WhatsApp belum didukung. Gunakan Meta Cloud API.");
    }

    if (!settings.access_token || !settings.phone_number_id) {
        throw new Error("Access token dan Phone Number ID WhatsApp wajib diisi.");
    }

    const targetPhone = normalizeWhatsappPhone(toPhone);
    if (!targetPhone) {
        throw new Error("Nomor WhatsApp tujuan belum diisi.");
    }

    const apiVersion = settings.api_version || "v20.0";
    const response = await fetch(`https://graph.facebook.com/${apiVersion}/${settings.phone_number_id}/messages`, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${settings.access_token}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            messaging_product: "whatsapp",
            to: targetPhone,
            type: "text",
            text: { body: String(body || "") }
        })
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(result?.error?.message || result?.message || `WhatsApp API error ${response.status}`);
    }

    return result;
}

function getCurrentUsername(req) {
    return req.session?.user?.username || req.session?.user?.full_name || "SYSTEM";
}

function normalizeTime(value, fallback = "18:00") {
    const text = String(value || "").trim();
    return /^\d{2}:\d{2}$/.test(text) ? text : fallback;
}

function normalizeDate(value) {
    if (value instanceof Date) return localDateKey(value);
    const text = String(value || "").trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.slice(0, 10);
    return localDateKey();
}

function normalizeScheduleType(value, fallback = "ONCE") {
    const type = String(value || fallback).trim().toUpperCase();
    return ["ONCE", "DAILY", "MONTHLY", "YEARLY"].includes(type) ? type : fallback;
}

function pad2(value) {
    return String(value).padStart(2, "0");
}

function localDateKey(date = new Date()) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

async function saveActivityLog(req, activityType, description) {
    try {
        await pool.query(
            `INSERT INTO activity_logs
            (
                username,
                activity_type,
                description,
                ip_address
            )
            VALUES ($1,$2,$3,$4)`,
            [
                getCurrentUsername(req),
                activityType,
                description,
                req.ip
            ]
        );
    } catch (error) {
        console.log("SAVE VISITOR ACTIVITY LOG ERROR:", error.message);
    }
}

function normalizeWatchlistType(value) {
    const type = String(value || "").trim().toUpperCase();
    return type === "WHITELIST" ? "WHITELIST" : "BLACKLIST";
}

function normalizeWatchlistMode(value) {
    const mode = String(value || "").trim().toUpperCase();
    return ["WARNING_ONLY", "BLOCK_CHECKIN", "REQUIRE_SUPERADMIN"].includes(mode) ? mode : "WARNING_ONLY";
}

function normalizeComparable(value) {
    return String(value || "").trim();
}

function normalizePhoneComparable(value) {
    return String(value || "").replace(/[^0-9]/g, "");
}

function getWatchlistVisitorName(payload = {}) {
    return String(payload.visitor_name || `${payload.first_name || ""} ${payload.second_name || ""}`.trim() || "").trim();
}

async function getWatchlistSettings() {
    const result = await pool.query("SELECT * FROM visitor_watchlist_settings WHERE setting_id = 1");
    return result.rows[0] || { blacklist_mode: "WARNING_ONLY", notify_security: true };
}

function watchlistEntryActiveSql(alias = "") {
    const prefix = alias ? `${alias}.` : "";
    return `${prefix}is_active = TRUE AND (${prefix}start_date IS NULL OR ${prefix}start_date <= NOW()) AND (${prefix}expiry_date IS NULL OR ${prefix}expiry_date >= NOW())`;
}

async function findVisitorWatchlistMatches(payload = {}) {
    const identityNumber = normalizeComparable(payload.identity_number);
    const email = normalizeComparable(payload.email_address || payload.email).toLowerCase();
    const phone = normalizePhoneComparable(payload.phone_number || payload.telephone_number);
    const visitorName = getWatchlistVisitorName(payload).toLowerCase();
    const params = [];
    const filters = [];

    if (identityNumber) {
        params.push(identityNumber);
        filters.push(`identity_number = $${params.length}`);
    }
    if (email) {
        params.push(email);
        filters.push(`LOWER(email_address) = $${params.length}`);
    }
    if (phone) {
        params.push(phone);
        filters.push(`REGEXP_REPLACE(COALESCE(phone_number, ''), '[^0-9]', '', 'g') = $${params.length}`);
    }
    if (visitorName) {
        params.push(`%${visitorName}%`);
        filters.push(`LOWER(COALESCE(visitor_name, '')) LIKE $${params.length}`);
    }

    if (!filters.length) return [];

    const identityOrder = identityNumber ? "CASE WHEN identity_number = $1 THEN 0 ELSE 1 END," : "";
    const result = await pool.query(
        `SELECT *
         FROM visitor_watchlist
         WHERE ${watchlistEntryActiveSql()}
           AND (${filters.join(" OR ")})
         ORDER BY
           CASE list_type WHEN 'BLACKLIST' THEN 0 ELSE 1 END,
           ${identityOrder}
           watchlist_id DESC`,
        params
    );

    return result.rows.map(row => {
        const matchTypes = [];
        if (identityNumber && String(row.identity_number || "").trim() === identityNumber) matchTypes.push("ID_NUMBER");
        if (email && String(row.email_address || "").trim().toLowerCase() === email) matchTypes.push("EMAIL");
        if (phone && normalizePhoneComparable(row.phone_number) === phone) matchTypes.push("PHONE");
        if (visitorName && String(row.visitor_name || "").trim().toLowerCase().includes(visitorName)) matchTypes.push("NAME");
        return { ...row, match_types: matchTypes };
    });
}

function summarizeWatchlistDecision(matches = [], settings = {}) {
    const exactBlacklist = matches.find(row => row.list_type === "BLACKLIST" && row.match_types?.some(type => ["ID_NUMBER", "EMAIL", "PHONE"].includes(type)));
    const possibleBlacklist = matches.find(row => row.list_type === "BLACKLIST");
    const exactWhitelist = matches.find(row => row.list_type === "WHITELIST" && row.match_types?.some(type => ["ID_NUMBER", "EMAIL", "PHONE"].includes(type)));
    const mode = normalizeWatchlistMode(settings.blacklist_mode);
    const primary = exactBlacklist || exactWhitelist || possibleBlacklist || matches[0] || null;
    const status = exactBlacklist ? "BLACKLIST" : exactWhitelist ? "WHITELIST" : possibleBlacklist ? "BLACKLIST" : "NORMAL";

    return {
        status,
        mode,
        blocked: status === "BLACKLIST" && mode === "BLOCK_CHECKIN" && !!exactBlacklist,
        require_approval: status === "BLACKLIST" && mode === "REQUIRE_SUPERADMIN" && !!exactBlacklist,
        primary,
        matches
    };
}

router.get("/api/system-notifications/unread-count", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const result = await pool.query(
            "SELECT COUNT(*)::int AS unread_count FROM system_notifications WHERE is_read = FALSE"
        );
        res.json({ success: true, unread_count: result.rows[0]?.unread_count || 0 });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/system-notifications", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 500);
        const filters = [];
        const params = [];

        if (req.query.unread_only === "true") {
            filters.push("is_read = FALSE");
        }

        if (String(req.query.read_status || "").toUpperCase() === "READ") {
            filters.push("is_read = TRUE");
        } else if (String(req.query.read_status || "").toUpperCase() === "UNREAD") {
            filters.push("is_read = FALSE");
        }

        if (req.query.channel) {
            params.push(String(req.query.channel).toUpperCase());
            filters.push(`channel = $${params.length}`);
        }

        if (req.query.status) {
            params.push(String(req.query.status).toUpperCase());
            filters.push(`status = $${params.length}`);
        }

        if (req.query.search) {
            params.push(`%${String(req.query.search).trim()}%`);
            filters.push(`(title ILIKE $${params.length} OR message ILIKE $${params.length} OR visitor_name ILIKE $${params.length} OR target ILIKE $${params.length})`);
        }

        params.push(limit);
        const result = await pool.query(
            `SELECT *
             FROM system_notifications
             ${filters.length ? `WHERE ${filters.join(" AND ")}` : ""}
             ORDER BY created_time DESC
             LIMIT $${params.length}`,
            params
        );
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/system-notifications/mark-read", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationId = Number(req.body.notification_id || 0);
        if (notificationId) {
            await pool.query(
                `UPDATE system_notifications
                 SET is_read = TRUE,
                     read_by = $1,
                     read_time = NOW()
                 WHERE notification_id = $2`,
                [getCurrentUsername(req), notificationId]
            );
        } else {
            await pool.query(
                `UPDATE system_notifications
                 SET is_read = TRUE,
                     read_by = $1,
                     read_time = NOW()
                 WHERE is_read = FALSE`,
                [getCurrentUsername(req)]
            );
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/system-notifications/:id/retry-api", async (req, res) => {
    try {
        await ensureSystemNotificationSchema();
        const notificationResult = await pool.query(
            "SELECT * FROM system_notifications WHERE notification_id = $1",
            [req.params.id]
        );
        const notification = notificationResult.rows[0];

        if (!notification) {
            return res.status(404).json({ success: false, message: "Notification tidak ditemukan." });
        }

        const channel = String(notification.channel || "").toUpperCase();
        const provider = String(notification.provider_type || channel.replace(/^API_/, "") || "").toUpperCase();
        const triggerEvent = String(notification.event_type || "").toUpperCase();
        const detail = notification.detail || {};
        const configId = detail.config_id ? Number(detail.config_id) : null;

        if (!channel.startsWith("API_") || !provider || notification.status !== "FAILED") {
            return res.status(400).json({ success: false, message: "Retry hanya tersedia untuk notification API yang statusnya FAILED." });
        }
        if (!notification.visitor_id) {
            return res.status(400).json({ success: false, message: "Visitor ID tidak tersedia untuk retry API." });
        }
        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Event API tidak tersedia untuk retry." });
        }

        const visitorResult = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [notification.visitor_id]);
        const visitor = visitorResult.rows[0];
        if (!visitor) {
            return res.status(404).json({ success: false, message: "Visitor tidak ditemukan." });
        }

        await saveActivityLog(
            req,
            "RETRY_THIRD_PARTY_API",
            `Retry ${provider} ${triggerEvent} API for ${getVisitorDisplayName(visitor)} (Visitor ID ${visitor.visitor_id}) from notification ${notification.notification_id}`
        );

        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, visitor, {
            providerType: provider,
            configId
        });
        const retryResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === provider);
        const ok = retryResults.some(item => item.success === true);

        res.json({
            success: ok,
            message: ok ? `Retry ${provider} ${triggerEvent} berhasil.` : `Retry ${provider} ${triggerEvent} gagal. Cek Log Activity API dan notification terbaru.`,
            data: retryResults,
            api_results: apiResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

function hasNonEmptyInnerrangeCard(responseBody) {
    const text = String(responseBody || "");
    const cardMatches = [...text.matchAll(/<CardNumber>\s*([^<\s]+)\s*<\/CardNumber>/gi)];
    return cardMatches.some(match => String(match[1] || "").trim());
}

function hasActiveInnerrangePermissionGroup(responseBody) {
    const text = String(responseBody || "");
    return /<PrimaryPermissionGroup\b[\s\S]*?<Ref\b[\s\S]*?<\/PrimaryPermissionGroup>/i.test(text);
}

function isInnerrangeUserCleanForReuse(responseBody) {
    const text = String(responseBody || "");
    if (!text.trim()) return false;
    return !hasNonEmptyInnerrangeCard(text) && !hasActiveInnerrangePermissionGroup(text);
}

async function verifyInnerrangeSlotClean(reqLike, thirdPartyUserId) {
    const apiResults = await executeActiveThirdPartyConfigs(
        reqLike,
        "CHECK_INNERRANGE",
        {
            third_party_user_id: thirdPartyUserId,
            innerrange_user_id: thirdPartyUserId
        },
        { providerType: "INNERRANGE" }
    );
    const checkResult = apiResults.find(item =>
        String(item.provider_type || "").toUpperCase() === "INNERRANGE"
        && item.skipped !== true
    );

    if (!checkResult) {
        return { clean: false, reason: "API CHECK_INNERRANGE belum aktif." };
    }
    if (checkResult.success !== true) {
        return {
            clean: false,
            reason: checkResult.error || `API CHECK_INNERRANGE gagal (${checkResult.status || "-"})`
        };
    }

    const clean = isInnerrangeUserCleanForReuse(checkResult.response_body);
    return {
        clean,
        reason: clean ? "" : "User InnerRange masih memiliki card atau permission group aktif."
    };
}

async function reserveThirdPartyUserSlotForVerify(visitorId) {
    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('innerrange_slot_allocation'))");

        const result = await client.query(
            `UPDATE third_party_user_slots
             SET status = 'VERIFYING',
                 current_visitor_id = $1,
                 last_visitor_id = $1,
                 modified_time = NOW()
             WHERE slot_id = (
                 SELECT slot_id
                 FROM third_party_user_slots
                 WHERE provider = 'innerrange'
                   AND status IN ('AVAILABLE', 'PENDING_VERIFY')
                   AND NOT EXISTS (
                       SELECT 1
                       FROM visitor_registration v
                       WHERE v.third_party_user_id = third_party_user_slots.third_party_user_id
                         AND v.check_out_time IS NULL
                   )
                 ORDER BY last_released_time ASC NULLS FIRST, slot_id ASC
                 LIMIT 1
                 FOR UPDATE SKIP LOCKED
             )
             RETURNING third_party_user_id`,
            [visitorId]
        );

        await client.query("COMMIT");
        return result.rows[0]?.third_party_user_id || null;
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

async function markThirdPartyUserSlotPendingVerify(thirdPartyUserId, visitorId) {
    await pool.query(
        `UPDATE third_party_user_slots
         SET status = 'PENDING_VERIFY',
             current_visitor_id = NULL,
             last_visitor_id = $2,
             last_released_time = NOW(),
             modified_time = NOW()
         WHERE provider = 'innerrange'
           AND third_party_user_id = $1`,
        [thirdPartyUserId, visitorId]
    );
}

async function allocateThirdPartyUserSlot(visitorId, reqLike) {
    const maxVerifyAttempts = 10;

    for (let attempt = 0; attempt < maxVerifyAttempts; attempt += 1) {
        const candidateUserId = await reserveThirdPartyUserSlotForVerify(visitorId);
        if (!candidateUserId) return null;

        const verifyResult = await verifyInnerrangeSlotClean(reqLike, candidateUserId);
        if (verifyResult.clean) {
            await upsertThirdPartyUserSlot(candidateUserId, visitorId, "IN_USE");
            return candidateUserId;
        }

        console.log(`SKIP REUSE SLOT ${candidateUserId}: ${verifyResult.reason}`);
        await markThirdPartyUserSlotPendingVerify(candidateUserId, visitorId);
    }

    return null;
}

async function upsertThirdPartyUserSlot(thirdPartyUserId, visitorId, status = "IN_USE") {
    if (!thirdPartyUserId) return;

    await pool.query(
        `INSERT INTO third_party_user_slots (
            provider,
            third_party_user_id,
            status,
            current_visitor_id,
            last_visitor_id,
            last_assigned_time,
            last_released_time,
            created_time,
            modified_time
        )
        VALUES (
            'innerrange',
            $1,
            $2::text,
            $3::integer,
            $3::integer,
            CASE WHEN $2::text = 'IN_USE' THEN NOW() ELSE NULL END,
            CASE WHEN $2::text IN ('AVAILABLE', 'PENDING_VERIFY') THEN NOW() ELSE NULL END,
            NOW(),
            NOW()
        )
        ON CONFLICT (provider, third_party_user_id)
        DO UPDATE SET
            status = EXCLUDED.status,
            current_visitor_id = EXCLUDED.current_visitor_id,
            last_visitor_id = EXCLUDED.last_visitor_id,
            last_assigned_time = CASE WHEN EXCLUDED.status = 'IN_USE' THEN NOW() ELSE third_party_user_slots.last_assigned_time END,
            last_released_time = CASE WHEN EXCLUDED.status IN ('AVAILABLE', 'PENDING_VERIFY') THEN NOW() ELSE third_party_user_slots.last_released_time END,
            modified_time = NOW()`,
        [thirdPartyUserId, status, visitorId]
    );
}

async function releaseThirdPartyUserSlot(thirdPartyUserId, visitorId) {
    if (!thirdPartyUserId) return;

    const client = await pool.connect();
    try {
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('innerrange_slot_allocation'))");

        const existing = await client.query(
            `SELECT status, current_visitor_id
             FROM third_party_user_slots
             WHERE provider = 'innerrange'
               AND third_party_user_id = $1
             FOR UPDATE`,
            [thirdPartyUserId]
        );

        if (existing.rows.length > 0) {
            const currentVisitorId = existing.rows[0].current_visitor_id;
            const isHeldByAnotherVisitor = existing.rows[0].status === "IN_USE"
                && currentVisitorId
                && Number(currentVisitorId) !== Number(visitorId);

            if (isHeldByAnotherVisitor) {
                console.log(`SKIP RELEASE SLOT ${thirdPartyUserId}: held by visitor ${currentVisitorId}, not ${visitorId}`);
                await client.query("COMMIT");
                return;
            }
        }

        await client.query(
            `INSERT INTO third_party_user_slots (
                provider,
                third_party_user_id,
                status,
                current_visitor_id,
                last_visitor_id,
                last_released_time,
                created_time,
                modified_time
            )
            VALUES ('innerrange', $1, 'PENDING_VERIFY', NULL, $2, NOW(), NOW(), NOW())
            ON CONFLICT (provider, third_party_user_id)
            DO UPDATE SET
                status = 'PENDING_VERIFY',
                current_visitor_id = NULL,
                last_visitor_id = $2,
                last_released_time = NOW(),
                modified_time = NOW()`,
            [thirdPartyUserId, visitorId]
        );

        await client.query("COMMIT");
    } catch (error) {
        await client.query("ROLLBACK").catch(() => {});
        throw error;
    } finally {
        client.release();
    }
}

function hasProviderSuccess(apiResults, providerType) {
    return (apiResults || []).some(item =>
        String(item.provider_type || "").toUpperCase() === String(providerType || "").toUpperCase()
        && item.success === true
    );
}

function hasProviderResult(apiResults, providerType) {
    return (apiResults || []).some(item =>
        String(item.provider_type || "").toUpperCase() === String(providerType || "").toUpperCase()
    );
}

function shouldReleaseInnerrangeSlot(apiResults) {
    return !hasProviderResult(apiResults, "INNERRANGE") || hasProviderSuccess(apiResults, "INNERRANGE");
}

function getVisitorDisplayName(visitor) {
    return `${visitor?.first_name || ""} ${visitor?.second_name || ""}`.trim() || "Visitor";
}

async function generateSchindlerPersonId() {
    for (let attempt = 0; attempt < 10; attempt += 1) {
        const personId = crypto.randomUUID().replace(/-/g, "").toUpperCase();
        const existing = await pool.query(
            "SELECT 1 FROM visitor_registration WHERE schindler_person_id = $1 LIMIT 1",
            [personId]
        );
        if (existing.rows.length === 0) return personId;
    }

    throw new Error("Gagal generate Schindler Person ID unik.");
}

async function getAutoCheckoutSettings() {
    await ensureVisitorSchema();
    const result = await pool.query("SELECT * FROM auto_checkout_settings WHERE setting_id = 1");
    return result.rows[0] || {};
}

function shouldRunAutoCheckout(settings) {
    const now = new Date();
    const todayKey = localDateKey(now);
    const scheduleDateKey = normalizeDate(settings.schedule_date);
    const currentTime = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
    const lastRunKey = settings.last_run_at ? localDateKey(new Date(settings.last_run_at)) : "";
    return settings.enabled === true
        && todayKey >= scheduleDateKey
        && currentTime >= normalizeTime(settings.schedule_time)
        && lastRunKey !== todayKey;
}

function addAutoCheckoutScheduleInterval(dateValue, scheduleType) {
    const date = new Date(`${normalizeDate(dateValue)}T00:00:00`);
    if (scheduleType === "MONTHLY") date.setMonth(date.getMonth() + 1);
    else if (scheduleType === "YEARLY") date.setFullYear(date.getFullYear() + 1);
    else date.setDate(date.getDate() + 1);
    return localDateKey(date);
}

async function advanceAutoCheckoutSchedule(settings) {
    const scheduleType = normalizeScheduleType(settings.schedule_type);
    if (scheduleType === "ONCE") {
        await pool.query("UPDATE auto_checkout_settings SET enabled = FALSE, last_run_at = NOW(), updated_at = NOW() WHERE setting_id = 1");
        return;
    }

    const nextDate = addAutoCheckoutScheduleInterval(settings.schedule_date, scheduleType);
    await pool.query(
        "UPDATE auto_checkout_settings SET schedule_date = $1, last_run_at = NOW(), updated_at = NOW() WHERE setting_id = 1",
        [nextDate]
    );
}

async function checkoutVisitorRecord(visitor, reqLike, sourceLabel) {
    const result = await pool.query(
        `UPDATE visitor_registration
         SET check_out_time = NOW(),
             modified_by = $2,
             modified_time = NOW()
         WHERE visitor_id = $1
           AND check_out_time IS NULL
         RETURNING *`,
        [visitor.visitor_id, getCurrentUsername(reqLike)]
    );

    if (result.rows.length === 0) {
        return { success: false, visitor_id: visitor.visitor_id, message: "Visitor sudah check-out atau tidak ditemukan." };
    }

    const checkedOutVisitor = result.rows[0];
    await saveActivityLog(
        reqLike,
        sourceLabel === "AUTO_CHECKOUT" ? "AUTO_CHECK_OUT_VISITOR" : "CHECK_OUT_VISITOR",
        `${sourceLabel === "AUTO_CHECKOUT" ? "Auto check out" : "Check out"} visitor ${getVisitorDisplayName(checkedOutVisitor)} (Visitor ID ${checkedOutVisitor.visitor_id}, Card ${checkedOutVisitor.card_number || "-"})`
    );

    let apiResults = [];
    if (await isVisitorRegistrationApiMode()) {
        try {
            apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKOUT", checkedOutVisitor);
        } catch (apiError) {
            console.log("THIRD PARTY AUTO CHECKOUT API ERROR:", apiError.message);
        }
    }

    if (shouldReleaseInnerrangeSlot(apiResults)) {
        await releaseThirdPartyUserSlot(checkedOutVisitor.third_party_user_id, checkedOutVisitor.visitor_id);
    }

    runBackgroundTask(`DEVICE CHECKOUT VISITOR ${checkedOutVisitor.visitor_id || "-"}`, () =>
        runDeviceSyncBackground(reqLike, checkedOutVisitor, "CHECKOUT")
    );

    return { success: true, visitor_id: checkedOutVisitor.visitor_id, api_results: apiResults };
}

async function runAutoCheckout(createdBy = "AUTO_CHECKOUT", ipAddress = "127.0.0.1") {
    if (autoCheckoutRunning) {
        throw new Error("Auto Check-Out sedang berjalan. Tunggu proses sebelumnya selesai.");
    }

    autoCheckoutRunning = true;
    const reqLike = {
        session: { user: { username: createdBy, full_name: createdBy } },
        ip: ipAddress
    };

    try {
        await ensureVisitorSchema();
        const activeVisitors = await pool.query(`
            SELECT *
            FROM visitor_registration
            WHERE check_out_time IS NULL
            ORDER BY check_in_time ASC, visitor_id ASC
        `);

        const results = [];
        for (const visitor of activeVisitors.rows) {
            results.push(await checkoutVisitorRecord(visitor, reqLike, "AUTO_CHECKOUT"));
        }

        await saveActivityLog(
            reqLike,
            "AUTO_CHECKOUT_RUN",
            `Auto Check-Out selesai. ${results.filter(item => item.success).length} dari ${activeVisitors.rows.length} visitor aktif berhasil di-checkout.`
        );

        return {
            total_active: activeVisitors.rows.length,
            checked_out: results.filter(item => item.success).length,
            failed: results.filter(item => !item.success).length,
            results
        };
    } finally {
        autoCheckoutRunning = false;
    }
}

async function runAutoCheckoutSchedulerTick() {
    try {
        const settings = await getAutoCheckoutSettings();
        if (!shouldRunAutoCheckout(settings)) return;

        runAutoCheckout("AUTO_CHECKOUT_SCHEDULER")
            .then(() => advanceAutoCheckoutSchedule(settings))
            .catch(error => console.log("AUTO CHECKOUT SCHEDULER ERROR:", error.message));
    } catch (error) {
        console.log("AUTO CHECKOUT SCHEDULER TICK ERROR:", error.message);
    }
}

function startAutoCheckoutScheduler() {
    if (autoCheckoutSchedulerStarted) return;
    autoCheckoutSchedulerStarted = true;
    setInterval(runAutoCheckoutSchedulerTick, 60 * 1000);
    setTimeout(runAutoCheckoutSchedulerTick, 5000);
}

function createBackgroundReq(req) {
    return {
        session: req.session,
        ip: req.ip,
        headers: req.headers,
        socket: req.socket
    };
}

function runBackgroundTask(label, task) {
    setImmediate(() => {
        Promise.resolve()
            .then(task)
            .catch(error => console.log(`${label} ERROR:`, error.message));
    });
}

async function runCheckinApiBackground(reqLike, visitor) {
    if (!(await isVisitorRegistrationApiMode())) {
        return;
    }

    const username = getCurrentUsername(reqLike);
    const workingVisitor = { ...(visitor || {}) };
    let reusableThirdPartyUserId = null;

    try {
        const skipThirdPartyReuse = parseLooseBoolean(
            workingVisitor.skip_third_party_reuse ||
            workingVisitor.force_new_third_party_user ||
            workingVisitor.disable_third_party_reuse
        );
        const hasInnerrangeCheckin = skipThirdPartyReuse
            ? false
            : await hasActiveThirdPartyProvider("CHECKIN", "INNERRANGE");
        reusableThirdPartyUserId = hasInnerrangeCheckin
            ? await allocateThirdPartyUserSlot(workingVisitor.visitor_id, reqLike)
            : null;

        if (reusableThirdPartyUserId) {
            workingVisitor.third_party_user_id = reusableThirdPartyUserId;
            workingVisitor.innerrange_user_id = reusableThirdPartyUserId;
            workingVisitor.reuse_third_party_user_id = true;
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = $1,
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE visitor_id = $3`,
                [reusableThirdPartyUserId, username, workingVisitor.visitor_id]
            );
        }

        const apiResults = await executeActiveThirdPartyConfigs(reqLike, "CHECKIN", workingVisitor);
        const successResult = apiResults.find(item => item.success && String(item.provider_type || "").toUpperCase() === "INNERRANGE");
        const referenceResult = apiResults.find(item => item.success && item.reference_id && String(item.provider_type || "").toUpperCase() === "INNERRANGE");

        if (referenceResult?.reference_id) {
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = $1,
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE visitor_id = $3`,
                [referenceResult.reference_id, username, workingVisitor.visitor_id]
            );
            await upsertThirdPartyUserSlot(referenceResult.reference_id, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId && successResult) {
            await upsertThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id, "IN_USE");
        } else if (reusableThirdPartyUserId) {
            await releaseThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id);
            await pool.query(
                `UPDATE visitor_registration
                 SET third_party_user_id = NULL,
                     modified_by = $1,
                     modified_time = NOW()
                 WHERE visitor_id = $2`,
                [username, workingVisitor.visitor_id]
            );
        }
    } catch (apiError) {
        console.log("THIRD PARTY CHECK-IN API BACKGROUND ERROR:", apiError.message);
        if (reusableThirdPartyUserId) {
            await releaseThirdPartyUserSlot(reusableThirdPartyUserId, workingVisitor.visitor_id);
        }
    }
}

async function runDeviceSyncBackground(reqLike, visitor, action) {
    try {
        await executeDeviceSyncForVisitor(visitor, action, reqLike);
    } catch (error) {
        console.log(`DEVICE SYNC ${action} ERROR:`, error.message);
    }
}

function runCheckinFollowupBackground(req, visitor) {
    const reqLike = createBackgroundReq(req);
    const visitorSnapshot = { ...(visitor || {}) };
    runBackgroundTask(`CHECKIN FOLLOWUP VISITOR ${visitorSnapshot.visitor_id || "-"}`, async () => {
        await Promise.allSettled([
            sendHostCheckinEmail(reqLike, visitorSnapshot),
            sendVisitorCheckinQrEmail(reqLike, visitorSnapshot),
            runCheckinApiBackground(reqLike, visitorSnapshot),
            runDeviceSyncBackground(reqLike, visitorSnapshot, "CHECKIN")
        ]);
    });
}

const VISITOR_SCHEMA_PATHS = [
    "/register-visitor",
    "/visitors",
    "/api/public/qr-info",
    "/api/public/self-registration",
    "/api/permission-groups",
    "/api/visitor-history",
    "/api/floors",
    "/api/invitations",
    "/api/hosts",
    "/api/host-notification-settings",
    "/api/qr-settings",
    "/api/smtp-settings",
    "/api/send-qr-email",
    "/api/whatsapp-settings",
    "/api/send-qr-whatsapp",
    "/api/whatsapp-opened",
    "/api/auto-checkout-settings",
    "/api/auto-checkout",
    "/api/visitor-log-filter-options",
    "/api/visitor-logs",
    "/api/visitor-stats",
    "/api/visitor-analytics",
    "/api/visitor-watchlist",
    "/api/visitor-watchlist-settings",
    "/sync-acs",
    "/sync-lift",
    "/export-excel",
    "/card-reader"
];

router.use(VISITOR_SCHEMA_PATHS, async (req, res, next) => {
    try {
        await ensureVisitorSchema();
        next();
    } catch (error) {
        next(error);
    }
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, "uploads/"),
    filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage: storage });

router.get("/api/visitor-watchlist-settings", async (req, res) => {
    try {
        const settings = await getWatchlistSettings();
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/visitor-watchlist-settings", async (req, res) => {
    try {
        const mode = normalizeWatchlistMode(req.body.blacklist_mode);
        const notifySecurity = req.body.notify_security !== false;
        const result = await pool.query(
            `INSERT INTO visitor_watchlist_settings (setting_id, blacklist_mode, notify_security, updated_by, updated_at)
             VALUES (1, $1, $2, $3, NOW())
             ON CONFLICT (setting_id) DO UPDATE
             SET blacklist_mode = EXCLUDED.blacklist_mode,
                 notify_security = EXCLUDED.notify_security,
                 updated_by = EXCLUDED.updated_by,
                 updated_at = NOW()
             RETURNING *`,
            [mode, notifySecurity, getCurrentUsername(req)]
        );
        await saveActivityLog(req, "UPDATE_VISITOR_WATCHLIST_SETTING", `Update visitor watchlist mode to ${mode}`);
        res.json({ success: true, message: "Setting watchlist berhasil disimpan.", data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/visitor-watchlist", async (req, res) => {
    try {
        const type = String(req.query.type || "").trim().toUpperCase();
        const search = String(req.query.search || "").trim();
        const params = [];
        const filters = [];

        if (["BLACKLIST", "WHITELIST"].includes(type)) {
            params.push(type);
            filters.push(`list_type = $${params.length}`);
        }
        if (search) {
            params.push(`%${search.toLowerCase()}%`);
            filters.push(`(
                LOWER(COALESCE(visitor_name, '')) LIKE $${params.length}
                OR LOWER(COALESCE(identity_number, '')) LIKE $${params.length}
                OR LOWER(COALESCE(phone_number, '')) LIKE $${params.length}
                OR LOWER(COALESCE(email_address, '')) LIKE $${params.length}
                OR LOWER(COALESCE(company_name, '')) LIKE $${params.length}
            )`);
        }

        const where = filters.length ? `WHERE ${filters.join(" AND ")}` : "";
        const result = await pool.query(
            `SELECT *
             FROM visitor_watchlist
             ${where}
             ORDER BY is_active DESC,
                      CASE list_type WHEN 'BLACKLIST' THEN 0 ELSE 1 END,
                      watchlist_id DESC`,
            params
        );
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/visitor-watchlist", async (req, res) => {
    try {
        const listType = normalizeWatchlistType(req.body.list_type);
        const visitorName = String(req.body.visitor_name || "").trim();
        const identityNumber = String(req.body.identity_number || "").trim();
        const phoneNumber = String(req.body.phone_number || "").trim();
        const emailAddress = String(req.body.email_address || "").trim();

        if (!visitorName && !identityNumber && !phoneNumber && !emailAddress) {
            return res.status(400).json({ success: false, message: "Isi minimal nama, ID Number, phone, atau email." });
        }

        const result = await pool.query(
            `INSERT INTO visitor_watchlist (
                list_type, visitor_name, identity_number, phone_number, email_address,
                company_name, reason, start_date, expiry_date, is_active, created_by, created_time
             )
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
             RETURNING *`,
            [
                listType,
                visitorName || null,
                identityNumber || null,
                phoneNumber || null,
                emailAddress || null,
                String(req.body.company_name || "").trim() || null,
                String(req.body.reason || "").trim() || null,
                req.body.start_date || null,
                req.body.expiry_date || null,
                req.body.is_active !== false,
                getCurrentUsername(req)
            ]
        );
        await saveActivityLog(req, `ADD_${listType}_VISITOR`, `Add ${listType.toLowerCase()} visitor ${visitorName || identityNumber || emailAddress || phoneNumber}`);
        res.json({ success: true, message: `${listType} visitor berhasil disimpan.`, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/api/visitor-watchlist/:id", async (req, res) => {
    try {
        const listType = normalizeWatchlistType(req.body.list_type);
        const result = await pool.query(
            `UPDATE visitor_watchlist
             SET list_type = $1,
                 visitor_name = $2,
                 identity_number = $3,
                 phone_number = $4,
                 email_address = $5,
                 company_name = $6,
                 reason = $7,
                 start_date = $8,
                 expiry_date = $9,
                 is_active = $10,
                 modified_by = $11,
                 modified_time = NOW()
             WHERE watchlist_id = $12
             RETURNING *`,
            [
                listType,
                String(req.body.visitor_name || "").trim() || null,
                String(req.body.identity_number || "").trim() || null,
                String(req.body.phone_number || "").trim() || null,
                String(req.body.email_address || "").trim() || null,
                String(req.body.company_name || "").trim() || null,
                String(req.body.reason || "").trim() || null,
                req.body.start_date || null,
                req.body.expiry_date || null,
                req.body.is_active !== false,
                getCurrentUsername(req),
                req.params.id
            ]
        );
        if (!result.rows.length) return res.status(404).json({ success: false, message: "Data watchlist tidak ditemukan." });
        await saveActivityLog(req, `EDIT_${listType}_VISITOR`, `Edit ${listType.toLowerCase()} visitor ${result.rows[0].visitor_name || result.rows[0].identity_number || "-"}`);
        res.json({ success: true, message: "Watchlist berhasil diupdate.", data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.delete("/api/visitor-watchlist/:id", async (req, res) => {
    try {
        const current = await pool.query("SELECT * FROM visitor_watchlist WHERE watchlist_id = $1", [req.params.id]);
        if (!current.rows.length) return res.status(404).json({ success: false, message: "Data watchlist tidak ditemukan." });
        await pool.query("DELETE FROM visitor_watchlist WHERE watchlist_id = $1", [req.params.id]);
        await saveActivityLog(req, `DELETE_${current.rows[0].list_type}_VISITOR`, `Delete ${String(current.rows[0].list_type || "").toLowerCase()} visitor ${current.rows[0].visitor_name || current.rows[0].identity_number || "-"}`);
        res.json({ success: true, message: "Watchlist berhasil dihapus." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/visitor-watchlist/check", async (req, res) => {
    try {
        const matches = await findVisitorWatchlistMatches(req.query);
        const settings = await getWatchlistSettings();
        const decision = summarizeWatchlistDecision(matches, settings);
        res.json({ success: true, data: decision });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Register Visitor
router.post("/register-visitor", upload.fields([{ name: "visitor_photo", maxCount: 1 }, { name: "identity_photo", maxCount: 1 }]), async (req, res) => {
    try {
        let visitorPhoto = req.files["visitor_photo"] ? req.files["visitor_photo"][0].filename : null;
        let identityPhoto = req.files["identity_photo"] ? req.files["identity_photo"][0].filename : null;
        const { first_name, second_name, identity_number, identity_type, company_name, email_address, card_number, permission_group, purpose_note, start_date, expiry_date, host } = req.body;
        const skipThirdPartyReuse = parseLooseBoolean(
            req.body.skip_third_party_reuse ||
            req.body.force_new_third_party_user ||
            req.body.disable_third_party_reuse
        );
        const bookingCode = normalizeBookingCode(req.body.booking_code);
        const phone_number = req.body.phone_number || req.body.telephone_number || null;
        const username = getCurrentUsername(req);
        const schindlerPersonId = await generateSchindlerPersonId();

        let bookingInvitation = null;
        if (bookingCode) {
            const validation = await validatePendingInvitationByCode(bookingCode);
            if (!validation.ok) {
                return res.status(validation.status).json({ success: false, message: validation.message });
            }
            bookingInvitation = validation.invitation;
            visitorPhoto = visitorPhoto || bookingInvitation.visitor_photo || null;
            identityPhoto = identityPhoto || bookingInvitation.identity_photo || null;
        }

        const watchlistSettings = await getWatchlistSettings();
        const watchlistMatches = await findVisitorWatchlistMatches({
            first_name,
            second_name,
            identity_number,
            email_address,
            phone_number
        });
        const watchlistDecision = summarizeWatchlistDecision(watchlistMatches, watchlistSettings);

        const requiresSuperadminApproval = watchlistDecision.require_approval &&
            String(req.session?.role_name || "").toUpperCase() !== "SUPERADMIN";

        if (watchlistDecision.blocked || requiresSuperadminApproval) {
            const primary = watchlistDecision.primary || {};
            await saveActivityLog(
                req,
                requiresSuperadminApproval ? "BLACKLIST_CHECKIN_NEED_APPROVAL" : "BLACKLIST_CHECKIN_BLOCKED",
                `${requiresSuperadminApproval ? "Need superadmin approval for" : "Blocked"} blacklist visitor ${first_name || ""} ${second_name || ""} (ID ${identity_number || "-"}). Reason: ${primary.reason || "-"}`
            );
            if (watchlistSettings.notify_security !== false) {
                await createSystemNotification(req, {
                    channel: "VISITOR_WATCHLIST",
                    event_type: "CHECKIN",
                    status: "FAILED",
                    visitor_name: `${first_name || ""} ${second_name || ""}`.trim(),
                    target: identity_number || null,
                    title: requiresSuperadminApproval ? "Blacklist Visitor perlu approval" : "Blacklist Visitor diblokir",
                    message: `Visitor ${`${first_name || ""} ${second_name || ""}`.trim() || identity_number || "-"} masuk blacklist. ${primary.reason || ""}`.trim(),
                    detail: { identity_number, watchlist_id: primary.watchlist_id || null, mode: watchlistDecision.mode }
                });
            }
            return res.status(403).json({
                success: false,
                watchlist: watchlistDecision,
                message: requiresSuperadminApproval
                    ? "Visitor masuk Blacklist. Check-In perlu approval SUPERADMIN."
                    : "Visitor masuk Blacklist. Check-In diblokir sesuai setting."
            });
        }
        
        const qrData = JSON.stringify({ first_name, second_name, company_name, host, card_number, start_date, expiry_date });
        const qrCode = await QRCode.toDataURL(qrData);
        
        const result = await pool.query(
            `INSERT INTO visitor_registration (
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note,
            visitor_photo,
            identity_photo,
            qr_code,
            start_date,
            expiry_date,
            schindler_person_id,
            watchlist_status,
            watchlist_entry_id,
            watchlist_note,
            created_by,
            created_time,
            check_in_time
            )
            VALUES (
            $1, $2, $3, $4, $5,
            $6, $7, $8, $9, $10,
            $11, $12, $13, $14, $15,
            $16, $17, $18, $19, $20, $21,
            NOW(),
            NOW()
            )
            RETURNING *`,
            [
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note,
            visitorPhoto,
            identityPhoto,
            qrCode,
            start_date || null,
            expiry_date || null,
            schindlerPersonId,
            watchlistDecision.status,
            watchlistDecision.primary?.watchlist_id || null,
            watchlistDecision.primary?.reason || null,
            username
            ]
            );
            
        await saveActivityLog(
            req,
            "CHECK_IN_VISITOR",
            `Check in visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );

        if (watchlistDecision.status === "BLACKLIST") {
            await saveActivityLog(
                req,
                "BLACKLIST_VISITOR_CHECKIN_WARNING",
                `Blacklist visitor check-in warning ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, ID Number ${identity_number || "-"})`
            );
            if (watchlistSettings.notify_security !== false) {
                await createSystemNotification(req, {
                    channel: "VISITOR_WATCHLIST",
                    event_type: "CHECKIN",
                    status: "FAILED",
                    visitor_id: result.rows[0].visitor_id,
                    visitor_name: getVisitorDisplayName(result.rows[0]),
                    target: identity_number || null,
                    title: "Warning Blacklist Visitor",
                    message: `${getVisitorDisplayName(result.rows[0])} masuk blacklist. ${watchlistDecision.primary?.reason || ""}`.trim(),
                    detail: {
                        identity_number,
                        watchlist_id: watchlistDecision.primary?.watchlist_id || null,
                        mode: watchlistDecision.mode,
                        matches: watchlistDecision.matches?.map(item => ({ id: item.watchlist_id, type: item.list_type, match_types: item.match_types })) || []
                    }
                });
            }
        }

        if (bookingInvitation) {
            await pool.query(
                `UPDATE visitor_invitations
                 SET status = 'CHECKED_IN',
                     checked_in_visitor_id = $1,
                     checked_in_time = NOW(),
                     modified_by = $2,
                     modified_time = NOW()
                 WHERE invitation_id = $3`,
                [result.rows[0].visitor_id, username, bookingInvitation.invitation_id]
            );
            await saveActivityLog(
                req,
                "USE_BOOKING_CODE",
                `Use booking code ${bookingCode} for visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id})`
            );
        }

        runCheckinFollowupBackground(req, {
            ...result.rows[0],
            skip_third_party_reuse: skipThirdPartyReuse,
            force_new_third_party_user: skipThirdPartyReuse
        });

        res.json({
            success: true,
            message: "Visitor registered",
            data: result.rows[0],
            watchlist: watchlistDecision,
            api_results: [],
            background_processing: true
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Search Visitor by ID
router.get("/visitors/search", async (req, res) => {
    try {
        const { id } = req.query;
        const result = await pool.query("SELECT * FROM visitor_registration WHERE identity_number = $1 ORDER BY visitor_id DESC LIMIT 1", [id]);
        res.json(result.rows.length > 0 ? { found: true, ...result.rows[0] } : { found: false });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/api/public/returning-visitor", async (req, res) => {
    try {
        const identityNumber = String(req.query.id || req.query.identity_number || "").trim();
        if (!identityNumber) {
            return res.status(400).json({ success: false, message: "ID Number wajib diisi." });
        }

        const result = await pool.query(
            `SELECT
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number,
                visitor_photo,
                identity_photo
             FROM visitor_registration
             WHERE identity_number = $1
             ORDER BY visitor_id DESC
             LIMIT 1`,
            [identityNumber]
        );

        if (!result.rows.length) {
            return res.json({ success: true, found: false });
        }

        const row = result.rows[0];
        res.json({
            success: true,
            found: true,
            data: {
                first_name: row.first_name || "",
                second_name: row.second_name || "",
                identity_number: row.identity_number || "",
                identity_type: row.identity_type || "",
                company_name: row.company_name || "",
                email_address: row.email_address || "",
                phone_number: row.phone_number || "",
                visitor_photo: safeUploadFilename(row.visitor_photo),
                identity_photo: safeUploadFilename(row.identity_photo)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/public/qr-info", async (req, res) => {
    try {
        const cardNumber = String(req.query.card_number || "").trim();

        if (!cardNumber) {
            return res.status(400).json({ success: false, message: "Card number wajib diisi" });
        }

        const result = await pool.query(
            `SELECT first_name,
                    second_name,
                    company_name,
                    host,
                    permission_group,
                    purpose_note,
                    start_date,
                    expiry_date,
                    card_number
             FROM visitor_registration
             WHERE card_number = $1
             ORDER BY visitor_id DESC
             LIMIT 1`,
            [cardNumber]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "QR visitor tidak ditemukan" });
        }

        const settings = await pool.query("SELECT preview_title, preview_subtitle, show_card_number FROM qr_settings WHERE setting_id = 1");

        res.json({
            success: true,
            data: result.rows[0],
            settings: settings.rows[0] || {}
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/permission-groups", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT pg.group_id,
                   pg.group_name,
                   pg.integration_id,
                   pg.floor_id,
                   sf.floor_name,
                   sf.destination_code AS schindler_destination_floor_code,
                   sf.return_code AS schindler_return_floor_code,
                   CASE
                       WHEN sf.destination_code IS NOT NULL
                       THEN CONCAT('specific,', sf.destination_code, ',', sf.return_code)
                       ELSE ''
                   END AS schindler_auto_zone,
                   CASE
                       WHEN sf.destination_code IS NOT NULL
                       THEN CONCAT(sf.return_code, ',', sf.destination_code)
                       ELSE ''
                   END AS schindler_access_zones_always,
                   pg.description,
                   pg.created_at,
                   COALESCE(
                       ARRAY_REMOVE(ARRAY_AGG(DISTINCT d.device_id), NULL),
                       ARRAY[]::integer[]
                   ) AS device_ids,
                   COALESCE(
                       STRING_AGG(DISTINCT d.device_name, ', '),
                       ''
                   ) AS device_names
            FROM permission_groups pg
            LEFT JOIN schindler_floors sf ON sf.floor_id = pg.floor_id
            LEFT JOIN permission_group_devices pgd ON pgd.group_id = pg.group_id
            LEFT JOIN devices d ON d.device_id = pgd.device_id
            GROUP BY pg.group_id, sf.floor_id
            ORDER BY pg.group_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/visitors/:id", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-history", async (req, res) => {
    try {
        const identityNumber = String(req.query.identity_number || "").trim();

        if (!identityNumber) {
            return res.status(400).json({ success: false, message: "Identity number wajib diisi" });
        }

        const result = await pool.query(
            `SELECT visitor_id,
                    first_name,
                    second_name,
                    identity_number,
                    company_name,
                    host,
                    permission_group,
                    purpose_note,
                    check_in_time,
                    check_out_time,
                    created_by
             FROM visitor_registration
             WHERE identity_number = $1
             ORDER BY check_in_time ASC NULLS LAST, visitor_id ASC`,
            [identityNumber]
        );

        res.json({
            success: true,
            data: {
                total_visits: result.rows.length,
                visits: result.rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/visitors/:id/check-integration", async (req, res) => {
    try {
        const provider = String(req.body.provider || "").trim().toUpperCase();
        const configId = req.body.config_id ? Number(req.body.config_id) : null;
        const triggerMap = {
            INNERRANGE: "CHECK_INNERRANGE",
            SCHINDLER: "CHECK_SCHINDLER"
        };
        const triggerEvent = triggerMap[provider];

        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Provider check tidak valid" });
        }

        const visitor = await pool.query("SELECT * FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);
        if (visitor.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        const apiResults = await executeActiveThirdPartyConfigs(req, triggerEvent, visitor.rows[0], {
            providerType: provider,
            configId
        });
        const providerResults = apiResults.filter(item => String(item.provider_type || "").toUpperCase() === provider);

        if (providerResults.length === 0) {
            return res.status(400).json({
                success: false,
                message: `API check ${provider} belum dibuat/aktif. Buat setting API dengan mode ${triggerEvent}.`
            });
        }

        const ok = providerResults.some(item => item.success === true);

        res.json({
            success: ok,
            message: ok ? `Check ${provider} berhasil.` : `Check ${provider} gagal. Cek Log Activity API.`,
            data: providerResults,
            api_results: apiResults
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/visitors/:id/check-integration-configs", async (req, res) => {
    try {
        const provider = String(req.query.provider || "").trim().toUpperCase();
        const triggerMap = {
            INNERRANGE: "CHECK_INNERRANGE",
            SCHINDLER: "CHECK_SCHINDLER"
        };
        const triggerEvent = triggerMap[provider];

        if (!triggerEvent) {
            return res.status(400).json({ success: false, message: "Provider check tidak valid" });
        }

        const result = await pool.query(
            `SELECT config_id,
                    config_name,
                    provider_type,
                    trigger_event,
                    action_type,
                    execution_order
             FROM third_party_api_configs
             WHERE is_active = TRUE
               AND provider_type = $1
               AND trigger_event = $2
             ORDER BY execution_order ASC, config_id ASC`,
            [provider, triggerEvent]
        );

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.put("/visitors/:id", async (req, res) => {
    try {
        const {
            first_name,
            second_name,
            identity_number,
            identity_type,
            company_name,
            email_address,
            telephone_number,
            phone_number,
            host,
            card_number,
            permission_group,
            purpose_note
        } = req.body;

        const result = await pool.query(
            `UPDATE visitor_registration
             SET first_name = $1,
                 second_name = $2,
                 identity_number = $3,
                 identity_type = $4,
                 company_name = $5,
                 email_address = $6,
                 phone_number = $7,
                 host = $8,
                 card_number = $9,
                 permission_group = $10,
                 purpose_note = $11,
                 modified_by = $12,
                 modified_time = NOW()
             WHERE visitor_id = $13
             RETURNING *`,
            [
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number || telephone_number || null,
                host,
                card_number,
                permission_group,
                purpose_note,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            "EDIT_VISITOR",
            `Edit visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "EDIT", result.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY EDIT API ERROR:", apiError.message);
            }
        }

        runBackgroundTask(`DEVICE EDIT VISITOR ${result.rows[0].visitor_id || "-"}`, () =>
            runDeviceSyncBackground(createBackgroundReq(req), result.rows[0], "EDIT")
        );

        res.json({ success: true, data: result.rows[0], api_results: apiResults });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/visitors/:id", async (req, res) => {
    try {
        const target = await pool.query(
            "SELECT * FROM visitor_registration WHERE visitor_id = $1",
            [req.params.id]
        );

        if (target.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "DELETE", target.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY DELETE API ERROR:", apiError.message);
            }
        }

        if (shouldReleaseInnerrangeSlot(apiResults)) {
            await releaseThirdPartyUserSlot(target.rows[0].third_party_user_id, target.rows[0].visitor_id);
        }

        runBackgroundTask(`DEVICE DELETE VISITOR ${target.rows[0].visitor_id || "-"}`, () =>
            runDeviceSyncBackground(createBackgroundReq(req), target.rows[0], "DELETE")
        );

        await pool.query("DELETE FROM visitor_registration WHERE visitor_id = $1", [req.params.id]);

        await saveActivityLog(
            req,
            "DELETE_VISITOR",
            `Delete visitor ${getVisitorDisplayName(target.rows[0])} (Visitor ID ${target.rows[0].visitor_id}, Card ${target.rows[0].card_number || "-"})`
        );

        res.json({ success: true, api_results: apiResults });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/permission-groups", async (req, res) => {
    try {
        const groupName = String(req.body.group_name || "").trim();
        const integrationId = String(req.body.integration_id || "").trim();
        const floorId = req.body.floor_id ? Number(req.body.floor_id) : null;
        const description = String(req.body.description || "").trim();
        const deviceIds = normalizeDeviceIds(req.body.device_ids);

        if (!groupName) {
            return res.status(400).json({ success: false, message: "Nama grouping wajib diisi" });
        }

        const result = await pool.query(
            `INSERT INTO permission_groups (group_name, integration_id, floor_id, description)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [groupName, integrationId || null, floorId || null, description || null]
        );

        await syncPermissionGroupDevices(result.rows[0].group_id, deviceIds);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Grouping sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/permission-groups/:id", async (req, res) => {
    try {
        const groupName = String(req.body.group_name || "").trim();
        const integrationId = String(req.body.integration_id || "").trim();
        const floorId = req.body.floor_id ? Number(req.body.floor_id) : null;
        const description = String(req.body.description || "").trim();
        const deviceIds = normalizeDeviceIds(req.body.device_ids);

        if (!groupName) {
            return res.status(400).json({ success: false, message: "Nama grouping wajib diisi" });
        }

        const result = await pool.query(
            `UPDATE permission_groups
             SET group_name = $1,
                 integration_id = $2,
                 floor_id = $3,
                 description = $4
             WHERE group_id = $5
             RETURNING *`,
            [groupName, integrationId || null, floorId || null, description || null, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Grouping tidak ditemukan" });
        }

        await syncPermissionGroupDevices(result.rows[0].group_id, deviceIds);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Grouping sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/permission-groups/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM permission_groups WHERE group_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/floors", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT floor_id,
                   floor_name,
                   destination_code,
                   return_code,
                   CONCAT('specific,', destination_code, ',', return_code) AS schindler_auto_zone,
                   CONCAT(return_code, ',', destination_code) AS schindler_access_zones_always,
                   description,
                   created_at,
                   modified_at
            FROM schindler_floors
            ORDER BY floor_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/floors", async (req, res) => {
    try {
        const floorName = String(req.body.floor_name || "").trim();
        const destinationCode = String(req.body.destination_code || "").trim();
        const returnCode = String(req.body.return_code || "1").trim();
        const description = String(req.body.description || "").trim();

        if (!floorName) return res.status(400).json({ success: false, message: "Nama floor wajib diisi" });
        if (!destinationCode) return res.status(400).json({ success: false, message: "Kode lantai tujuan wajib diisi" });
        if (!returnCode) return res.status(400).json({ success: false, message: "Kode turun/lobby wajib diisi" });

        const result = await pool.query(
            `INSERT INTO schindler_floors (floor_name, destination_code, return_code, description)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [floorName, destinationCode, returnCode, description || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Floor sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/floors/:id", async (req, res) => {
    try {
        const floorName = String(req.body.floor_name || "").trim();
        const destinationCode = String(req.body.destination_code || "").trim();
        const returnCode = String(req.body.return_code || "1").trim();
        const description = String(req.body.description || "").trim();

        if (!floorName) return res.status(400).json({ success: false, message: "Nama floor wajib diisi" });
        if (!destinationCode) return res.status(400).json({ success: false, message: "Kode lantai tujuan wajib diisi" });
        if (!returnCode) return res.status(400).json({ success: false, message: "Kode turun/lobby wajib diisi" });

        const result = await pool.query(
            `UPDATE schindler_floors
             SET floor_name = $1,
                 destination_code = $2,
                 return_code = $3,
                 description = $4,
                 modified_at = NOW()
             WHERE floor_id = $5
             RETURNING *`,
            [floorName, destinationCode, returnCode, description || null, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Floor tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Floor sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.delete("/api/floors/:id", async (req, res) => {
    try {
        const usage = await pool.query("SELECT COUNT(*)::int AS total FROM permission_groups WHERE floor_id = $1", [req.params.id]);
        if ((usage.rows[0]?.total || 0) > 0) {
            return res.status(400).json({ success: false, message: "Floor masih dipakai di Permission Group" });
        }

        await pool.query("DELETE FROM schindler_floors WHERE floor_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/invitations", async (req, res) => {
    try {
        const includeCheckedIn = req.query.include_checked_in === "true";
        const statusFilter = includeCheckedIn ? "" : "WHERE status <> 'CHECKED_IN'";
        const result = await pool.query(`
            SELECT *
            FROM visitor_invitations
            ${statusFilter}
            ORDER BY invitation_id DESC
            LIMIT 500
        `);
        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations", async (req, res) => {
    try {
        const body = req.body || {};
        const firstName = String(body.first_name || "").trim();
        const secondName = String(body.second_name || "").trim();
        const identityNumber = String(body.identity_number || body.id_number || "").trim();
        const identityType = String(body.identity_type || "").trim();
        const email = String(body.email_address || "").trim();
        const phone = String(body.phone_number || body.telephone_number || "").trim();
        const host = String(body.host || "").trim();
        const visitorPhoto = safeUploadFilename(body.visitor_photo || body.existing_visitor_photo);
        const identityPhoto = safeUploadFilename(body.identity_photo || body.existing_identity_photo);

        if (!firstName) return res.status(400).json({ success: false, message: "First name wajib diisi." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib diisi." });
        if (!email && !phone) return res.status(400).json({ success: false, message: "Isi email atau nomor WhatsApp visitor." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const bookingCode = await generateBookingCode();
        const result = await pool.query(
            `INSERT INTO visitor_invitations (
                booking_code,
                status,
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number,
                visitor_photo,
                identity_photo,
                host,
                start_date,
                expiry_date,
                permission_group,
                purpose_note,
                created_by,
                created_time
             )
             VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, NOW())
             RETURNING *`,
            [
                bookingCode,
                firstName,
                secondName || null,
                identityNumber || null,
                identityType || null,
                String(body.company_name || "").trim() || null,
                email || null,
                phone || null,
                visitorPhoto,
                identityPhoto,
                host,
                body.start_date || null,
                body.expiry_date || null,
                String(body.permission_group || "Visitor").trim() || "Visitor",
                String(body.purpose_note || "").trim() || null,
                getCurrentUsername(req)
            ]
        );

        const invitation = result.rows[0];
        let emailWarning = null;
        if (body.send_email === true && invitation.email_address) {
            try {
                await sendBookingInvitationEmail(req, invitation);
            } catch (emailError) {
                emailWarning = emailError.message;
                await createSystemNotification(req, {
                    channel: "EMAIL_VISITOR",
                    event_type: "INVITATION",
                    status: "FAILED",
                    visitor_name: getVisitorDisplayName(invitation),
                    target: invitation.email_address,
                    title: "Email invitation gagal",
                    message: emailError.message,
                    detail: { booking_code: bookingCode }
                });
            }
        }

        await saveActivityLog(
            req,
            "CREATE_VISITOR_INVITATION",
            `Create booking invitation ${bookingCode} for ${getVisitorDisplayName(invitation)}`
        );

        res.json({ success: true, data: invitation, email_warning: emailWarning });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

function normalizeImportHeader(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "");
}

function getImportValue(row, aliases) {
    for (const alias of aliases) {
        const value = row[alias];
        if (value !== undefined && value !== null && String(value).trim() !== "") return value;
    }
    return "";
}

function normalizeExcelDateValue(value) {
    if (!value) return null;
    if (value instanceof Date) return value;
    const text = String(value).trim();
    if (!text) return null;

    const dmyMatch = text.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})(?:[,\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (dmyMatch) {
        const [, day, month, year, hour = "0", minute = "0", second = "0"] = dmyMatch;
        return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }

    const ymdMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (ymdMatch) {
        const [, year, month, day, hour = "0", minute = "0", second = "0"] = ymdMatch;
        return new Date(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
    }

    const date = new Date(text);
    return Number.isNaN(date.getTime()) ? text : date;
}

function isPastDateValue(value) {
    if (!value) return false;
    const date = value instanceof Date ? value : new Date(value);
    return !Number.isNaN(date.getTime()) && date < new Date();
}

async function sendImportedInvitationEmails(reqLike, invitations) {
    const list = Array.isArray(invitations) ? invitations : [];
    for (const invitation of list) {
        if (!invitation?.email_address) {
            await createSystemNotification(reqLike, {
                channel: "EMAIL_VISITOR",
                event_type: "INVITATION_IMPORT",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                title: "Email invitation import gagal",
                message: "Email visitor belum diisi, booking code tidak bisa dikirim otomatis.",
                detail: { booking_code: invitation?.booking_code || null, invitation_id: invitation?.invitation_id || null }
            });
            continue;
        }

        try {
            await sendBookingInvitationEmail(reqLike, invitation);
        } catch (emailError) {
            await createSystemNotification(reqLike, {
                channel: "EMAIL_VISITOR",
                event_type: "INVITATION_IMPORT",
                status: "FAILED",
                visitor_name: getVisitorDisplayName(invitation),
                target: invitation.email_address,
                title: "Email invitation import gagal",
                message: emailError.message,
                detail: { booking_code: invitation.booking_code, invitation_id: invitation.invitation_id }
            });
        }
    }
}

router.get("/api/invitations/template", async (req, res) => {
    try {
        const workbook = new ExcelJS.Workbook();
        workbook.creator = "Innersync";
        workbook.created = new Date();
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const sampleStart = `${tomorrow.getFullYear()}-${pad2(tomorrow.getMonth() + 1)}-${pad2(tomorrow.getDate())} 09:00`;
        const sampleExpiry = `${tomorrow.getFullYear()}-${pad2(tomorrow.getMonth() + 1)}-${pad2(tomorrow.getDate())} 17:00`;

        const worksheet = workbook.addWorksheet("Invitation Template");
        worksheet.columns = [
            { header: "First Name", key: "first_name", width: 18 },
            { header: "Second Name", key: "second_name", width: 18 },
            { header: "ID Number", key: "identity_number", width: 20 },
            { header: "Identity Type", key: "identity_type", width: 16 },
            { header: "Company", key: "company", width: 24 },
            { header: "Email", key: "email", width: 28 },
            { header: "Phone", key: "phone", width: 18 },
            { header: "Host", key: "host", width: 24 },
            { header: "Start Date", key: "start_date", width: 22 },
            { header: "Expiry Date", key: "expiry_date", width: 22 },
            { header: "Grouping", key: "grouping", width: 18 },
            { header: "Keperluan", key: "keperluan", width: 32 }
        ];

        worksheet.getRow(1).eachCell((cell) => {
            cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
            cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1677FF" } };
            cell.alignment = { vertical: "middle", horizontal: "center" };
            cell.border = {
                top: { style: "thin", color: { argb: "FFD1D5DB" } },
                left: { style: "thin", color: { argb: "FFD1D5DB" } },
                bottom: { style: "thin", color: { argb: "FFD1D5DB" } },
                right: { style: "thin", color: { argb: "FFD1D5DB" } }
            };
        });
        worksheet.getRow(1).height = 24;

        worksheet.addRow({
            first_name: "Budi",
            second_name: "Santoso",
            identity_number: "317xxxxxxxxxxxxx",
            identity_type: "E-KTP",
            company: "PT Contoh",
            email: "budi@example.com",
            phone: "081234567890",
            host: "PT EPCON MULTI GUNA",
            start_date: sampleStart,
            expiry_date: sampleExpiry,
            grouping: "Visitor",
            keperluan: "Meeting"
        });

        worksheet.views = [{ state: "frozen", ySplit: 1 }];
        worksheet.autoFilter = "A1:L1";
        worksheet.getColumn("start_date").numFmt = "yyyy-mm-dd hh:mm";
        worksheet.getColumn("expiry_date").numFmt = "yyyy-mm-dd hh:mm";

        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", "attachment; filename=\"invitation_import_template.xlsx\"");
        await workbook.xlsx.write(res);
        res.end();
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/import", upload.single("invitation_file"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "Pilih file Excel terlebih dahulu." });
        }

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(req.file.path);
        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
            return res.status(400).json({ success: false, message: "Sheet Excel tidak ditemukan." });
        }

        const headerRow = worksheet.getRow(1);
        const headers = {};
        headerRow.eachCell((cell, colNumber) => {
            const key = normalizeImportHeader(cell.value?.text || cell.value);
            if (key) headers[colNumber] = key;
        });

        const imported = [];
        const errors = [];

        for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber += 1) {
            const excelRow = worksheet.getRow(rowNumber);
            const row = {};
            excelRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                const key = headers[colNumber];
                if (!key) return;
                const value = cell.value?.text ?? cell.value?.result ?? cell.value;
                row[key] = value instanceof Date ? value : String(value ?? "").trim();
            });

            const firstName = String(getImportValue(row, ["first_name", "firstname", "nama_depan", "nama", "visitor_name", "name"]) || "").trim();
            const secondName = String(getImportValue(row, ["second_name", "lastname", "last_name", "nama_belakang"]) || "").trim();
            const identityNumber = String(getImportValue(row, ["id_number", "identity_number", "nomor_identitas", "no_identitas", "nik"]) || "").trim();
            const identityType = String(getImportValue(row, ["identity_type", "id_type", "tipe_identitas", "jenis_identitas"]) || "").trim();
            const email = String(getImportValue(row, ["email", "email_address", "email_visitor"]) || "").trim();
            const phone = String(getImportValue(row, ["phone", "phone_number", "whatsapp", "wa", "telephone", "telephone_number"]) || "").trim();
            const host = String(getImportValue(row, ["host", "nama_host"]) || "").trim();
            const startDateValue = normalizeExcelDateValue(getImportValue(row, ["start", "start_date", "tanggal_start", "check_in", "checkin"]));
            const expiryDateValue = normalizeExcelDateValue(getImportValue(row, ["expiry", "expiry_date", "expired", "tanggal_expiry"]));

            const isEmptyRow = !firstName && !secondName && !email && !phone && !host;
            if (isEmptyRow) continue;

            if (!firstName) {
                errors.push({ row: rowNumber, message: "First Name wajib diisi." });
                continue;
            }
            if (!host) {
                errors.push({ row: rowNumber, message: "Host wajib diisi." });
                continue;
            }
            if (!email && !phone) {
                errors.push({ row: rowNumber, message: "Email atau WhatsApp wajib diisi." });
                continue;
            }
            if (isPastDateValue(expiryDateValue)) {
                errors.push({ row: rowNumber, message: "Expiry Date sudah lewat, booking code tidak dibuat." });
                continue;
            }

            const bookingCode = await generateBookingCode();
            const result = await pool.query(
                `INSERT INTO visitor_invitations (
                    booking_code,
                    status,
                    first_name,
                    second_name,
                    identity_number,
                    identity_type,
                    company_name,
                    email_address,
                    phone_number,
                    host,
                    start_date,
                    expiry_date,
                    permission_group,
                    purpose_note,
                    created_by,
                    created_time
                 )
                 VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW())
                 RETURNING *`,
                [
                    bookingCode,
                    firstName,
                    secondName || null,
                    identityNumber || null,
                    identityType || null,
                    String(getImportValue(row, ["company", "company_name", "perusahaan"]) || "").trim() || null,
                    email || null,
                    phone || null,
                    host,
                    startDateValue,
                    expiryDateValue,
                    String(getImportValue(row, ["grouping", "permission_group", "group"]) || "Visitor").trim() || "Visitor",
                    String(getImportValue(row, ["keperluan", "purpose", "purpose_note", "note", "notes"]) || "").trim() || null,
                    getCurrentUsername(req)
                ]
            );
            imported.push(result.rows[0]);
        }

        await saveActivityLog(
            req,
            "IMPORT_VISITOR_INVITATION",
            `Import invitation XLS selesai. Imported ${imported.length}, failed ${errors.length}.`
        );

        if (imported.length > 0) {
            const reqLike = createBackgroundReq(req);
            const importedSnapshot = imported.map(item => ({ ...item }));
            runBackgroundTask("IMPORT INVITATION EMAIL", () => sendImportedInvitationEmails(reqLike, importedSnapshot));
        }

        res.json({
            success: true,
            imported: imported.length,
            failed: errors.length,
            email_processing: imported.length > 0,
            email_total: imported.length,
            errors,
            data: imported
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/self-registration/options", async (req, res) => {
    try {
        const [hosts, groups] = await Promise.all([
            pool.query(`
                SELECT host_name, host_email, host_whatsapp, location, note
                FROM visitor_hosts
                ORDER BY host_name ASC
            `),
            pool.query(`
                SELECT group_name
                FROM permission_groups
                ORDER BY group_name ASC
            `)
        ]);

        res.json({
            success: true,
            data: {
                hosts: hosts.rows,
                permission_groups: groups.rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/self-registration/qr", async (req, res) => {
    try {
        const value = String(req.query.value || req.query.url || "").trim();
        if (!value) return res.status(400).send("QR value wajib diisi.");

        const svg = await QRCode.toString(value, {
            type: "svg",
            errorCorrectionLevel: "H",
            margin: 2,
            width: 260
        });

        res.setHeader("Cache-Control", "no-store");
        res.type("image/svg+xml").send(svg);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

router.post("/api/public/self-registration", upload.fields([{ name: "visitor_photo", maxCount: 1 }, { name: "identity_photo", maxCount: 1 }]), async (req, res) => {
    try {
        const body = req.body || {};
        const uploadedVisitorPhoto = req.files?.["visitor_photo"] ? req.files["visitor_photo"][0].filename : null;
        const uploadedIdentityPhoto = req.files?.["identity_photo"] ? req.files["identity_photo"][0].filename : null;
        const visitorPhoto = uploadedVisitorPhoto || safeUploadFilename(body.existing_visitor_photo || body.visitor_photo);
        const identityPhoto = uploadedIdentityPhoto || safeUploadFilename(body.existing_identity_photo || body.identity_photo);
        const firstName = String(body.first_name || "").trim();
        const secondName = String(body.second_name || "").trim();
        const identityNumber = String(body.identity_number || body.id_number || "").trim();
        const identityType = String(body.identity_type || "E-KTP").trim();
        const email = String(body.email_address || "").trim();
        const phone = String(body.phone_number || body.telephone_number || "").trim();
        const host = String(body.host || "").trim();
        const permissionGroup = String(body.permission_group || "Visitor").trim() || "Visitor";
        const purposeNote = String(body.purpose_note || "").trim();

        if (!firstName) return res.status(400).json({ success: false, message: "Nama depan wajib diisi." });
        if (!identityNumber) return res.status(400).json({ success: false, message: "ID Number wajib diisi." });
        if (!visitorPhoto) return res.status(400).json({ success: false, message: "Foto wajah wajib diambil/upload." });
        if (!identityPhoto) return res.status(400).json({ success: false, message: "Foto identitas wajib diambil/upload." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib dipilih." });
        if (!email && !phone) return res.status(400).json({ success: false, message: "Isi email atau nomor WhatsApp." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const pendingInvitation = await pool.query(
            `SELECT *
             FROM visitor_invitations
             WHERE identity_number = $1
               AND status = 'PENDING'
               AND (expiry_date IS NULL OR expiry_date >= NOW())
             ORDER BY created_time DESC
             LIMIT 1`,
            [identityNumber]
        );

        if (pendingInvitation.rows.length) {
            const invitation = pendingInvitation.rows[0];
            return res.json({
                success: true,
                data: invitation,
                reused: true,
                message: "Booking code aktif untuk ID Number ini sudah ada."
            });
        }

        const bookingCode = await generateBookingCode();
        const startDate = body.start_date || new Date();
        const result = await pool.query(
            `INSERT INTO visitor_invitations (
                booking_code,
                status,
                first_name,
                second_name,
                identity_number,
                identity_type,
                company_name,
                email_address,
                phone_number,
                visitor_photo,
                identity_photo,
                host,
                start_date,
                expiry_date,
                permission_group,
                purpose_note,
                created_by,
                created_time
             )
             VALUES ($1, 'PENDING', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, 'SELF_REGISTRATION', NOW())
             RETURNING *`,
            [
                bookingCode,
                firstName,
                secondName || null,
                identityNumber,
                identityType || null,
                String(body.company_name || "").trim() || null,
                email || null,
                phone || null,
                visitorPhoto,
                identityPhoto,
                host,
                startDate,
                body.expiry_date || null,
                permissionGroup,
                purposeNote || null
            ]
        );

        const invitation = result.rows[0];
        await saveActivityLog(
            req,
            "SELF_REGISTRATION_INVITATION",
            `Self registration booking ${bookingCode} for ${getVisitorDisplayName(invitation)}`
        );
        await createSystemNotification(req, {
            channel: "SELF_REGISTRATION",
            event_type: "INVITATION",
            status: "SUCCESS",
            visitor_name: getVisitorDisplayName(invitation),
            target: email || phone || null,
            title: "Self registration baru",
            message: `Booking code ${bookingCode} dibuat dari form mandiri.`,
            detail: { booking_code: bookingCode, invitation_id: invitation.invitation_id }
        });

        res.json({
            success: true,
            data: invitation,
            message: "Booking code berhasil dibuat."
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/invitations/:id", async (req, res) => {
    try {
        const body = req.body || {};
        const firstName = String(body.first_name || "").trim();
        const identityNumber = String(body.identity_number || body.id_number || "").trim();
        const identityType = String(body.identity_type || "").trim();
        const host = String(body.host || "").trim();
        if (!firstName) return res.status(400).json({ success: false, message: "First name wajib diisi." });
        if (!host) return res.status(400).json({ success: false, message: "Host wajib diisi." });
        if (isPastDateValue(body.expiry_date)) return res.status(400).json({ success: false, message: "Expiry Date sudah lewat." });

        const current = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        if (!current.rows.length) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (!["PENDING", "EXPIRED"].includes(current.rows[0].status)) {
            return res.status(400).json({ success: false, message: "Invitation yang sudah check-in/cancel tidak bisa diedit." });
        }

        const result = await pool.query(
            `UPDATE visitor_invitations
             SET first_name = $1,
                 second_name = $2,
                 identity_number = $3,
                 identity_type = $4,
                 company_name = $5,
                 email_address = $6,
                 phone_number = $7,
                 host = $8,
                 start_date = $9,
                 expiry_date = $10,
                 permission_group = $11,
                 purpose_note = $12,
                 status = 'PENDING',
                 modified_by = $13,
                 modified_time = NOW()
             WHERE invitation_id = $14
             RETURNING *`,
            [
                firstName,
                String(body.second_name || "").trim() || null,
                identityNumber || null,
                identityType || null,
                String(body.company_name || "").trim() || null,
                String(body.email_address || "").trim() || null,
                String(body.phone_number || body.telephone_number || "").trim() || null,
                host,
                body.start_date || null,
                body.expiry_date || null,
                String(body.permission_group || "Visitor").trim() || "Visitor",
                String(body.purpose_note || "").trim() || null,
                getCurrentUsername(req),
                req.params.id
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/:id/send-email", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        const invitation = result.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        await sendBookingInvitationEmail(req, invitation);
        res.json({ success: true, message: "Email booking code berhasil dikirim." });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "INVITATION",
            status: "FAILED",
            title: "Email invitation gagal",
            message: error.message,
            detail: { invitation_id: req.params.id }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/invitations/:id/whatsapp-sent", async (req, res) => {
    try {
        const result = await pool.query(
            "UPDATE visitor_invitations SET sent_whatsapp_time = NOW(), modified_by = $1, modified_time = NOW() WHERE invitation_id = $2 RETURNING *",
            [getCurrentUsername(req), req.params.id]
        );
        const invitation = result.rows[0];
        if (invitation) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "INVITATION",
                status: "OPENED",
                visitor_name: getVisitorDisplayName(invitation),
                target: normalizeWhatsappPhone(invitation.phone_number) || invitation.phone_number || null,
                title: "WhatsApp invitation dibuka",
                message: `WhatsApp booking code ${invitation.booking_code} sudah dibuka. Operator perlu klik kirim.`,
                detail: { booking_code: invitation.booking_code, mode: "MANUAL" }
            });
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/invitations/:id/cancel", async (req, res) => {
    try {
        const reason = String(req.body?.reason || "").trim();
        const result = await pool.query(
            `UPDATE visitor_invitations
             SET status = 'CANCELLED',
                 cancel_reason = $1,
                 cancelled_time = NOW(),
                 modified_by = $2,
                 modified_time = NOW()
             WHERE invitation_id = $3
               AND status IN ('PENDING', 'EXPIRED')
             RETURNING *`,
            [reason || null, getCurrentUsername(req), req.params.id]
        );
        if (!result.rows.length) return res.status(400).json({ success: false, message: "Invitation tidak bisa dicancel." });
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/invitations/:id", async (req, res) => {
    try {
        const current = await pool.query("SELECT * FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        const invitation = current.rows[0];
        if (!invitation) return res.status(404).json({ success: false, message: "Invitation tidak ditemukan." });
        if (!["CANCELLED", "EXPIRED"].includes(invitation.status)) {
            return res.status(400).json({ success: false, message: "Hanya invitation CANCELLED atau EXPIRED yang bisa dihapus." });
        }

        await pool.query("DELETE FROM visitor_invitations WHERE invitation_id = $1", [req.params.id]);
        await saveActivityLog(
            req,
            "DELETE_VISITOR_INVITATION",
            `Delete ${invitation.status.toLowerCase()} invitation ${invitation.booking_code} for ${getVisitorDisplayName(invitation)}`
        );
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/invitations/booking/:code", async (req, res) => {
    try {
        const validation = await validatePendingInvitationByCode(req.params.code);
        if (!validation.ok) return res.status(validation.status).json({ success: false, message: validation.message });
        res.json({ success: true, data: validation.invitation });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/public/self-registration/status/:code", async (req, res) => {
    try {
        const bookingCode = normalizeBookingCode(req.params.code);
        if (!bookingCode) return res.status(400).json({ success: false, message: "Booking code wajib diisi." });

        const result = await pool.query(
            `SELECT booking_code, status, checked_in_time
             FROM visitor_invitations
             WHERE booking_code = $1
             LIMIT 1`,
            [bookingCode]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Booking code tidak ditemukan." });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/hosts", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT host_id, host_name, host_email, host_whatsapp, location, note, description, created_at, modified_at
            FROM visitor_hosts
            ORDER BY host_name ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/hosts", async (req, res) => {
    try {
        const hostName = String(req.body.host_name || "").trim();
        const hostEmail = String(req.body.host_email || "").trim();
        const hostWhatsapp = String(req.body.host_whatsapp || "").trim();
        const location = String(req.body.location || "").trim();
        const note = String(req.body.note || req.body.description || "").trim();

        if (!hostName) {
            return res.status(400).json({ success: false, message: "Nama host wajib diisi" });
        }

        const result = await pool.query(
            `INSERT INTO visitor_hosts (host_name, host_email, host_whatsapp, location, note, description)
             VALUES ($1, $2, $3, $4, $5, $5)
             RETURNING *`,
            [hostName, hostEmail || null, hostWhatsapp || null, location || null, note || null]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Host sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.put("/api/hosts/:id", async (req, res) => {
    try {
        const hostName = String(req.body.host_name || "").trim();
        const hostEmail = String(req.body.host_email || "").trim();
        const hostWhatsapp = String(req.body.host_whatsapp || "").trim();
        const location = String(req.body.location || "").trim();
        const note = String(req.body.note || req.body.description || "").trim();

        if (!hostName) {
            return res.status(400).json({ success: false, message: "Nama host wajib diisi" });
        }

        const result = await pool.query(
            `UPDATE visitor_hosts
             SET host_name = $1,
                 host_email = $2,
                 host_whatsapp = $3,
                 location = $4,
                 note = $5,
                 description = $5,
                 modified_at = NOW()
             WHERE host_id = $6
             RETURNING *`,
            [hostName, hostEmail || null, hostWhatsapp || null, location || null, note || null, req.params.id]
        );

        if (!result.rows.length) {
            return res.status(404).json({ success: false, message: "Host tidak ditemukan" });
        }

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        const message = error.code === "23505" ? "Host sudah ada" : error.message;
        res.status(500).json({ success: false, message });
    }
});

router.get("/api/hosts/:id/visitors", async (req, res) => {
    try {
        const hostResult = await pool.query(
            `SELECT host_id, host_name, host_email, host_whatsapp, location, note, description, created_at, modified_at
             FROM visitor_hosts
             WHERE host_id = $1`,
            [req.params.id]
        );

        if (!hostResult.rows.length) {
            return res.status(404).json({ success: false, message: "Host tidak ditemukan" });
        }

        const host = hostResult.rows[0];
        const visitorsResult = await pool.query(
            `SELECT visitor_id,
                    first_name,
                    second_name,
                    identity_number,
                    company_name,
                    email_address,
                    phone_number,
                    card_number,
                    permission_group,
                    purpose_note,
                    check_in_time,
                    check_out_time,
                    created_by,
                    created_time,
                    modified_by,
                    modified_time
             FROM visitor_registration
             WHERE host = $1
             ORDER BY check_in_time DESC NULLS LAST, visitor_id DESC`,
            [host.host_name]
        );

        const rows = visitorsResult.rows;
        const uniqueVisitors = new Set(
            rows.map(row => String(row.identity_number || "").trim()).filter(Boolean)
        );

        res.json({
            success: true,
            data: {
                host,
                summary: {
                    total_visits: rows.length,
                    active_visits: rows.filter(row => !row.check_out_time).length,
                    checked_out_visits: rows.filter(row => row.check_out_time).length,
                    unique_visitors: uniqueVisitors.size
                },
                visitors: rows
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/host-notification-settings", async (req, res) => {
    try {
        const settings = await getHostNotificationSettings();
        res.json({
            success: true,
            data: {
                enabled: settings?.enabled === true,
                email_subject: settings?.email_subject || "Visitor Check-In - {{visitor_name}}",
                email_body: settings?.email_body || "",
                whatsapp_enabled: settings?.whatsapp_enabled === true,
                whatsapp_body: settings?.whatsapp_body || ""
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/host-notification-settings", async (req, res) => {
    try {
        const emailSubject = String(req.body.email_subject || "Visitor Check-In - {{visitor_name}}").trim();
        const emailBody = String(req.body.email_body || "").trim()
            || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}";
        const whatsappBody = String(req.body.whatsapp_body || "").trim()
            || "Informasi visitor check-in\nNama Visitor: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nKeperluan: {{purpose_note}}\nCard Number: {{card_number}}\nCheck-In: {{check_in_time}}";

        const result = await pool.query(
            `UPDATE host_notification_settings
             SET enabled = $1,
                 email_subject = $2,
                 email_body = $3,
                 whatsapp_enabled = $4,
                 whatsapp_body = $5,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [req.body.enabled === true, emailSubject, emailBody, req.body.whatsapp_enabled === true, whatsappBody]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.delete("/api/hosts/:id", async (req, res) => {
    try {
        await pool.query("DELETE FROM visitor_hosts WHERE host_id = $1", [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/qr-settings", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM qr_settings WHERE setting_id = 1");
        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/qr-settings", async (req, res) => {
    try {
        const digitLength = Math.min(Math.max(parseInt(req.body.digit_length, 10) || 10, 4), 24);
        const previewTitle = String(req.body.preview_title || "Visitor QR Code").trim();
        const previewSubtitle = String(req.body.preview_subtitle || "QR Code dibuat dari Card Number").trim();
        const showCardNumber = req.body.show_card_number !== false;
        const autoEmail = req.body.auto_email === true;
        const autoWhatsapp = req.body.auto_whatsapp === true;
        const autoSms = req.body.auto_sms === true;
        const publicBaseUrl = String(req.body.public_base_url || "").trim();
        const selfRegistrationQrTitle = String(req.body.self_registration_qr_title || "Visitor Self Registration").trim();
        const selfRegistrationQrSubtitle = String(req.body.self_registration_qr_subtitle || "Scan QR untuk isi form kunjungan mandiri").trim();

        const result = await pool.query(
            `UPDATE qr_settings
             SET digit_length = $1,
                 preview_title = $2,
                 preview_subtitle = $3,
                 show_card_number = $4,
                 auto_email = $5,
                 auto_whatsapp = $6,
                 auto_sms = $7,
                 public_base_url = $8,
                 self_registration_qr_title = $9,
                 self_registration_qr_subtitle = $10,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                digitLength,
                previewTitle,
                previewSubtitle,
                showCardNumber,
                autoEmail,
                autoWhatsapp,
                autoSms,
                publicBaseUrl || null,
                selfRegistrationQrTitle || "Visitor Self Registration",
                selfRegistrationQrSubtitle || "Scan QR untuk isi form kunjungan mandiri"
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/card-format-settings", async (req, res) => {
    try {
        const settings = await getCardFormatSettings(pool);
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/card-format-settings", async (req, res) => {
    try {
        const settings = normalizeCardFormatSettings(req.body || {});
        const result = await pool.query(
            `UPDATE card_format_settings
             SET enabled = $1,
                 profile_name = $2,
                 format_mode = $3,
                 input_base = $4,
                 output_base = $5,
                 wiegand_preset = $6,
                 wiegand_total_bits = $7,
                 wiegand_facility_start = $8,
                 wiegand_facility_bits = $9,
                 wiegand_card_start = $10,
                 wiegand_card_bits = $11,
                 wiegand_bit_order = $12,
                 wiegand_output = $13,
                 remove_non_alnum = $14,
                 uppercase = $15,
                 reverse_bytes = $16,
                 slice_mode = $17,
                 slice_length = $18,
                 pad_side = $19,
                 pad_length = $20,
                 pad_char = $21,
                 prefix = $22,
                 suffix = $23,
                 max_length = $24,
                 max_length_keep = $25,
                 apply_to_api = $26,
                 apply_to_qr = $27,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                settings.enabled,
                settings.profile_name,
                settings.format_mode,
                settings.input_base,
                settings.output_base,
                settings.wiegand_preset,
                settings.wiegand_total_bits,
                settings.wiegand_facility_start,
                settings.wiegand_facility_bits,
                settings.wiegand_card_start,
                settings.wiegand_card_bits,
                settings.wiegand_bit_order,
                settings.wiegand_output,
                settings.remove_non_alnum,
                settings.uppercase,
                settings.reverse_bytes,
                settings.slice_mode,
                settings.slice_length,
                settings.pad_side,
                settings.pad_length,
                settings.pad_char,
                settings.prefix,
                settings.suffix,
                settings.max_length,
                settings.max_length_keep,
                settings.apply_to_api,
                settings.apply_to_qr
            ]
        );

        res.json({ success: true, data: normalizeCardFormatSettings(result.rows[0]) });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/card-format-settings/preview", async (req, res) => {
    try {
        const settings = normalizeCardFormatSettings(req.body?.settings || req.body || {});
        const preview = formatCardNumber(req.body?.card_number || req.body?.sample_card || "", settings);
        res.json({ success: true, data: preview });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/card-format-settings/analyze", async (req, res) => {
    try {
        const analysis = analyzeCardFormats(req.body?.samples || []);
        res.json({ success: true, data: analysis });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/smtp-settings", async (req, res) => {
    try {
        const settings = await getSmtpSettings();
        if (!settings) {
            return res.json({ success: true, data: null });
        }

        res.json({
            success: true,
            data: {
                smtp_host: settings.smtp_host || "",
                smtp_port: settings.smtp_port || 587,
                smtp_secure: settings.smtp_secure === true,
                smtp_user: settings.smtp_user || "",
                smtp_pass: settings.smtp_pass || "",
                password_configured: Boolean(settings.smtp_pass),
                from_email: settings.from_email || "",
                from_name: settings.from_name || "Visitor Registration",
                email_subject: settings.email_subject || "Visitor QR Code - {{visitor_name}}",
                email_body: settings.email_body || "",
                invitation_email_subject: settings.invitation_email_subject || "Visitor Invitation - {{booking_code}}",
                invitation_email_body: settings.invitation_email_body || "Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang."
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/smtp-settings", async (req, res) => {
    try {
        const current = await getSmtpSettings();
        const smtpHost = String(req.body.smtp_host || "").trim();
        const smtpPort = parseInt(req.body.smtp_port, 10) || 587;
        const smtpSecure = req.body.smtp_secure === true;
        const smtpUser = String(req.body.smtp_user || "").trim();
        const smtpPass = String(req.body.smtp_pass || "").trim();
        const fromEmail = String(req.body.from_email || "").trim();
        const fromName = String(req.body.from_name || "Visitor Registration").trim();
        const emailSubject = String(req.body.email_subject || "Visitor QR Code - {{visitor_name}}").trim();
        const emailBody = String(req.body.email_body || "").trim();
        const invitationEmailSubject = String(req.body.invitation_email_subject || "Visitor Invitation - {{booking_code}}").trim();
        const invitationEmailBody = String(req.body.invitation_email_body || "").trim();

        const result = await pool.query(
            `UPDATE smtp_settings
             SET smtp_host = $1,
                 smtp_port = $2,
                 smtp_secure = $3,
                 smtp_user = $4,
                 smtp_pass = $5,
                 from_email = $6,
                 from_name = $7,
                 email_subject = $8,
                 email_body = $9,
                 invitation_email_subject = $10,
                 invitation_email_body = $11,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                smtpHost || null,
                smtpPort,
                smtpSecure,
                smtpUser || null,
                smtpPass || current?.smtp_pass || null,
                fromEmail || null,
                fromName || "Visitor Registration",
                emailSubject || "Visitor QR Code - {{visitor_name}}",
                emailBody || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}",
                invitationEmailSubject || "Visitor Invitation - {{booking_code}}",
                invitationEmailBody || "Visitor Invitation\nBooking Code: {{booking_code}}\nNama: {{visitor_name}}\nCompany: {{company_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nKeperluan: {{purpose_note}}\n\nTunjukkan booking code ini ke operator saat datang."
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/smtp-settings/test", async (req, res) => {
    try {
        const testEmail = String(req.body.test_email || "").trim();
        if (!testEmail) {
            return res.status(400).json({ success: false, message: "Email tujuan test wajib diisi." });
        }

        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: testEmail,
            subject: "SMTP Test - Visitor Registration",
            text: "SMTP berhasil digunakan untuk mengirim email dari Visitor Registration Portal."
        });

        res.json({ success: true, message: "Test email berhasil dikirim." });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/send-qr-email", async (req, res) => {
    try {
        const settings = await getSmtpSettings();
        const transporter = createSmtpTransport(settings);
        const {
            to_email,
            visitor_name,
            host,
            start,
            expiry,
            card_number,
            share_url,
            image_base64
        } = req.body;

        const targetEmail = String(to_email || "").trim();
        if (!targetEmail) {
            return res.status(400).json({ success: false, message: "Email visitor belum diisi." });
        }

        if (!image_base64) {
            return res.status(400).json({ success: false, message: "Gambar QR belum tersedia." });
        }

        const templateData = {
            visitor_name: visitor_name || "Visitor",
            host: host || "-",
            start: start || "-",
            expiry: expiry || "-",
            card_number: card_number || "-",
            share_url: share_url || "-"
        };

        const subject = buildTemplate(settings.email_subject, templateData);
        const body = buildTemplate(settings.email_body, templateData);
        const imageBuffer = Buffer.from(String(image_base64).replace(/^data:image\/png;base64,/, ""), "base64");

        await transporter.sendMail({
            from: `"${settings.from_name || "Visitor Registration"}" <${settings.from_email || settings.smtp_user}>`,
            to: targetEmail,
            subject,
            text: body,
            attachments: [
                {
                    filename: `QR_${String(card_number || "visitor").replace(/[^a-z0-9_-]+/gi, "_")}.png`,
                    content: imageBuffer,
                    contentType: "image/png"
                }
            ]
        });

        await saveActivityLog(
            req,
            "SEND_QR_EMAIL",
            `Send QR email to ${targetEmail} for ${visitor_name || "Visitor"} (Card ${card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_name: visitor_name || "Visitor",
            target: targetEmail,
            title: "Email QR ke Visitor berhasil",
            message: `QR Code visitor berhasil dikirim ke ${targetEmail}.`,
            detail: { card_number: card_number || null, share_url: share_url || null }
        });

        res.json({ success: true, message: "Email QR berhasil dikirim." });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "EMAIL_VISITOR",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_name: req.body?.visitor_name || "Visitor",
            target: req.body?.to_email || null,
            title: "Email QR ke Visitor gagal",
            message: error.message,
            detail: { card_number: req.body?.card_number || null }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.get("/api/whatsapp-settings", async (req, res) => {
    try {
        const settings = await getWhatsappSettings();
        res.json({
            success: true,
            data: {
                send_mode: settings?.send_mode || "manual",
                provider: settings?.provider || "meta",
                phone_number_id: settings?.phone_number_id || "",
                api_version: settings?.api_version || "v20.0",
                token_configured: Boolean(settings?.access_token),
                message_template: settings?.message_template || ""
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/whatsapp-settings", async (req, res) => {
    try {
        const current = await getWhatsappSettings();
        const sendMode = ["manual", "api"].includes(req.body.send_mode) ? req.body.send_mode : "manual";
        const provider = String(req.body.provider || "meta").trim() || "meta";
        const accessToken = String(req.body.access_token || "").trim();
        const phoneNumberId = String(req.body.phone_number_id || "").trim();
        const apiVersion = String(req.body.api_version || "v20.0").trim() || "v20.0";
        const messageTemplate = String(req.body.message_template || "").trim()
            || "Visitor QR Code\nNama: {{visitor_name}}\nHost: {{host}}\nStart: {{start}}\nExpiry: {{expiry}}\nCard Number: {{card_number}}\nLink QR: {{share_url}}";

        const result = await pool.query(
            `UPDATE whatsapp_settings
             SET send_mode = $1,
                 provider = $2,
                 access_token = $3,
                 phone_number_id = $4,
                 api_version = $5,
                 message_template = $6,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                sendMode,
                provider,
                accessToken || current?.access_token || null,
                phoneNumberId || null,
                apiVersion,
                messageTemplate
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/send-qr-whatsapp", async (req, res) => {
    try {
        const settings = await getWhatsappSettings();

        if (!settings || settings.send_mode !== "api") {
            return res.status(400).json({ success: false, message: "Mode WhatsApp API belum aktif." });
        }

        if (settings.provider !== "meta") {
            return res.status(400).json({ success: false, message: "Provider WhatsApp belum didukung. Gunakan Meta Cloud API." });
        }

        if (!settings.access_token || !settings.phone_number_id) {
            return res.status(400).json({ success: false, message: "Access token dan Phone Number ID wajib diisi." });
        }

        const {
            to_phone,
            visitor_name,
            host,
            start,
            expiry,
            card_number,
            share_url,
            image_base64
        } = req.body;

        const targetPhone = normalizeWhatsappPhone(to_phone);
        if (!targetPhone) {
            return res.status(400).json({ success: false, message: "Nomor WhatsApp visitor belum diisi." });
        }

        if (!image_base64) {
            return res.status(400).json({ success: false, message: "Gambar QR belum tersedia." });
        }

        const templateData = {
            visitor_name: visitor_name || "Visitor",
            host: host || "-",
            start: start || "-",
            expiry: expiry || "-",
            card_number: card_number || "-",
            share_url: share_url || "-"
        };
        const caption = buildTemplate(settings.message_template, templateData);
        const apiVersion = settings.api_version || "v20.0";
        const baseUrl = `https://graph.facebook.com/${apiVersion}/${settings.phone_number_id}`;
        const imageBuffer = Buffer.from(String(image_base64).replace(/^data:image\/png;base64,/, ""), "base64");

        const uploadForm = new FormData();
        uploadForm.append("messaging_product", "whatsapp");
        uploadForm.append("type", "image/png");
        uploadForm.append("file", new Blob([imageBuffer], { type: "image/png" }), `QR_${card_number || "visitor"}.png`);

        const uploadResponse = await fetch(`${baseUrl}/media`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${settings.access_token}`
            },
            body: uploadForm
        });
        const uploadResult = await uploadResponse.json();

        if (!uploadResponse.ok || !uploadResult.id) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_name: visitor_name || "Visitor",
                target: targetPhone,
                title: "WhatsApp QR gagal",
                message: uploadResult.error?.message || "Upload media WhatsApp gagal.",
                detail: { provider: "META", card_number: card_number || null, stage: "media_upload" }
            });
            return res.status(500).json({
                success: false,
                message: uploadResult.error?.message || "Upload media WhatsApp gagal."
            });
        }

        const sendResponse = await fetch(`${baseUrl}/messages`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${settings.access_token}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                messaging_product: "whatsapp",
                to: targetPhone,
                type: "image",
                image: {
                    id: uploadResult.id,
                    caption
                }
            })
        });
        const sendResult = await sendResponse.json();

        if (!sendResponse.ok) {
            await createSystemNotification(req, {
                channel: "WHATSAPP",
                event_type: "QR_SHARE",
                status: "FAILED",
                visitor_name: visitor_name || "Visitor",
                target: targetPhone,
                title: "WhatsApp QR gagal",
                message: sendResult.error?.message || "Kirim WhatsApp API gagal.",
                detail: { provider: "META", card_number: card_number || null, stage: "message_send" }
            });
            return res.status(500).json({
                success: false,
                message: sendResult.error?.message || "Kirim WhatsApp API gagal."
            });
        }

        await saveActivityLog(
            req,
            "SEND_QR_WHATSAPP",
            `Send QR WhatsApp API to ${targetPhone} for ${visitor_name || "Visitor"} (Card ${card_number || "-"})`
        );
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "SUCCESS",
            visitor_name: visitor_name || "Visitor",
            target: targetPhone,
            title: "WhatsApp QR berhasil",
            message: `QR Code visitor berhasil dikirim via WhatsApp Business API ke ${targetPhone}.`,
            detail: { provider: "META", card_number: card_number || null, response: sendResult }
        });

        res.json({ success: true, message: "WhatsApp QR berhasil dikirim via API.", data: sendResult });
    } catch (error) {
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: "QR_SHARE",
            status: "FAILED",
            visitor_name: req.body?.visitor_name || "Visitor",
            target: req.body?.to_phone || null,
            title: "WhatsApp QR gagal",
            message: error.message,
            detail: { provider: "META", card_number: req.body?.card_number || null }
        });
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post("/api/whatsapp-opened", async (req, res) => {
    try {
        const targetPhone = normalizeWhatsappPhone(req.body?.to_phone);
        await createSystemNotification(req, {
            channel: "WHATSAPP",
            event_type: req.body?.event_type || "QR_SHARE",
            status: "OPENED",
            visitor_id: req.body?.visitor_id || null,
            visitor_name: req.body?.visitor_name || "Visitor",
            target: targetPhone || req.body?.to_phone || null,
            title: "WhatsApp dibuka",
            message: targetPhone
                ? `WhatsApp dibuka ke nomor ${targetPhone}. Operator perlu klik kirim.`
                : "WhatsApp dibuka tanpa nomor tujuan. Operator perlu memilih nomor dan klik kirim.",
            detail: {
                mode: "MANUAL",
                card_number: req.body?.card_number || null,
                booking_code: req.body?.booking_code || null
            }
        });
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/auto-checkout-settings", async (req, res) => {
    try {
        const settings = await getAutoCheckoutSettings();
        res.json({
            success: true,
            data: {
                ...settings,
                schedule_date: normalizeDate(settings.schedule_date),
                schedule_time: normalizeTime(settings.schedule_time),
                schedule_type: normalizeScheduleType(settings.schedule_type)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.put("/api/auto-checkout-settings", async (req, res) => {
    try {
        const body = req.body || {};
        const result = await pool.query(
            `UPDATE auto_checkout_settings
             SET enabled = $1,
                 schedule_date = $2,
                 schedule_time = $3,
                 schedule_type = $4,
                 updated_at = NOW()
             WHERE setting_id = 1
             RETURNING *`,
            [
                body.enabled === true,
                normalizeDate(body.schedule_date),
                normalizeTime(body.schedule_time),
                normalizeScheduleType(body.schedule_type)
            ]
        );

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.post("/api/auto-checkout/run-now", async (req, res) => {
    try {
        const result = await runAutoCheckout(getCurrentUsername(req), req.ip);
        res.json({ success: true, data: result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// Update Check-In / Check-Out
router.post("/visitors/update-status", async (req, res) => {
    try {

        const { id, type } = req.body;

        const column =
            (type === 'checkin')
            ? 'check_in_time'
            : 'check_out_time';

        const result = await pool.query(
            `UPDATE visitor_registration
             SET ${column} = NOW(),
                 modified_by = $2,
                 modified_time = NOW()
             WHERE visitor_id = $1
             RETURNING *`,
            [id, getCurrentUsername(req)]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: "Visitor not found" });
        }

        await saveActivityLog(
            req,
            type === "checkin" ? "CHECK_IN_VISITOR" : "CHECK_OUT_VISITOR",
            `${type === "checkin" ? "Check in" : "Check out"} visitor ${getVisitorDisplayName(result.rows[0])} (Visitor ID ${result.rows[0].visitor_id}, Card ${result.rows[0].card_number || "-"})`
        );
        if (type === "checkin") {
            runCheckinFollowupBackground(req, result.rows[0]);
            return res.json({
                success: true,
                api_results: [],
                background_processing: true
            });
        }

        let apiResults = [];
        if (await isVisitorRegistrationApiMode()) {
            try {
                apiResults = await executeActiveThirdPartyConfigs(req, "CHECKOUT", result.rows[0]);
            } catch (apiError) {
                console.log("THIRD PARTY STATUS API ERROR:", apiError.message);
            }
        }

        if (shouldReleaseInnerrangeSlot(apiResults)) {
            await releaseThirdPartyUserSlot(result.rows[0].third_party_user_id, result.rows[0].visitor_id);
        }

        runBackgroundTask(`DEVICE CHECKOUT VISITOR ${result.rows[0].visitor_id || "-"}`, () =>
            runDeviceSyncBackground(createBackgroundReq(req), result.rows[0], "CHECKOUT")
        );

        res.json({
            success: true,
            api_results: apiResults
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});

// ACTIVE VISITORS ONLY
router.get("/visitors", async (req, res) => {
    try {

        const result = await pool.query(`

            SELECT *
            FROM visitor_registration
            WHERE check_out_time IS NULL
            ORDER BY check_in_time ASC, visitor_id ASC

        `);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});


// ALL VISITOR LOGS
router.get("/api/visitor-log-filter-options", async (req, res) => {
    try {
        const [operators, groups, hosts] = await Promise.all([
            pool.query(`
                SELECT DISTINCT created_by
                FROM visitor_registration
                WHERE created_by IS NOT NULL
                  AND TRIM(created_by) <> ''
                ORDER BY created_by ASC
            `),
            pool.query(`
                SELECT group_name
                FROM permission_groups
                ORDER BY group_name ASC
            `),
            pool.query(`
                SELECT host_name
                FROM visitor_hosts
                ORDER BY host_name ASC
            `)
        ]);

        res.json({
            success: true,
            data: {
                operators: operators.rows.map(row => row.created_by),
                groups: groups.rows.map(row => row.group_name),
                hosts: hosts.rows.map(row => row.host_name)
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-logs", async (req, res) => {
    try {
        const {
            created_by,
            visitor_name,
            permission_group,
            host,
            check_in_from,
            check_in_to,
            check_out_from,
            check_out_to
        } = req.query;

        const filters = ["check_out_time IS NOT NULL"];
        const params = [];

        const addParam = (value) => {
            params.push(value);
            return `$${params.length}`;
        };

        if (created_by) {
            filters.push(`created_by = ${addParam(created_by)}`);
        }

        if (visitor_name) {
            filters.push(`CONCAT_WS(' ', first_name, second_name) ILIKE ${addParam(`%${visitor_name}%`)}`);
        }

        if (permission_group) {
            filters.push(`permission_group = ${addParam(permission_group)}`);
        }

        if (host) {
            filters.push(`host = ${addParam(host)}`);
        }

        if (check_in_from) {
            filters.push(`check_in_time >= ${addParam(check_in_from)}::timestamp`);
        }

        if (check_in_to) {
            filters.push(`check_in_time <= ${addParam(check_in_to)}::timestamp`);
        }

        if (check_out_from) {
            filters.push(`check_out_time >= ${addParam(check_out_from)}::timestamp`);
        }

        if (check_out_to) {
            filters.push(`check_out_time <= ${addParam(check_out_to)}::timestamp`);
        }

        const result = await pool.query(`

            SELECT *
            FROM visitor_registration
            WHERE ${filters.join(" AND ")}
            ORDER BY check_in_time ASC, visitor_id ASC

        `, params);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            error: error.message
        });

    }
});

router.get("/api/visitor-stats", async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT
                COUNT(*) FILTER (WHERE check_in_time::date = CURRENT_DATE) AS check_in_today,
                COUNT(*) FILTER (WHERE check_out_time::date = CURRENT_DATE) AS check_out_today,
                COUNT(*) FILTER (WHERE check_in_time::date = CURRENT_DATE) AS visitors_today,
                COUNT(*) FILTER (WHERE check_out_time IS NULL) AS active_visitors
            FROM visitor_registration
        `);

        res.json({ success: true, data: result.rows[0] });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

router.get("/api/visitor-analytics", async (req, res) => {
    try {
        const mode = ["daily", "monthly", "yearly"].includes(req.query.mode) ? req.query.mode : "daily";
        const dateExpression =
            mode === "yearly"
                ? "TO_CHAR(check_in_time, 'YYYY')"
                : mode === "monthly"
                    ? "TO_CHAR(check_in_time, 'YYYY-MM')"
                    : "TO_CHAR(check_in_time, 'YYYY-MM-DD')";

        const result = await pool.query(`
            SELECT ${dateExpression} AS period,
                   COUNT(*) AS check_in_count,
                   COUNT(*) FILTER (WHERE check_out_time IS NOT NULL) AS check_out_count
            FROM visitor_registration
            WHERE check_in_time IS NOT NULL
            GROUP BY period
            ORDER BY period ASC
        `);

        res.json({ success: true, data: result.rows });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// (Route sync-acs, sync-lift, dan export-excel Anda tetap di bawah sini...)
router.post("/sync-acs/:id", async (req, res) => { /* ... */ });
router.post("/sync-lift/:id", async (req, res) => { /* ... */ });
router.get("/export-excel", async (req, res) => { /* ... */ });
// 1. Route untuk daftar semua port COM yang aktif
router.get("/card-reader/list-ports", async (req, res) => {
    try {
        const ports = await SerialPort.list();
        // Mengembalikan daftar path port saja, contoh: ["COM1", "COM3"]
        res.json(ports.map(p => p.path));
    } catch (error) {
        res.status(500).json({ error: "Gagal mendeteksi port" });
    }
});

// 2. Route untuk konek ke port spesifik
// ... (kode sebelumnya) ...

// 2. Route untuk konek ke port spesifik
router.post("/card-reader/connect", (req, res) => {
    const { port, baudRate } = req.body;
    if (!port) return res.status(400).json({ success: false, message: "Port tidak dipilih" });

    try {
        // TANGANI KONEKSI LAMA
        if (activePort && activePort.isOpen) {
            activePort.close();
            activePort = null;
        }

        const selectedBaud = parseInt(baudRate) || 9600;
        
        // INISIALISASI BARU
        activePort = new SerialPort({ path: port, baudRate: selectedBaud });
        const parser = activePort.pipe(new ReadlineParser({ delimiter: '\r\n' }));

        activePort.on('open', () => {
            console.log("Koneksi berhasil ke:", port);
            res.json({ success: true, message: "Terhubung ke " + port });
        });

        parser.on('data', (data) => {
            lastCard = data.trim();
        });

        // TANGANI ERROR DALAM KONEKSI
        activePort.on('error', (err) => {
            console.error("Serial Error:", err);
            activePort = null; 
        });

        // TANGANI PENUTUPAN PORT
        activePort.on('close', () => {
            console.log("Port tertutup");
            activePort = null;
        });

    } catch (error) {
        console.error("Gagal inisialisasi:", error);
        activePort = null;
        res.status(500).json({ success: false, message: error.message });
    }
});

// Route untuk frontend mengambil data kartu (Polling)
router.get("/card-reader/data", (req, res) => {
    if (lastCard !== "") {
        res.json({ success: true, card: lastCard });
        lastCard = ""; 
    } else {
        res.json({ success: false });
    }
});


module.exports = router;
module.exports.ensureVisitorSchema = ensureVisitorSchema;
module.exports.startAutoCheckoutScheduler = startAutoCheckoutScheduler;
